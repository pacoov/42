# Le Fil d'Ariane — règles pour Claude Code

Site éducatif sur la mythologie grecque pour les 15–25 ans. Cahier des charges : `docs/PROJECT_BLUEPRINT.md` (v1.2, à lire en entier avant toute tâche importante).

## Répartition du travail (important)

Deux équipes travaillent sur ce dépôt :

| Qui | Possède | Ne touche pas |
|---|---|---|
| **Équipe contenu** (Claude sur claude.ai + agents rédacteur/vérificateur + Enzo) | `content/entities/**`, `content/i18n/*/entities/**`, `content/planned.yaml`, `content/media/registry.yaml`, `public/media/**`, `docs/editorial/**` | le code |
| **Claude Code (toi)** | tout le reste : `app/`, `components/`, `lib/`, `styles`, `scripts/`, tests, CI, `content/i18n/*/ui.json` (textes d'interface) | les **faits** du contenu |

- Tu ne modifies **jamais** un fait, une source, une date ou une citation dans `content/`. Ce contenu a été vérifié ligne à ligne contre les textes antiques.
- Tu peux corriger un problème **de format** dans `content/` (YAML invalide, champ renommé par une évolution de schéma) et tu le signales dans le message de commit.
- Si tu as besoin d'un nouveau type de contenu (mythes, quiz, comparaisons pop culture, mots…) : définis son schéma Zod dans `lib/content/schema.ts`, documente le format dans `docs/editorial/FORMATS.md` avec un exemple complet, et ajoute **2 exemples marqués `review: { status: draft }`** (jamais publiés). L'équipe contenu produira les vraies données dans ce format.

## Commandes

```bash
npm run content:check   # valide tout le contenu (lancé automatiquement avant build)
npm test                # vitest
npm run typecheck       # next typegen + tsc
npm run lint
npm run build
```
Une tâche n'est terminée que si ces 5 commandes passent.

## Next.js 16 : attention

Cette version de Next.js a des API différentes de tes données d'entraînement. Avant d'utiliser une API de Next, lis la doc embarquée dans `node_modules/next/dist/docs/` (voir `AGENTS.md`). Choix déjà faits :
- site **100 % statique** : `generateStaticParams` + `dynamicParams = false`, **Cache Components désactivé** ;
- i18n native : `app/[lang]`, dictionnaires `content/i18n/<lang>/ui.json`, segments d'URL localisés dans `lib/i18n` (`SECTION_SEGMENTS`) ;
- polices auto-hébergées via `next/font/local` (Fraunces, Inter latin + grec, Cinzel).

## Règles de conception (extraits du blueprint)

- **Design system** : tokens dans `app/globals.css` (§17). Pas de couleur ni de taille en dur hors tokens. Thèmes clair et sombre obligatoires.
- **Accessibilité WCAG 2.2 AA** (§20) : clavier partout, focus visible, `prefers-reduced-motion`, jamais l'information par la couleur seule, alternative textuelle pour toute visualisation.
- **Mobile d'abord** (§19), aucun défilement horizontal à 320 px.
- **Performance** (§36) : JS initial ≤ 120 Ko par fiche, animations `transform`/`opacity` uniquement, îlots client minimaux.
- **Aucun texte en dur** dans les composants : tout passe par `ui.json`.
- **Couches éditoriales** 🏺 source antique / 🔍 interprétation / 🎬 adaptation moderne : toujours distinguées visuellement (composant `LayerBadge`).
- **Le fil d'or** est la signature visuelle ; une seule animation orchestrée par page, pas d'effets éparpillés.
- Un personnage cité mais non publié s'affiche **sans lien** (jamais de lien mort) : voir `EntityLink`.

## Git

- Commits en français, au présent, une intention par commit.
- Ne jamais pousser de `node_modules`, `.next` ou de secrets.
