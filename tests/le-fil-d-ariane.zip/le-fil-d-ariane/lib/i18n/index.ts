import "server-only";
import { LOCALES, type Category, type Locale } from "@/lib/content/schema";
import fr from "@/content/i18n/fr/ui.json";

export type Dictionary = typeof fr;

const dictionaries: Record<Locale, Dictionary> = { fr };

export const hasLocale = (value: string): value is Locale => (LOCALES as readonly string[]).includes(value);

export function getDictionary(locale: Locale): Dictionary {
  return dictionaries[locale];
}

/** Segment d'URL de chaque catégorie, par langue (slugs localisés, blueprint §12.2). */
export const SECTION_SEGMENTS: Record<Locale, Record<Category, string>> = {
  fr: {
    gods: "dieux",
    titans: "titans",
    heroes: "heros",
    creatures: "creatures",
    places: "lieux",
    objects: "objets",
  },
};

export function categoryFromSegment(locale: Locale, segment: string): Category | undefined {
  const entry = Object.entries(SECTION_SEGMENTS[locale]).find(([, s]) => s === segment);
  return entry?.[0] as Category | undefined;
}

export function sectionHref(locale: Locale, category: Category): string {
  return `/${locale}/${SECTION_SEGMENTS[locale][category]}`;
}

export function entityHref(locale: Locale, category: Category, slug: string): string {
  return `${sectionHref(locale, category)}/${slug}`;
}
