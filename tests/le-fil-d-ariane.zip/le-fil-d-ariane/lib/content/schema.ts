import { z } from "zod";

/**
 * Schémas du contenu du Fil d'Ariane (blueprint §24).
 * Ces schémas sont le contrat entre la chaîne éditoriale (agents rédacteur
 * et vérificateur) et le site : un fichier qui ne les respecte pas fait
 * échouer le build.
 */

export const LOCALES = ["fr"] as const; // prêtes ensuite : en, es, de, it, pt
export type Locale = (typeof LOCALES)[number];
export const DEFAULT_LOCALE: Locale = "fr";

/** Identifiant stable : anglais, kebab-case. */
export const EntityId = z
  .string()
  .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "id en kebab-case attendu (ex. « mount-olympus »)");

export const ENTITY_TYPES = [
  "primordial",
  "titan",
  "deity",
  "minor-deity",
  "hero",
  "mortal",
  "creature",
  "people",
  "place",
  "object",
] as const;

export const CATEGORIES = ["gods", "titans", "heroes", "creatures", "places", "objects"] as const;
export type Category = (typeof CATEGORIES)[number];

export const ERAS = ["origins", "titans", "olympians", "heroes", "trojan-war", "returns"] as const;

/** Types de relation autorisés (sens : from → to). */
export const RELATION_TYPES = [
  "parent-of",
  "spouse-of",
  "sibling-of",
  "lover-of",
  "enemy-of",
  "defeated",
  "punished",
  "ally-of",
  "helped",
  "mentor-of",
  "created",
  "owns",
  "lives-in",
] as const;
export type RelationType = (typeof RELATION_TYPES)[number];

/** Famille de relation, utilisée pour la couleur ET le style de trait (§15.14). */
export const RELATION_FAMILY: Record<RelationType, "family" | "love" | "conflict" | "alliance" | "other"> = {
  "parent-of": "family",
  "spouse-of": "family",
  "sibling-of": "family",
  "lover-of": "love",
  "enemy-of": "conflict",
  defeated: "conflict",
  punished: "conflict",
  "ally-of": "alliance",
  helped: "alliance",
  "mentor-of": "alliance",
  created: "other",
  owns: "other",
  "lives-in": "other",
};

export const REVIEW_STATUSES = ["draft", "review", "verified-ai", "verified"] as const;
export type ReviewStatus = (typeof REVIEW_STATUSES)[number];

export const SourceRef = z.object({
  source: z.string().min(3),
  locus: z.string().optional(),
  url: z.url().optional(),
});
export type SourceRef = z.infer<typeof SourceRef>;

export const Relation = z.object({
  from: EntityId,
  to: EntityId,
  type: z.enum(RELATION_TYPES),
  certainty: z.enum(["canonical", "variant"]),
  source: z.string().min(3, "chaque relation doit citer sa source"),
});
export type Relation = z.infer<typeof Relation>;

export const MediaRef = z.object({
  hero: z.string().optional(),
  gallery: z.array(z.string()).default([]),
  pictogram: z.string().optional(),
});

export const Entity = z
  .object({
    id: EntityId,
    type: z.enum(ENTITY_TYPES),
    category: z.enum(CATEGORIES),
    names: z.object({
      greek: z.string().optional(),
      transliteration: z.string().optional(),
      roman: z.string().optional(),
      aliases: z.array(z.string()).default([]),
    }),
    /** Genre grammatical du personnage, pour accorder les libellés (« fils de », « mère de »). */
    gender: z.enum(["f", "m", "n"]).optional(),
    era: z.enum(ERAS).optional(),
    importance: z.union([z.literal(1), z.literal(2), z.literal(3)]),
    creature: z
      .object({
        kind: z.enum(["monster", "mythic-animal", "hybrid", "people"]),
        danger: z.union([z.literal(1), z.literal(2), z.literal(3)]),
        habitat: z.array(z.enum(["sea", "land", "underworld", "sky"])).min(1),
        defeatedBy: z.array(EntityId).default([]),
      })
      .optional(),
    /** Spécialisation des divinités. Les valeurs sont des clés neutres
     * (traduites dans ui.json) ou des ids d'entités : jamais de texte localisé. */
    deity: z
      .object({
        domains: z.array(EntityId).min(1),
        symbols: z.array(EntityId).default([]),
        olympian: z.boolean(),
        residence: EntityId.optional(),
        epithets: z
          .array(z.object({ greek: z.string(), transliteration: z.string(), source: z.string().min(3) }))
          .default([]),
      })
      .optional(),
    relations: z.array(Relation).default([]),
    sources: z.array(SourceRef).min(1, "au moins une source est obligatoire"),
    media: MediaRef.default({ gallery: [] }),
    review: z.object({
      status: z.enum(REVIEW_STATUSES),
      at: z.string().optional(),
      note: z.string().optional(),
    }),
  })
  .superRefine((e, ctx) => {
    if ((e.type === "creature" || e.type === "people") && !e.creature) {
      ctx.addIssue({ code: "custom", message: "une créature doit avoir un bloc `creature`" });
    }
  });
export type Entity = z.infer<typeof Entity>;

/** En-tête du fichier MDX localisé. */
export const EntityText = z.object({
  name: z.string().min(1),
  role: z.string().min(3).max(90),
  hook: z.string().min(10).max(220),
  slug: z
    .string()
    .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/)
    .optional(),
});
export type EntityText = z.infer<typeof EntityText>;

/** Entités annoncées mais pas encore rédigées : on peut les citer, elles s'affichent sans lien. */
export const PlannedEntity = z.object({
  id: EntityId,
  category: z.enum(CATEGORIES).or(z.enum(["myths", "concepts"])),
  name: z.string().min(1),
});
export type PlannedEntity = z.infer<typeof PlannedEntity>;

export const MediaAsset = z.object({
  id: z.string().min(1),
  file: z.string().regex(/^\/media\//, "les médias vivent sous /public/media/"),
  width: z.number().int().positive(),
  height: z.number().int().positive(),
  alt: z.string().min(10, "texte alternatif obligatoire"),
  caption: z.string().min(3),
  credit: z.string().min(3),
  license: z.enum(["CC0", "PD", "CC-BY-4.0", "CC-BY-SA-4.0", "original"]),
  sourceUrl: z.url(),
  verifiedAt: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  approvedInGallery: z.literal(true, "un média doit être validé dans la galerie avant intégration"),
});
export type MediaAsset = z.infer<typeof MediaAsset>;
