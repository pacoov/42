import fs from "node:fs";
import path from "node:path";
import { parse as parseYaml } from "yaml";
import { z } from "zod";
import {
  Entity,
  EntityText,
  MediaAsset,
  PlannedEntity,
  type Category,
  type Locale,
  type Relation,
  type ReviewStatus,
  LOCALES,
} from "./schema";

/**
 * Chargement et validation du contenu (blueprint §23.3).
 *
 * Tout ce qui est incohérent lève une ContentError avec la liste complète
 * des problèmes : le build échoue et l'erreur dit quoi corriger, où.
 * Ce module n'importe rien de Next.js : il tourne aussi dans les tests
 * et dans `npm run content:check`.
 */

/** Statuts publiés. `verified-ai` reste publiable pendant la phase de
 * construction, avec un bandeau « relecture humaine en cours ».
 * À restreindre à ["verified"] avant le lancement public (blueprint §22.5). */
export const PUBLISHABLE: readonly ReviewStatus[] = ["verified-ai", "verified"];

export class ContentError extends Error {
  constructor(public readonly problems: string[]) {
    super(`Contenu invalide (${problems.length} problème${problems.length > 1 ? "s" : ""}) :\n- ${problems.join("\n- ")}`);
    this.name = "ContentError";
  }
}

export type LocalizedEntity = Entity & {
  slug: string;
  text: Record<Locale, { meta: EntityText; body: string } | undefined>;
  file: string;
};

export type ContentGraph = {
  entities: Map<string, LocalizedEntity>;
  planned: Map<string, PlannedEntity>;
  relations: Relation[];
  media: Map<string, MediaAsset>;
};

const FRONTMATTER = /^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/;
const E_TAG = /<E\s+id="([^"]+)"/g;

export function slugify(name: string): string {
  return name
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/['’]/g, "-")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function walk(dir: string, ext: string): string[] {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((d) => {
    const p = path.join(dir, d.name);
    if (d.isDirectory()) return walk(p, ext);
    return d.name.endsWith(ext) ? [p] : [];
  });
}

function zodProblems(file: string, err: z.ZodError): string[] {
  return err.issues.map((i) => `${file} › ${i.path.join(".") || "(racine)"} : ${i.message}`);
}

export function loadContent(root: string): ContentGraph {
  const problems: string[] = [];
  const rel = (p: string) => path.relative(root, p);

  // 1. Entités annoncées
  const planned = new Map<string, PlannedEntity>();
  const plannedFile = path.join(root, "planned.yaml");
  if (fs.existsSync(plannedFile)) {
    const parsed = z.array(PlannedEntity).safeParse(parseYaml(fs.readFileSync(plannedFile, "utf8")));
    if (!parsed.success) problems.push(...zodProblems("planned.yaml", parsed.error));
    else for (const p of parsed.data) planned.set(p.id, p);
  }

  // 2. Médias
  const media = new Map<string, MediaAsset>();
  const mediaFile = path.join(root, "media", "registry.yaml");
  if (fs.existsSync(mediaFile)) {
    const parsed = z.array(MediaAsset).safeParse(parseYaml(fs.readFileSync(mediaFile, "utf8")));
    if (!parsed.success) problems.push(...zodProblems("media/registry.yaml", parsed.error));
    else for (const m of parsed.data) media.set(m.id, m);
  }

  // 3. Entités + textes localisés
  const entities = new Map<string, LocalizedEntity>();
  for (const file of walk(path.join(root, "entities"), ".yaml")) {
    let raw: unknown;
    try {
      raw = parseYaml(fs.readFileSync(file, "utf8"));
    } catch (e) {
      problems.push(`${rel(file)} : YAML illisible (${(e as Error).message.split("\n")[0]})`);
      continue;
    }
    const parsed = Entity.safeParse(raw);
    if (!parsed.success) {
      problems.push(...zodProblems(rel(file), parsed.error));
      continue;
    }
    const e = parsed.data;
    if (path.basename(file, ".yaml") !== e.id) problems.push(`${rel(file)} : le nom du fichier doit être « ${e.id}.yaml »`);
    if (entities.has(e.id)) problems.push(`${rel(file)} : id « ${e.id} » déjà utilisé par ${entities.get(e.id)!.file}`);
    if (planned.has(e.id)) problems.push(`planned.yaml : « ${e.id} » est rédigé, retire-le de la liste des entités annoncées`);

    const text = {} as LocalizedEntity["text"];
    for (const locale of LOCALES) {
      const mdx = path.join(root, "i18n", locale, "entities", e.category, `${e.id}.mdx`);
      if (!fs.existsSync(mdx)) {
        text[locale] = undefined;
        continue;
      }
      const m = fs.readFileSync(mdx, "utf8").match(FRONTMATTER);
      if (!m) {
        problems.push(`${rel(mdx)} : en-tête « --- » manquant`);
        continue;
      }
      let rawMeta: unknown;
      try {
        rawMeta = parseYaml(m[1]);
      } catch (err) {
        problems.push(`${rel(mdx)} : en-tête YAML illisible (${(err as Error).message.split("\n")[0]}). Astuce : mettre les valeurs contenant « : » entre guillemets.`);
        continue;
      }
      const meta = EntityText.safeParse(rawMeta);
      if (!meta.success) {
        problems.push(...zodProblems(rel(mdx), meta.error));
        continue;
      }
      text[locale] = { meta: meta.data, body: m[2] };
    }
    const fr = text.fr;
    if (!fr) problems.push(`${rel(file)} : texte français manquant (i18n/fr/entities/${e.category}/${e.id}.mdx)`);
    entities.set(e.id, { ...e, slug: fr?.meta.slug ?? slugify(fr?.meta.name ?? e.id), text, file: rel(file) });
  }

  // 4. Références : relations, vainqueurs, liens <E> et médias
  const known = (id: string) => entities.has(id) || planned.has(id);
  const relations: Relation[] = [];
  const seen = new Set<string>();
  for (const e of entities.values()) {
    // Une fiche peut déclarer des relations entre d'autres personnages de son
    // récit (ex. Hermès aide Persée) : toutes alimentent le graphe commun.
    for (const r of e.relations) {
      for (const id of [r.from, r.to])
        if (!known(id)) problems.push(`${e.file} : relation vers « ${id} », entité inconnue (ni rédigée, ni annoncée dans planned.yaml)`);
      const key = `${r.from}|${r.type}|${r.to}`;
      if (!seen.has(key)) {
        seen.add(key);
        relations.push(r);
      }
    }
    for (const id of e.creature?.defeatedBy ?? [])
      if (!known(id)) problems.push(`${e.file} › creature.defeatedBy : « ${id} » inconnu`);
    for (const [locale, t] of Object.entries(e.text)) {
      if (!t) continue;
      for (const [, id] of t.body.matchAll(E_TAG))
        if (!known(id)) problems.push(`i18n/${locale}/…/${e.id}.mdx : lien <E id="${id}">, entité inconnue`);
    }
    for (const m of [e.media.hero, e.media.pictogram, ...e.media.gallery].filter(Boolean) as string[])
      if (!media.has(m)) problems.push(`${e.file} › media : « ${m} » absent du registre des médias (media/registry.yaml)`);
  }

  // 5. Slugs uniques par catégorie
  const slugs = new Map<string, string>();
  for (const e of entities.values()) {
    const k = `${e.category}/${e.slug}`;
    if (slugs.has(k)) problems.push(`slug « ${k} » utilisé par « ${slugs.get(k)} » et « ${e.id} »`);
    slugs.set(k, e.id);
  }

  if (problems.length) throw new ContentError(problems);
  return { entities, planned, relations, media };
}

// ---------- Requêtes ----------

export function isPublished(e: LocalizedEntity, locale: Locale): boolean {
  return PUBLISHABLE.includes(e.review.status) && !!e.text[locale];
}

export function publishedEntities(g: ContentGraph, locale: Locale, category?: Category): LocalizedEntity[] {
  return [...g.entities.values()]
    .filter((e) => isPublished(e, locale) && (!category || e.category === category))
    .sort((a, b) => a.importance - b.importance || a.slug.localeCompare(b.slug));
}

export type Neighbor = { relation: Relation; other: string; direction: "out" | "in" };

/** Toutes les relations d'une entité, dans les deux sens (relations inverses calculées). */
export function neighbors(g: ContentGraph, id: string): Neighbor[] {
  return g.relations.flatMap<Neighbor>((r) =>
    r.from === id ? [{ relation: r, other: r.to, direction: "out" }] : r.to === id ? [{ relation: r, other: r.from, direction: "in" }] : [],
  );
}

export function displayName(g: ContentGraph, id: string, locale: Locale): string {
  return g.entities.get(id)?.text[locale]?.meta.name ?? g.planned.get(id)?.name ?? id;
}
