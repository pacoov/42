import "server-only";
import { evaluate } from "@mdx-js/mdx";
import * as runtime from "react/jsx-runtime";
import type { ContentGraph } from "./load";
import type { Locale } from "./schema";
import type { Dictionary } from "@/lib/i18n";
import { makeEntityLink } from "@/components/content/EntityLink";
import { makeVersions } from "@/components/content/Versions";

/** Compile le corps MDX d'une fiche au build. Seuls les composants
 * listés ici sont disponibles dans le contenu (liste blanche, §40). */
export async function renderMdx(body: string, g: ContentGraph, locale: Locale, t: Dictionary) {
  const { default: Content } = await evaluate(body, { ...runtime, baseUrl: import.meta.url });
  const { Versions, Version } = makeVersions(t);
  const E = makeEntityLink(g, locale, t.entity.notYetWritten);
  return <Content components={{ E, Versions, Version }} />;
}
