import "server-only";
import path from "node:path";
import { loadContent, type ContentGraph } from "./load";

let graph: ContentGraph | undefined;

/** Graphe de contenu chargé une fois par processus de build. Lève une
 * ContentError (et fait donc échouer le build) si le contenu est invalide. */
export function getGraph(): ContentGraph {
  graph ??= loadContent(path.join(process.cwd(), "content"));
  return graph;
}

export * from "./load";
