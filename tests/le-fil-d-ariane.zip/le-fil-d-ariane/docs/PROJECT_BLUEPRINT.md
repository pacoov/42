# PROJECT_BLUEPRINT.md
## LE FIL D'ARIANE — Le site qui donne envie de découvrir la mythologie grecque

> Nom du site : **Le Fil d'Ariane** (validé le 15/10/2026 — disponibilité du domaine à vérifier).
> Version du document : 1.2 — 15 octobre 2026 (décisions §0.4, ajustements de la phase 1 §0.5)
> Statut : **validé — phase 1 prête à démarrer**

---

## SOMMAIRE

- **PARTIE A — STRATÉGIE**
  0. Résumé exécutif & décisions à valider
  1. Vision du projet
  2. Positionnement
  3. Public cible
  4. Personas
  5. Benchmark & enseignements
  6. Risques identifiés
  7. Priorisation des fonctionnalités (MoSCoW)
  8. Stratégie UX
  9. Architecture pédagogique (4 niveaux)
  10. Propositions originales (au-delà du brief)
- **PARTIE B — ARCHITECTURE DE L'EXPÉRIENCE**
  11. Architecture du site
  12. Sitemap & URLs
  13. Système de navigation
  14. User journeys
  15. Wireframes textuels page par page
- **PARTIE C — DESIGN**
  16. Direction artistique
  17. Design system (palette, gradients, typo, spacing, radius, ombres, composants de base)
  18. Stratégie d'animation
  19. Stratégie responsive
  20. Accessibilité
- **PARTIE D — CONTENU**
  21. Approche éditoriale & ton
  22. Méthodologie des sources
  23. Architecture du contenu
  24. Modèle de données
  25. Système de comparaison Mythe / Pop culture
  26. Système de quiz
  27. Gamification
  28. Système de recherche
  29. Stratégie d'images
  30. Stratégie de licences
  31. Microcopy
- **PARTIE E — TECHNIQUE**
  32. Stack technique justifiée
  33. Structure des dossiers
  34. Spécifications composant par composant
  35. SEO
  36. Performance
  37. Internationalisation
  38. Tests
  39. Déploiement
  40. Sécurité & vie privée
  41. Analytics
- **PARTIE F — EXÉCUTION**
  42. Plan de développement par phases
  43. Évolutivité & fonctionnalités futures
  44. Checklist QA
  45. Definition of Done

---

# PARTIE A — STRATÉGIE

## 0. RÉSUMÉ EXÉCUTIF & DÉCISIONS À VALIDER

### 0.1 La promesse en une phrase

> **La mythologie grecque comme un réseau d'histoires à explorer, pas comme un cours à lire.**

Chaque page est une porte vers trois autres. Le visiteur arrive par Percy Jackson, God of War ou un mot qu'il utilise tous les jours (« panique », « narcissique »), et repart avec une vraie carte mentale des dieux, des héros, des monstres et des mythes — en sachant distinguer ce que disent les sources antiques de ce qu'ont inventé les œuvres modernes.

### 0.2 Les 10 décisions structurantes

| # | Décision | Pourquoi |
|---|----------|----------|
| 1 | **Next.js 16 (App Router) + TypeScript, rendu statique (SSG) par défaut** | SEO excellent, pages instantanées, coût d'hébergement quasi nul, pas de serveur à maintenir pour du contenu éditorial. |
| 2 | **Contenu en fichiers (YAML + MDX) versionnés dans le repo, validés par Zod au build** | Contenu séparé de l'UI, relations vérifiées automatiquement (un lien cassé = build cassé), traduction facile, pas de CMS payant au départ. |
| 3 | **Tailwind CSS v4 + tokens CSS du design system** | Rapidité, cohérence, thème clair/sombre natif, zéro CSS mort en production. |
| 4 | **Motion (ex-Framer Motion) en chargement paresseux (`LazyMotion`) ; pas de GSAP au MVP** | Couvre 95 % des besoins (scroll, layout, transitions) avec un coût JS maîtrisé. GSAP seulement si un besoin précis le justifie. |
| 5 | **Recherche 100 % statique avec Pagefind** | Pas de serveur, multilingue natif, filtres par type, très léger côté navigateur. |
| 6 | **Visualisations (arbre, galaxie, carte) en SVG maison, layouts pré-calculés au build** | Contrôle total du rendu, accessibilité, performance mobile ; les bibliothèques de graphes génériques sont lourdes et difficiles à rendre accessibles. |
| 7 | **Gamification sans compte, stockée localement (localStorage)** | Le brief interdit d'obliger la création de compte ; public en partie mineur → minimiser les données personnelles (RGPD). |
| 8 | **Chaque information distingue 3 couches : SOURCE ANTIQUE / INTERPRÉTATION / ADAPTATION MODERNE** | C'est la valeur unique du site et son garde-fou contre la désinformation. Intégré au modèle de données, pas seulement à la rédaction. |
| 9 | **Images : œuvres antiques du domaine public (Met Open Access CC0, Wikimedia Commons vérifié) + illustrations originales. Zéro image d'œuvre moderne protégée** | Sécurité juridique et identité visuelle propre. La pop culture est traitée par le texte et des visuels originaux. |
| 10 | **Français d'abord, architecture i18n dès le jour 1 (next-intl, slugs localisés)** | Traduire plus tard ne doit demander aucune réécriture de composant. |

### 0.3 Questions de la v1.0 (toutes tranchées — voir §0.4)

1. Nom du site · 2. Qui rédige et vérifie · 3. Illustrations · 4. Hébergement · 5. Ordre des phases.

### 0.5 Ajustements techniques de la phase 1 (v1.2)

| Prévu | Fait | Raison |
|---|---|---|
| next-intl | i18n native de Next 16 (`app/[lang]`, dictionnaires JSON) | Compatibilité non garantie avec Next 16.4 ; la solution native couvre le besoin sans dépendance. Les slugs localisés passent par `SECTION_SEGMENTS`. |
| Cache Components activé | Désactivé | Site 100 % statique : `generateStaticParams` + `dynamicParams = false` suffisent. |
| Polices via Google | Auto-hébergées (paquets Fontsource, OFL) | Vie privée, performance, et build possible sans accès réseau. |
| Relations dans `content/relations/*.yaml` | Déclarées dans chaque fiche, fusionnées au build | Les agents écrivent une fiche complète en un fichier ; le graphe commun est reconstruit et dédoublonné. |
| — | `content/planned.yaml` | Une fiche peut citer une entité pas encore rédigée : affichée sans lien, jamais de lien mort. |
| — | Bloc `deity:` (domaines en clés, symboles en ids, `olympian`, épithètes) | Proposé par trois rédacteurs ; normalisé pour rester langue-agnostique. |
| — | Statut `verified-ai` publiable avec bandeau | Permet de construire le site pendant la relecture humaine ; à restreindre à `verified` avant lancement. |
| URL `/dieux/titans/cronos` | `/titans/cronos` | Une catégorie = un segment ; plus simple, à revoir si besoin. |

### 0.4 Décisions validées (v1.1 — 15/10/2026)

| Sujet | Décision | Conséquences dans ce document |
|---|---|---|
| **Nom** | **Le Fil d'Ariane** | Le Fil de progression devient la **fonctionnalité signature** et passe en MUST (§7, §10, §27). Le breadcrumb est appelé « chemin de navigation » pour éviter la confusion (§13.3). Domaine et marque à vérifier avant lancement. |
| **Rédaction** | Chaîne de **deux agents IA** (rédacteur → vérificateur), **pilotée par Claude** (directives, arbitrage, questions à Enzo) | Nouveau §22.5. Garde-fou : le vérificateur travaille **à partir des sources consultées en ligne**, pas de mémoire ; contrôle humain par échantillonnage. |
| **Illustrations** | **Images libres trouvées en ligne d'abord** (CC0 / domaine public / CC BY), **SVG original en secours**, et **galerie de validation** montrant chaque visuel à Enzo avant intégration | §29 mis à jour. Aucun visuel n'entre dans le site sans être passé par la galerie. |
| **Hébergement** | Reporté | Aucun impact avant la phase 12 : le code reste compatible Vercel et Cloudflare Pages. |
| **Phases** | Schéma de données en phase 1, contenu rempli en parallèle dès la phase 2 | §42 mis à jour. |

---

## 1. VISION DU PROJET

### 1.1 Vision

Créer **la meilleure porte d'entrée numérique vers la mythologie grecque pour les 15–25 ans** : un site qu'on ouvre « pour deux minutes » et qu'on referme trente minutes plus tard en ayant appris quelque chose, sans jamais avoir eu l'impression de suivre un cours.

### 1.2 Mission

- **Rendre la curiosité contagieuse** : chaque fiche se termine par une question ou une connexion qui donne envie de cliquer.
- **Être fiable sans être scolaire** : toujours dire d'où vient une information et s'il en existe plusieurs versions.
- **Relier l'Antiquité au quotidien** : mots, prénoms, planètes, jeux vidéo, marques.

### 1.3 Les 5 principes produit (à relire à chaque décision)

1. **Une porte, trois sorties.** Aucune page n'est un cul-de-sac.
2. **Court d'abord, profond ensuite.** Toujours une version en 10 secondes, puis la possibilité de creuser.
3. **Montrer avant d'expliquer.** Un schéma, une carte, une relation visuelle valent mieux qu'un paragraphe.
4. **Honnêteté des sources.** « Il existe plusieurs versions » est une richesse, pas un aveu de faiblesse.
5. **L'animation se ressent avant de se remarquer.** Rien qui ralentit, rien qui fatigue.

### 1.4 Critère de succès qualitatif

Le test du brief : un ado de 16 ans qui ne connaît que Percy Jackson, après 20 minutes, sait citer et situer Zeus, Poséidon, Hadès, Athéna, quelques héros, quelques monstres, plusieurs grands mythes, faire la différence entre mythe et fiction, et expliquer l'origine de quelques expressions françaises.

### 1.5 Indicateurs de succès (KPI)

| KPI | Cible à 6 mois | Pourquoi |
|-----|----------------|----------|
| Pages vues par session | ≥ 5 | Mesure directe de l'effet « réseau ». |
| Durée médiane de session | ≥ 4 min | Engagement réel. |
| Taux de clic sur « liens connexes » en bas de fiche | ≥ 25 % | Valide le principe « une porte, trois sorties ». |
| Taux de complétion des quiz commencés | ≥ 60 % | Qualité du quiz. |
| Partages (quiz, « Quel dieu es-tu ? ») | à suivre | Viralité. |
| Score Lighthouse mobile (Perf / A11y / SEO) | ≥ 90 / 100 / 100 | Qualité technique. |

---

## 2. POSITIONNEMENT

### 2.1 Carte concurrentielle

| | **Fiable / sourcé** | **Peu fiable** |
|---|---|---|
| **Ludique / moderne** | ➜ **LE FIL D'ARIANE (espace libre)** | Vidéos courtes, quiz viraux, fandom wikis |
| **Austère / scolaire** | Wikipédia, Theoi Project, sites universitaires, dictionnaires | Blogs SEO recopiés |

L'espace « ludique ET fiable » est largement inoccupé en français.

### 2.2 Ce que nous sommes / ce que nous ne sommes pas

| Nous sommes | Nous ne sommes pas |
|---|---|
| Une expérience d'exploration | Une encyclopédie exhaustive |
| Un réseau de connaissances | Une liste de dieux |
| Un pont entre Antiquité et pop culture | Un site de fans d'une franchise |
| Vulgarisé et sourcé | Universitaire dans la forme |
| Gratuit, sans compte obligatoire | Une plateforme qui collecte des données |

### 2.3 Proposition de valeur par cible

- **Ado fan de Percy Jackson / Hades** : « Découvre ce que l'histoire originale raconte vraiment — c'est encore plus fou. »
- **Étudiant** : « Révise ta culture générale en 10 minutes par jour, avec les sources. »
- **Curieux adulte** : « Comprends enfin qui est qui dans cette famille compliquée. »

---

## 3. PUBLIC CIBLE

### 3.1 Cœur de cible
- **15–25 ans**, francophones, majoritairement sur **smartphone** (hypothèse : 70 %+ du trafic mobile — à valider via analytics).
- Connaissance de la mythologie : **indirecte**, via films, séries, jeux vidéo, livres jeunesse.

### 3.2 Cibles secondaires
- Enseignants de collège/lycée (lettres, histoire) qui cherchent un support attractif.
- Parents qui accompagnent un enfant fan de Percy Jackson.
- Adultes curieux, joueurs de jeux vidéo.

### 3.3 Contraintes déduites du public
- Lecture **sur mobile, souvent en mouvement** → textes courts, gros titres, interactions au pouce.
- Attention fragmentée → contenu « snackable » + profondeur optionnelle.
- **Une partie des utilisateurs est mineure** → pas de compte obligatoire, pas de tracking publicitaire, analytics sans cookies, aucun contenu sexuellement explicite (certains mythes impliquent violences et agressions : traitement sobre, factuel, non graphique — voir §21.6).
- Références culturelles fortes (jeux, séries) → les utiliser comme **points d'entrée**, jamais comme vérité.

---

## 4. PERSONAS

### Persona 1 — Lina, 16 ans, lycéenne, « la fan »
- **Contexte** : a lu toute la saga Percy Jackson, regarde la série. Découvre le site via un TikTok « 5 choses que Percy Jackson a changées ».
- **Objectif** : savoir si Annabeth « existe » dans la mythologie, ce qui est vrai sur Méduse.
- **Frustrations** : Wikipédia trop long, sites moches, pubs.
- **Ce qui la retient** : comparaisons « Dans le mythe / Dans Percy Jackson », fiches visuelles, quiz partageables.
- **Parcours type** : Accueil → porte « Je connais Percy Jackson » → Méduse (comparaison) → fiche Méduse → Persée → Athéna → quiz « Mythe ou fiction ? ».

### Persona 2 — Yanis, 19 ans, étudiant, « le joueur »
- **Contexte** : a joué à *Hades* et *God of War*. Arrive en cherchant « Zagreus mythologie » sur Google.
- **Objectif** : comprendre qui sont vraiment Zagreus, Nyx, Thanatos, et les Enfers.
- **Ce qui le retient** : la carte des Enfers, l'arbre généalogique, le « Codex » de progression (il adore compléter).
- **Parcours type** : Recherche Google → fiche Zagreus → « Plusieurs versions » → Enfers (carte) → Hadès → Perséphone → généalogie.

### Persona 3 — Camille, 23 ans, en master (hors lettres), « la culture-géné »
- **Contexte** : prépare des concours, veut combler des lacunes.
- **Objectif** : les grands mythes en version courte, les expressions françaises.
- **Ce qui la retient** : « La mythologie en 5 minutes », section « Mots que nous utilisons encore », mode révision des quiz.
- **Parcours type** : Accueil → « En 5 minutes » → « Mots » → « talon d'Achille » → fiche Achille → guerre de Troie.

### Persona 4 — Théo, 15 ans, « le zappeur »
- **Contexte** : arrive via un lien partagé par un ami (« Quel dieu grec es-tu ? »).
- **Objectif** : aucun au départ. S'amuser.
- **Ce qui le retient** : le résultat du test, « Surprends-moi », les anecdotes « Le saviez-vous ? ».
- **Risque** : partir après le test. **Réponse design** : la page résultat propose immédiatement « Découvre ton dieu », « 3 choses que tu ignores sur lui », « Teste un ami ».

### Persona 5 (secondaire) — M. Durand, 41 ans, professeur de lettres
- **Objectif** : un support fiable à montrer en classe.
- **Ce qui le retient** : page « Sources & Méthodologie », références aux textes antiques, niveau « Approfondir ».
- **Implication design** : chaque fiche a un bloc « Sources » propre et citable ; une version imprimable lisible.

---

## 5. BENCHMARK & ENSEIGNEMENTS

> Objectif : identifier des **mécaniques qui fonctionnent**, pas des looks à copier. L'identité visuelle du Fil d'Ariane doit rester originale.

| Famille de sites | Mécanique qui fonctionne | Pourquoi ça marche | Ce qu'on en retient |
|---|---|---|---|
| **Encyclopédies collaboratives** (effet « terrier de lapin ») | Liens internes omniprésents | Chaque lien est une micro-curiosité satisfaite immédiatement | Liens contextuels dans le texte + bloc « Pour aller plus loin » systématique. **Mais** : hiérarchiser (3 liens forts > 50 liens faibles). |
| **Jeux vidéo à « codex »** (journal de découvertes qui se remplit) | Collection progressive, entrées débloquées | Le besoin de complétion est un moteur puissant | « Codex » optionnel : « Tu as découvert 12/120 entrées ». |
| **Journalisme de données en scrollytelling** | Récit qui se construit au défilement, visuels qui réagissent | Le lecteur contrôle le rythme ; l'info arrive par couches | Pages « Grands mythes » en scrollytelling léger. |
| **Plateformes culturelles de musées / Google Arts & Culture** | Exploration visuelle, zoom, collections thématiques | Le visuel déclenche la curiosité avant le texte | Galerie « Objets & symboles », œuvres antiques réelles en grand format. |
| **Apps d'apprentissage gamifiées** | Sessions courtes, feedback immédiat, séries | Récompense rapide, effort faible | Quiz de 5–10 questions, explication après chaque réponse. **Éviter** la culpabilisation (pas de « tu vas perdre ta série ! »). |
| **Plateformes de streaming** | « À suivre » automatique en fin de contenu | Supprime l'effort de décision | Bloc « Prochaine histoire » en fin de mythe. |
| **Quiz viraux de personnalité** | Résultat identitaire partageable | Les gens partagent ce qui parle d'eux | « Quel dieu grec es-tu ? » avec image de partage générée, résultat **qui renvoie vers du vrai contenu**. |
| **Sites éditoriaux premium** | Typographie forte, beaucoup d'air, hiérarchie claire | Lisibilité = crédibilité | Grilles éditoriales, grands titres, corps de texte confortable. |

### Tendances UI actuelles pertinentes (et notre usage)
- **Bento grids** (grilles de cartes de tailles variées) → hub « Explorer ». ✅
- **Typographie variable expressive** → titres. ✅
- **Effets de profondeur / parallaxe légère** → hero. ✅ avec parcimonie.
- **Glassmorphism** → seulement pour la barre de navigation et les modales. ⚠️ Attention au contraste.
- **Fonds WebGL / shaders lourds** → ❌ au MVP (performance mobile, batterie). Option « effet premium » sur desktop seulement, plus tard.
- **Command palette (Ctrl/⌘+K)** → recherche globale. ✅

---

## 6. RISQUES IDENTIFIÉS

| Risque | Probabilité | Impact | Mitigation |
|---|---|---|---|
| **R1 — Volume éditorial sous-estimé** (120+ fiches à rédiger, vérifier, relier) | Élevée | Critique | MVP à périmètre fixe ; gabarits de rédaction stricts ; contenu « niveau 1 » d'abord pour toutes les fiches, niveaux 2–3 ensuite ; checklist de vérification par fiche. |
| **R2 — Erreurs factuelles / versions présentées comme uniques** | Moyenne | Élevé (crédibilité) | Champ `sources` obligatoire (validation au build) ; champ `variants` ; relecture croisée ; page Méthodologie ; bouton « Signaler une erreur ». |
| **R3 — Droits d'images** | Moyenne | Élevé (juridique) | Registre des médias avec licence obligatoire (build échoue sans) ; uniquement CC0 / domaine public / CC BY vérifiées / créations originales. |
| **R4 — Composants 21st.dev sans licence claire** | Élevée | Moyen | Beaucoup de composants de cette plateforme sont publiés **sans licence** (« no-license »), ce qui signifie juridiquement « tous droits réservés ». Règle : **n'utiliser que les composants explicitement sous licence MIT/Apache/ISC**, sinon s'en inspirer conceptuellement et réécrire. |
| **R5 — Animations qui plombent la perf mobile** | Moyenne | Élevé | Budgets de performance (§36), tests sur appareil Android milieu de gamme, `prefers-reduced-motion`, animations limitées à `transform`/`opacity`. |
| **R6 — Graphes illisibles sur mobile** (arbre, galaxie) | Élevée | Moyen | Vue mobile dédiée (liste navigable « focus sur un personnage »), pas un graphe miniaturisé. |
| **R7 — Marques & pop culture** (Percy Jackson, Marvel, etc.) | Faible | Moyen | Usage nominatif uniquement (citer les noms pour commenter), aucun logo, aucune image officielle, aucune reproduction de texte ; mention « marques citées à titre d'information ». |
| **R8 — Contenus sensibles** (violences, agressions dans les mythes) | Certaine | Moyen | Charte de traitement sobre (§21.6), jamais graphique, contextualisée. |
| **R9 — Scope creep** (le brief est très riche) | Élevée | Élevé | MoSCoW strict (§7), phases avec livrables, ajout de fonctionnalités seulement après MVP. |
| **R10 — SEO dupliqué entre langues** | Faible | Moyen | `hreflang`, canonical par langue, slugs localisés. |

---

## 7. PRIORISATION DES FONCTIONNALITÉS (MoSCoW)

### MUST (MVP — lancement)
- Accueil + hero + portes d'entrée
- « La mythologie en 5 minutes »
- Panthéon (liste + fiches) — 14 divinités olympiennes + Hadès
- Primordiaux & Titans clés (~10 fiches)
- Héros (7 fiches)
- Bestiaire avec filtres (14 fiches)
- Grands mythes (16 récits)
- Arbre généalogique (desktop + vue mobile)
- Comparaisons Mythe vs Pop culture : Percy Jackson (≥ 8 comparaisons) + page « Où as-tu déjà rencontré la mythologie ? »
- « Mots que nous utilisons encore » (≥ 30 mots)
- Quiz (≥ 3 quiz thématiques + « Mythe ou fiction ? »)
- Recherche globale
- Surprends-moi (l'Oracle)
- **Le Fil d'Ariane** : fil de progression de session, visible et partageable (fonctionnalité signature, §10)
- Sources & Méthodologie, À propos, Mentions légales, Confidentialité, Crédits
- SEO de base, accessibilité AA, responsive, `prefers-reduced-motion`

### SHOULD (V1.1 — dans les 2 mois)
- Galaxie des relations
- Lieux (9 fiches) + carte interactive du monde mythique
- Objets & symboles (10 fiches)
- Codex / progression / badges
- « Quel dieu grec es-tu ? »
- Comparaisons Marvel + autres œuvres
- Images de partage (Open Graph) générées

### COULD (V2)
- Astronomie (« Le ciel des dieux »)
- Chronologie mythique interactive
- Mode « versions » comparées (Hésiode vs Ovide…)
- Anglais
- Mini-jeux (« Qui suis-je ? », associations symboles)
- Mode impression enseignant

### WON'T (pour l'instant)
- Comptes utilisateurs, commentaires, forum
- Contenu généré par les utilisateurs
- Application mobile native
- Fond WebGL 3D sur toutes les pages

### Volume de contenu MVP

| Type | Nombre | Exemples |
|---|---|---|
| Divinités olympiennes (+ Hadès) | 15 | Zeus, Héra, Poséidon, Hadès, Athéna, Arès, Aphrodite, Apollon, Artémis, Hermès, Héphaïstos, Dionysos, Déméter, Hestia, Perséphone* |
| Primordiaux & Titans | 10 | Chaos, Gaïa, Ouranos, Nyx, Cronos, Rhéa, Océan, Prométhée, Atlas, Thémis |
| Héros | 7 | Héraclès, Persée, Thésée, Achille, Ulysse, Jason, Orphée |
| Créatures | 14 | Méduse, Minotaure, Cerbère, Hydre de Lerne, Cyclopes, Sphinx, Sirènes, Scylla, Charybde, Chimère, Pégase, Centaures, Harpies, Griffons** |
| Mythes | 16 | liste du brief §17 |
| Comparaisons pop culture | 10 | Percy Jackson ×8, Hades ×1, Disney *Hercule* ×1 |
| Mots | 30 | narcissique, panique, odyssée, mentor… |
| **Total** | **~102 fiches** + 16 récits = **~118 contenus** | |

\* Perséphone n'est pas toujours comptée parmi les Olympiens : c'est un excellent cas pour expliquer que **la liste des « Douze » varie selon les sources** (Hestia ou Dionysos, notamment). Hadès, qui réside aux Enfers, n'est généralement pas compté parmi les Douze — on l'expliquera.
\** Le griffon est surtout présent dans l'art et chez certains auteurs (Hérodote, Eschyle) ; il est d'origine proche-orientale. À traiter avec la mention « créature présente dans le monde grec, mais peu de mythes la mettent en scène ».

---

## 8. STRATÉGIE UX

### 8.1 Le modèle mental : un réseau, pas une hiérarchie
L'architecture technique est hiérarchique (catégories → fiches), mais l'**expérience** est réticulaire : le visiteur navigue de connexion en connexion. Trois mécanismes garantissent cela :

1. **Liens contextuels inline** : chaque nom propre important dans un texte est un lien (style discret, tooltip « carte d'identité » au survol/appui long).
2. **Bloc « Connexions »** à chaque fiche : relations typées (famille, amour, conflit, alliance) visualisées en mini-graphe.
3. **Bloc « Prochaine porte »** en fin de page : 3 suggestions maximum, chacune avec une phrase d'accroche (« Tu as aimé Méduse ? Découvre celui qui l'a affrontée → Persée »).

### 8.2 Les portes d'entrée (hub « Explorer »)
Reprend les portes du brief, formulées à la première personne :

| Porte | Destination | Public |
|---|---|---|
| « Je ne connais rien » | La mythologie en 5 minutes | Débutants |
| « Je veux connaître les dieux » | Panthéon | Tous |
| « Je veux des histoires » | Bibliothèque des mythes | Tous |
| « Qui est le père de qui ?! » | Arbre généalogique | Curieux |
| « Je veux des monstres » | Bestiaire | Ados |
| « Je connais Percy Jackson » | Comparaisons Percy Jackson | Fans |
| « Je joue aux jeux vidéo » | Hades, God of War, Assassin's Creed | Joueurs |
| « Je connais Marvel » | Comparaisons Marvel | Fans |
| « Teste-moi » | Quiz | Tous |
| « Surprends-moi » | Contenu aléatoire | Zappeurs |

### 8.3 Divulgation progressive
Chaque fiche est construite en **couches** :
- **Couche 0 — 10 secondes** : nom, rôle en une ligne, symbole, visuel.
- **Couche 1 — 1 minute** : « En bref » (3–5 puces).
- **Couche 2 — 5 minutes** : histoires, relations, pouvoirs.
- **Couche 3 — pour les curieux** : versions, sources, contexte historique (accordéons).
- **Couche 4 — aujourd'hui** : culture populaire, mots, astronomie.

### 8.4 Règles UX transversales
- **Pas de mur de texte** : paragraphe max 4 lignes sur mobile (~60 mots), puis rupture (visuel, citation, carte, puce).
- **Toujours une action suivante visible** sans scroller jusqu'en bas (CTA collant discret sur mobile : « Suivant : Persée → »).
- **Retour en arrière fiable** : l'historique navigateur fonctionne partout (y compris filtres → paramètres d'URL).
- **États vides soignés** : recherche sans résultat → « Même l'Oracle de Delphes n'a rien trouvé. Essaie… » + suggestions.
- **Aucune interaction critique au survol uniquement** (mobile).

---

## 9. ARCHITECTURE PÉDAGOGIQUE (4 NIVEAUX)

| Niveau | Nom affiché | Objectif | Formats | Exemple (Zeus) |
|---|---|---|---|---|
| 1 | **Découvrir** | Reconnaître | Carte, 1 phrase, symbole, visuel | « Roi des dieux. Arme : la foudre. Vit sur l'Olympe. » |
| 2 | **Comprendre** | Relier | Relations, histoires courtes, arbre | Fils de Cronos, a renversé son père, frère de Poséidon et Hadès. |
| 3 | **Approfondir** | Nuancer | Versions, sources, contexte | Où est né Zeus ? Le mont Ida ou le mont Dicté en Crète, selon les sources. Qui sont nos sources (Hésiode) ? |
| 4 | **Culture** | Transférer | Mots, pop culture, astronomie | Jupiter (nom romain) et ses lunes nommées d'après des personnages liés à Zeus : Io, Europe, Ganymède, Callisto. |

**Mise en œuvre** :
- Chaque bloc de contenu est **tagué** avec son niveau dans les données.
- Sur chaque fiche, un sélecteur discret **« Profondeur : Découvrir · Comprendre · Approfondir »** (par défaut : Comprendre). Il replie/déplie les blocs correspondants — rien n'est caché aux moteurs de recherche (contenu toujours dans le HTML, simplement replié).
- Les quiz ont aussi des niveaux de difficulté alignés.

---

## 10. PROPOSITIONS ORIGINALES (AU-DELÀ DU BRIEF)

| Proposition | Description | Pourquoi elle apporte quelque chose | Priorité |
|---|---|---|---|
| **🧵 Le Fil d'Ariane** | Un fil doré visualise le parcours du visiteur dans la session (Zeus → Cronos → Titanomachie…). Accessible depuis un bouton flottant. On peut revenir à n'importe quel point et **partager son parcours**. | Transforme la navigation en récit personnel ; référence mythologique parfaitement dans le thème ; renforce l'effet « réseau ». **C'est désormais l'identité même du site.** | **MUST** |
| **🏛️ L'Oracle** (habillage de « Surprends-moi ») | Le bouton aléatoire devient « Consulter l'Oracle » avec une micro-animation (fumée/lueur) et une phrase énigmatique avant le résultat. Pondération : favorise ce que le visiteur n'a pas encore vu. | Rend l'aléatoire mémorable et thématique. | MUST |
| **📜 Le Codex** | Collection des entrées découvertes, par catégorie, avec silhouettes « à découvrir ». | Moteur de complétion (cf. benchmark jeux vidéo), 100 % optionnel. | SHOULD |
| **⚖️ « Une histoire, plusieurs versions »** | Composant qui affiche côte à côte deux versions d'un même épisode avec leurs sources (ex. Méduse chez Hésiode vs chez Ovide). | Rend tangible la notion de variantes ; développe l'esprit critique. | MUST (composant) |
| **🃏 « Mythe ou fiction ? »** | Mini-jeu de cartes à balayer (gauche/droite ou boutons) : « Annabeth est la fille d'Athéna dans les mythes antiques » → Fiction. | Ultra partageable, mobile-first, cœur de la promesse « distinguer mythe et pop culture ». | MUST |
| **🗺️ Les Âges du mythe** | Frise : Origines (Chaos) → Titans → Olympiens → Âge des héros → Guerre de Troie → Retour d'Ulysse. Chaque fiche est positionnée dessus. | Résout la confusion chronologique, très fréquente chez les débutants. | COULD |
| **🔤 « Ton prénom vient-il des mythes ? »** | Recherche dédiée sur les prénoms (Chloé, Hélène, Jason, Alexandre…). Uniquement des étymologies vérifiées. | Viralité forte, entrée identitaire. | COULD |
| **🎧 Version audio** | Lecture des mythes (synthèse ou voix enregistrée). | Accessibilité + usage en transport. | Futur |
| **🍎 Microcopie « famille compliquée »** | Badges humoristiques sur les liens de parenté complexes (« Oui, c'est aussi son oncle »). | Désamorce la complexité généalogique avec humour. | MUST (léger) |

---

# PARTIE B — ARCHITECTURE DE L'EXPÉRIENCE

## 11. ARCHITECTURE DU SITE

### 11.1 Les 7 univers

```
                         ┌────────────────────┐
                         │      ACCUEIL       │
                         └─────────┬──────────┘
                                   │
                         ┌─────────▼──────────┐
                         │      EXPLORER      │  (hub des portes + Oracle)
                         └─────────┬──────────┘
   ┌──────────┬──────────┬─────────┼──────────┬───────────┬─────────────┐
   ▼          ▼          ▼         ▼          ▼           ▼             ▼
 DIEUX     HÉROS    CRÉATURES   MYTHES     MONDES     POP CULTURE      QUIZ
(+Titans)                                 (lieux,     (comparaisons,  (+Mythe ou
(+généal.)                               objets,      mots, ciel)      fiction,
(+relations)                              carte)                       Quel dieu)
   └──────────┴──────────┴─────────┴──────────┴───────────┴─────────────┘
                 Toutes les fiches sont reliées entre elles (graphe)
```

### 11.2 Types de pages (templates)

| Template | Utilisé par | Nb au MVP |
|---|---|---|
| `HomePage` | Accueil | 1 |
| `HubPage` | Explorer | 1 |
| `StoryIntroPage` | La mythologie en 5 minutes | 1 |
| `CollectionPage` | Dieux, Héros, Créatures, Mythes, Lieux, Objets, Mots | 7 |
| `EntityPage` (variantes : divinité, titan, héros, créature, lieu, objet) | Fiches | ~80 |
| `MythPage` | Récits | 16 |
| `ComparisonPage` | Mythe vs pop culture | ~10 |
| `WorkPage` | Une œuvre (Percy Jackson, Hades…) | ~6 |
| `WordPage` | Un mot (optionnel, pour le SEO) | ~30 |
| `VisualizationPage` | Généalogie, Galaxie, Carte, Chronologie | 4 |
| `QuizPage` / `QuizResultPage` | Quiz | ~5 |
| `CodexPage` | Progression | 1 |
| `SearchPage` | Recherche | 1 |
| `ContentPage` | Sources, À propos, Mentions, Confidentialité, Crédits | 5 |
| `NotFoundPage` | 404 | 1 |

---

## 12. SITEMAP & URLs

### 12.1 Arborescence (français)

```
/fr
├── /                                   Accueil
├── /explorer                           Hub des portes + Oracle
├── /decouvrir                          La mythologie en 5 minutes
├── /dieux                              Panthéon
│   ├── /dieux/zeus                     Fiche
│   └── /dieux/titans                   Sous-collection Primordiaux & Titans
│       └── /dieux/cronos
├── /heros
│   └── /heros/persee
├── /creatures                          Bestiaire (filtres en paramètres d'URL)
│   └── /creatures/meduse
├── /mythes
│   └── /mythes/persee-et-meduse
├── /mondes
│   ├── /mondes/carte                   Carte interactive
│   ├── /mondes/enfers                  Fiche lieu
│   └── /mondes/objets
│       └── /mondes/objets/foudre-de-zeus
├── /genealogie                         Arbre généalogique (?focus=zeus)
├── /relations                          Galaxie des relations (?focus=zeus)
├── /chronologie                        Les Âges du mythe (V2)
├── /pop-culture                        « Mythe ou pop culture ? »
│   ├── /pop-culture/ou-tu-las-rencontree
│   ├── /pop-culture/oeuvres/percy-jackson
│   ├── /pop-culture/oeuvres/marvel
│   ├── /pop-culture/comparaisons/meduse-percy-jackson
│   ├── /pop-culture/mots               Mots que nous utilisons encore
│   │   └── /pop-culture/mots/panique
│   └── /pop-culture/ciel               Astronomie (V2)
├── /quiz
│   ├── /quiz/les-olympiens
│   ├── /quiz/mythe-ou-fiction
│   ├── /quiz/quel-dieu-es-tu
│   └── /quiz/[slug]/resultat?s=…       Résultat partageable
├── /codex                              Progression (optionnel)
├── /recherche?q=…
├── /sources-et-methodologie
├── /a-propos
├── /credits
├── /mentions-legales
└── /confidentialite
```

### 12.2 Règles d'URL
- Préfixe de langue systématique (`/fr`, `/en`…). La racine `/` redirige selon `Accept-Language` (avec mémorisation du choix).
- **Slugs localisés** : `/fr/dieux/zeus` ↔ `/en/gods/zeus` ; `/fr/creatures/hydre-de-lerne` ↔ `/en/creatures/lernaean-hydra`. Le lien est fait par l'`id` stable de l'entité, pas par le slug.
- Minuscules, sans accents, mots séparés par des tirets.
- Filtres et états partageables en paramètres (`/creatures?type=hybride&danger=extreme`).
- Redirections 301 maintenues dans `data/redirects.ts` si un slug change.

---

## 13. SYSTÈME DE NAVIGATION

### 13.1 Navigation principale (desktop ≥ 1024 px)

```
┌──────────────────────────────────────────────────────────────────────────────┐
│ [🧵 Le Fil d'Ariane] Explorer Dieux Héros Créatures Mythes Mondes Pop culture│
│                                                    Quiz   [🔍 ⌘K]  [🏛 Oracle] │
└──────────────────────────────────────────────────────────────────────────────┘
```
- Barre fixe, translucide (verre dépoli + fond suffisamment opaque pour le contraste), qui **se rétracte au scroll vers le bas et réapparaît au scroll vers le haut**.
- **Méga-menus** au survol/focus sur « Dieux », « Créatures », « Mythes » : 6 vignettes + lien « Tout voir » + lien vers la visualisation associée (ex. « Voir l'arbre généalogique »).
- « À propos » est déplacé dans le footer (allège la barre ; le brief le place dans la nav, mais il est rarement cliqué — à valider).

### 13.2 Navigation mobile (< 768 px)
- **Barre supérieure** : logo · recherche · burger.
- **Menu burger plein écran** : grandes entrées typographiques (une par univers) avec pictogramme et couleur de catégorie, apparition en cascade ; en bas : Oracle, Codex, langue.
- **Barre d'action inférieure contextuelle** (sur les fiches uniquement) : `← Précédent` · `🧵 Fil` · `Suivant →`. Zone du pouce.

### 13.3 Navigation secondaire
- **Chemin de navigation** (breadcrumb — on évite l'appellation française habituelle « fil d'Ariane » pour ne pas la confondre avec la fonctionnalité phare du site) en haut de chaque fiche : `Dieux › Olympiens › Zeus` (balisé en données structurées `BreadcrumbList`).
- **Sommaire collant** sur les longues fiches (desktop : colonne latérale ; mobile : pastille « Sommaire » qui ouvre une feuille).
- **Liens contextuels** dans le texte avec **carte d'aperçu** (survol desktop, appui long ou icône ⓘ mobile).

### 13.4 Recherche
- Accessible partout : icône + raccourci `⌘K` / `Ctrl+K` / `/`.
- Ouvre une **palette de commandes** (modale) avec résultats instantanés groupés par type. Détail §28.

### 13.5 Footer
```
┌───────────────────────────────────────────────────────────────────────┐
│ 🧵 LE FIL D'ARIANE                                                    │
│ « Des dieux, des héros, des monstres — et des histoires qui vivent    │
│   encore aujourd'hui. »                                                │
│                                                                       │
│ EXPLORER        DÉCOUVRIR          LE PROJET          SUIVRE          │
│ Dieux           En 5 minutes       À propos           (réseaux si     │
│ Héros           Généalogie         Sources &          existants)      │
│ Créatures       Relations          méthodologie                       │
│ Mythes          Carte              Crédits                            │
│ Mondes          Quiz               Signaler une erreur                │
│ Pop culture     Oracle             Mentions légales                   │
│                                    Confidentialité                    │
│ [Langue : Français ▾]                [Thème : ☀ / ☾ / Auto]          │
│ Marques citées à titre informatif. Œuvres antiques : domaine public.  │
└───────────────────────────────────────────────────────────────────────┘
```

---

## 14. USER JOURNEYS

### Journey 1 — Lina (fan de Percy Jackson), découverte
```
TikTok « 5 choses que Percy Jackson a changées »
  → /pop-culture/oeuvres/percy-jackson (liste des comparaisons)
  → Comparaison « Méduse » : DANS LE MYTHE / DANS PERCY JACKSON / CE QUI CHANGE / POURQUOI
  → CTA « Toute l'histoire de Méduse » → /creatures/meduse
  → bloc « Une histoire, plusieurs versions » (Hésiode vs Ovide) — surprise
  → « Celui qui l'a affrontée » → /heros/persee
  → « Ses alliés divins » → Athéna, Hermès
  → bloc final « Teste-toi : Mythe ou fiction ? »
  → résultat 70 % → partage
Moment « wow » visé : découvrir que Méduse n'est pas qu'un monstre.
```

### Journey 2 — Yanis (joueur d'Hades), arrivée par Google
```
Google « Zagreus mythologie »
  → /dieux/zagreus (fiche secondaire — V1.1) : bandeau « Tu viens d'Hades ? »
  → Couche « Approfondir » : tradition orphique, versions de sa filiation
  → lien « Les Enfers » → /mondes/enfers : carte des Enfers (Styx, Achéron, Champs Élysées, Tartare)
  → Hadès → Perséphone → mythe Déméter et Perséphone (origine des saisons)
  → /genealogie?focus=hades
  → Codex : « 9/120 découverts » → envie de compléter
```

### Journey 3 — Camille (culture générale), révision
```
Accueil → « Je ne connais rien » → /decouvrir (5 minutes, 6 étapes)
  → fin : « Choisis ta suite : Dieux · Mythes · Mots »
  → /pop-culture/mots → « talon d'Achille » → /heros/achille
  → « Dans quelle source apparaît le talon ? » (source tardive : surprise)
  → /mythes/guerre-de-troie
  → /quiz/culture-generale (niveau Comprendre)
```

### Journey 4 — Théo (zappeur), partage reçu
```
Lien « J'ai eu Hermès, et toi ? » → /quiz/quel-dieu-es-tu
  → 8 questions → résultat « Athéna » avec visuel partageable
  → « 3 choses que tu ignores sur Athéna » (cartes animées)
  → « Découvre sa fiche » ou « Consulter l'Oracle »
  → Oracle → « Le mot "panique" vient du dieu Pan » → /pop-culture/mots/panique
```

### Journey 5 — Exploration libre (le brief §47)
```
/dieux/zeus
  → « Sa famille » → Cronos
  → « Son principal conflit » → Titanomachie
  → « Ses frères » → Poséidon / Hadès
  → « Son symbole » → Foudre de Zeus
  → « Dans la culture populaire » → Percy Jackson / Marvel
Le Fil d'Ariane (fonctionnalité signature) enregistre et dessine ce parcours.
```

---

## 15. WIREFRAMES TEXTUELS PAGE PAR PAGE

> Convention : `[M]` = mobile, `[D]` = desktop. Les animations détaillées sont référencées au §18.

### 15.1 ACCUEIL `/`

**Objectif** : impressionner en 3 secondes, orienter en 10, faire cliquer en 30.

**Structure (ordre des sections)**

```
1. HERO (100 vh)
   ┌────────────────────────────────────────────────────────┐
   │  [ciel crépusculaire → bleu profond, nuages en couches]│
   │  [silhouette stylisée du mont Olympe, temple au sommet]│
   │                                                        │
   │             MYTHOLOGIE GRECQUE                         │
   │   Des dieux. Des héros. Des monstres.                  │
   │   Et des histoires qui vivent encore aujourd'hui.      │
   │                                                        │
   │   Tu les as croisés dans Percy Jackson, God of War     │
   │   ou Hades. Découvre ce que racontaient vraiment       │
   │   les Grecs — c'est encore plus fou.                   │
   │                                                        │
   │   [ COMMENCER L'EXPLORATION ]  [ Je connais déjà → ]   │
   │                                                        │
   │                 ⌄ (indicateur de scroll)                │
   └────────────────────────────────────────────────────────┘
   - CTA 1 → /decouvrir ; CTA 2 → /explorer
   - Éclair subtil toutes les ~12 s (désactivé en reduced-motion)
   - Parallaxe 3 couches au scroll / au mouvement de souris [D]

2. BANDEAU « TU LES CONNAIS DÉJÀ » (défilement horizontal)
   Noms + mini-pictos : Zeus · Méduse · Hercule* · Achille · Pégase · Hadès…
   *Survol/appui : « En grec, on dit Héraclès. Hercule, c'est le nom romain. »
   → Effet de reconnaissance immédiate.

3. LES PORTES D'ENTRÉE (bento grid)
   [D] grille 4 colonnes, cartes de tailles variées
   [M] liste verticale de grandes cartes, 2 visibles par écran
   Chaque carte : picto + titre à la 1re personne + 1 ligne + couleur de catégorie

4. « LE PANTHÉON EN UN COUP D'ŒIL »
   Rangée de 12 cartes divinités (carrousel [M], grille [D])
   → CTA « Voir les 14 divinités »

5. « UNE HISTOIRE AU HASARD » (mythe vedette, rotatif)
   Visuel antique (vase du domaine public) + accroche narrative 3 lignes
   → « Lire l'histoire (4 min) »

6. « MYTHE OU POP CULTURE ? » (teaser du mini-jeu)
   Une carte interactive : « Poséidon a un fils qui s'appelle Percy. Vrai ou faux ? »
   Réponse immédiate + « Jouer à la version complète »

7. « LE SAVIEZ-VOUS ? » (3 anecdotes en cartes retournables)

8. « TU PARLES GREC SANS LE SAVOIR » (mots)
   Panique ← Pan · Odyssée ← Odysseus · Mentor ← Mentor → CTA

9. ORACLE (bloc pleine largeur, sombre)
   « Tu ne sais pas par où commencer ? Consulte l'Oracle. » [ CONSULTER ]

10. FOOTER
```

**Responsive** : hero en 100 svh mobile, titre ~44 px ; bento → pile ; sections 4, 5, 8 en carrousels avec indicateur de position.
**Navigation sortante** : chaque section mène à un univers différent.

### 15.2 EXPLORER `/explorer`

**Objectif** : donner le choix sans paralyser.
```
H1 « Par où veux-tu commencer ? »
Sous-titre : « Il n'y a pas de mauvaise porte. »
[Grille des 10 portes — §8.2]
[Bloc Oracle]
[« Reprendre où tu en étais » — si historique local présent]
[Les 4 visualisations : Généalogie · Relations · Carte · Chronologie]
```
Interactions : survol → la carte se soulève, le picto s'anime ; filtres « J'ai 2 min / 10 min / 30 min » (COULD).

### 15.3 LA MYTHOLOGIE EN 5 MINUTES `/decouvrir`

**Objectif** : poser les fondations, ultra visuel, scrollytelling léger.
```
Barre de progression en haut (6 étapes)

ÉTAPE 1 — « C'est quoi, un mythe ? »
  1 phrase + illustration. Ni vrai ni faux : des récits pour expliquer le monde.
ÉTAPE 2 — « D'où ça vient ? »
  Mini-carte de la Grèce antique + frise (traditions orales → Homère, Hésiode
  vers le VIIIe–VIIe s. av. J.-C., dates données comme approximatives)
ÉTAPE 3 — « Au début, il y avait… le Chaos »
  Animation : Chaos → Gaïa → Ouranos → Titans → Olympiens (4 écrans)
ÉTAPE 4 — « Les 12 (enfin, à peu près) »
  Grille des Olympiens, chacun 1 ligne. Micro-copie : « La liste change selon
  les auteurs. Oui, même les dieux ont des problèmes de casting. »
ÉTAPE 5 — « Des héros, des monstres »
  3 héros + 3 monstres en cartes
ÉTAPE 6 — « Pourquoi on en parle encore ? »
  Mots, planètes, films, jeux. Compteur animé.

FIN : « Tu viens de faire le tour en 5 minutes. Et maintenant ? »
  [Les dieux] [Les histoires] [Teste-toi (quiz débutant, 5 questions)]
  → Badge « Premier pas sur l'Olympe » (si gamification active)
```

### 15.4 PANTHÉON `/dieux`

```
HERO court : « Le Panthéon » + phrase d'accroche
  « Quatorze personnalités, une seule famille. Accroche-toi. »

BARRE DE FILTRES (chips) : Tous · Olympiens · Enfers · Primordiaux & Titans
  Tri : Par génération · A→Z · Par domaine
  Vue : [Cartes] [Arbre →] [Galaxie →]

GRILLE DE GodCard
  [M] 2 colonnes compactes  [T] 3  [D] 4
  Carte : symbole (SVG), nom FR, nom grec translittéré, domaine en 3 mots,
  pastilles de relations (« frère de 4 dieux »), couleur d'accent individuelle
  Survol [D] : légère inclinaison 3D (≤ 6°), reflet doré sur le symbole,
  apparition de « Domaine · Symboles · Parents »
  Clic → fiche (transition partagée du symbole et du nom)

BLOC « Pourquoi Hadès n'est pas sur l'Olympe ? » (FactCard)
BLOC « Comprendre la famille » → /genealogie
```

### 15.5 FICHE D'UNE DIVINITÉ `/dieux/[slug]` — template de référence

```
BREADCRUMB : Dieux › Olympiens › Zeus

HERO DE FICHE
  [Gauche D / haut M] Œuvre antique du domaine public (statue, vase) avec
  légende + crédit, OU illustration originale
  [Droite D / bas M]
    ZEUS  (Ζεύς — Zeus)          ← nom grec en police d'accent
    Roi des dieux, maître du ciel et de la foudre.
    [Badges] Olympien · Ciel · Foudre · Justice
    Équivalent romain : Jupiter
    [Sélecteur de profondeur : Découvrir · Comprendre · Approfondir]
    [♡ Ajouter au Codex] (auto si gamification active) [⇪ Partager]

NAV LOCALE (sommaire collant)
  En bref · Pouvoirs · Symboles · Famille · Relations · Histoires · Conflits
  · Le saviez-vous · Culture pop · Sources

1. EN BREF (StatBlock, niveau 1)
   Domaine | Résidence | Arme/attribut | Animal | Parents | Conjoint(e) | Romain
2. SES POUVOIRS (cartes icônes, niveau 1–2)
3. SES SYMBOLES (galerie ObjectCard → liens vers /mondes/objets/...)
4. SA FAMILLE (mini-arbre centré sur l'entité, 3 générations)
   → « Voir l'arbre complet » (/genealogie?focus=zeus)
   Microcopy : « Attention, cette famille implique beaucoup de membres
   d'une même famille. »
5. SES RELATIONS (mini-galaxie : famille/amour/conflit/alliance, légende accessible)
6. SES HISTOIRES (MythCard ×3–6)
7. SES CONFLITS (Timeline verticale : Titanomachie, Gigantomachie, Typhon…)
8. UNE HISTOIRE, PLUSIEURS VERSIONS (VariantCompare — niveau 3)
   ex. « Où Zeus a-t-il grandi ? » mont Ida / mont Dicté
9. LE SAVIEZ-VOUS ? (FactCard ×2–3, partageables)
10. DANS LA CULTURE POPULAIRE (ComparisonCard ×n, niveau 4)
    Chaque carte : œuvre · ce qui est fidèle · ce qui change → page comparaison
11. SOURCES (SourceList : textes antiques + références modernes)
12. PROCHAINE PORTE (NextDoor ×3) + « Teste tes connaissances sur Zeus » (3 questions)
```

**Mobile** : hero empilé (visuel 45 vh), sommaire en pastille, sections en accordéons à partir de la section 5, barre d'action inférieure.
**Animations** : entrée du nom lettre par lettre (subtile), révélation des sections au scroll, tracé des liens du mini-arbre.

### 15.6 FICHE TITAN / PRIMORDIAL
Même template que 15.5, avec :
- Section « Avant les Olympiens » (positionnement sur la frise des âges)
- « Son destin après la Titanomachie » (ex. Atlas condamné à porter le ciel ; Cronos — versions : Tartare, ou roi des Îles des Bienheureux chez certains auteurs).

### 15.7 HÉROS `/heros` et `/heros/[slug]`

**Collection** : grandes cartes portrait (format affiche), 1 par ligne [M], 3 [D]. Tri par « âge héroïque » (Persée et Héraclès avant Achille et Ulysse).

**Fiche héros** (spécifique) :
```
HERO : nom, épithète (« le plus fort des hommes »), origine (parents divins/mortels)
EN BREF : Origine · Qualités · Faiblesse · Ennemis · Destin
SES AVENTURES : Timeline horizontale scrollable [D] / verticale [M]
   ex. Héraclès : les 12 travaux en grille 4×3 cliquable (chaque travail = carte)
SES QUALITÉS / SES FAIBLESSES : deux colonnes (« Ce qui le rend fort / Ce qui le perd »)
ALLIÉS & ENNEMIS : mini-graphe
SA MORT / SON DESTIN : traitement sobre
VERSIONS : ex. talon d'Achille — source tardive (Stace, Ier s. apr. J.-C.)
CULTURE POP : Disney, Marvel, jeux…
SOURCES · PROCHAINE PORTE
```

### 15.8 BESTIAIRE `/creatures` et `/creatures/[slug]`

**Collection** :
```
HERO sombre (fond abysse) : « Le Bestiaire » — « Certains sont des monstres.
  D'autres ont juste une très mauvaise réputation. »
FILTRES (chips multi-sélection, état dans l'URL)
  Type : Monstre · Animal mythique · Hybride · Peuple (Centaures, Cyclopes…)
  Danger : ● Faible ●● Moyen ●●● Extrême
  Habitat : Mer · Terre · Enfers · Ciel
  Affronté par : Héraclès · Persée · Thésée · Ulysse…
COMPTEUR : « 6 créatures correspondent »
GRILLE CreatureCard (format « carte de collection »)
  Recto : illustration/silhouette, nom, jauge de danger, type
  Survol/clic [D] ou bouton ↻ [M] : verso avec 3 stats + « vaincu par »
État vide : « Aucune créature… pour l'instant. Les Grecs avaient pourtant
  beaucoup d'imagination. » + bouton Réinitialiser
```

**Fiche créature** :
```
HERO : nom, type, jauge de danger (avec libellé texte, pas seulement couleur)
FICHE D'IDENTITÉ (StatBlock) : Apparence · Pouvoirs · Habitat · Parents · Vaincu(e) par
SON HISTOIRE (récit court)
UNE HISTOIRE, PLUSIEURS VERSIONS (crucial pour Méduse)
COMMENT L'AFFRONTER ? (ton ludique : comment le héros l'a vaincue)
CULTURE POP · SOURCES · PROCHAINE PORTE
```

### 15.9 BIBLIOTHÈQUE DES MYTHES `/mythes`

```
HERO : « Les grandes histoires » — « Trahisons, ruses, monstres et amours
  impossibles. Les séries n'ont rien inventé. »
FILTRES : Thème (Origines · Exploits · Amour · Châtiment · Guerre · Voyage)
          Durée de lecture (≤ 3 min · 3–6 min · 6+ min)
          Niveau
GRILLE MythCard : visuel, titre, accroche d'une ligne, durée, personnages (avatars)
SECTION « Par où commencer » : 4 mythes recommandés aux débutants
```

### 15.10 RÉCIT D'UN MYTHE `/mythes/[slug]`

Structure imposée par le brief : INTRODUCTION → CONTEXTE → HISTOIRE → PERSONNAGES → CE QU'IL FAUT RETENIR → INTERPRÉTATION → HÉRITAGE MODERNE.

```
HERO immersif : titre, accroche, durée de lecture, distribution (avatars cliquables)
BARRE DE PROGRESSION DE LECTURE (fine, dorée)

1. INTRODUCTION (2–3 phrases, ton narratif)
2. CONTEXTE (« Ce qu'il faut savoir avant ») — cartes des personnages et lieux
3. L'HISTOIRE — découpée en CHAPITRES (3–7)
   Chaque chapitre : titre, 2–4 paragraphes courts, 1 visuel ou citation courte
   d'une source antique (traduction du domaine public), illustration de transition
   [D] scrollytelling : la colonne visuelle change avec le chapitre
   [M] visuel en tête de chapitre
   Encadrés « Il existe plusieurs versions » insérés au bon endroit
4. LES PERSONNAGES (cartes cliquables)
5. CE QU'IL FAUT RETENIR (3 puces, idéal pour réviser)
6. INTERPRÉTATION (accordéon, niveau 3 : lectures possibles, présentées comme telles)
7. HÉRITAGE MODERNE (mots, œuvres, expressions)
8. SOURCES
9. « PROCHAINE HISTOIRE » (grand bloc type streaming) + mini-quiz 3 questions
```

### 15.11 MONDES `/mondes` (lieux) et carte `/mondes/carte`

```
/mondes : « Les mondes du mythe »
  3 strates visuelles verticales : CIEL (Olympe) / TERRE (Delphes, Troie, Labyrinthe,
  mer Égée) / SOUS-TERRE (Enfers, Champs Élysées, Tartare)
  [D] scroll vertical = descente du ciel vers les Enfers (signature visuelle forte)
  [M] même logique, sections empilées

/mondes/carte : carte illustrée originale (SVG) de la Méditerranée orientale
  - Lieux réels (Delphes, Troie, Crète/Cnossos, Ithaque) ET lieux mythiques
    (Olympe en tant que demeure divine, Enfers) — légende distinguant
    « lieu réel » / « lieu mythique » / « lieu réel associé à un mythe »
  - Couche « Voyages » : itinéraires d'Ulysse et des Argonautes, avec mention
    « les géographies proposées sont des reconstitutions débattues »
  - Zoom/pan au doigt ; alternative accessible : liste des lieux
Fiche lieu : description, ce qui s'y passe, qui y vit, mythes associés,
  réalité archéologique (si lieu réel : ex. Troie / Hisarlık), sources
```

### 15.12 OBJETS & SYMBOLES `/mondes/objets`
```
« Vitrine » : grille de type musée (fond sombre, objets éclairés)
ObjectCard : pictogramme SVG original, nom, propriétaire, pouvoir
Fiche objet : origine (ex. foudre forgée par les Cyclopes), pouvoirs,
  propriétaires successifs, mythes, plusieurs versions (ex. l'égide :
  bouclier ou peau de chèvre selon les sources), héritage (ex. « boîte de
  Pandore » : chez Hésiode, c'est une jarre ; la « boîte » vient d'une
  traduction de la Renaissance)
```

### 15.13 ARBRE GÉNÉALOGIQUE `/genealogie`

**Desktop** :
```
Canvas SVG zoomable/déplaçable, générations en bandes horizontales :
  Primordiaux → Titans → Olympiens → Enfants des Olympiens → Héros
Contrôles : [Recentrer] [Zoom +/-] [Rechercher un personnage]
  [Afficher : Unions · Enfants hors mariage · Versions alternatives]
Clic sur un nœud : mise en surbrillance des parents/enfants, panneau latéral
  (carte d'identité + lien fiche)
Indicateur de variantes : lien en pointillé = « filiation selon certaines sources »
  (ex. Aphrodite née d'Ouranos chez Hésiode / fille de Zeus et Dioné chez Homère)
```
**Mobile** (vue « focus ») :
```
Un personnage au centre :
   ┌ Parents (2 cartes) ┐
   │   [ PERSONNAGE ]   │ ← frères/sœurs en carrousel horizontal
   └ Enfants (liste)    ┘
Toucher un parent/enfant = il devient le centre (transition animée).
Bouton « Voir où je suis » : mini-plan de l'arbre.
```
**Accessibilité** : alternative textuelle complète sous forme de listes imbriquées (`<ul>` arborescentes) et navigation clavier nœud par nœud.

### 15.14 GALAXIE DES RELATIONS `/relations` (SHOULD)
```
Graphe radial centré sur un personnage (par défaut Zeus).
Liens colorés ET stylés (jamais la couleur seule) :
  Famille — trait plein   | Amour — trait ondulé
  Conflit — trait en zigzag | Alliance — trait double | Parenté indirecte — pointillé
Filtres par type de lien ; slider « degrés de séparation » (1–3).
Clic = nouveau centre. Mode « Chemin » : « Comment Persée est-il relié à Méduse ? »
  → affiche le plus court chemin (fonctionnalité virale).
Mobile : liste groupée par type de relation + mini-graphe statique.
```

### 15.15 POP CULTURE `/pop-culture`

```
HERO : « MYTHE OU POP CULTURE ? »
  « Tu connais déjà la mythologie grecque. Mais laquelle ? »
SÉLECTEUR D'ŒUVRES (grandes tuiles typographiques, sans logos ni visuels officiels)
  Percy Jackson · Marvel · God of War · Hades · Assassin's Creed Odyssey ·
  Wonder Woman · Blood of Zeus · Hercule (Disney) · Romans · Autres
MINI-JEU « Mythe ou fiction ? » (intégré)
« 5 choses que Percy Jackson a changées » (contenu viral)
« Où as-tu déjà rencontré la mythologie ? » → page dédiée (vie moderne : mots,
  marques, astronomie, psychologie, architecture, art)
AVERTISSEMENT permanent (discret, en tête) :
  « Ici, on compare. Les œuvres modernes sont des fictions inspirées des mythes,
  pas des sources. »
```

### 15.16 PAGE ŒUVRE `/pop-culture/oeuvres/[slug]`
```
Présentation factuelle de l'œuvre (auteur/studio, date, support) — texte uniquement
« Comment cette œuvre utilise la mythologie » (3 puces)
Liste des comparaisons (ComparisonCard)
Jauge globale « Fidélité » — à éviter ou à nuancer : préférer « Ce qui est
  repris / Ce qui est réinventé » (une adaptation n'a pas à être fidèle)
```

### 15.17 PAGE COMPARAISON `/pop-culture/comparaisons/[slug]`

Structure imposée (§23 du brief) :
```
Titre : « Méduse — Mythe vs Percy Jackson »
Vue en DEUX COLONNES [D] / ONGLETS ou bascule [M]
  ┌─────────────────────────┬─────────────────────────┐
  │ 🏺 DANS LE MYTHE         │ 📖 DANS PERCY JACKSON    │
  │ (sources citées)         │ (œuvre, tome/épisode)    │
  └─────────────────────────┴─────────────────────────┘
CE QUI CHANGE (liste avec pictos : ✚ ajouté · ✎ modifié · ✕ supprimé · = conservé)
POURQUOI ? (hypothèses narratives, présentées comme interprétation)
CTA : fiche Méduse · autres comparaisons Percy Jackson · quiz Mythe ou fiction
```

### 15.18 MOTS QUE NOUS UTILISONS ENCORE `/pop-culture/mots`
```
HERO : « Tu parles grec sans le savoir »
GRILLE WordCard (retournables) :
  Recto : le mot moderne (« PANIQUE »)
  Verso : origine (« Pan, dieu des bergers, dont le cri semait la terreur ») +
  lien vers le personnage + exemple d'usage
Filtres : Expressions (talon d'Achille, boîte de Pandore, travail de Titan…) ·
  Mots courants (panique, mentor, musique, chimère…) · Adjectifs (herculéen,
  narcissique, olympien…)
Bloc « Dans d'autres domaines » : médecine (atlas, hypnose ← Hypnos),
  psychologie (complexe d'Œdipe), marques (citées sans logos)
```

### 15.19 LE CIEL DES DIEUX `/pop-culture/ciel` (V2)
```
Fond étoilé (CSS/SVG léger)
Système solaire : noms romains des planètes → équivalents grecs
  (Jupiter = Zeus, Mars = Arès…)
Lunes : Jupiter (Io, Europe, Ganymède, Callisto), Mars (Phobos et Deimos, fils
  d'Arès), Pluton (Charon)
Constellations : Persée, Andromède, Cassiopée, Pégase, Orion (versions)
Chaque élément lié à la fiche du personnage
```

### 15.20 QUIZ `/quiz`, `/quiz/[slug]`, résultat
```
/quiz : grille de quiz (titre, nb questions, durée, difficulté, meilleur score local)
  Mis en avant : Mythe ou fiction ? · Quel dieu es-tu ? · Les Olympiens · Monstres

/quiz/[slug] (plein écran, une question par écran)
  Barre de progression · numéro « 3/10 »
  Question (grande typo) + visuel éventuel
  Réponses : boutons larges (≥ 48 px), touches 1–4 au clavier
  Après réponse : feedback immédiat (✓/✕ + couleur + texte), explication
  courte (1–2 phrases) + lien « En savoir plus » (ouvre dans un panneau, sans
  quitter le quiz) → [Question suivante]

Résultat :
  Score animé (compteur) + palier :
    0–20 %  « Tu viens d'arriver sur l'Olympe. »
    20–50 % « Tu commences à connaître les dieux. »
    50–80 % « Les Olympiens commencent à te respecter. »
    80–100 % « Bienvenue parmi les grands connaisseurs. »
  Récapitulatif des erreurs → liens vers les fiches correspondantes
  [Partager mon score] (image OG générée) [Rejouer] [Quiz suivant]
```

### 15.21 CODEX `/codex` (SHOULD)
```
« Ton Codex » — « 23 / 118 découvertes »
Onglets par catégorie ; entrées découvertes en couleur, autres en silhouettes
  « ??? » avec un indice (« Un dieu forgeron »)
Badges obtenus / à obtenir
Bouton « Effacer ma progression » + mention « stockée uniquement sur cet appareil »
```

### 15.22 RECHERCHE `/recherche`
Page de résultats complète (version non-modale de la palette, utile pour SEO interne et liens partageables) : groupes par type, filtres, suggestions si zéro résultat.

### 15.23 SOURCES & MÉTHODOLOGIE `/sources-et-methodologie`
```
1. « Pourquoi les mythes ont plusieurs versions » (explication simple)
2. Nos 3 couches : Source antique / Interprétation / Adaptation moderne (légende des pictos)
3. Nos sources antiques principales (liste avec dates approximatives et liens
   vers traductions accessibles)
4. Nos références modernes
5. Comment nous vérifions (processus de relecture)
6. Images : d'où elles viennent, licences
7. Signaler une erreur (formulaire simple ou lien mail)
```

### 15.24 PAGES LÉGALES & 404
- **Mentions légales**, **Confidentialité** (analytics sans cookies, localStorage expliqué), **Crédits** (liste générée automatiquement depuis le registre des médias).
- **404** : « Tu t'es perdu dans le Labyrinthe. » + recherche + Oracle + 3 liens populaires. Petite animation de fil d'Ariane qui se déroule.

---

# PARTIE C — DESIGN

## 16. DIRECTION ARTISTIQUE

### 16.1 Concept : « Marbre & Abysse »
Deux pôles qui structurent toute l'identité :

- **Le jour — Marbre & Égée** : blanc cassé lumineux, bleu de la mer Égée, ciel. Pour la lecture, les fiches, le savoir. Calme, aéré, éditorial.
- **La nuit — Abysse & Or** : bleu nuit profond presque noir, or parcimonieux, lueurs. Pour les moments d'émerveillement : hero, Oracle, Enfers, bestiaire, quiz.

Le passage de l'un à l'autre (ciel → mer → profondeurs) devient un **langage narratif** : on « monte » vers l'Olympe, on « descend » aux Enfers.

### 16.2 Mots-clés
**Lumineux · Éditorial · Mythique · Joueur · Précis.**
Références d'ambiance (à interpréter, jamais copier) : photographie de statues en lumière rasante, céramique à figures noires et rouges (aplats, silhouettes, frises), interfaces de jeux d'action modernes (codex, cartes), magazines culturels premium.

### 16.3 Système graphique original
- **Le trait de céramique** : pictogrammes et illustrations construits en aplats + contours, inspirés des vases à figures rouges/noires, mais **géométrisés et modernes**. Cohérent, reproductible, léger (SVG), sans dépendance à un illustrateur pour le MVP.
- **La frise** : motif de méandre (grecque) utilisé **uniquement comme séparateur fin** ou indicateur de progression — jamais en bordure omniprésente.
- **Le fil d'or** : une ligne dorée fine qui relie les éléments (connexions, progression, Fil d'Ariane). C'est la signature visuelle du concept « réseau ».
- **Les fragments** : photos d'œuvres antiques détourées présentées comme des fragments flottants, avec ombre portée douce.
- **Le grain** : léger bruit (SVG `feTurbulence` ou PNG 2 Ko en tuile) sur les fonds sombres pour éviter l'effet « plat numérique ».

### 16.4 Ce qu'on évite
Colonnes doriques partout, papyrus, police « Trajan de péplum », beige/marron dominant, textures vieillies, dorures excessives, effets 3D gadgets.

### 16.5 Logo (proposition)
Monogramme : une **pelote dont le fil se déroule** et dessine en une seule ligne continue la lettre **A** (ou un méandre simplifié). Le fil du logo se prolonge dans l'interface : c'est le même trait doré que celui du Fil de progression. Wordmark « Le Fil d'Ariane » en Fraunces, « Fil d'Ariane » en graisse forte.

---

## 17. DESIGN SYSTEM

> Tous les tokens sont exposés en **variables CSS** (source unique) et consommés par Tailwind v4 via `@theme`. Les noms sont sémantiques (usage) au-dessus de primitives (valeurs).

### 17.1 Palette — primitives

| Token | Hex | Usage |
|---|---|---|
| `abyss-950` | `#070D16` | Fond nuit le plus profond |
| `abyss-900` | `#0B1626` | Fond nuit principal |
| `abyss-800` | `#12223A` | Surfaces sur fond nuit |
| `aegean-800` | `#0F3A63` | Bleu profond (titres sur clair, fonds) |
| `aegean-600` | `#1B5E96` | Liens, actions primaires |
| `aegean-500` | `#2A7AB8` | États survol, accents |
| `aegean-300` | `#7FB8E0` | Bleu ciel, liens sur fond nuit |
| `aegean-100` | `#DDEDF8` | Fonds teintés légers |
| `marble-50` | `#FAF8F4` | Fond jour principal (blanc cassé) |
| `marble-100` | `#F2EEE6` | Surfaces, cartes sur fond jour |
| `marble-200` | `#E4DED2` | Bordures douces |
| `stone-500` | `#7A7468` | Texte secondaire décoratif (grandes tailles seulement) |
| `stone-700` | `#4A463F` | Texte secondaire |
| `ink-900` | `#14171C` | Texte principal (jamais noir pur) |
| `gold-300` | `#E8C77A` | Or sur fond nuit (texte/lueurs) |
| `gold-500` | `#C9993A` | Or décoratif (traits, icônes, jamais du texte sur clair) |
| `gold-700` | `#8A6420` | Or lisible sur fond clair |

### 17.2 Couleurs de catégorie (identification des univers)
Chaque catégorie a **une teinte claire (fond) et une teinte foncée (texte/icône)**. Utilisées en accent (pastilles, bordures, pictos), jamais en grands aplats saturés.

| Catégorie | Foncé | Clair | Symbolique |
|---|---|---|---|
| Dieux | `#8A6420` (or) | `#F6ECD6` | Lumière divine |
| Titans & primordiaux | `#5B4B8A` (améthyste) | `#ECE8F6` | Cosmos, origines |
| Héros | `#9A4E1C` (bronze) | `#F7E7DA` | Armes de bronze |
| Créatures | `#1F6F5C` (vert-de-gris) | `#DDF1EB` | Écailles, profondeurs |
| Mythes | `#7A2E4D` (pourpre de Tyr) | `#F5E1E9` | Récit, tragédie |
| Mondes / lieux | `#55642A` (olivier) | `#ECF0DD` | Terre grecque |
| Pop culture | `#3B4FC4` (indigo électrique) | `#E3E7FB` | Écrans, modernité |

### 17.3 Couleurs sémantiques
| Token | Valeur | Usage |
|---|---|---|
| `success` | `#1E7A4F` | Bonne réponse |
| `error` | `#B3261E` | Mauvaise réponse |
| `warning` | `#9A6700` | Avertissement |
| `info` | `aegean-600` | Info |

**Couches éditoriales** (utilisées partout) :
| Couche | Picto | Couleur |
|---|---|---|
| 🏺 Source antique | amphore | `gold-700` |
| 🔍 Interprétation | loupe | `aegean-600` |
| 🎬 Adaptation moderne | écran | `#3B4FC4` |

### 17.4 Rôles sémantiques (thème clair / sombre)

| Rôle | Clair | Sombre |
|---|---|---|
| `--bg` | marble-50 | abyss-900 |
| `--surface` | #FFFFFF | abyss-800 |
| `--surface-muted` | marble-100 | #172A45 |
| `--border` | marble-200 | #24395A |
| `--text` | ink-900 | #EEF2F7 |
| `--text-muted` | stone-700 | #A9B6C8 |
| `--link` | aegean-600 | aegean-300 |
| `--accent` | gold-700 | gold-300 |
| `--focus-ring` | aegean-500 | gold-300 |

Thème par défaut : **suit le système** ; le hero, l'Oracle, le bestiaire et les Enfers sont **toujours** en ambiance nuit (sections « immersives »), quel que soit le thème.

**Règle de contraste** : texte courant ≥ 4.5:1, grands titres et éléments d'interface ≥ 3:1 (WCAG 2.2 AA). Toutes les paires texte/fond sont vérifiées automatiquement en CI (§38).

**Contrastes mesurés (v1.0)** :

| Paire | Ratio | Verdict |
|---|---|---|
| ink-900 / marble-50 | 16.9 | AAA |
| stone-700 / marble-50 | 8.8 | AAA |
| aegean-600 / marble-50 (liens) | 6.4 | AA |
| blanc / aegean-600 (bouton primaire) | 6.8 | AA |
| gold-700 / marble-50 | 5.0 | AA |
| texte sombre / abyss-900 | 16.1 | AAA |
| gold-300 / abyss-900 | 11.1 | AAA |
| Couleurs de catégorie foncé / clair | 4.6 – 7.2 | AA |
| success / error / warning sur blanc | 5.3 / 6.5 / 4.9 | AA |
| stone-500 / marble-50 | 4.4 | **Grands textes uniquement** (≥ 24 px ou 19 px gras) |

### 17.5 Gradients
| Token | Définition | Usage |
|---|---|---|
| `grad-dawn` | `linear-gradient(180deg, #0B1626 0%, #0F3A63 55%, #C9993A33 100%)` | Hero (aube sur l'Olympe) |
| `grad-aegean` | `linear-gradient(135deg, #1B5E96, #2A7AB8 60%, #7FB8E0)` | Bandeaux, CTA secondaires |
| `grad-underworld` | `radial-gradient(ellipse at 50% 0%, #12223A, #070D16 70%)` | Enfers, bestiaire |
| `grad-gold-line` | `linear-gradient(90deg, transparent, #C9993A, transparent)` | Fil d'or, séparateurs |
| `grad-oracle` | `radial-gradient(circle, #E8C77A40, transparent 60%)` | Lueur de l'Oracle |

### 17.6 Typographie

| Rôle | Police | Licence | Pourquoi |
|---|---|---|---|
| **Display** (titres) | **Fraunces** (variable : graisse, optique, « softness ») | SIL OFL | Serif expressive et moderne, chaleur éditoriale, très lisible en grand ; ses axes variables permettent des titres « sculptés » sans charger plusieurs fichiers. |
| **Texte** (corps, UI) | **Inter** (variable) | SIL OFL | Lisibilité écran exceptionnelle, chiffres tabulaires, excellente couverture de langues (grec inclus) pour l'internationalisation. |
| **Accent antique** (ponctuel) | **Cinzel** | SIL OFL | Capitales inspirées des inscriptions romaines/grecques. **Uniquement** : noms en surtitre, numéros de chapitres, badges. Jamais de texte courant. |
| Noms grecs (Ζεύς) | Inter (couverture grecque) | — | Affiche les noms en alphabet grec sans police supplémentaire. |

Alternative au choix si tu préfères un display sans empattement plus « jeu vidéo » : *Space Grotesk* ou *Syne* (OFL). Toutes **auto-hébergées** via `next/font` (aucun appel à Google au runtime, meilleur pour la vie privée et la performance), avec `font-display: swap` et sous-ensembles (latin, latin-ext, grec).

**Échelle typographique fluide** (`clamp(min, préféré, max)`, base 16 px mobile → 18 px desktop) :

| Token | Mobile → Desktop | Police / graisse | Interlignage | Usage |
|---|---|---|---|---|
| `display-xl` | 44 → 96 px | Fraunces 600, opsz max | 0.95 | Hero |
| `display-l` | 36 → 64 px | Fraunces 600 | 1.0 | Titre de fiche |
| `h1` | 32 → 48 px | Fraunces 600 | 1.1 | Titres de page |
| `h2` | 26 → 36 px | Fraunces 600 | 1.15 | Sections |
| `h3` | 20 → 24 px | Inter 650 | 1.25 | Sous-sections, titres de cartes |
| `h4` | 17 → 18 px | Inter 650 | 1.3 | Petits titres |
| `body-l` | 18 → 20 px | Inter 400 | 1.6 | Récits (mythes) |
| `body` | 16 → 18 px | Inter 400 | 1.6 | Texte courant |
| `body-s` | 14 → 15 px | Inter 400 | 1.5 | Légendes |
| `label` | 13 → 14 px | Inter 600, +0.02em | 1.3 | Boutons, chips |
| `overline` | 12 → 13 px | Cinzel 600, +0.12em, MAJ | 1.2 | Surtitres |

Règles : longueur de ligne 60–75 caractères ; jamais de texte justifié ; jamais de texte courant en italique long ; pas de texte < 14 px sauf mentions légales.

### 17.7 Spacing system
Base **4 px**, échelle :
`0 · 1 (4) · 2 (8) · 3 (12) · 4 (16) · 5 (20) · 6 (24) · 8 (32) · 10 (40) · 12 (48) · 16 (64) · 20 (80) · 24 (96) · 32 (128)`

| Contexte | Mobile | Desktop |
|---|---|---|
| Marge latérale de page | 16 px | 32–64 px (conteneur max 1280 px ; texte max 720 px) |
| Espacement entre sections | 64 px | 120 px |
| Padding de carte | 16 px | 24 px |
| Gap de grille | 12 px | 24 px |
| Zone tactile minimale | 44 × 44 px (cible 48) | — |

### 17.8 Border radius
| Token | Valeur | Usage |
|---|---|---|
| `radius-xs` | 4 px | Chips, badges |
| `radius-s` | 8 px | Inputs, boutons |
| `radius-m` | 14 px | Cartes |
| `radius-l` | 24 px | Grandes cartes, modales |
| `radius-arch` | `999px 999px 14px 14px` | **Signature** : cartes portrait en forme d'arche (niche de temple) pour les divinités et héros |
| `radius-full` | 999 px | Avatars, boutons ronds |

### 17.9 Ombres & élévation
| Token | Clair | Sombre |
|---|---|---|
| `shadow-1` | `0 1px 2px rgb(20 23 28 / .06), 0 1px 1px rgb(20 23 28 / .04)` | bordure 1 px `--border` (pas d'ombre) |
| `shadow-2` | `0 6px 16px -4px rgb(15 58 99 / .12)` | `0 0 0 1px #24395A, 0 8px 24px -8px #000a` |
| `shadow-3` | `0 18px 40px -12px rgb(15 58 99 / .22)` | `0 24px 48px -16px #000c` |
| `glow-gold` | `0 0 24px rgb(201 153 58 / .35)` | idem | Survol de cartes divines, Oracle |

Les ombres sont teintées de bleu (`aegean-800`), jamais grises neutres → cohérence avec la palette.

### 17.10 Composants de base (atomes)

**Boutons**
| Variante | Style | Usage |
|---|---|---|
| `primary` | fond `aegean-600`, texte blanc ; sur nuit : fond `gold-300`, texte `abyss-950` | Action principale (1 par écran) |
| `secondary` | bordure 1.5 px `--text`, fond transparent | Action secondaire |
| `ghost` | texte seul + soulignement animé au survol | Liens d'action |
| `oracle` | fond nuit, bordure dorée, lueur animée | Surprends-moi / Oracle uniquement |
| `icon` | 44 × 44, rond | Actions iconographiques (toujours avec `aria-label`) |
Tailles : `sm` 36 px · `md` 44 px · `lg` 52 px. États : survol, actif (scale .98), focus (anneau 2 px + offset 2 px), désactivé (opacité .45 + `aria-disabled`), chargement (spinner + texte conservé).

**Cards** : base commune `Card` (surface, radius-m, shadow-1 → shadow-2 au survol, bordure 1 px, padding 16/24) + variantes métiers (§34).

**Badges / Chips**
- `Badge` : catégorie (couleur de catégorie, picto + texte), couche éditoriale, niveau, danger.
- `Chip` (filtre) : sélectionnable, `aria-pressed`, coche visible quand actif.

**Inputs** : hauteur 48 px, radius-s, bordure 1.5 px, label toujours visible (pas de placeholder seul), message d'erreur sous le champ avec icône.

**Navigation** : voir §13 ; liens actifs signalés par fil doré + `aria-current="page"`.

**Modales / feuilles** : desktop = modale centrée (radius-l, max 640 px) ; mobile = **feuille du bas** (bottom sheet) glissable. Piège de focus, fermeture `Échap`, retour du focus à l'élément déclencheur, fond assombri `abyss-950 / 60 %`.

**Tooltips / aperçus** : apparition 150 ms après survol (desktop) ou au focus clavier ; sur mobile, remplacés par un bouton ⓘ qui ouvre une feuille. Jamais d'information exclusive dans un tooltip.

**Accordéons** : `<details>/<summary>` stylés (natif = accessible + fonctionne sans JS), icône chevron animée.

**Onglets** : pattern WAI-ARIA Tabs (flèches clavier).

### 17.11 Iconographie
- **Lucide** (licence ISC) pour les icônes d'interface (recherche, menu, flèches, partage…), trait 1.75 px.
- **Pictogrammes mythologiques originaux** (foudre, trident, chouette, lyre, caducée, casque, arc, épi de blé, vigne, marteau, coquillage, paon…) dessinés en SVG dans le style « trait de céramique », grille 24 px, même épaisseur que Lucide pour cohérence.

---

## 18. STRATÉGIE D'ANIMATION

### 18.1 Principe
> « On doit ressentir l'animation avant de la remarquer. »

Toute animation doit **guider l'attention, donner du feedback, ou raconter**. Sinon, elle est supprimée.

### 18.2 Tokens de mouvement
| Token | Valeur | Usage |
|---|---|---|
| `dur-instant` | 100 ms | Feedback de pression |
| `dur-fast` | 180 ms | Survols, chips |
| `dur-base` | 280 ms | Ouvertures, cartes |
| `dur-slow` | 480 ms | Transitions de page, révélations |
| `dur-epic` | 900 ms | Hero, Oracle (rare) |
| `ease-out` | `cubic-bezier(.22,1,.36,1)` | Entrées |
| `ease-in-out` | `cubic-bezier(.65,0,.35,1)` | Déplacements |
| `spring-soft` | Motion spring (stiffness 260, damping 30) | Cartes, layout |
| `stagger` | 40–60 ms | Apparitions en cascade (max 8 éléments) |

### 18.3 Catalogue des animations

| Animation | Où | Technique | Reduced-motion |
|---|---|---|---|
| Apparition au scroll (fondu + translation 16 px) | Sections, cartes | CSS `animation-timeline: view()` si supporté, sinon Motion `whileInView` (une seule fois) | Apparition directe |
| Parallaxe 3 couches | Hero accueil, hero Mondes | `transform` piloté par scroll (Motion `useScroll`) ; [D] léger suivi du curseur | Image fixe |
| Nuages qui dérivent | Hero | CSS `@keyframes` sur `transform`, 60–90 s | Arrêt |
| Éclair subtil | Hero | flash d'opacité sur un calque SVG, toutes les ~12 s, jamais plus de 3 flashs/s (sécurité photosensibilité) | **Désactivé** |
| Particules (poussière dorée) | Hero, Oracle | Canvas 2D léger, ≤ 40 particules, pause hors écran et onglet caché | Désactivé |
| Hover card (inclinaison ≤ 6° + reflet) | GodCard, CreatureCard [D] | `transform: perspective rotateX/Y` | Pas d'inclinaison |
| Retournement de carte | CreatureCard, WordCard, FactCard | `rotateY` 3D | Fondu croisé |
| Transition partagée (symbole + nom de la carte vers la fiche) | Collection → fiche | **View Transitions API** (natif, progressif) ; repli fondu | Fondu simple |
| Tracé des liens | Mini-arbre, galaxie, Fil d'Ariane | SVG `stroke-dashoffset` | Lignes affichées directement |
| Compteur de score | Résultat quiz | Interpolation numérique | Valeur finale |
| Barre de progression de lecture | Mythes | `scaleX` lié au scroll | Conservée (informative) |
| Micro-interactions (boutons, chips, ♡) | Partout | CSS | Conservées sans mouvement (couleur seulement) |
| Oracle | Bouton Surprends-moi | Lueur pulsée + fumée (SVG filtré) 900 ms puis navigation | Navigation directe |

### 18.4 Règles de performance
- N'animer que `transform`, `opacity`, `filter` léger, `clip-path` ponctuel. **Jamais** `width/height/top/left`.
- Pas d'animation infinie dans le viewport hors hero/Oracle ; tout s'arrête hors écran (`IntersectionObserver`) et quand l'onglet est caché.
- Motion chargé via `LazyMotion` + `domAnimation` (sous-ensemble léger) ; `domMax` seulement sur les pages qui ont besoin des animations de layout.
- Sur appareils modestes (`navigator.hardwareConcurrency ≤ 4` ou `deviceMemory ≤ 4`), désactivation des particules et de la parallaxe.
- `prefers-reduced-motion: reduce` → mouvements supprimés, fondus courts conservés ; **plus un réglage manuel** « Réduire les animations » dans le footer (stocké localement).

---

## 19. STRATÉGIE RESPONSIVE

### 19.1 Mobile-first, breakpoints
| Nom | Largeur | Cible |
|---|---|---|
| base | 0–479 | Smartphones |
| `sm` | ≥ 480 | Grands smartphones |
| `md` | ≥ 768 | Tablettes portrait |
| `lg` | ≥ 1024 | Tablettes paysage, petits laptops |
| `xl` | ≥ 1280 | Laptops |
| `2xl` | ≥ 1536 | Grands écrans (conteneur plafonné, décor étendu) |

Les composants complexes utilisent les **container queries** (une carte s'adapte à la colonne dans laquelle elle est, pas à l'écran).

### 19.2 Adaptations clés
| Élément | Mobile | Desktop |
|---|---|---|
| Navigation | Burger plein écran + barre d'action basse | Barre horizontale + méga-menus |
| Hero | 100 svh, 1 couche de parallaxe max | 3 couches + suivi curseur |
| Grilles de cartes | 1–2 colonnes, carrousels avec snap | 3–4 colonnes |
| Fiche | Sections en accordéon après la 4e | Sommaire latéral collant |
| Arbre généalogique | Vue « focus » | Canvas zoomable |
| Galaxie | Liste groupée + mini-graphe | Graphe interactif |
| Comparaisons | Onglets Mythe / Œuvre | Deux colonnes |
| Carte des mondes | Pan/zoom tactile + liste | Survols + panneau latéral |
| Quiz | Plein écran, réponses en bas (pouce) | Centré, max 720 px |
| Tooltips | Feuilles du bas | Popovers |

### 19.3 Contraintes mobiles
- Hauteurs en `svh/dvh` (pas `vh`) pour la barre d'adresse mobile.
- `safe-area-inset-*` respectées (encoches).
- Pas de survol requis ; gestes doublés par des boutons (accessibilité).
- Images servies à la taille d'affichage réelle (`sizes` précis).

---

## 20. ACCESSIBILITÉ

**Objectif : WCAG 2.2 niveau AA** (référence européenne EN 301 549 / RGAA en France).

| Domaine | Exigences |
|---|---|
| **Structure** | Un seul `h1` par page, hiérarchie de titres sans saut, landmarks (`header`, `nav`, `main`, `footer`, `aside`), lien « Aller au contenu » en premier élément focusable. |
| **Clavier** | Tout est utilisable au clavier : cartes, filtres, quiz (touches 1–4, Entrée), graphes (flèches pour naviguer entre nœuds), carte (liste alternative). Ordre de focus logique. Aucun piège sauf modales (avec sortie Échap). |
| **Focus** | Anneau visible 2 px, contraste ≥ 3:1, jamais `outline: none` sans remplacement. |
| **Contraste** | Texte ≥ 4.5:1 ; grands textes et composants ≥ 3:1 ; vérification sur fonds photos (voile de dégradé sous le texte). |
| **Couleur** | Jamais seule porteuse d'information (danger = jauge + libellé ; relations = couleur + style de trait + légende ; quiz = icône ✓/✕ + texte). |
| **Images** | `alt` descriptif pour les œuvres (« Amphore attique à figures noires représentant Héraclès et le lion de Némée ») ; `alt=""` pour le décoratif. Champ `alt` obligatoire dans le registre des médias. |
| **Visualisations** | Arbre et galaxie : équivalent textuel structuré (listes imbriquées / tableaux), `role="tree"` avec `aria-expanded` pour la version interactive de l'arbre. |
| **Mouvement** | `prefers-reduced-motion` + bouton manuel ; aucun flash > 3/s ; pas de lecture automatique de son. |
| **Lecteurs d'écran** | `aria-live="polite"` pour les résultats de filtres (« 6 créatures »), le feedback de quiz, les badges obtenus. Noms grecs annotés `lang="grc"` (ou `el` selon support). |
| **Texte** | Zoom 200 % sans perte ; espacement de texte personnalisable sans casse ; pas de texte dans les images. |
| **Formulaires** | Labels visibles, erreurs explicites, `autocomplete` pertinents. |
| **Langue** | `lang` sur `<html>` ; passages en langue étrangère balisés. |
| **Sans JS** | Contenu des fiches et mythes entièrement lisible sans JavaScript (rendu statique). Les interactions dégradent proprement (accordéons natifs, liens réels). |

Tests : axe-core automatisé en CI + tests manuels lecteur d'écran (NVDA + Firefox, VoiceOver iOS) à chaque phase majeure.

---

# PARTIE D — CONTENU

## 21. APPROCHE ÉDITORIALE & TON

### 21.1 Le ton en une phrase
> **Un ami cultivé et drôle qui te raconte une histoire incroyable — et qui te dit d'où il la tient.**

### 21.2 Les règles de rédaction
1. **Commencer par l'accroche, pas par la définition.**
   ❌ « Zeus est une divinité indo-européenne dont les attributs… »
   ✅ « Zeus est le roi des dieux de l'Olympe. Son arme emblématique ? La foudre. Mais son histoire est bien plus compliquée que ça… »
2. **Phrases courtes** (≤ 20 mots en moyenne), voix active, tutoiement.
3. **Un paragraphe = une idée**, 4 lignes max sur mobile.
4. **L'humour vient des faits**, pas de blagues plaquées (la famille divine est naturellement absurde ; il suffit de le pointer).
5. **Jamais infantilisant** : pas de « Super ! », pas d'emojis dans le texte courant, pas de diminutifs.
6. **Jamais universitaire dans la forme** : pas de jargon sans explication immédiate (« chthonien — lié au monde souterrain »).
7. **Toujours marquer l'incertitude** : « selon Hésiode », « dans la version la plus connue », « certains auteurs racontent que… ».
8. **Noms** : forme française usuelle en premier (Héraclès), puis translittération/grec en annexe ; équivalent romain signalé (Hercule) pour faire le lien avec la pop culture.

### 21.3 Les 3 couches (obligatoires dans le modèle de données)
| Couche | Définition | Formulation type |
|---|---|---|
| 🏺 **Mythe / tradition antique** | Ce que racontent les sources grecques (et latines, signalées comme telles) | « Chez Hésiode… », « Selon la tradition… » |
| 🔍 **Interprétation** | Lectures d'historiens, de philosophes, d'anthropologues | « Certains historiens y voient… », « Une lecture possible… » |
| 🎬 **Adaptation moderne** | Ce qu'une œuvre contemporaine fait du mythe | « Dans Percy Jackson, Rick Riordan imagine que… » |

**Règle d'or** : une information de couche 🎬 n'apparaît **jamais** dans les blocs « En bref », « Famille », « Pouvoirs » d'une fiche. Elle vit uniquement dans « Dans la culture populaire » et les pages de comparaison.

### 21.4 Gabarit de rédaction d'une fiche (pour les rédacteurs)
| Bloc | Longueur | Niveau |
|---|---|---|
| Rôle en une ligne | ≤ 12 mots | 1 |
| En bref | 5–7 champs | 1 |
| Intro | 40–70 mots | 1 |
| Pouvoirs / Symboles | 3–6 éléments × 1 phrase | 1–2 |
| Histoires | 3–6 liens + 1 phrase chacun | 2 |
| Versions | 1–3 encadrés × 60–120 mots | 3 |
| Le saviez-vous | 2–3 × ≤ 35 mots | 1–4 |
| Culture pop | 1–4 cartes | 4 |
| Sources | ≥ 2 sources antiques quand elles existent | 3 |

### 21.5 Gabarit d'un récit (mythes)
Intro (≤ 60 mots) → Contexte (cartes) → Histoire en chapitres (300–1 200 mots au total selon le mythe, chapitres de 100–250 mots) → Personnages → À retenir (3 puces) → Interprétation (≤ 200 mots) → Héritage (≤ 150 mots) → Sources.

### 21.6 Charte des contenus sensibles
La mythologie contient violence, enlèvements, agressions sexuelles, infanticides, mutilations. Règles :
- **Ne pas édulcorer au point de mentir** (ex. l'histoire de Méduse chez Ovide implique une agression par Poséidon : le dire).
- **Formulation factuelle et sobre**, sans détail graphique (« Poséidon l'agresse dans le temple d'Athéna »), jamais romantisée (« l'enlèvement de Perséphone » et non « l'histoire d'amour »).
- **Contextualiser** : ces récits reflètent les valeurs d'une société antique ; l'interprétation peut l'expliquer.
- Pas d'illustration explicite ; choix d'œuvres antiques prudents (de nombreuses céramiques montrent de la nudité : acceptable dans un cadre artistique et éducatif, mais éviter les scènes sexuelles explicites).
- Mention discrète en tête de récit si nécessaire : « Ce mythe évoque des violences. »

### 21.7 Exemples d'écriture (référence de ton)

**Méduse — intro**
> Un regard, et tu deviens statue. Méduse est le monstre le plus célèbre de la mythologie grecque… et peut-être le plus mal compris. Car selon les auteurs, elle n'a pas toujours été un monstre.

**Encadré « Plusieurs versions » — Méduse**
> 🏺 **Chez Hésiode** (Théogonie, vers le VIIe s. av. J.-C.), Méduse est l'une des trois Gorgones, filles de divinités marines. Elle est la seule à être mortelle. Aucune transformation : elle est née ainsi.
> 🏺 **Chez Ovide** (Métamorphoses, poète romain, début du Ier s. apr. J.-C.), Méduse est une jeune femme dont la chevelure est célèbre. Poséidon l'agresse dans le temple d'Athéna ; la déesse la punit en changeant ses cheveux en serpents.
> 🔍 **Aujourd'hui**, beaucoup de lecteurs voient dans la version d'Ovide le récit d'une victime punie à la place de son agresseur. C'est une lecture moderne — et une raison pour laquelle Méduse est devenue un symbole.

**Le saviez-vous ? — Pandore**
> La « boîte » de Pandore n'était pas une boîte. Chez Hésiode, c'est une grande jarre (*pithos*). La boîte est apparue à la Renaissance, à cause d'une traduction.

**Le saviez-vous ? — Achille**
> Le talon d'Achille n'existe pas chez Homère. L'épisode du bain dans le Styx est raconté bien plus tard, notamment par le poète latin Stace, au Ier siècle de notre ère.

> ⚠️ Chaque exemple ci-dessus devra être revérifié dans les sources lors de la rédaction définitive (processus §22.4). Ils fixent le ton, pas le contenu final.

---

## 22. MÉTHODOLOGIE DES SOURCES

### 22.1 Hiérarchie des sources
| Rang | Type | Exemples |
|---|---|---|
| **A — Sources antiques** | Textes grecs et latins (en traduction) | Homère (*Iliade*, *Odyssée*), Hésiode (*Théogonie*, *Les Travaux et les Jours*), *Hymnes homériques*, Pindare, les tragiques (Eschyle, Sophocle, Euripide), Apollonios de Rhodes (*Argonautiques*), Apollodore (*Bibliothèque*), Pausanias, Ovide (*Métamorphoses*, latin — toujours signalé comme romain), Stace, Hygin |
| **B — Ouvrages de référence modernes** | Dictionnaires et synthèses reconnus | P. Grimal, *Dictionnaire de la mythologie grecque et romaine* (PUF) ; J.-P. Vernant, *L'univers, les dieux, les hommes* ; T. Gantz, *Early Greek Myth* (recense les variantes avec leurs sources) |
| **C — Ressources numériques fiables** | Bases de textes et de collections | Perseus Digital Library (Tufts), Theoi Project (compilation de sources antiques en traduction), collections du Louvre, du British Museum, du Met, Gallica (BnF), traductions anciennes du domaine public |
| **D — Pop culture** | Œuvres elles-mêmes | Livres, films, jeux cités précisément (titre, tome/épisode) |
| ❌ **Exclu** | Fandom wikis, blogs non sourcés, contenus générés automatiquement non vérifiés | — |

### 22.2 Règles
- Toute affirmation mythologique non triviale est rattachée à **au moins une source de rang A ou B**.
- Les dates des auteurs antiques sont données en **approximations** (« vers le VIIIe s. av. J.-C. »).
- Distinguer **grec / romain** : une version issue d'Ovide est présentée comme « version romaine ».
- Quand les sources divergent → composant `VariantCompare`, jamais un choix silencieux.
- Les **citations antiques** affichées proviennent de traductions du **domaine public** (ex. traductions françaises du XIXe siècle) ou sont traduites par l'équipe ; citations courtes.

### 22.3 Affichage des sources
- Bloc `SourceList` en bas de chaque fiche : source, passage (ex. *Théogonie*, v. 270–283), lien vers une traduction en ligne si disponible.
- Pastille de couche (🏺/🔍/🎬) devant chaque encadré.
- Page Méthodologie publique.

### 22.4 Processus de vérification (par fiche)
1. Rédaction avec sources renseignées dans le fichier de données.
2. Relecture factuelle par une seconde personne : chaque fait du bloc « En bref » et de « Versions » est confronté à une source A ou B.
3. Relecture de ton (gabarit §21).
4. Statut `reviewStatus: "verified"` + date + relecteur dans les métadonnées. **Seules les fiches `verified` sont publiées** (filtre au build).
5. Bouton « Signaler une erreur » → file de corrections ; correction tracée dans l'historique Git.

### 22.5 Chaîne de production éditoriale par agents IA (décision v1.1)

```
 ┌──────────────┐  brief de fiche   ┌───────────────┐   brouillon +    ┌──────────────────┐
 │   CLAUDE      │ ───────────────► │ AGENT RÉDACTEUR│ ───────────────►│ AGENT VÉRIFICATEUR│
 │ (directeur    │                   │ (rédige au ton │  sources citées │ (contrôle chaque  │
 │  éditorial)   │ ◄──────────────── │  du site)      │                 │  fait en ligne)   │
 └──────┬───────┘   rapport de        └───────────────┘                  └────────┬─────────┘
        │           vérification ◄─────────────────────────────────────────────────┘
        │ arbitre : corrige, renvoie au rédacteur, ou tranche
        ▼
 ┌──────────────┐   questions éditoriales (choix de version, ton, sujets sensibles)
 │     ENZO      │ ◄─ échantillon à relire (≈ 1 fiche sur 5 + toutes les fiches sensibles)
 └──────────────┘
```

| Rôle | Responsabilités | Ce qu'il ne fait pas |
|---|---|---|
| **Claude (directeur)** | Rédige le brief de chaque fiche (sujet, angle, liens à créer, pièges connus) ; arbitre les désaccords ; tient le registre des questions ; garantit la cohérence entre fiches (mêmes faits, mêmes noms, mêmes relations). | Ne publie jamais une fiche que le vérificateur a marquée « bloquante ». |
| **Agent rédacteur** | Rédige YAML + MDX selon `editorial/GUIDE_REDACTION.md` ; **cherche les sources en ligne** et cite chaque fait non trivial avec son passage. | N'invente aucune source, aucune citation, aucune date ; signale « [À VÉRIFIER] » quand il n'est pas sûr. |
| **Agent vérificateur** | Instance **séparée, sans accès au raisonnement du rédacteur** ; relit chaque affirmation et la confronte à une source consultée en ligne (texte antique en traduction, Theoi, Perseus, dictionnaires) ; vérifie aussi le ton et les couches 🏺/🔍/🎬. Rend un rapport : ✅ confirmé · ⚠️ nuance nécessaire · ❌ faux · ❓ invérifiable. | Ne réécrit pas la fiche ; il signale. |
| **Enzo** | Tranche les questions éditoriales ; relit un échantillon ; valide les fiches sensibles. | — |

**Limites assumées et garde-fous**
- Deux IA peuvent partager la même erreur de connaissance. D'où trois règles : le vérificateur **doit citer la page consultée** pour chaque ✅ ; un fait sans source consultable passe en ❓ et est retiré ou reformulé au conditionnel ; les erreurs les plus fréquentes (mélange grec/romain, détails tardifs présentés comme anciens, invention de citations) sont listées dans le guide du vérificateur.
- Les citations de textes antiques ne sont retenues que si le vérificateur a retrouvé le passage.
- Statut final : `verified-ai` (deux agents d'accord) puis `verified` (après l'échantillonnage humain du lot).
- Les guides vivent dans `editorial/` et s'enrichissent à chaque erreur trouvée (« journal des pièges »).

---

## 23. ARCHITECTURE DU CONTENU

### 23.1 Principe : données structurelles ≠ texte localisé
- **Données structurelles** (identiques dans toutes les langues) : id, type, relations, attributs, références médias, sources, niveaux → fichiers **YAML** dans `content/entities/`.
- **Texte éditorial** (traduit) : nom, accroche, récits, encadrés → fichiers **MDX** par langue dans `content/i18n/fr/…`, `content/i18n/en/…`.
- **Relations** : déclarées une seule fois dans `content/relations/*.yaml` (graphe central) ; les fiches les **calculent** (ex. « enfants de Zeus » est déduit des relations, jamais saisi deux fois).

### 23.2 Arborescence du contenu
```
content/
├── entities/                    # Données structurelles (langue-agnostiques)
│   ├── deities/zeus.yaml
│   ├── titans/cronos.yaml
│   ├── primordials/gaia.yaml
│   ├── heroes/perseus.yaml
│   ├── creatures/medusa.yaml
│   ├── places/underworld.yaml
│   └── objects/thunderbolt.yaml
├── myths/                       # Structure des récits
│   └── perseus-and-medusa.yaml
├── relations/                   # Graphe des relations (source unique)
│   ├── family.yaml
│   ├── love.yaml
│   ├── conflict.yaml
│   └── alliance.yaml
├── pop-culture/
│   ├── works/percy-jackson.yaml
│   └── comparisons/medusa-percy-jackson.yaml
├── words/panic.yaml
├── facts/pandora-jar.yaml       # « Le saviez-vous ? »
├── quizzes/olympians.yaml
├── sources/                     # Bibliographie centrale
│   └── hesiod-theogony.yaml
├── media/registry.yaml          # Registre des médias + licences
└── i18n/
    ├── fr/
    │   ├── entities/deities/zeus.mdx
    │   ├── myths/perseus-and-medusa.mdx
    │   ├── pop-culture/comparisons/medusa-percy-jackson.mdx
    │   ├── words/panic.mdx
    │   ├── facts/pandora-jar.mdx
    │   ├── quizzes/olympians.yaml
    │   └── ui.json              # Chaînes d'interface
    └── en/ …
```

### 23.3 Pipeline de build du contenu
```
YAML + MDX ──► chargement (Velite ou loader maison) ──► validation Zod
   ──► résolution des références (ids → objets ; erreur si id inconnu)
   ──► calcul du graphe (relations inverses, degrés, plus courts chemins pré-calculés)
   ──► calcul des layouts (arbre via dagre, galaxie via d3-force en mode statique)
   ──► génération : pages statiques, index de recherche, sitemap, images OG
```
**Le build échoue si** : référence cassée, source manquante sur un bloc mythologique, média sans licence ou sans `alt`, traduction manquante d'un champ obligatoire dans la langue publiée, fiche non vérifiée marquée publiée.

---

## 24. MODÈLE DE DONNÉES

> Types TypeScript de référence (les schémas Zod en sont la source et génèrent ces types).

```ts
// ---------- Primitives ----------
type EntityId = string;                 // stable, anglais, kebab-case : "zeus", "medusa"
type Locale = "fr" | "en" | "es" | "de" | "it" | "pt";
type Level = 1 | 2 | 3 | 4;             // Découvrir, Comprendre, Approfondir, Culture
type Layer = "ancient" | "interpretation" | "modern";

type EntityType =
  | "primordial" | "titan" | "deity" | "minor-deity"
  | "hero" | "mortal" | "creature" | "people"   // people = Cyclopes, Centaures…
  | "place" | "object";

type Category = "gods" | "titans" | "heroes" | "creatures" | "places" | "objects";

// ---------- Sources ----------
interface Source {
  id: string;                           // "hesiod-theogony"
  rank: "A" | "B" | "C" | "D";
  author?: string;                      // "Hésiode"
  title: string;                        // "Théogonie"
  culture?: "greek" | "roman" | "modern";
  date?: string;                        // "vers 700 av. J.-C." (approx.)
  url?: string;                         // traduction en ligne
}
interface SourceRef {
  sourceId: string;
  locus?: string;                       // "v. 270–283", "Livre IV, 765–803"
  note?: string;
}

// ---------- Médias ----------
interface MediaAsset {
  id: string;
  file: string;                         // chemin local optimisé
  kind: "photo-artwork" | "illustration" | "pictogram" | "map";
  alt: Record<Locale, string>;          // OBLIGATOIRE (au moins la langue par défaut)
  caption?: Record<Locale, string>;     // "Amphore attique, vers 530 av. J.-C."
  credit: string;                       // "The Metropolitan Museum of Art"
  license: "CC0" | "PD" | "CC-BY-4.0" | "CC-BY-SA-4.0" | "original" | "other";
  licenseUrl?: string;
  sourceUrl: string;                    // page d'origine (preuve)
  verifiedAt: string;                   // date de vérification de la licence
  focalPoint?: { x: number; y: number };// recadrage intelligent
}

// ---------- Entité (base commune) ----------
interface Entity {
  id: EntityId;
  type: EntityType;
  category: Category;
  names: {
    greek?: string;                     // "Ζεύς"
    transliteration?: string;           // "Zeus"
    roman?: string;                     // "Jupiter"
    aliases?: string[];                 // pour la recherche : ["Hercule", "Hercules"]
  };
  symbols?: EntityId[];                 // objets : ["thunderbolt", "eagle", "oak"]
  domains?: string[];                   // clés i18n : ["sky", "thunder", "justice"]
  residence?: EntityId[];               // ["mount-olympus"]
  era?: "origins" | "titans" | "olympians" | "heroes" | "trojan-war" | "returns";
  attributes?: Record<string, string | number>;   // spécifiques par type
  media: { hero?: string; gallery?: string[]; pictogram?: string };
  sources: SourceRef[];                 // ≥ 1 obligatoire
  popCulture?: string[];                // ids de comparaisons
  facts?: string[];                     // ids de FactCard
  words?: string[];                     // ids de mots dérivés
  importance: 1 | 2 | 3;                // 1 = incontournable (mise en avant, Oracle débutant)
  review: { status: "draft" | "review" | "verified"; by?: string; at?: string };
}

// Spécialisations (extraits)
interface Creature extends Entity {
  type: "creature" | "people";
  creature: {
    kind: "monster" | "mythic-animal" | "hybrid" | "people";
    danger: 1 | 2 | 3;                  // faible, moyen, extrême
    habitat: ("sea" | "land" | "underworld" | "sky")[];
    defeatedBy?: EntityId[];
  };
}
interface Hero extends Entity {
  type: "hero";
  hero: {
    labors?: { id: string; order: number; mythId?: string }[]; // ex. 12 travaux
    strengths: string[]; weaknesses: string[];
    fate: string;                       // clé i18n
  };
}
interface Place extends Entity {
  type: "place";
  place: {
    realm: "sky" | "earth" | "underworld" | "sea";
    reality: "mythical" | "real" | "real-associated";
    coords?: { x: number; y: number };  // coordonnées sur la carte SVG
    geo?: { lat: number; lng: number }; // si lieu réel
  };
}

// ---------- Relations (graphe) ----------
type RelationType =
  | "parent-of" | "spouse-of" | "sibling-of"      // famille
  | "lover-of"                                    // amour
  | "enemy-of" | "defeated" | "punished"          // conflit
  | "ally-of" | "helped" | "mentor-of"            // alliance
  | "created" | "owns" | "lives-in";              // autres

interface Relation {
  id: string;
  from: EntityId;
  to: EntityId;
  type: RelationType;
  certainty: "canonical" | "variant";             // variant = selon certaines sources
  sources: SourceRef[];
  noteKey?: string;                               // explication i18n
  myths?: string[];                               // mythes où la relation apparaît
}

// ---------- Mythe ----------
interface Myth {
  id: string;
  themes: ("origins" | "exploit" | "love" | "punishment" | "war" | "journey" | "metamorphosis")[];
  cast: EntityId[];                               // personnages
  places: EntityId[];
  era: Entity["era"];
  readingMinutes: number;                         // calculé au build
  chapters: { id: string; media?: string; level: Level }[];
  variants?: string[];                            // ids de VariantBlock
  next?: string[];                                // suggestions éditoriales
  contentWarning?: boolean;
  sources: SourceRef[];
  review: Entity["review"];
}

// ---------- Variantes ----------
interface VariantBlock {
  id: string;
  subject: EntityId | string;
  versions: { labelKey: string; layer: Layer; sources: SourceRef[] }[];  // ≥ 2
}

// ---------- Pop culture ----------
interface Work {
  id: string;                                     // "percy-jackson"
  medium: "book" | "film" | "series" | "game" | "comic";
  creators: string[];
  year: number;
  franchiseNoteKey?: string;
}
interface Comparison {
  id: string;
  subject: EntityId;
  work: string;
  changes: { kind: "kept" | "modified" | "added" | "removed"; textKey: string }[];
  ancientSources: SourceRef[];
  workRefs: string[];                             // "Tome 1, chapitre 11"
  review: Entity["review"];
}

// ---------- Mots ----------
interface Word {
  id: string;
  term: Record<Locale, string>;                   // le mot dans chaque langue
  kind: "word" | "expression" | "adjective" | "name" | "science";
  origin: EntityId | string;
  etymologySources: SourceRef[];                  // dictionnaire étymologique
}

// ---------- Quiz (§26) ----------
type QuestionType = "mcq" | "true-false" | "identify" | "match" | "which-myth" | "myth-or-fiction";
interface Question {
  id: string;
  type: QuestionType;
  difficulty: 1 | 2 | 3;
  entities: EntityId[];                           // pour lier explication et Codex
  media?: string;
  answers: { id: string; correct: boolean }[];    // textes dans i18n
  explanationKey: string;
  learnMore: EntityId | string;
  sources?: SourceRef[];
}
```

**Exemple YAML — `content/entities/deities/zeus.yaml`**
```yaml
id: zeus
type: deity
category: gods
names:
  greek: Ζεύς
  transliteration: Zeus
  roman: Jupiter
  aliases: [Zeus, Jupiter, Jove]
symbols: [thunderbolt, eagle, oak, aegis]
domains: [sky, thunder, justice, hospitality, kingship]
residence: [mount-olympus]
era: olympians
importance: 1
media:
  hero: met-zeus-bronze-01
  pictogram: picto-thunderbolt
sources:
  - { sourceId: hesiod-theogony, locus: "v. 453–506" }
  - { sourceId: grimal-dictionnaire }
popCulture: [zeus-percy-jackson, zeus-marvel, zeus-god-of-war]
facts: [zeus-cretan-childhood, jupiter-moons]
review: { status: draft }
```

**Exemple — relation**
```yaml
- id: cronos-parent-zeus
  from: cronos
  to: zeus
  type: parent-of
  certainty: canonical
  sources: [{ sourceId: hesiod-theogony, locus: "v. 453–458" }]
```

---

## 25. SYSTÈME DE COMPARAISON MYTHE / POP CULTURE

### 25.1 Objectif
Utiliser les œuvres modernes comme **porte d'entrée affective** tout en entraînant l'esprit critique : *qu'est-ce qui vient des Grecs, qu'est-ce qui a été inventé, et pourquoi ?*

### 25.2 Structure d'une comparaison (gabarit imposé)
1. **DANS LE MYTHE** 🏺 — sources citées.
2. **DANS L'ŒUVRE** 🎬 — référence précise (tome, épisode, jeu).
3. **CE QUI CHANGE** — liste typée : `= conservé` · `✎ modifié` · `✚ ajouté` · `✕ supprimé`.
4. **POURQUOI ?** 🔍 — hypothèses narratives (« pour rendre le personnage plus sympathique à un jeune lecteur »), présentées comme telles.
5. **POUR ALLER PLUS LOIN** — fiche mythologique + autres comparaisons.

### 25.3 Œuvres couvertes
| Œuvre | Priorité | Angle |
|---|---|---|
| Percy Jackson (romans, série) | MUST | Les « demi-dieux », le Camp des Sang-Mêlé (invention moderne), dieux installés en Amérique, Méduse, Minotaure, Hadès |
| *Hercule* (Disney, 1997) | MUST | Héra mère aimante (inversion du mythe), Hadès « méchant » (le Hadès antique n'est pas maléfique), Philoctète, Mégara |
| *Hades* (jeu) | MUST/SHOULD | Zagreus, Nyx, Thanatos, Achille et Patrocle, Orphée et Eurydice |
| God of War (série grecque) | SHOULD | Kratos (personnage inventé ; Kratos existe dans la mythologie comme personnification du pouvoir), vision des dieux |
| Marvel | SHOULD | Hercule, Zeus ; **Thor est nordique** → page « Toutes les mythologies ne sont pas grecques » (comparaison Zeus/Thor/Jupiter) |
| Wonder Woman (DC) | SHOULD | Amazones (présentes dans les mythes grecs), Arès |
| Assassin's Creed Odyssey | SHOULD | Grèce historique vs mythe, créatures |
| Blood of Zeus | COULD | — |

### 25.4 Garde-fous
- Bandeau permanent sur les pages pop culture : *« Les œuvres modernes s'inspirent des mythes. Elles ne sont pas des sources. »*
- Aucun visuel officiel, aucun logo ; tuiles typographiques originales.
- Aucune reproduction de texte des œuvres au-delà d'une très courte mention ; on décrit, on ne recopie pas.
- Ton **non condescendant** envers les œuvres : une adaptation libre n'est pas une « erreur ». Le mot « fidèle » est évité au profit de « repris / réinventé ».

### 25.5 Contenus viraux associés
- « 5 choses que Percy Jackson a changées »
- « Hadès n'était pas le méchant »
- « Kratos existe vraiment… mais pas comme tu crois »
- « Thor n'est pas grec (et ce n'est pas un détail) »

---

## 26. SYSTÈME DE QUIZ

### 26.1 Types de questions
| Type | Exemple | UI |
|---|---|---|
| QCM | « Quel dieu porte un trident ? » | 4 boutons |
| Vrai / Faux | « Hadès est l'un des douze Olympiens. » | 2 grands boutons |
| Reconnaître | Pictogramme ou œuvre antique → « Qui est-ce ? » | Image + 4 choix |
| Associer | Symbole ↔ divinité (4 paires) | Tap-tap (sélection puis cible) — pas de drag obligatoire |
| Quelle histoire ? | « Un fil, un labyrinthe, un monstre… » | 4 choix de mythes |
| Mythe ou fiction ? | « Annabeth Chase est la fille d'Athéna dans les mythes antiques. » | Cartes : Mythe / Fiction |

### 26.2 Mécanique
- Quiz de **5 à 10 questions**, tirées aléatoirement dans une banque par thème (≥ 3× plus de questions que la longueur du quiz pour la rejouabilité).
- Ordre des réponses mélangé ; graine aléatoire stockée dans l'URL du résultat (résultat reproductible et partageable).
- **Feedback immédiat** + explication 1–2 phrases + « En savoir plus » (panneau, sans quitter le quiz).
- Aucun chronomètre par défaut (mode « Chrono » optionnel pour les joueurs).
- Paliers de score : ceux du brief (§15.20).
- **Mode révision** : rejouer uniquement ses erreurs.
- Questions de difficulté 1 réservées au quiz débutant de fin de « 5 minutes ».

### 26.3 « Quel dieu grec es-tu ? »
- 8 questions de personnalité, chaque réponse pondère 2–3 divinités ; profil final = score max, égalité → divinité la moins « attribuée » récemment (variété).
- Résultat : portrait, 3 traits, « 3 choses que tu ignores sur [dieu] », lien fiche, image de partage.
- Mention discrète : « Un test pour s'amuser — les vrais dieux sont bien plus compliqués. »

### 26.4 Partage
- Image Open Graph générée (`next/og`) : score ou divinité, palier, identité visuelle. **Aucune donnée personnelle** dans l'image ni dans l'URL.
- Texte de partage pré-rempli : « J'ai eu 8/10 au quiz Mythe ou fiction ? Tu fais mieux ? »

### 26.5 Qualité
- Chaque question liée à au moins une entité et une source (pour les questions factuelles).
- Les questions « Mythe ou fiction » sont relues avec une attention particulière (pièges légitimes, pas de questions ambiguës entre versions).

---

## 27. GAMIFICATION

### 27.1 Principes
- **100 % optionnelle**, activée par défaut de manière discrète, désactivable en un clic.
- **Sans compte** : progression dans `localStorage`, sur l'appareil uniquement.
- **Aucune mécanique culpabilisante** (pas de série qui se « perd », pas de notifications, pas de FOMO).
- Récompenser **la curiosité** (découvrir, relier, comparer), pas seulement les bonnes réponses.

### 27.2 Mécaniques
| Mécanique | Règle |
|---|---|
| **Découverte** | Une entité est « découverte » après 10 s de lecture de sa fiche ou ouverture d'une section. |
| **Codex** | « 23/118 » global + par catégorie ; silhouettes avec indices. |
| **Niveaux** | Basés sur le nombre de découvertes : *Mortel curieux* (0) → *Pèlerin de Delphes* (10) → *Compagnon des héros* (30) → *Initié de l'Olympe* (60) → *Gardien des mythes* (100). |
| **Badges** | Définis en données (`content/badges.yaml`) avec conditions déclaratives. |
| **Fil d'Ariane** | Historique de session visualisé, partageable. |

### 27.3 Badges (exemples)
| Badge | Condition |
|---|---|
| 🏛️ Explorateur de l'Olympe | Découvrir les 12 Olympiens |
| ⚡ Disciple de Zeus | Lire 5 fiches liées à Zeus |
| 🐍 Chasseur de monstres | Découvrir 10 créatures |
| 📜 Connaisseur des mythes | Lire 8 récits en entier |
| 🔍 Esprit critique | Lire 5 encadrés « Plusieurs versions » |
| 🎬 Démystificateur | 10/10 à « Mythe ou fiction ? » |
| 🧵 Fil d'Ariane | Parcours de 10 fiches reliées en une session |
| 🗣️ Tu parles grec | Découvrir 20 mots |
| 🌌 Astronome | Lire la page Ciel (V2) |

### 27.4 Implémentation
- Store minimal (`useSyncExternalStore` + `localStorage`, versionné, avec migration) ; pas de bibliothèque d'état lourde.
- Événements internes (`entity_discovered`, `myth_completed`, `quiz_finished`) → moteur de règles des badges.
- Toast discret et `aria-live` à l'obtention d'un badge.
- Export/import de progression par code texte (COULD) pour changer d'appareil sans compte.

---

## 28. SYSTÈME DE RECHERCHE

### 28.1 Choix : Pagefind
Bibliothèque de recherche **entièrement statique** : l'index est généré au build et découpé en fragments, le navigateur ne télécharge que ce dont il a besoin. Le multilingue est géré sans configuration à partir de l'attribut `lang` des pages, avec racinisation (stemming) adaptée à la langue, et un moteur de filtres utile pour grouper les résultats par type. Aucun serveur, aucun coût, respect de la vie privée.

### 28.2 Fonctionnement
- Indexation des pages fiche/mythe/mot/comparaison (balises `data-pagefind-body`), exclusion de la navigation et du footer.
- Métadonnées indexées : type, catégorie, importance (pondération), image miniature.
- **Alias** : les noms alternatifs (Hercule/Héraclès/Hercules, Ulysse/Odysseus, Méduse/Medusa, Hydre/Hydra) sont injectés en texte caché indexé → taper « hercule » trouve Héraclès.
- **Insensibilité aux accents** : « meduse » = « Méduse » (normalisation à vérifier en phase 1 ; sinon ajout des formes sans accents dans les alias).

### 28.3 UX de la palette (`⌘K`)
```
┌───────────────────────────────────────────────┐
│ 🔍 méduse                                  Esc │
├───────────────────────────────────────────────┤
│ CRÉATURES                                     │
│  ▣ Méduse — Gorgone au regard pétrifiant      │
│ HÉROS                                         │
│  ▣ Persée — Celui qui a vaincu Méduse         │
│ MYTHES                                        │
│  ▣ Persée et Méduse · 6 min                   │
│ POP CULTURE                                   │
│  ▣ Méduse — Mythe vs Percy Jackson            │
├───────────────────────────────────────────────┤
│ ↑↓ naviguer · ↵ ouvrir · Voir tous les résultats│
└───────────────────────────────────────────────┘
```
- Avant saisie : recherches populaires + « récemment consultés » (local).
- Navigation clavier complète (pattern combobox ARIA).
- Zéro résultat : suggestions de correction (« Tu voulais dire Méduse ? » via distance d'édition sur la liste des noms) + Oracle.
- **Résultats enrichis par le graphe** : pour une entité trouvée, afficher ses 3 relations les plus fortes (c'est l'exemple du brief : Méduse → Persée, monstres, mythes, références modernes).

---

## 29. STRATÉGIE D'IMAGES

### 29.1 Trois familles de visuels
| Famille | Source | Usage |
|---|---|---|
| **Œuvres antiques réelles** | Met Open Access (CC0), Wikimedia Commons (photos d'œuvres antiques sous licence libre vérifiée), musées en accès ouvert | Héros de fiches, galeries, « Le saviez-vous » |
| **Système graphique original** | Créé pour le projet (SVG) | Pictogrammes, cartes, silhouettes, illustrations de transition, carte du monde, Codex |
| **Photographie de paysages** | Unsplash / Pexels (licences propres à vérifier), ou photos personnelles | Delphes, mer Égée, lieux réels |

Le Met met à disposition les images des œuvres qu'il considère dans le domaine public sous désignation CC0, réutilisables gratuitement, y compris à des fins commerciales — une ressource idéale pour les céramiques et sculptures grecques.

### 29.2 Traitement visuel
- Œuvres présentées **telles quelles** (respect de l'objet) avec légende et crédit ; détourage possible pour les fragments flottants (photo CC0 uniquement — une modification d'une image CC BY-SA impose de repartager sous la même licence).
- Traitement chromatique unifié pour les fonds (léger étalonnage froid sur les photos de paysages).

### 29.3 Pipeline technique
- Originaux stockés hors du bundle (`assets-src/`), optimisés au build : **AVIF + WebP**, tailles 320/640/960/1280/1920, `next/image` avec `sizes` exacts.
- `placeholder` flou (LQIP 20 px) pour éviter le vide au chargement.
- Hero : image prioritaire (`priority`/`fetchpriority="high"`), reste en lazy loading.
- Pictogrammes : SVG inline optimisés (SVGO), sprite pour les répétitions.
- Poids cibles : hero ≤ 180 Ko (mobile), vignettes ≤ 25 Ko.

### 29.4 Processus de sélection (décision v1.1)
1. **Recherche web d'abord** : pour chaque besoin visuel (une fiche, un mythe, un lieu), recherche dans l'ordre : Met Open Access → Wikimedia Commons → autres musées en accès ouvert (Walters, Cleveland, Rijksmuseum, Louvre si licence compatible) → Unsplash/Pexels pour les paysages.
2. **Filtre licence** : seulement CC0, domaine public, CC BY (CC BY-SA sans retouche). Licence relevée sur la page d'origine et notée dans le registre.
3. **Filtre qualité** : l'image doit montrer clairement le sujet, être assez grande (≥ 1 200 px de large pour un hero) et ne pas être une scène sexuelle explicite (§21.6).
4. **SVG original en secours** quand aucune image libre ne convient (sujet jamais représenté, image trop petite, licence incompatible, ou pictogramme d'interface).
5. **Galerie de validation** : chaque candidat (photo ou SVG) est présenté à Enzo dans une page de galerie avec la vignette, la source, la licence, l'usage prévu et un statut (proposé / validé / refusé). Rien n'est intégré au site sans passage par la galerie.
6. **Téléchargement** des images validées dans `assets-src/` (depuis l'ordinateur d'Enzo, ou depuis le cloud si les domaines `upload.wikimedia.org` et `images.metmuseum.org` sont autorisés dans les réglages réseau).

---

## 30. STRATÉGIE DE LICENCES

### 30.1 Registre des médias (obligatoire)
Chaque image a une entrée dans `content/media/registry.yaml` : source, URL d'origine, licence, auteur, date de vérification, texte alternatif. **Le build échoue** pour toute image utilisée sans entrée complète. La page Crédits est générée depuis ce registre.

### 30.2 Licences acceptées
| Licence | Accepté | Conditions |
|---|---|---|
| CC0 / domaine public | ✅ | Créditer quand même (bonne pratique) |
| CC BY 4.0 | ✅ | Attribution visible (légende ou crédits) |
| CC BY-SA 4.0 | ⚠️ | Attribution + toute modification partagée sous même licence → **pas de retouche** |
| CC BY-NC (ex. certaines images de musées) | ⚠️ | Seulement si le projet reste non commercial ; à éviter pour garder de la liberté (monétisation future, partenariats) |
| Licence Unsplash / Pexels | ✅ | Pas de revente en l'état ; vérifier l'absence de personnes/marques identifiables |
| « Tous droits réservés », images de films/jeux/séries, fan arts | ❌ | Jamais |

Attention aux **photos d'œuvres sur Wikimedia** : l'œuvre antique est dans le domaine public, mais la photo peut avoir sa propre licence (vérifier fichier par fichier).

### 30.3 Code et composants tiers
| Ressource | Licence | Statut |
|---|---|---|
| Next.js, React | MIT | ✅ |
| Tailwind CSS | MIT | ✅ |
| Motion | MIT | ✅ |
| Radix UI primitives (si utilisées) | MIT | ✅ |
| Lucide | ISC | ✅ |
| Pagefind | MIT | ✅ |
| d3-force, d3-zoom | ISC | ✅ |
| @dagrejs/dagre | MIT | ✅ (utilisé au build) |
| next-intl | MIT | ✅ |
| Polices Fraunces, Inter, Cinzel | SIL OFL 1.1 | ✅ (auto-hébergées) |
| **Composants 21st.dev** | **Variable selon l'auteur** | ⚠️ voir ci-dessous |

**21st.dev** est un registre communautaire de composants React/Tailwind (style shadcn/ui) que l'on copie dans son code. Le dépôt de la plateforme est sous MIT, mais **chaque composant a la licence choisie par son auteur**, et un nombre important sont publiés sans licence — ce qui, juridiquement, ne donne aucun droit de réutilisation. Certaines bibliothèques présentes sur la plateforme sont, elles, clairement sous MIT. L'installation via leur CLI requiert aussi une clé API avec un quota gratuit limité.

**Règle projet** :
1. Utiliser 21st.dev comme **source d'inspiration** et de patterns.
2. N'importer que les composants avec **licence permissive explicite** (MIT/Apache-2.0/ISC), noter la licence et l'auteur dans `THIRD_PARTY_NOTICES.md`.
3. Tout composant importé est **réécrit pour nos tokens, l'accessibilité et la performance** (pas de copier-coller tel quel).
4. Aucun composant WebGL/shader importé au MVP.

### 30.4 Marques et œuvres modernes
Citer les noms d'œuvres et de personnages pour commenter, comparer et informer relève d'un usage nominatif courant ; ne jamais utiliser logos, typographies officielles, visuels promotionnels, captures d'écran, extraits longs. Mention dans les mentions légales : « Les marques citées appartiennent à leurs propriétaires respectifs. Ce site n'est affilié à aucune d'entre elles. » (Je ne suis pas juriste : une relecture des mentions légales par un professionnel est recommandée avant un lancement public d'envergure.)

---

## 31. MICROCOPY

### 31.1 Principes
Drôle par touches (1 trait d'humour par écran maximum), utile d'abord, jamais au détriment de la clarté d'un bouton.

### 31.2 Bibliothèque initiale
| Contexte | Texte |
|---|---|
| Arbre généalogique (intro) | « Oui, les dieux grecs ont vraiment une généalogie compliquée. Respire. » |
| Lien de parenté complexe | « Attention, cette histoire implique beaucoup trop de membres d'une même famille. » |
| Méduse (teaser) | « Tu pensais que Méduse était juste un monstre ? Attends de connaître son histoire. » |
| Bouton Oracle | « Consulter l'Oracle » |
| Chargement Oracle | « La Pythie consulte les vapeurs… » |
| Recherche vide | « Même l'Oracle de Delphes n'a rien trouvé. Essaie autre chose. » |
| Filtres vides (bestiaire) | « Aucune créature ne correspond. Les Grecs avaient pourtant beaucoup d'imagination. » |
| 404 | « Tu t'es perdu dans le Labyrinthe. Heureusement, on a un fil. » |
| Fin de récit | « Fin. Enfin… jusqu'à la prochaine tragédie. » |
| Liste des Olympiens | « La liste change selon les auteurs. Oui, même les dieux ont des problèmes de casting. » |
| Hadès | « Spoiler : Hadès n'est pas le méchant. » |
| Codex vide | « Ton Codex est vide. L'Olympe t'attend. » |
| Badge obtenu | « Nouveau titre : Chasseur de monstres. Persée serait fier. » |
| Pop culture (bandeau) | « Ici, on compare. Les œuvres modernes s'inspirent des mythes — elles ne les remplacent pas. » |
| Quiz mauvaise réponse | « Presque. Même Ulysse s'est perdu dix ans. » |
| Quiz bonne réponse | « Exact. Athéna approuve. » |

---

# PARTIE E — TECHNIQUE

## 32. STACK TECHNIQUE JUSTIFIÉE

| Besoin | Choix | Justification | Alternatives écartées |
|---|---|---|---|
| Framework | **Next.js 16 (App Router)**, version stable 16.x la plus récente au démarrage | Génération statique (SSG) pour toutes les fiches → HTML complet pour le SEO, chargement instantané ; Server Components = moins de JS envoyé ; `next/image`, `next/font`, `next/og` intégrés ; écosystème i18n mature. | **Astro** : excellent pour le contenu statique, mais les nombreuses interactions riches (graphes, quiz, palette, transitions) sont plus naturelles dans un écosystème 100 % React. Choix défendable si tu préfères minimiser le JS — à discuter. **SPA Vite** : mauvais SEO. |
| Langage | **TypeScript strict** | Le modèle de données est le cœur du projet ; les types évitent les relations cassées. | JS |
| Styles | **Tailwind CSS v4** + variables CSS | Tokens centralisés, thèmes, purge automatique, rapidité. | CSS Modules (plus verbeux), CSS-in-JS (coût runtime) |
| Primitives UI accessibles | **Radix UI** (Dialog, Popover, Tabs, Tooltip) ou équivalent headless | Accessibilité clavier/ARIA déjà résolue, stylable librement. | Bibliothèques de composants stylés (identité générique) |
| Animation | **Motion 12** (`motion/react`) en `LazyMotion` + **CSS natif** (scroll-driven animations, View Transitions) | Motion couvre layout, gestes, scroll ; le CSS natif est gratuit en JS là où il suffit. | **GSAP** : puissant, mais inutile tant qu'aucune timeline complexe n'est requise (réévalué en phase 10). |
| Contenu | **YAML + MDX** dans le repo, **Velite** (ou loader maison) + **Zod** | Contenu versionné, relu par pull request, validé au build, typé ; gratuit. | **CMS headless** (Sanity, Payload…) : utile si des rédacteurs non techniques arrivent → prévu en évolution (§43). |
| i18n | **next-intl** | Routage par locale, slugs localisés (`pathnames`), messages ICU (pluriels), compatible Server Components. | i18next (moins intégré à l'App Router) |
| Recherche | **Pagefind** | Statique, léger, multilingue, filtres. | Algolia (coût, données envoyées à un tiers), Fuse.js (index complet chargé côté client) |
| Visualisations | **SVG maison** + **d3-force / d3-zoom** (modules légers) ; layout de l'arbre calculé au build avec **dagre** | Contrôle total, accessibilité, layouts pré-calculés = pas de calcul lourd sur mobile. | React Flow (lourd, pensé pour l'édition), Cytoscape (lourd), Three.js (inutile) |
| Carte | **SVG illustré original** + d3-zoom | Le monde mythique n'est pas une carte routière ; identité visuelle forte, ultra léger. | Mapbox/Leaflet (tuiles, poids, style imposé, cookies éventuels) |
| Icônes | **Lucide** + pictos SVG maison | Cohérence, licence ISC, tree-shaking. | — |
| État client | `useSyncExternalStore` + localStorage ; **nuqs** pour l'état dans l'URL (filtres) | Minimal ; filtres partageables. | Redux/Zustand (surdimensionné) |
| Images OG | `next/og` (génération au build/à la demande) | Images de partage par fiche et par résultat de quiz. | — |
| Qualité | ESLint, Prettier, Vitest, Playwright, axe-core, Lighthouse CI | §38 | — |
| Hébergement | **Vercel** (recommandé) ou **Cloudflare Pages** | Déploiements de preview par branche, CDN mondial, intégration Next native. | Serveur VPS (maintenance inutile) |
| Analytics | **Plausible** ou **Umami** (auto-hébergé possible) | Sans cookies, respectueux du RGPD, léger. | Google Analytics (consentement requis, données transférées) |

**Note de maintenance** : Next.js a récemment formalisé un processus de publication régulière de correctifs de sécurité ; il faudra suivre ces versions de patch (Renovate/Dependabot configurés en phase 1).

**Version minimale de Node** : Node.js 20+ (exigence de Next 16) — recommandé : Node 22 LTS.

---

## 33. STRUCTURE DES DOSSIERS

```
olympos/
├── app/
│   ├── [locale]/
│   │   ├── layout.tsx                  # Shell : header, footer, providers, fonts
│   │   ├── page.tsx                    # Accueil
│   │   ├── explorer/page.tsx
│   │   ├── decouvrir/page.tsx          # (chemins localisés via next-intl pathnames)
│   │   ├── dieux/
│   │   │   ├── page.tsx
│   │   │   └── [slug]/page.tsx         # generateStaticParams + generateMetadata
│   │   ├── heros/…  creatures/…  mythes/…  mondes/…
│   │   ├── genealogie/page.tsx
│   │   ├── relations/page.tsx
│   │   ├── pop-culture/…
│   │   ├── quiz/[slug]/page.tsx
│   │   ├── codex/page.tsx
│   │   ├── recherche/page.tsx
│   │   └── (legal)/…                   # sources, à propos, mentions, crédits…
│   ├── api/og/route.tsx                # Images de partage dynamiques (quiz)
│   ├── sitemap.ts
│   ├── robots.ts
│   └── not-found.tsx
├── components/
│   ├── ui/                             # Atomes : Button, Badge, Chip, Card, Dialog, Sheet, Tabs, Tooltip, Accordion
│   ├── layout/                         # Header, MobileMenu, Footer, Breadcrumb, TableOfContents, BottomActionBar
│   ├── entity/                         # GodCard, HeroCard, CreatureCard, ObjectCard, PlaceCard, EntityHero, StatBlock, RelationsMini, FamilyMini
│   ├── myth/                           # MythCard, MythChapter, ReadingProgress, CastList, NextStory
│   ├── content/                        # FactCard, VariantCompare, LayerBadge, SourceList, Quote, InlineEntityLink, NextDoor
│   ├── pop/                            # ComparisonCard, ComparisonView, WorkTile, MythOrFiction
│   ├── viz/                            # FamilyTree, RelationGraph, WorldMap, Timeline, ArianeThread
│   ├── quiz/                           # Quiz, QuestionRenderer, AnswerButton, MatchPairs, ScoreResult, ShareCard
│   ├── search/                         # CommandPalette, SearchResults
│   ├── gamification/                   # CodexGrid, BadgeToast, ProgressMeter
│   ├── oracle/                         # OracleButton, OracleReveal
│   └── home/                           # HeroSection, DoorsGrid, NameMarquee…
├── content/                            # Voir §23 (données + textes)
├── lib/
│   ├── content/                        # loaders, schémas Zod, résolution des références
│   ├── graph/                          # construction du graphe, relations inverses, plus courts chemins
│   ├── layout/                         # calcul des layouts (arbre, galaxie) au build
│   ├── search/                         # helpers Pagefind, alias, distance d'édition
│   ├── quiz/                           # tirage, score, paliers
│   ├── progress/                       # store local, moteur de badges
│   ├── oracle/                         # tirage pondéré
│   ├── seo/                            # metadata, JSON-LD
│   ├── motion/                         # variants partagés, hook reduced-motion
│   └── utils/
├── i18n/
│   ├── routing.ts                      # locales, pathnames localisés
│   └── request.ts
├── styles/
│   ├── tokens.css                      # Primitives + rôles sémantiques (source unique)
│   └── globals.css                     # @theme Tailwind, base, typo
├── types/                              # Types générés depuis Zod + types UI
├── public/
│   ├── pictograms/  textures/  favicons/
├── assets-src/                         # Images originales (non servies)
├── scripts/
│   ├── build-content.ts                # validation + graphe + layouts
│   ├── check-contrast.ts               # vérification des paires de couleurs
│   ├── optimize-images.ts
│   └── new-entity.ts                   # générateur de gabarit de fiche
├── tests/
│   ├── unit/  e2e/  a11y/
├── .github/workflows/                  # CI
├── PROJECT_BLUEPRINT.md
├── CONTRIBUTING_CONTENT.md             # Guide de rédaction (dérivé des §21–22)
└── THIRD_PARTY_NOTICES.md
```

---

## 34. SPÉCIFICATIONS COMPOSANT PAR COMPOSANT

> Format : **Rôle** · **Props principales** · **Comportement** · **Accessibilité** · **Responsive**. Tous les composants sont des Server Components sauf mention `client`.

### 34.1 Layout
| Composant | Spécification |
|---|---|
| `Header` (client) | Logo, nav, recherche, Oracle. Se masque au scroll bas, réapparaît au scroll haut. `nav aria-label="Principale"`, lien actif `aria-current`. Mobile : burger. |
| `MobileMenu` (client) | Plein écran, entrées en cascade, piège de focus, fermeture Échap/bouton, restitue le focus. |
| `Footer` | §13.5. Sélecteur de langue (liens réels vers la page équivalente), thème, réduire les animations. |
| `Breadcrumb` | Liste ordonnée, JSON-LD `BreadcrumbList`. |
| `TableOfContents` (client) | Suit la section active (IntersectionObserver), desktop latéral collant, mobile en feuille. |
| `BottomActionBar` (client) | Mobile, fiches : précédent / Fil / suivant ; masquée quand le clavier virtuel est ouvert. |

### 34.2 Cartes d'entités
| Composant | Props | Comportement | A11y |
|---|---|---|---|
| `GodCard` | `entity`, `variant: "compact" \| "full"` | Forme d'arche, picto, nom, nom grec, domaine, pastille relations ; survol : inclinaison ≤ 6° + reflet doré (desktop, motion autorisé). Toute la carte est un lien (pattern « lien étendu », un seul élément focusable). | Nom = texte du lien ; picto `aria-hidden`. |
| `HeroCard` | `entity` | Format affiche portrait, épithète, âge héroïque. | idem |
| `CreatureCard` (client) | `entity`, `flippable` | Recto/verso ; bouton « Retourner » explicite (pas seulement survol) ; jauge de danger avec libellé. | `aria-pressed` sur le bouton, contenu du verso aussi présent en texte accessible. |
| `ObjectCard` | `entity` | Vitrine sombre, objet « éclairé ». | — |
| `PlaceCard` | `entity` | Strate (ciel/terre/enfers), réalité (badge « lieu réel/mythique »). | — |
| `MythCard` | `myth` | Visuel, titre, accroche, durée, avatars des personnages (max 4 + « +2 »). | Avatars décoratifs, noms listés en texte. |
| `WordCard` (client) | `word` | Retournable, recto = mot moderne, verso = origine. | Comme CreatureCard. |
| `FactCard` | `fact`, `shareable` | « Le saviez-vous ? », couche éditoriale, bouton partager (Web Share API, repli copie du lien). | — |

### 34.3 Contenu
| Composant | Spécification |
|---|---|
| `EntityHero` | Visuel (œuvre/illustration) + nom + nom grec (`lang`) + rôle + badges + équivalent romain + sélecteur de profondeur. Transition partagée depuis la carte (View Transitions). |
| `StatBlock` | Liste de définitions (`<dl>`) : En bref. 2 colonnes desktop, 1 mobile. Valeurs liées aux entités quand pertinent. |
| `LayerBadge` | Pastille 🏺/🔍/🎬 + libellé texte. |
| `VariantCompare` | 2–3 versions côte à côte (desktop) / en onglets (mobile), chacune avec `LayerBadge` et sources. Titre : « Une histoire, plusieurs versions ». |
| `SourceList` | Liste des sources avec rang, passage, lien externe (`rel="noopener"`). |
| `InlineEntityLink` (client) | Lien dans le texte MDX (`<E id="perseus" />`) ; aperçu au survol/focus après 150 ms ; mobile : lien direct + icône ⓘ pour l'aperçu. Résolution du slug selon la locale. |
| `NextDoor` | 3 suggestions max : calculées (voisins du graphe pondérés par importance et non-vus) + override éditorial. Chaque suggestion a une phrase d'accroche. |
| `DepthSelector` (client) | Radio group « Découvrir · Comprendre · Approfondir » ; replie/déplie les blocs balisés `data-level` ; préférence mémorisée. Contenu toujours dans le DOM. |
| `Quote` | Citation antique courte + source + traduction (domaine public). |
| `Timeline` | Verticale (mobile) / horizontale scrollable (desktop) ; événements liés à des mythes. |

### 34.4 Mythes
| Composant | Spécification |
|---|---|
| `MythChapter` | Titre de chapitre (numéro Cinzel), texte, média ; desktop : colonne visuelle collante qui change au chapitre actif. |
| `ReadingProgress` (client) | Barre dorée en haut, `role="progressbar"` avec `aria-valuenow` (ou décorative si redondante). |
| `CastList` | Personnages cliquables. |
| `NextStory` | Grand bloc « Prochaine histoire » + mini-quiz. |
| `ContentWarning` | Bandeau discret si `contentWarning: true`. |

### 34.5 Visualisations
| Composant | Spécification |
|---|---|
| `FamilyTree` (client) | Desktop : SVG avec positions pré-calculées (dagre au build) ; zoom/pan d3-zoom ; nœuds = boutons focusables ; flèches clavier pour naviguer (parent ↑, enfant ↓, fratrie ←→) ; liens « variante » en pointillés ; panneau latéral. Mobile : `FamilyFocusView` (parents / personnage / enfants). Alternative textuelle complète (listes imbriquées) dans un `<details>`. Paramètre `?focus=`. |
| `FamilyMini` | Version statique 3 générations pour les fiches (SVG serveur, zéro JS). |
| `RelationGraph` (client) | Graphe radial ; positions calculées au build par d3-force (simulation figée) pour chaque centre important, calcul client seulement pour les centres secondaires ; styles de traits par type ; légende ; mode « chemin entre deux personnages » (BFS sur le graphe pré-chargé, JSON compact). Alternative : liste groupée par type. |
| `RelationsMini` | Version statique pour les fiches. |
| `WorldMap` (client) | SVG illustré, couches (lieux, voyages), zoom/pan, marqueurs focusables, panneau d'info ; liste alternative. |
| `ArianeThread` (client) | Historique de session (sessionStorage) dessiné en fil doré ; partage = URL avec la suite d'ids. |

### 34.6 Pop culture
| Composant | Spécification |
|---|---|
| `ComparisonView` | Deux colonnes (desktop) / onglets (mobile) « Dans le mythe / Dans l'œuvre » + liste des changements typés + « Pourquoi ? ». |
| `ComparisonCard` | Résumé : sujet × œuvre, 1 changement marquant, lien. |
| `WorkTile` | Tuile typographique originale (titre de l'œuvre en police du site, couleur pop culture). Jamais de logo. |
| `MythOrFiction` (client) | Pile de cartes ; boutons « Mythe » / « Fiction » (+ glissement optionnel) ; feedback + explication ; score. |

### 34.7 Quiz
| Composant | Spécification |
|---|---|
| `Quiz` (client) | Machine à états : `intro → question → feedback → … → result`. Tirage avec graine. Raccourcis 1–4. Sauvegarde du meilleur score local. |
| `QuestionRenderer` | Rend selon le type (QCM, V/F, identify, match, which-myth, myth-or-fiction). |
| `AnswerButton` | ≥ 48 px, états neutre/sélectionné/correct/incorrect (icône + couleur + texte), `aria-live` pour le feedback. |
| `MatchPairs` | Sélection en deux taps (pas de drag obligatoire), clavier compatible. |
| `ScoreResult` | Compteur animé, palier, erreurs → liens, partage, rejouer. |
| `ShareCard` | Prévisualisation de l'image OG + Web Share API. |

### 34.8 Recherche, Oracle, gamification
| Composant | Spécification |
|---|---|
| `CommandPalette` (client) | Combobox ARIA ; chargement paresseux de Pagefind à la première ouverture ; groupes par type ; récents ; suggestions. |
| `OracleButton` / `OracleReveal` (client) | Tirage pondéré (favorise l'inédit et l'importance 1 pour les débutants) parmi : entité, mythe, fait, comparaison, mot ; animation 900 ms (ou instantané en reduced-motion) puis navigation. |
| `CodexGrid` (client) | Grille par catégorie, silhouettes, indices. |
| `BadgeToast` (client) | Notification discrète, `aria-live="polite"`, disparaît après 5 s, pas de son. |
| `ProgressMeter` | « 23/118 », barre + libellé. |

### 34.9 Accueil
`HeroSection` (parallaxe, nuages, éclair, CTA), `NameMarquee` (bandeau défilant, pause au survol/focus, `prefers-reduced-motion` = statique), `DoorsGrid` (bento), `FeaturedMyth`, `MythOrFictionTeaser`, `WordsTeaser`, `OracleBanner`.

---

## 35. SEO

| Élément | Mise en œuvre |
|---|---|
| Rendu | Toutes les pages de contenu en **SSG** → HTML complet indexable. |
| Titres | Gabarits : `Zeus — roi des dieux et maître de la foudre | Le Fil d'Ariane` ; `Persée et Méduse : l'histoire complète en 6 minutes | Le Fil d'Ariane` ; `Méduse : mythe vs Percy Jackson, ce qui change | Fil d'Ariane`. ≤ 60 caractères visibles. |
| Descriptions | Générées depuis l'accroche (≤ 155 caractères), surchargées si besoin. |
| Open Graph / Twitter | Image OG générée par fiche (nom + picto + couleur de catégorie), `og:locale` + `og:locale:alternate`. |
| Structure sémantique | `h1` unique, `article` pour fiches et mythes, `dl` pour les fiches d'identité. |
| URLs | Propres, localisées (§12.2). |
| Sitemap | `app/sitemap.ts` généré depuis le contenu (toutes locales, `alternates.languages`). |
| robots.txt | `app/robots.ts` ; pages de résultats de quiz paramétrées en `noindex`. |
| hreflang | `alternates.languages` sur chaque page + `x-default`. |
| Canonical | Une par page et par langue ; paramètres de filtre → canonical vers la collection. |
| Données structurées | `BreadcrumbList` ; `Article` (mythes, avec `author` = équipe éditoriale, `dateModified`) ; `DefinedTerm` (mots) ; `Quiz` (quiz) ; `FAQPage` évité sauf contenu réellement en Q/R. |
| Maillage interne | Natif grâce au graphe (liens contextuels + NextDoor). Aucune page orpheline (vérifié en CI). |
| Mots-clés cibles | Requêtes informationnelles : « [nom] mythologie », « histoire de [mythe] », « [personnage] percy jackson vs mythe », « origine du mot [mot] », « arbre généalogique dieux grecs ». |
| Performance | Core Web Vitals (§36) = facteur de classement. |

---

## 36. PERFORMANCE

### 36.1 Budgets (mesurés sur mobile milieu de gamme, 4G simulée)
| Métrique | Cible |
|---|---|
| LCP | < 2,0 s (max 2,5 s) |
| INP | < 200 ms |
| CLS | < 0,05 |
| JS initial (gzip) — fiche | ≤ 120 Ko |
| JS initial — accueil | ≤ 160 Ko |
| JS — page visualisation | ≤ 220 Ko |
| Poids total fiche (hors lazy) | ≤ 600 Ko |
| Polices | ≤ 3 fichiers variables, ≤ 150 Ko au total, préchargement de la police display uniquement |

### 36.2 Leviers
- Server Components par défaut ; îlots client minimaux.
- `LazyMotion`, imports dynamiques pour graphes, palette de recherche, quiz, Pagefind.
- Layouts de graphes pré-calculés au build (pas de simulation physique sur mobile).
- Images AVIF/WebP, `sizes` exacts, LQIP, lazy.
- Sous-ensembles de polices, `font-display: swap`, `size-adjust` pour limiter le décalage.
- Préchargement des liens au survol/visibilité (comportement par défaut de `next/link`, limité sur connexions lentes via `navigator.connection.saveData`).
- Aucun script tiers bloquant ; analytics < 2 Ko, chargé en différé.
- Cache CDN long pour les assets fingerprintés.

### 36.3 Contrôle
Lighthouse CI sur chaque PR (seuils bloquants), suivi des Web Vitals réels via l'analytics (sans cookies).

---

## 37. INTERNATIONALISATION

| Aspect | Décision |
|---|---|
| Locales | `fr` (défaut, publiée), puis `en`, `es`, `de`, `it`, `pt`. Une locale n'est publiée que si ≥ 95 % du contenu MUST est traduit et vérifié. |
| Routage | `/[locale]/…` via next-intl, `pathnames` localisés (`/fr/dieux` ↔ `/en/gods`). |
| UI | Toutes les chaînes dans `content/i18n/[locale]/ui.json` (format ICU : pluriels, genres). **Aucune chaîne en dur** dans les composants (règle ESLint dédiée). |
| Contenu | Données structurelles partagées, textes par locale (§23). Champs i18n manquants → build échoue pour les locales publiées. |
| Noms propres | Les noms diffèrent selon les langues (Ulysse/Odysseus/Ulises) → stockés par locale, l'`id` reste stable. Alias multilingues pour la recherche. |
| Slugs | Localisés, générés depuis le nom localisé, figés une fois publiés (redirections sinon). |
| Formats | Dates et nombres via `Intl`. Siècles « av. J.-C. » localisés (BCE/a.C./v. Chr.). |
| Typographie | Polices couvrant latin étendu + grec ; règles typographiques françaises (espaces insécables avant `: ; ? !`, guillemets « ») appliquées par un plugin de rendu MDX. |
| Pop culture | Titres d'œuvres localisés (titres officiels par pays). |
| Sens de lecture | LTR uniquement prévu, mais usage de propriétés CSS logiques (`margin-inline`, `padding-block`) pour ne pas bloquer une future langue RTL. |
| Workflow de traduction | Fichiers MDX par langue → compatibles avec des outils de traduction (Crowdin, Weblate) plus tard. |

---

## 38. STRATÉGIE DE TESTS

| Niveau | Outil | Ce qu'on teste |
|---|---|---|
| **Contenu** | Zod + script `build-content` | Schémas, références, sources obligatoires, licences médias, traductions, relations symétriques cohérentes (ex. `sibling-of`), absence de cycles absurdes dans `parent-of`. |
| **Unitaires** | Vitest | Graphe (relations inverses, plus court chemin), tirage Oracle, quiz (score, paliers, graine), moteur de badges, normalisation de recherche. |
| **Composants** | Vitest + Testing Library | États des composants interactifs (quiz, filtres, cartes retournables, palette). |
| **E2E** | Playwright (Chromium, WebKit, Firefox ; viewports mobile/desktop) | Parcours clés : Journey 1 à 5 (§14), quiz complet, recherche, changement de langue, navigation clavier complète. |
| **Accessibilité** | axe-core (Playwright) sur toutes les pages-types ; tests manuels lecteur d'écran | 0 violation critique/sérieuse. |
| **Contraste** | `scripts/check-contrast.ts` | Toutes les paires de tokens texte/fond déclarées. |
| **Performance** | Lighthouse CI | Budgets §36 bloquants. |
| **Liens** | Vérificateur de liens internes/externes (hebdomadaire pour les externes) | Aucun lien interne cassé ; signalement des liens de sources morts. |
| **Visuel** | Captures Playwright (COULD) | Régressions du design system. |
| **Reduced-motion** | Playwright avec `reducedMotion: "reduce"` | Aucune animation de mouvement, contenu intact. |
| **Sans JS** | Playwright `javaScriptEnabled: false` | Fiches et mythes lisibles. |

---

## 39. STRATÉGIE DE DÉPLOIEMENT

- **Git** : `main` = production ; branches de fonctionnalité ; pull requests obligatoires.
- **CI (GitHub Actions)** à chaque PR : lint → typecheck → validation contenu → tests unitaires → build → Pagefind → Playwright + axe → Lighthouse CI.
- **Previews** : un déploiement de prévisualisation par PR (Vercel), utile pour relire le contenu en situation réelle.
- **Production** : déploiement automatique à la fusion sur `main` ; build entièrement statique (sauf route OG).
- **Rollback** : retour instantané à un déploiement précédent depuis l'hébergeur.
- **Domaine** : HTTPS, HSTS, redirections `www` → apex.
- **Contenu** : une correction de contenu = une PR (traçabilité, relecture).
- **Mises à jour** : Renovate/Dependabot hebdomadaire, priorité aux correctifs de sécurité Next/React.

---

## 40. SÉCURITÉ & VIE PRIVÉE

| Domaine | Mesure |
|---|---|
| Surface d'attaque | Site statique, pas de base de données, pas de comptes, pas d'API d'écriture → surface minimale. |
| En-têtes | CSP stricte (nonces si scripts inline), `X-Content-Type-Options`, `Referrer-Policy: strict-origin-when-cross-origin`, `Permissions-Policy` restrictive, `frame-ancestors 'none'`. |
| Contenu MDX | MDX compilé au build depuis le repo uniquement (jamais de MDX utilisateur), composants autorisés en liste blanche. |
| Formulaire « Signaler une erreur » | Via service tiers ou `mailto:` au MVP ; si endpoint maison : validation, limitation de débit, protection anti-spam sans traceur (honeypot / Turnstile). |
| Dépendances | Audit automatique, verrouillage des versions, peu de dépendances. |
| Liens externes | `rel="noopener noreferrer"`. |
| Vie privée (RGPD) | Analytics sans cookies et sans données personnelles ; `localStorage` uniquement pour des fonctions demandées par l'utilisateur (progression, préférences), expliqué dans la page Confidentialité ; bouton « effacer mes données locales ». Public potentiellement mineur → **aucune collecte de données personnelles**. |
| Partage | Aucune donnée personnelle dans les URLs/images partagées. |

---

## 41. STRATÉGIE ANALYTICS

**Outil** : Plausible ou Umami (sans cookies). Respect de `Do Not Track` / Global Privacy Control.

**Événements suivis** (anonymes, agrégés) :
| Événement | Propriétés | Question à laquelle il répond |
|---|---|---|
| `door_click` | porte | Quelles portes d'entrée attirent ? |
| `inline_link_click` | type source → type cible | L'effet réseau fonctionne-t-il ? |
| `nextdoor_click` | position (1–3), type | Les suggestions sont-elles pertinentes ? |
| `depth_change` | niveau | Les gens veulent-ils approfondir ? |
| `variant_open` | — | L'esprit critique intéresse-t-il ? |
| `oracle_use` | type tiré | Usage de l'aléatoire |
| `search` | nb résultats (pas la requête brute au départ ; requêtes sans résultat agrégées pour enrichir les alias) | Contenus manquants |
| `quiz_start` / `quiz_complete` | quiz, palier | Complétion |
| `share` | type de contenu | Viralité |
| `myth_read_complete` | mythe | Les récits sont-ils lus jusqu'au bout ? |
| `codex_disable` | — | La gamification gêne-t-elle ? |

**Tableau de bord mensuel** : KPI §1.5, top 20 pages, requêtes sans résultat, taux de complétion des mythes, chemins de navigation les plus fréquents.

---

# PARTIE F — EXÉCUTION

## 42. PLAN DE DÉVELOPPEMENT PAR PHASES

> Les phases reprennent celles du brief, avec un ajustement : le **schéma de données** est posé dès la phase 1 (le contenu, lui, est rempli en phase 5). Chaque phase se termine par une démo et une validation.

| Phase | Objectif | Livrables | Critère de sortie |
|---|---|---|---|
| **0 — Pilote éditorial** (fait le 15/10) | Valider la chaîne | Guides agents, fiche Méduse rédigée + vérifiée, galerie d'images pilote | Enzo valide le ton, la rigueur et le format de la galerie. |
| **1 — Fondations** | Socle technique | Repo, Next 16 + TS strict, Tailwind v4, next-intl (fr), ESLint/Prettier, CI de base, déploiement preview, **schémas Zod + pipeline de contenu avec 3 fiches d'exemple** (Zeus, Méduse, Persée) + 1 mythe, structure des dossiers | Build vert ; une fiche brute s'affiche depuis les données ; une référence cassée fait échouer le build. |
| **2 — Design system** | Identité et composants de base | `tokens.css`, typographie, thèmes clair/sombre, atomes (Button, Badge, Chip, Card, Dialog/Sheet, Tabs, Accordion, Tooltip), pictogrammes v1 (15), page `/styleguide` interne, script de contraste | Tous les atomes accessibles au clavier, contrastes validés. |
| **3 — Accueil** | Première impression | Header/Footer/MobileMenu, HeroSection, portes, teasers, Oracle (version simple) | Lighthouse mobile ≥ 90 ; validation visuelle. |
| **4 — Exploration** | Navigation par collections | Pages collection (Dieux, Héros, Créatures, Mythes), filtres en URL, `/explorer`, `/decouvrir`, recherche Pagefind + palette | Parcours débutant complet possible. |
| **5 — Données mythologiques** | Contenu MVP | ~118 contenus produits par la chaîne d'agents (§22.5) **par lots de 10–15** (Olympiens → créatures → héros → mythes → pop culture → mots), chaque lot suivi de sa galerie d'images (§29.4) et d'un échantillonnage par Enzo | 100 % des fiches MVP `verified` ; 0 média sans licence ni validation en galerie. **Démarre dès la phase 2, en parallèle du code.** |
| **6 — Pages détaillées** | Templates riches | EntityPage (toutes variantes), MythPage (chapitres, progression), VariantCompare, SourceList, NextDoor, InlineEntityLink, DepthSelector | Journey 5 (§14) réalisable de bout en bout. |
| **7 — Relations / généalogie** | Visualisations | FamilyTree desktop + vue focus mobile + alternative textuelle ; FamilyMini ; (SHOULD) RelationGraph | Navigation clavier de l'arbre ; mobile utilisable d'une main. |
| **8 — Quiz** | Apprentissage actif | Moteur de quiz, 6 types de questions, 3 quiz + Mythe ou fiction, résultats partageables (OG) | Quiz complet au clavier et au lecteur d'écran. |
| **9 — Pop culture** | Différenciation | Pages œuvre, comparaisons (Percy Jackson ×8 + Hercule + Hades), Mots, « Où l'as-tu rencontrée ? » | Bandeaux de garde-fou présents ; relecture « couches » OK. |
| **10 — Animations** | Polissage | Transitions de page (View Transitions), parallaxe, retournements, tracés SVG, Oracle complet, réglage reduced-motion | Budgets perf tenus ; tests reduced-motion verts. |
| **11 — SEO** | Visibilité | Métadonnées, OG par fiche, JSON-LD, sitemap, robots, hreflang, maillage vérifié | 0 page orpheline ; validateurs de données structurées OK. |
| **12 — Optimisation** | Qualité finale | Audit perf, a11y manuel, tests appareils réels, pages légales, analytics, QA complète (§44) | Definition of Done (§45) atteinte → **lancement MVP**. |
| **Post-MVP (V1.1)** | SHOULD | Galaxie, Lieux + carte, Objets, Codex + badges, Quel dieu es-tu, Marvel & autres œuvres | — |

---

## 43. ÉVOLUTIVITÉ & FONCTIONNALITÉS FUTURES

### 43.1 Évolutivité prévue par l'architecture
- **Nouvelle fiche** = 1 fichier YAML + 1 MDX par langue. Aucun composant à modifier.
- **Nouvelle catégorie** (ex. « Nymphes ») = ajout d'une valeur d'énumération + éventuelle spécialisation de schéma.
- **Nouvelle langue** = dossier `i18n/xx` + `ui.json` + traduction des slugs.
- **Autres mythologies** (nordique, égyptienne…) : le modèle supporte un champ `pantheon` futur ; la galaxie pourrait relier Zeus ↔ Jupiter ↔ Thor comme « équivalents/comparables ».
- **CMS** : si des rédacteurs non techniques rejoignent le projet, brancher un CMS headless basé sur Git (Keystatic, TinaCMS, Decap) qui édite les mêmes fichiers → aucune migration de données.

### 43.2 Fonctionnalités futures (backlog commenté)
| Fonctionnalité | Intérêt |
|---|---|
| Chronologie « Les Âges du mythe » | Résout la confusion temporelle. |
| Le Ciel des dieux (astronomie) | Pont science/culture, très visuel. |
| « Ton prénom vient-il des mythes ? » | Viralité identitaire. |
| Mini-jeux (« Qui suis-je ? » en indices progressifs, Labyrinthe de connaissances) | Rejouabilité. |
| Version audio des mythes | Accessibilité, usage mobile. |
| Mode enseignant (fiches imprimables, parcours de classe, quiz projetables) | Diffusion par les profs. |
| Comparateur de versions avancé (Hésiode / Homère / Ovide en parallèle) | Niveau « Approfondir ». |
| Export/import de progression | Multi-appareils sans compte. |
| Comptes optionnels (si vraiment demandé) | Synchronisation — à n'envisager qu'avec une politique de données irréprochable. |
| PWA (lecture hors ligne des mythes) | Transports, zones mal couvertes. |

---

## 44. CHECKLIST QA

### Contenu
- [ ] Chaque fiche a `review.status: verified`, relecteur et date.
- [ ] Chaque bloc mythologique a ≥ 1 source A ou B.
- [ ] Aucune info 🎬 hors des blocs « culture populaire » et des pages de comparaison.
- [ ] Les variantes sont signalées (« plusieurs versions »), sources grecques/romaines distinguées.
- [ ] Ton conforme (gabarit §21) ; aucun paragraphe > 4 lignes sur mobile.
- [ ] Contenus sensibles traités selon la charte §21.6.
- [ ] Orthographe et typographie françaises (espaces insécables, guillemets).

### Médias & licences
- [ ] Chaque image a une entrée de registre complète (licence, source, `alt`, date).
- [ ] Aucune image d'œuvre moderne protégée ni de logo.
- [ ] Page Crédits à jour (générée).
- [ ] `THIRD_PARTY_NOTICES.md` à jour (code et polices).

### Design & responsive
- [ ] Conforme au design system (tokens uniquement, pas de valeurs en dur).
- [ ] Testé à 320, 375, 414, 768, 1024, 1280, 1536 px.
- [ ] Testé sur iPhone (Safari), Android milieu de gamme (Chrome), Firefox desktop, Safari desktop.
- [ ] Thèmes clair et sombre vérifiés sur toutes les pages-types.
- [ ] Aucune interaction dépendant uniquement du survol.

### Accessibilité
- [ ] axe : 0 violation critique/sérieuse.
- [ ] Parcours complet au clavier (accueil → fiche → quiz → recherche).
- [ ] Focus visible partout, ordre logique.
- [ ] Lecteur d'écran : fiche, quiz, arbre (alternative), palette de recherche.
- [ ] Zoom 200 % sans perte.
- [ ] `prefers-reduced-motion` et réglage manuel respectés.

### Performance
- [ ] Lighthouse mobile ≥ 90 perf sur accueil, fiche, mythe, collection, quiz, généalogie.
- [ ] Budgets JS/poids respectés (§36).
- [ ] CLS < 0,05 (images dimensionnées, polices ajustées).

### SEO
- [ ] Titre, description, OG uniques par page.
- [ ] hreflang/canonical corrects.
- [ ] Sitemap complet, robots correct.
- [ ] JSON-LD valide.
- [ ] Aucune page orpheline, aucun lien interne cassé.

### Fonctionnel
- [ ] Recherche : alias (Hercule → Héraclès), sans accents, zéro résultat géré.
- [ ] Oracle : jamais deux fois de suite le même contenu.
- [ ] Quiz : scores et paliers corrects, partage fonctionnel, mode révision.
- [ ] Filtres : état dans l'URL, retour arrière fonctionnel.
- [ ] Gamification désactivable, données locales effaçables.
- [ ] 404 et états vides soignés.
- [ ] Sans JavaScript : fiches et mythes lisibles.

### Légal & vie privée
- [ ] Mentions légales, confidentialité, crédits publiés.
- [ ] Aucun cookie non essentiel, analytics conforme.
- [ ] Mention des marques citées.

---

## 45. DEFINITION OF DONE

### Pour une fonctionnalité / un composant
Une fonctionnalité est **terminée** quand :
1. Elle respecte sa spécification (§15 / §34) et le design system.
2. Elle fonctionne de 320 px au grand écran, au tactile et au clavier.
3. Elle passe axe sans violation critique et respecte `prefers-reduced-motion`.
4. Elle n'introduit aucune chaîne en dur (i18n) ni valeur de style hors tokens.
5. Elle est couverte par des tests (unitaires et/ou E2E selon le cas).
6. Elle respecte les budgets de performance de la page concernée.
7. Elle a été relue (PR) et vue en preview.

### Pour un contenu (fiche, mythe, comparaison)
1. Gabarit respecté, toutes les couches correctement étiquetées.
2. Sources renseignées et vérifiées ; variantes signalées.
3. Médias sous licence valide, `alt` rédigé.
4. Au moins 3 connexions sortantes (relations, NextDoor) et au moins 1 entrante (pas d'orphelin).
5. Statut `verified`.

### Pour le MVP
1. Tous les éléments **MUST** (§7) livrés.
2. Checklist QA (§44) entièrement cochée.
3. Le **test du persona** est réussi : 3 personnes de 15–25 ans testent le site 20 minutes sans consigne ; au moins 2 sur 3 consultent ≥ 8 pages et savent ensuite expliquer la différence entre un élément de mythe et un élément de Percy Jackson.
4. Et la question du brief reçoit un **oui** honnête :
   > « Est-ce que cela donne davantage envie à quelqu'un de 15–25 ans de découvrir la mythologie grecque ? »

---

*Fin du blueprint v1.0 — en attente de validation.*

