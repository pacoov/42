# Rapport de vérification : fiche « Hadès » (lot 1, vague A)

- **Fiche vérifiée :** `/home/claude/editorial/drafts/hades.draft.md` (YAML + MDX, draft v1)
- **Brief :** `/home/claude/editorial/briefs/lot1-vagueA.md` (en-tête de lot + section HADÈS)
- **Vérificateur :** agent indépendant, 2026-10-15
- **Méthode :** chaque affirmation a été contrôlée en ligne, sans s'appuyer sur la mémoire. Pour les textes antiques, j'ai travaillé sur le **texte original numéroté** : fichiers TEI des éditions Perseus, dépôt `PerseusDL/canonical-greekLit` / `canonical-latinLit` sur raw.githubusercontent.com. Les vers ont été extraits par leur numéro. J'ai recoupé avec des traductions anglaises (Perseus eng, theoi.com) et le LSJ (lsj.gr). Le serveur theoi.com refusait les téléchargements directs ; je l'ai consulté par WebFetch. Les sections « Sources consultées » et « Doutes » de l'auteur m'ont servi d'indices, jamais de preuves.

**URL des textes consultés (abrégées dans le tableau) :**
- [IL-GR] Homère, *Iliade*, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml
- [HES-GR] Hésiode, *Théogonie*, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml
- [SC-GR] *Bouclier d'Héraclès*, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg003/tlg0020.tlg003.perseus-grc2.xml
- [HHD-GR] *Hymne homérique à Déméter*, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg002/tlg0013.tlg002.perseus-grc2.xml
- [APD-GR] / [APD-EN] Apollodore, *Bibliothèque*, grec et trad. Frazer : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-grc2.xml et …/tlg0548.tlg001.perseus-eng2.xml
- [EUM-GR] Eschyle, *Euménides* : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0085/tlg007/tlg0085.tlg007.perseus-grc2.xml
- [SUPP-GR] Eschyle, *Suppliantes* : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0085/tlg001/tlg0085.tlg001.perseus-grc2.xml
- [CRAT-GR] Platon, *Cratyle* : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0059/tlg005/tlg0059.tlg005.perseus-grc2.xml
- [LOIS-GR] Platon, *Lois* : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0059/tlg034/tlg0059.tlg034.perseus-grc2.xml
- [PAUS] Pausanias, grec et trad. : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0525/tlg001/tlg0525.tlg001.perseus-grc2.xml et …/tlg0525.tlg001.perseus-eng2.xml
- [OV-LA] Ovide, *Métamorphoses*, latin numéroté : https://raw.githubusercontent.com/PerseusDL/canonical-latinLit/master/data/phi0959/phi006/phi0959.phi006.perseus-lat2.xml (recoupé avec https://www.thelatinlibrary.com/ovid/ovid.met5.shtml)
- [THEOI] https://www.theoi.com/Khthonios/Haides.html
- [LSJ-H] https://lsj.gr/wiki/ᾍδης · [LSJ-K] https://lsj.gr/wiki/κυνέη

---

### Verdict global
**PUBLIABLE APRÈS CORRECTIONS**

La fiche est solide. Je n'ai trouvé aucune erreur grave sur la généalogie, le partage du monde, la grenade, Ploutôn ou le casque. Presque tous les numéros de vers grecs sont exacts. L'enlèvement est traité de façon factuelle et sobre, et la version d'Ovide est bien signalée comme romaine. Avant publication, il faut toutefois corriger les points suivants :
1. une **citation de l'*Iliade* attribuée à Homère** alors que c'est Agamemnon qui parle ; elle sert d'argument à un bloc d'interprétation trop affirmatif (« pas cruel », « sévère mais juste ») ;
2. des **formules absolues** (« ne laisse sortir personne ») que la fiche contredit elle-même, ainsi qu'une porte de sortie qui semble rendre Perséphone responsable (« tout ça pour un grain de grenade ») ;
3. un **numéro de vers d'Ovide** (383 au lieu de 384), la **balise `[À VÉRIFIER]`** encore présente (le fait est maintenant confirmé) et deux points du brief absents du MDX (casque donné par les Cyclopes ; le nom d'Hadès qui désigne le lieu, encore balisé).

---

### Tableau des affirmations

| # | Affirmation (résumée) | Verdict | Source consultée (URL) | Correction proposée |
|---|---|---|---|---|
| 1 | Hadès est le fils de Cronos et Rhéa | ✅ | [IL-GR] XV, 187 « τρεῖς… ἐκ Κρόνου… οὓς τέκετο Ῥέα » ; [HES-GR] v. 453–455 ; [APD-GR] I, 1, 5 (Πλούτωνα) | — |
| 2 | Hadès est le frère de Zeus et de Poséidon | ✅ | [IL-GR] XV, 187–188 ; [HES-GR] v. 453–457 | — |
| 3 | Hadès est le frère d'Héra, Déméter et Hestia | ✅ | [HES-GR] v. 454 « Ἱστίην Δήμητρα καὶ Ἥρην » | — |
| 4 | Cronos avale ses enfants parce qu'il sait qu'un d'eux le renversera | ✅ | [HES-GR] v. 459–467 (prédiction de Gaïa et Ouranos, v. 463–465) | — |
| 5 | Seul Zeus y échappe : Rhéa fait avaler une pierre emmaillotée | ✅ | [HES-GR] v. 485–487 ; [APD-GR] I, 1, 7 | — |
| 6 | Cronos recrache ensuite tous ses enfants | ✅ | [HES-GR] v. 494–497 (ruse de Gaïa) ; [APD-GR] I, 2, 1 (drogue donnée par Métis) | Facultatif : préciser que les moyens diffèrent selon les auteurs (Gaïa chez Hésiode, Métis chez Apollodore). |
| 7 | Hadès et ses frères et sœurs font la guerre aux Titans aux côtés de Zeus | ✅ | [HES-GR] v. 624–634 (« ὅσοι Κρόνου ἐξεγένοντο ») ; [APD-GR] I, 2, 1 | — |
| 8 | Chez Homère : tirage au sort ; ciel pour Zeus, mer pour Poséidon, « ombre brumeuse » pour Hadès ; la terre et l'Olympe restent communs | ✅ | [IL-GR] XV, 189–193 (ἔλαχε ζόφον ἠερόεντα, v. 191 ; γαῖα… ξυνὴ πάντων καὶ μακρὸς Ὄλυμπος, v. 193) | Facultatif : le tirage au sort se retrouve aussi chez Apollodore, I, 2, 1 (διακληροῦνται). |
| 9 | Hésiode, *Théogonie*, v. 881–885 : « Pas de tirage au sort » ; les dieux poussent Zeus à régner et il répartit les honneurs | ⚠️ | [HES-GR] v. 881–885 (ὤτρυνον βασιλευέμεν… Γαίης φραδμοσύνῃσιν… διεδάσσατο τιμάς) | Le contenu est exact, mais Hésiode *ne mentionne pas* de tirage ; il ne le nie pas. Écrire : « Hésiode ne parle pas de tirage au sort : sur le conseil de Gaïa, les dieux poussent Zeus à régner… ». |
| 10 | La Mort personnifiée est Thanatos, fils de la Nuit | ✅ | [HES-GR] v. 211–212 (Νὺξ… τέκε… Θάνατον) ; https://en.wikipedia.org/wiki/Thanatos | — |
| 11 | Son épouse est Perséphone, fille de Déméter (YAML `spouse-of`) | ✅ | [HES-GR] v. 767–768, 912–914 ; [HHD-GR] v. 79 (ἄκοιτιν), 343 (παρακοίτι) | — |
| 12 | Il porte aussi le nom d'Aïdoneus | ✅ | [HHD-GR] v. 2, 84, 357 ; [HES-GR] v. 913 ; [IL-GR] XX, 61 | — |
| 13 | Pluton (Ploutôn) signifie « le riche » | ✅ | https://www.britannica.com/topic/Hades-Greek-mythology (« the Wealthy One » / « the Giver of Wealth ») ; [THEOI] (« the giver of wealth ») | Facultatif : « le riche, ou celui qui donne la richesse ». |
| 14 | Selon Platon (IVe s. av. J.-C.), on l'appelle Pluton parce que la richesse monte du sous-sol | ✅ | [CRAT-GR] 403a « κατὰ τὴν τοῦ πλούτου δόσιν, ὅτι ἐκ τῆς γῆς κάτωθεν ἀνίεται ὁ πλοῦτος » ; dates de Platon : https://en.wikipedia.org/wiki/Plato | Facultatif (répond au brief) : le même passage dit qu'on emploie « Pluton » *par peur* du nom d'Hadès (φοβούμενοι τὸ ὄνομα). C'est l'euphémisme. Le lien avec les récoltes n'apparaît que dans des synthèses modernes (Wikipédia, d'après Wypustek 2012) : ne pas l'écrire sans source antique. |
| 15 | Les Romains l'appellent Pluton, Dis ou Orcus | ✅ | [OV-LA] V, 384 (« Ditem ») ; [THEOI] : Cicéron, *De nat. deorum*, III, 17 (« Orcus ») ; Hygin, préface (« Pluto ») | Voir forme : « Pluton » apparaît deux fois dans la même puce. |
| 16 | La kunée est un casque qui rend invisible | ✅ | [LSJ-K] : « mythical helmet which rendered the wearer invisible » ; [APD-GR]/[APD-EN] II, 4, 2 (« he saw whom he pleased, but was not seen by others ») | Doute 2 de l'auteur levé : le LSJ confirme le sens d'origine (« a dog's skin… used for making soldiers' caps »). La glose « à l'origine, un bonnet en peau de chien » peut être ajoutée. |
| 17 | Dans l'*Iliade*, Athéna met le casque pour qu'Arès ne la voie pas | ✅ | [IL-GR] V, 845 « δῦνʼ Ἄϊδος κυνέην, μή μιν ἴδοι ὄβριμος Ἄρης » | Doute 3 : la formulation est juste. L'invisibilité y est implicite (le LSJ la lit ainsi) ; elle est explicite chez Apollodore, II, 4, 2. |
| 18 | Les Cyclopes lui donnent le casque pendant la guerre contre les Titans (YAML) | ✅ | [APD-GR] I, 2, 1 « Κύκλωπες… Πλούτωνι δὲ κυνέην » | Point obligatoire du brief **absent du MDX** : ajouter « offert par les Cyclopes selon Apollodore » dans la puce sur la kunée. |
| 19 | « Le casque d'Hadès » apparaît dans le *Bouclier d'Héraclès*, v. 226–227 (YAML) | ✅ | [SC-GR] v. 226–227 « Ἄιδος κυνέη νυκτὸς ζόφον αἰνὸν ἔχουσα » (sur la tête de Persée) | — |
| 20 | Cerbère est « le chien d'Hadès » ; il a cinquante têtes chez Hésiode et trois chez Apollodore | ✅ | [HES-GR] v. 311–312 (Ἀίδεω κύνα… πεντηκοντακέφαλον) ; [APD-GR] II, 5, 12 (τρεῖς… κυνῶν κεφαλάς) | — |
| 21 | Chez Hésiode, le chien accueille les arrivants en remuant la queue et dévore ceux qui tentent de sortir | ✅ | [HES-GR] v. 769–773 (σαίνει… οὐρῇ… ἐσθίει, ὅν κε λάβῃσι… ἔκτοσθεν ἰόντα) | Le chien n'est pas nommé à cet endroit (il l'est au v. 311). Écrire « son chien » est acceptable. |
| 22 | Hook « … et ne laisse sortir personne » ; puce « Personne ne ressort de chez lui » | ⚠️ | [HHD-GR] v. 357–360 (Hadès laisse partir Perséphone) ; [APD-GR] II, 5, 12 (Pluton autorise Héraclès à emmener Cerbère ; Héraclès ramène Thésée) | Trop absolu : la fiche raconte elle-même deux sorties. Écrire « … et ne laisse (presque) personne sortir » ; puce : « En principe, on ne ressort pas de chez lui ». |
| 23 | Homère : « celui qui règne sur ceux d'en bas » (*Iliade*, XV, 188) | ✅ | [IL-GR] XV, 188 « Ἀΐδης ἐνέροισιν ἀνάσσων » | — |
| 24 | « Il juge » : chez Eschyle (Ve s.), les Érinyes disent qu'il surveille les mortels et note tout dans son esprit | ⚠️ | [EUM-GR] v. 273–275 « μέγας γὰρ Ἅιδης ἐστὶν εὔθυνος βροτῶν ἔνερθε χθονός, δελτογράφῳ δὲ πάντʼ ἐπωπᾷ φρενί » ; date (458) : https://en.wikipedia.org/wiki/Oresteia ; Britannica : il n'était « pas normalement un juge » | La paraphrase est exacte, mais il manque « sous la terre » et le titre « Il juge » va trop loin. Le mot εὔθυνος désigne celui qui demande des comptes. Proposer : « Il demande des comptes : chez Eschyle, les Érinyes disent que, sous la terre, il fait rendre des comptes aux mortels et note tout dans son esprit. » |
| 25 | Enlèvement : Perséphone cueille des fleurs, la terre s'ouvre, Hadès surgit sur son char et l'emporte contre son gré | ✅ | [HHD-GR] v. 5–19 (ἄνθεά τʼ αἰνυμένην ; χάνε δὲ χθὼν ; ἁρπάξας δʼ ἀέκουσαν ἐπὶ χρυσέοισιν ὄχοισιν) | Traitement factuel et sobre : conforme à la charte. |
| 26 | C'est Zeus qui la lui a « donnée », sans demander l'avis de la mère | ✅ | [HHD-GR] v. 3–4 « δῶκεν δὲ… Ζεύς, νόσφιν Δήμητρος » ; v. 77–79 ; [HES-GR] v. 914 ; [APD-GR] I, 5, 1 (Διὸς συνεργοῦντος) | — |
| 27 | L'*Hymne à Déméter* date du VIIe–VIe s. av. J.-C. | ✅ | https://human.libretexts.org/Courses/Long_Beach_City_College/Temples_of_the_Gods%3A_An_Introduction_to_Classical_Mythology/05%3A_The_Feminine_Divine/5.06%3A_The_Homeric_Hymn_to_Demeter (« seventh century as the probable date », « not later than the beginning of the sixth ») | — |
| 28 | Déméter empêche les graines de pousser | ✅ | [HHD-GR] v. 305–307 (οὐδέ τι γαῖα σπέρμʼ ἀνίει) | — |
| 29 | « Les humains meurent de faim, les dieux n'ont plus d'offrandes » | ⚠️ | [HHD-GR] v. 310–313 (« elle *aurait* anéanti la race des hommes… et privé les dieux de sacrifices, *si Zeus ne s'en était aperçu* ») | Le texte décrit une menace, pas un fait accompli. Écrire : « Les humains vont mourir de faim, et les dieux perdre leurs offrandes. » |
| 30 | Zeus envoie Hermès chercher Perséphone ; Hadès obéit | ✅ | [HHD-GR] v. 334–341, 357–358 | — |
| 31 | Hadès lui fait manger en cachette un grain de grenade, qui la lie au monde d'en bas pour un tiers de l'année | ✅ | [HHD-GR] v. 371–374 (ῥοιῆς κόκκον… λάθρῃ), 398–400, 445–447 | — |
| 32 | Version de l'*Hymne* : elle dit ensuite à sa mère qu'il l'a forcée à le manger | ✅ | [HHD-GR] v. 411–413 (ἄκουσαν δὲ βίῃ με προσηνάγκασσε πάσασθαι) | — |
| 33 | Version d'Apollodore : enlèvement « avec l'aide de Zeus », un grain de grenade, Ascalaphe témoigne, un tiers de l'année avec Hadès ; Ier–IIe s. apr. J.-C. | ✅ | [APD-GR]/[APD-EN] I, 5, 1 et I, 5, 3 ; date : https://en.wikipedia.org/wiki/Bibliotheca_(Pseudo-Apollodorus) | « Un habitant des Enfers » : Apollodore le dit fils d'Achéron et de Gorgyra, ce qui est acceptable. |
| 34 | Version d'Ovide : Cupidon, sur ordre de Vénus, frappe Dis ; sept grains ; année partagée en deux ; vers « V, 366–383, 536–539, 565–567 » | ⚠️ | [OV-LA] V, 365–384 (la flèche frappe Dis au **v. 384** : « inque cor hamata percussit harundine Ditem ») ; v. 537 (septem… grana) ; v. 564–567 (ex aequo… dividit annum) ; confirmé par thelatinlibrary (v. 384 entre les repères 380 et 385) | Le contenu est exact. Corriger les vers en « V, 365–384, 536–539, 564–567 » dans le MDX (Versions et Sources) et dans le YAML. |
| 35 | Ovide est un poète romain, vers 8 apr. J.-C. | ✅ | https://en.wikipedia.org/wiki/Metamorphoses (« first published in 8 CE ») | — |
| 36 | « Homère le juge “le plus détesté des dieux” parce qu'on ne peut pas le fléchir » | ❌ | [IL-GR] IX, 158–159 : c'est **Agamemnon** qui parle (discours rapporté à Achille) : « Ἀΐδης τοι ἀμείλιχος ἠδʼ ἀδάμαστος, τοὔνεκα καί τε **βροτοῖσι** θεῶν ἔχθιστος ἁπάντων » | Il s'agit des paroles d'un personnage, pas d'un jugement du poète. De plus, la phrase grecque dit « le plus détesté des dieux **pour les mortels** ». Écrire : « Dans l'*Iliade*, Agamemnon le dit implacable, et pour cela le plus détesté des dieux par les mortels. » |
| 37 | « Les textes anciens ne le montrent pas cruel » | ⚠️ | [HES-GR] v. 456 « νηλεὲς ἦτορ ἔχων » (« au cœur sans pitié ») ; [HHD-GR] v. 395 « στυγεροῦ Ἀίδαο » (« l'odieux Hadès ») ; [HHD-GR] v. 413 (la force) | Généralisation trop forte. Proposer : « Les textes anciens le disent impitoyable et inflexible, mais ne font pas de lui un dieu du mal. » |
| 38 | « Beaucoup de lectures modernes en font… un dieu sévère mais juste » | ⚠️ | https://en.wikipedia.org/wiki/Hades (« stern, cruel, and unpitying, he was still just » : phrase **sans note de source**) ; Britannica : « stern and pitiless » (rien sur « juste ») ; [THEOI] : « fierce and inexorable » (rien sur « juste ») | Aucune source savante nommée n'a été trouvée pour « juste ». Le seul appui antique trouvé est Eschyle (#24), qui le montre demandant des comptes. Garder « sévère », supprimer « beaucoup » et fonder « juste » sur Eschyle. Exemple : « Les lectures modernes y voient plutôt un dieu sévère, gardien de l'ordre, qu'un dieu du mal. Eschyle le montre déjà demander des comptes aux mortels. » Voir les questions pour le directeur. |
| 39 | Le nom du dieu a fini par désigner le lieu ([À VÉRIFIER]) | ✅ | [LSJ-H] : « in Hom. only as pr.n. » ; sens de lieu « first in Il. 23.244 » ; [THEOI] (Smith) : « in later times it was transferred to his house… a name for the lower world itself » ; [IL-GR] XXIII, 244 « Ἄϊδι κεύθωμαι » | Doute 1 levé : **retirer la balise**. On peut préciser : « Chez Homère, Hadès est presque toujours le dieu ; on va “chez Hadès”. Plus tard, le nom désigne le lieu lui-même. » Ce point du brief mériterait aussi une ligne dans « En bref ». |
| 40 | Homère : les morts vont « dans la maison d'Hadès » (*Iliade*, XXIII, 19) | ✅ | [IL-GR] XXIII, 19 « εἰν Ἀΐδαο δόμοισι » | — |
| 41 | Hadès vit « sous la terre » (*Théogonie*, v. 455) | ✅ | [HES-GR] v. 455 « ὃς ὑπὸ χθονὶ δώματα ναίει » | — |
| 42 | Il est rarement compté parmi les Douze parce qu'il vit sous la terre et non sur l'Olympe | ✅ | https://en.wikipedia.org/wiki/Twelve_Olympians (« his realm was far away from Olympus… not usually considered » ; « no single canonical list ») ; [LOIS-GR] 828c–d (contre-exemple : mois de Pluton) | L'explication demandée par le brief est présente et correcte. |
| 43 | Blessé par une flèche d'Héraclès, il monte se faire soigner sur l'Olympe (*Iliade*, V, 395–402) | ✅ | [IL-GR] V, 395–402 (βῆ πρὸς δῶμα Διὸς καὶ μακρὸν Ὄλυμπον ; Παιήων… ἠκέσατʼ) | — |
| 44 | Pausanias (IIe s.) : les Éléens sont les seuls qu'il connaisse à honorer Hadès ; le temple ouvre une fois par an, car on ne descend chez Hadès qu'une fois | ✅ | [PAUS] VI, 25, 2–3 (« ἅπαξ κατὰ ἔτος », « μόνοι τιμῶσιν Ἅιδην Ἠλεῖοι », « ὅτι οἶμαι… ἅπαξ ἡ κάθοδος ») ; dates : https://en.wikipedia.org/wiki/Pausanias_(geographer) | L'explication est une supposition de Pausanias lui-même (« je suppose »). « Raison avancée » convient. |
| 45 | *Hercule* (Disney, 1997) : Hadès est le grand méchant, a des cheveux de flammes et complote pour renverser Zeus et régner sur l'Olympe | ✅ | https://en.wikipedia.org/wiki/Hercules_(1997_film) (« plots to overthrow Zeus and rule Mount Olympus » ; « fiery hair ») | — |
| 46 | *Percy Jackson et le Voleur de foudre* (Riordan, 2005) : « tout le monde soupçonne Hadès » ; il est innocent ; son casque a aussi été volé | ⚠️ | https://en.wikipedia.org/wiki/The_Lightning_Thief (2005 ; Hadès « possible culprit » ; Luke a volé la foudre et le casque) ; titre français : https://www.livraddict.com/biblio/book.php?id=4046 | Le fond est exact, mais : (a) *Percy Jackson et le Voleur de foudre* est le titre français du **film** (2010) ; le roman s'intitule *Percy Jackson, t. 1 : Le Voleur de foudre* (2005, trad. fr. 2006). (b) « Tout le monde » est trop fort : c'est Percy et ses amis qui soupçonnent Hadès, alors que Zeus accuse Percy. Écrire « Percy et ses amis soupçonnent Hadès… ». |
| 47 | *Hades* (Supergiant Games, 2020) : on joue Zagreus, son fils, qui tente de s'évader ; Hadès est un père sévère et distant et le boss final | ✅ | https://en.wikipedia.org/wiki/Hades_(video_game) (sortie complète en septembre 2020, accès anticipé en 2018 ; « unloving father » ; boss final) | Facultatif : chez Eschyle (fragment), Zagreus semble déjà fils d'Hadès (https://en.wikipedia.org/wiki/Zagreus). Cela ferait un bon « Le saviez-vous » si on le vérifie dans le fragment lui-même. |
| 48 | Porte vers Cerbère : « Trois têtes ou cinquante ? » | ✅ | voir #20 | — |
| 49 | Porte vers Perséphone : « Reine des Enfers un tiers de l'année, et tout ça pour un grain de grenade » | ⚠️ | [HHD-GR] v. 411–413 (forcée) ; [OV-LA] V, 537 (sept grains) | Le ton fait porter la responsabilité sur Perséphone, alors que l'*Hymne* dit qu'elle a été forcée. Proposer : « Reine des Enfers un tiers de l'année : enlevée, puis liée au monde d'en bas par un grain de grenade. » |
| 50 | YAML, alias « Polydegmôn » | ✅ | [HHD-GR] v. 17, 31, 404 (Πολυδέγμων) | — |
| 51 | YAML, alias « Zeus souterrain » (*Iliade*, IX, 457) | ✅ | [IL-GR] IX, 457 « Ζεύς τε καταχθόνιος » | — |
| 52 | YAML, `heracles → hades : enemy-of` (variant) | ✅ | [IL-GR] V, 395–402 ; [PAUS] VI, 25, 2–3 (« foe of Heracles ») ; [APD-GR] II, 5, 12 | Ajouter Pausanias VI, 25, 2–3 comme source : c'est le texte qui le dit explicitement. |
| 53 | YAML, sources Platon *Lois* VIII, 828c ; Eschyle *Suppliantes* v. 230–231 ; *Iliade* XX, 61–65 | ✅ | [LOIS-GR] 828c–d (ἐν τῷ τοῦ Πλούτωνος μηνὶ τῷ δωδεκάτῳ) ; [SUPP-GR] v. 230–231 (Ζεὺς ἄλλος ἐν καμοῦσιν) ; [IL-GR] XX, 61–65 | Le passage des *Lois* s'étend sur 828c–d. |
| 54 | Datations : Homère « vers le VIIIe s. », Hésiode « vers 700 » | ✅ | https://en.wikipedia.org/wiki/Iliad (consensus : fin du VIIIe s.) ; https://en.wikipedia.org/wiki/Hesiod (floruit vers 700) | — |

**Décompte : 44 ✅ · 9 ⚠️ · 1 ❌ · 0 ❓** (54 affirmations)

---

### Problèmes de forme et de ton
- **Balise `[À VÉRIFIER]`** encore présente dans « Le saviez-vous » (#39). Le fait est confirmé : retirer la balise.
- **Points obligatoires du brief incomplets dans le MDX** : le don du casque par les Cyclopes n'apparaît que dans le YAML (#18). L'emploi du nom d'Hadès pour désigner le lieu n'est traité que dans une puce encore balisée.
- **« Autres noms »** : « Pluton » apparaît deux fois, comme nom grec (Ploutôn) puis comme nom romain. Reformuler : « Ploutôn (« le riche »), d'où le latin Pluto, Pluton en français ; les Romains disent aussi Dis ou Orcus. »
- **YAML / MDX incohérents** sur les sources :
  - le YAML cite le *Bouclier*, les *Suppliantes*, les *Lois*, l'*Iliade* IX, 457 et XX, 61–65, absents de la liste « Sources » du MDX ;
  - inversement, Eschyle n'est daté qu'au siècle dans les deux, ce qui est correct.
  - Il faut aligner les deux listes, ou documenter la règle (le YAML peut lister plus de sources que le MDX).
- **Numéros de vers d'Ovide** à corriger aux trois endroits (#34).
- **Couches** : la section « Culture populaire » est bien isolée (🎬) et la version « interpretation » est bien marquée (🔍). Rien de pop culture ne déborde dans les faits.
- **Longueurs** : tous les paragraphes de « Son histoire » font 48 à 59 mots (≤ 60), ce qui est conforme.
- **Ton** : l'accroche et le tutoiement sont conformes (« tu joues Zagreus »). Le ton n'est ni scolaire ni infantilisant.
- **Contenu sensible (enlèvement)** : le traitement est factuel et sobre. « Contre son gré », la complicité de Zeus et la contrainte (v. 413) sont dites sans romantisation, et le YAML refuse à juste titre `lover-of`. Seule réserve : la porte « tout ça pour un grain de grenade » (#49).
- **Tension entre l'angle et le contenu** : l'accroche « Hadès n'est pas le méchant » cohabite avec un enlèvement non consenti. Le bloc d'interprétation devrait l'assumer, par exemple : « pas un dieu du mal, mais pas un héros non plus : il enlève Perséphone ». Sinon, la fiche risque de paraître le blanchir.
- **Typographie** : il faut contrôler les espaces insécables au rendu (doute 15 de l'auteur).

### Questions pour le directeur éditorial
1. **« Sévère mais juste »** : le brief impose cette formule, mais je n'ai trouvé aucune source savante nommée pour « juste ». La seule source est une phrase non sourcée de Wikipédia EN ; Britannica et le dictionnaire de Smith (via theoi) disent « sévère / impitoyable », sans « juste ». Deux options : garder la formule, attribuée prudemment et appuyée sur Eschyle, *Euménides* 273–275 ; ou la remplacer par « sévère, pas maléfique ».
2. **Ids hors liste du lot** : `cerberus`, `thanatos` et `hermes` ne figurent pas dans la liste commune. Faut-il les créer ou les valider ?
3. **Bloc YAML `deity:`** inventé sur le modèle de `creature:` : faut-il valider ce schéma pour les 5 fiches du lot ?
4. **Types de relations** : `cyclopes → hades : helped` (pour « a donné le casque ») et `heracles → hades : enemy-of` sont des approximations. Faut-il un type « gave » ?
5. **Anecdote facultative** : faut-il ajouter *Iliade* XX, 61–65 (Aïdoneus bondit de son trône, de peur que Poséidon ne fasse éclater la terre), qui est vérifiée et frappante ?
