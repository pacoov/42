# Rapport de vérification — Fiche « Poséidon » (lot 1, vague A, v1)

Vérificateur indépendant. Fiche vérifiée : `/home/claude/editorial/drafts/poseidon.draft.md`.
Brief : `/home/claude/editorial/briefs/lot1-vagueA.md` (en-tête + section POSÉIDON). Cohérence contrôlée avec `/home/claude/editorial/drafts/meduse.v2.md`.

**Méthode.** J'ai relu moi-même chaque passage antique dans le texte grec ou latin, ou dans une traduction du domaine public. Les textes grecs viennent du dépôt PerseusDL (TEI numérotés). J'en ai extrait les vers et les sections par script. Ovide et Augustin viennent de The Latin Library ; les dates et la culture populaire, de Wikipédia FR/EN ; Callimaque, de ToposText. Le site remacle.org n'a pas été nécessaire. Le site theoi.com n'a pas répondu (erreur de chargement). Les « Sources consultées » et les « Doutes » de l'auteur m'ont servi d'indices ; aucun n'a été repris sans contrôle.

URL utilisées (abréviations du tableau) :
- **[IL]** Iliade, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml
- **[OD]** Odyssée, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg002/tlg0012.tlg002.perseus-grc2.xml
- **[TH]** Hésiode, Théogonie, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml
- **[HH22]** Hymne homérique 22, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg022/tlg0013.tlg022.perseus-grc2.xml
- **[HDT]** Hérodote, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0016/tlg001/tlg0016.tlg001.perseus-grc2.xml
- **[APG]** Apollodore, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-grc2.xml
- **[APE]** Apollodore, trad. Frazer : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-eng2.xml
- **[BAC]** Bacchylide, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0199/tlg002/tlg0199.tlg002.perseus-grc2.xml
- **[PAU]** Pausanias, trad. Jones : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0525/tlg001/tlg0525.tlg001.perseus-eng2.xml
- **[SOPH]** Sophocle, Œdipe à Colone, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0011/tlg007/tlg0011.tlg007.perseus-grc2.xml
- **[OV]** Ovide, Métamorphoses VI : https://www.thelatinlibrary.com/ovid/ovid.met6.shtml
- **[AUG]** Augustin, Cité de Dieu XVIII : https://www.thelatinlibrary.com/augustine/civ18.shtml
- **[CALL]** Callimaque, Hymne à Délos (trad. Mair) : https://topostext.org/work/123

---

### Verdict global
**PUBLIABLE APRÈS CORRECTIONS**

La fiche est solide. Les numéros de vers et de sections ont presque tous été retrouvés exactement. Grec et romain sont bien distingués, et le piège du trident « forgé » a été évité à juste titre. Il n'y a aucune erreur factuelle bloquante. Il reste des corrections de nuance (voir ⚠️), une incohérence de références avec la fiche Méduse, et un problème de ton : la fiche n'emploie jamais le tutoiement.

**Décompte : 54 ✅ · 9 ⚠️ · 0 ❌ · 0 ❓** (63 affirmations)

---

### Tableau des affirmations

#### Accroche, rôle, « En bref »

| # | Affirmation (résumée) | Verdict | Source consultée (URL) | Correction proposée |
|---|---|---|---|---|
| 1 | Hook : « Quand il marche, les montagnes tremblent » | ✅ | [IL] XIII, 18–19 : τρέμε δʼ οὔρεα μακρὰ καὶ ὕλη / ποσσὶν ὑπʼ ἀθανάτοισι Ποσειδάωνος ἰόντος — https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml | — |
| 2 | Hook : « Quand il se vexe, Ulysse ne rentre plus chez lui » | ⚠️ | [OD] I, 20–21 : Poséidon s'acharne « jusqu'à ce qu'il atteigne sa terre » ; I, 75 : il le fait errer (πλάζει) ; IX, 532–534 : retour tardif prévu — https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg002/tlg0012.tlg002.perseus-grc2.xml | Ulysse finit par rentrer. Proposer : « Quand il se vexe, Ulysse met des années à rentrer chez lui. » |
| 3 | Fils de Cronos et Rhéa | ✅ | [TH] v. 453–456 (Rhéa, unie à Cronos, enfante… Ἐννοσίγαιον) ; [IL] XV, 187 ; [APG] I, 1, 5 — https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml | — |
| 4 | Frère de Zeus, Hadès, Héra, Hestia, Déméter | ✅ | [TH] v. 454–457 (Hestia, Déméter, Héra, Hadès, Ennosigaios, Zeus) ; [APG] I, 1, 5 — https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-grc2.xml | — |
| 5 | Domaines : mer, séismes, chevaux | ✅ | [HH22] v. 2 (γαίης κινητῆρα καὶ … θαλάσσης), v. 5 (ἵππων τε δμητῆρʼ) — https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg022/tlg0013.tlg022.perseus-grc2.xml | — |
| 6 | Trident « donné par les Cyclopes selon Apollodore » | ✅ | [APG] I, 2, 1 : Κύκλωπες τότε Διὶ μὲν διδόασι βροντὴν… Πλούτωνι δὲ κυνέην, Ποσειδῶνι δὲ τρίαιναν — https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-grc2.xml. Le texte dit bien « donnent », non « forgent ». Hésiode ([TH] v. 139–141, 501–506) ne parle que de la foudre de Zeus. Contre-version : chez [CALL] § 30 (Hymne IV, v. 30–31), le dieu frappe les montagnes avec l'« épée à trois pointes que les Telchines avaient fabriquée pour lui » — https://topostext.org/work/123 | Formulation correcte. Le « forgé par les Cyclopes » du brief n'est pas attesté : ne pas le réintroduire. Option : ajouter en YAML/commentaire « fabriqué par les Telchines chez Callimaque (IIIe s. av. J.-C.) ». |
| 7 | Palais d'or au fond de la mer, à Aigai | ✅ | [IL] XIII, 21–22 : Αἰγάς, ἔνθα δέ οἱ κλυτὰ δώματα βένθεσι λίμνης / χρύσεα μαρμαίροντα ; [OD] V, 381 — https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml | — |
| 8 | Épouse Amphitrite, mère de Triton | ✅ | [TH] v. 930–933 ; [APG] I, 4, 5 : Ποσειδῶν δὲ Ἀμφιτρίτην … γαμεῖ, καὶ αὐτῷ γίνεται Τρίτων καὶ Ῥόδη — https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-grc2.xml | — |
| 9 | Enfants célèbres : Polyphème, Pégase, Chrysaor | ⚠️ | Les faits sont exacts : [OD] I, 68–73 ; [APE] II, 4, 2 fin (« these she had by Poseidon ») = [APG] début de II, 4, 3 (τούτους δὲ ἐγέννησεν ἐκ Ποσειδῶνος) — https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-eng2.xml | Le brief demande de renvoyer à la fiche Méduse, avec le même traitement sobre. Or le MDX ne nomme jamais Méduse et n'a aucun `<E id="medusa">`. Proposer : « <E id="pegasus">Pégase</E> et <E id="chrysaor">Chrysaor</E>, nés de <E id="medusa">Méduse</E> ». Voir aussi la ligne 59 (locus). |
| 10 | Thésée « selon certaines versions » | ✅ | [BAC] 17, v. 33–36 (la fille de Pitthée unie à Poséidon m'a enfanté) ; [APG] III, 15, 7 (Égée, puis Poséidon la même nuit) ; [PAU] I, 17, 3 (Minos nie qu'il soit fils de Poséidon ; l'anneau) — https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0199/tlg002/tlg0199.tlg002.perseus-grc2.xml | — |
| 11 | Chez les Romains : Neptune | ✅ | [AUG] XVIII, 9 : « unda Neptunum » ; « mares pro Neptuno » — https://www.thelatinlibrary.com/augustine/civ18.shtml | — |

#### « Son histoire »

| # | Affirmation (résumée) | Verdict | Source consultée (URL) | Correction proposée |
|---|---|---|---|---|
| 12 | Avalé par son père à peine né | ✅ | [TH] v. 459–460 (chaque enfant avalé dès qu'il sort du ventre de sa mère) ; [APG] I, 1, 5 (… Πλούτωνα καὶ Ποσειδῶνα) — https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml | — |
| 13 | Cronos craint d'être renversé par un de ses enfants | ✅ | [TH] v. 461–465 ; [APG] I, 1, 5 (oracle de Gê et Ouranos) — https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-grc2.xml | — |
| 14 | Seul Zeus y échappe | ✅ | [APG] I, 1, 7 (pierre emmaillotée) ; [TH] v. 478–479, 485 et suiv. — https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-grc2.xml | (La variante arcadienne du poulain, n° 40, est correctement présentée comme une autre légende.) |
| 15 | « Adulte, il force Cronos à recracher toute la fratrie » | ⚠️ | [TH] v. 494–497 : Cronos recrache « trompé par les conseils avisés de Gaïa » (v. 496, « vaincu par la ruse et la force de son fils », est athétisé dans l'édition) ; [APG] I, 2, 1 : Métis donne à Cronos un vomitif (φάρμακον) — https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-grc2.xml | La force n'est pas le moyen décrit. Proposer : « Adulte, il fait recracher toute la fratrie à Cronos, par ruse (chez Apollodore, Métis lui fait boire un vomitif). » |
| 16 | Zeus mène la guerre contre les Titans | ✅ | [APG] I, 2, 1 (τὸν πρὸς Κρόνον καὶ Τιτᾶνας ἐξήνεγκε πόλεμον) — https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-grc2.xml | — |
| 17 | Citation : « Le sort m'a donné la mer grise, pour l'habiter à jamais » (XV, 190) | ✅ | [IL] XV, 190–191 : ἤτοι ἐγὼν ἔλαχον πολιὴν ἅλα ναιέμεν αἰεὶ / παλλομένων — https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml | Traduction fidèle (12 mots). On peut noter « XV, 190–191 », mais ce n'est pas obligatoire. |
| 18 | Zeus obtient le ciel, Hadès les ténèbres | ✅ | [IL] XV, 191–192 (Ἀΐδης δʼ ἔλαχε ζόφον ἠερόεντα, Ζεὺς δʼ ἔλαχʼ οὐρανὸν) ; [APG] I, 2, 1 (διακληροῦνται) — URL [IL] ci-dessus | — |
| 19 | Chez Hésiode, Zeus proclamé roi distribue les honneurs | ✅ | [TH] v. 881–885 (ὃ δὲ τοῖσιν ἑὰς διεδάσσατο τιμάς) — https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml | — |
| 20 | Ennosigaios, « l'Ébranleur de la terre » | ✅ | [TH] v. 456 ; [IL] XV, 184 ; [HH22] v. 4 — https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg022/tlg0013.tlg022.perseus-grc2.xml | — |
| 21 | Honoré comme Hippios, « dieu des chevaux » | ✅ | [PAU] I, 30, 4 (« altar to Poseidon, Horse God ») ; VIII, 25, 7 (« the first Arcadians to call Poseidon Horse ») — https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0525/tlg001/tlg0525.tlg001.perseus-eng2.xml | Option : Sophocle, *Œdipe à Colone*, v. 707–716 ([SOPH]) célèbre Poséidon qui a donné à Colone le mors des chevaux. Cette source est déjà listée dans le YAML mais n'est pas exploitée. |
| 22 | Polyphème, fils de Poséidon et de la nymphe Thoosa | ✅ | [OD] I, 70–73 (Θόωσα δέ μιν τέκε νύμφη … Ποσειδάωνι μιγεῖσα) — https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg002/tlg0012.tlg002.perseus-grc2.xml | — |
| 23 | Prière : qu'Ulysse rentre tard, seul, dans le malheur | ✅ | [OD] IX, 528–535 (ὀψὲ κακῶς ἔλθοι, ὀλέσας ἄπο πάντας ἑταίρους … εὕροι δʼ ἐν πήματα οἴκῳ) — URL [OD] | — |
| 24 | Poséidon ne le tue pas, il le fait errer | ✅ | [OD] I, 74–75 (οὔ τι κατακτείνει, πλάζει δʼ ἀπὸ πατρίδος αἴης) — URL [OD] | — |
| 25 | « tempête après tempête » | ⚠️ | [OD] V, 282–294 et 366–381 : l'unique tempête que Poséidon déchaîne lui-même contre Ulysse. La tempête qui détruit le navire en XII, 405 et suiv. vient de Zeus (Κρονίων). — URL [OD] | Proposer : « Il le fait errer loin de chez lui et, quand Ulysse croit enfin s'en sortir, brise son radeau dans une tempête. » |

#### « Ses pouvoirs »

| # | Affirmation (résumée) | Verdict | Source consultée (URL) | Correction proposée |
|---|---|---|---|---|
| 26 | Il secoue le sol immense et les sommets (*Il.* XX, 57–60) | ✅ | [IL] XX, 57–60 (ἐτίναξε γαῖαν ἀπειρεσίην ὀρέων τʼ αἰπεινὰ κάρηνα) — URL [IL] | — |
| 27 | Trident en main, il rassemble les nuages et lève tous les vents (*Od.* V, 291–294) | ✅ | [OD] V, 291–294 (σύναγεν νεφέλας … χερσὶ τρίαιναν ἑλών· πάσας δʼ ὀρόθυνεν ἀέλλας) — URL [OD] | — |
| 28 | Il change en rocher le navire phéacien (*Od.* XIII, 159–164) | ✅ | [OD] XIII, 159–164 (ὅς μιν λᾶαν ἔθηκε καὶ ἐρρίζωσεν ἔνερθε) — URL [OD] | — |
| 29 | Hymne : « dompteur de chevaux et sauveur des navires » | ✅ | [HH22] v. 5 (ἵππων τε δμητῆρʼ ἔμεναι σωτῆρά τε νηῶν) — URL [HH22] | On peut préciser « (v. 5) ». |
| 30 | Il offre à Pélée Balios et Xanthos, chevaux immortels (Apollodore) | ✅ | [APG] III, 13, 5 (Ποσειδῶν δὲ ἵππους Βαλίον καὶ Ξάνθον· ἀθάνατοι δὲ ἦσαν) ; déjà chez Homère : [IL] XXIII, 277–278 (ἀθάνατοί τε γάρ εἰσι, Ποσειδάων δὲ πόρʼ αὐτοὺς πατρὶ ἐμῷ Πηλῆϊ) — URL [APG] et [IL] | Option : « déjà chez Homère (*Il.* XXIII, 277–278) », une source plus ancienne. |

#### Bloc `<Versions>` : la dispute de l'Attique

| # | Affirmation (résumée) | Verdict | Source consultée (URL) | Correction proposée |
|---|---|---|---|---|
| 31 | Hérodote : tradition athénienne ; olivier et « mer » dans le temple d'Érechthée comme témoins ; ni jugement ni vainqueur | ✅ | [HDT] VIII, 55 (Ἐρεχθέος … νηός, ἐν τῷ ἐλαίη τε καὶ θάλασσα ἔνι, τὰ λόγος παρὰ Ἀθηναίων … μαρτύρια θέσθαι) — https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0016/tlg001/tlg0016.tlg001.perseus-grc2.xml | Résumé exact. |
| 32 | Hérodote « vers 430 av. J.-C. » | ✅ | Wikipédia FR, « Hérodote » : né vers 484, mort vers 425 av. J.-C. — https://fr.wikipedia.org/wiki/Hérodote | Approximation acceptable. |
| 33 | Apollodore : Poséidon d'abord (coup de trident, « mer ») ; Athéna plante l'olivier avec Cécrops pour témoin ; les douze dieux jugent ; Athéna gagne ; inondation de la plaine de Thria et de l'Attique | ✅ | [APG] III, 14, 1 (πλήξας τῇ τριαίνῃ … ἀπέφηνε θάλασσαν … Κέκροπα μάρτυρα ἐφύτευσεν ἐλαίαν … θεοὺς δὲ τοὺς δώδεκα … τὸ Θριάσιον πεδίον ἐπέκλυσε καὶ τὴν Ἀττικὴν ὕφαλον ἐποίησε) — https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-grc2.xml | Fidèle, y compris le paradoxe du texte (Poséidon arrive le premier, mais c'est Athéna qui a « planté la première »). |
| 34 | Apollodore « Ier–IIe s. apr. J.-C. » | ✅ | Wikipédia FR, « Pseudo-Apollodore » : « écrite au Ier ou IIe siècle » — https://fr.wikipedia.org/wiki/Pseudo-Apollodore | — |
| 35 | Varron chez Augustin : olivier et source apparaissent, vote, Minerve gagne d'une voix, Neptune ravage le pays, les femmes perdent le droit de vote | ⚠️ | [AUG] XVIII, 9 : « mares pro Neptuno, feminae pro Minerua » ; « una plus inuenta est feminarum, Minerua uicit » ; « Neptunus iratus marinis fluctibus … populatus est » ; triple punition : « ut nulla ulterius ferrent suffragia, ut nullus nascentium maternum nomen acciperet, ut ne quis eas Athenaeas uocaret » — https://www.thelatinlibrary.com/augustine/civ18.shtml | Le résumé est exact, mais la punition est incomplète. Ajouter : « Les femmes perdent le droit de vote, leurs enfants ne portent plus le nom de leur mère, et on ne les appelle plus Athéniennes. » Option : « sur l'avis d'un oracle d'Apollon consulté par le roi Cécrops ». |
| 36 | Varron, « Ier s. av. J.-C. » | ✅ | Wikipédia FR, « Varron » : « écrivain du Ier siècle av. J.-C. » — https://fr.wikipedia.org/wiki/Varron | — |
| 37 | Ovide, *Mét.* VI, 70–82 : Minerve tisse la scène ; douze dieux autour de Jupiter ; eau de mer jaillie du rocher ; olivier ; Victoire | ✅ | [OV] : « Cecropia Pallas scopulum Mavortis in arce » (v. 70, numéroté sur la page) … « bis sex caelestes medio Iove » … « exsiluisse fretum » … « edere cum bacis fetum canentis olivae » … « operis Victoria finis » (v. 82) — https://www.thelatinlibrary.com/ovid/ovid.met6.shtml | Bornes exactes. « La Victoire couronne son œuvre » est une paraphrase acceptable de « operis Victoria finis ». |
| 38 | Ovide « vers 8 apr. J.-C. », poète romain | ✅ | Wikipédia EN, « Metamorphoses » : « Latin narrative poem from 8 CE » — https://en.wikipedia.org/wiki/Metamorphoses | — |
| 39 | Couche `interpretation` : mythe étiologique (nom d'Athènes, culte commun, « reliques ») | ⚠️ | La lecture est conforme aux textes : [PAU] I, 26, 5 (« Legend says that these appeared as evidence in support of Poseidon's claim ») ; [AUG] XVIII, 9 (origine du nom). Mais elle n'est attribuée à personne — https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0525/tlg001/tlg0525.tlg001.perseus-eng2.xml | Le guide demande une lecture « au conditionnel ou attribuée ». Le conditionnel est présent, donc c'est acceptable. Proposer : « Les historiens des religions y voient souvent… » ou citer un ouvrage de référence. Voir les questions au directeur. |

#### « Le saviez-vous ? »

| # | Affirmation (résumée) | Verdict | Source consultée (URL) | Correction proposée |
|---|---|---|---|---|
| 40 | Légende arcadienne : Poséidon caché parmi les agneaux, poulain avalé par Cronos (Paus. VIII, 8, 2) | ✅ | [PAU] VIII, 8, 2 (« she laid him in a flock … gave him a foal to swallow instead of the child ») — URL [PAU] | — |
| 41 | Hadès bondit de son trône en criant (*Il.* XX, 61–65) | ✅ | [IL] XX, 61–65 (ἐκ θρόνου ἆλτο καὶ ἴαχε, μή οἱ ὕπερθε γαῖαν ἀναρρήξειε) — URL [IL] | — |
| 42 | Pausanias (IIe s.) voit dans l'Érechthéion un puits d'eau de mer et la marque d'un trident (I, 26, 5) | ✅ | [PAU] I, 26, 5 (« sea-water in a cistern … On the rock is the outline of a trident ») ; dates : Wikipédia FR « Pausanias le Périégète » (v. 115 – v. 180) — https://fr.wikipedia.org/wiki/Pausanias_le_Périégète | — |

#### « Dans la culture populaire »

| # | Affirmation (résumée) | Verdict | Source consultée (URL) | Correction proposée |
|---|---|---|---|---|
| 43 | Percy Jackson : romans depuis 2005, série Disney+ depuis 2023 ; fils de Poséidon et d'une mortelle ; invention moderne | ✅ | https://en.wikipedia.org/wiki/The_Lightning_Thief (1er juillet 2005) ; https://en.wikipedia.org/wiki/Percy_Jackson_and_the_Olympians_(TV_series) (Disney+, 19 décembre 2023) ; https://en.wikipedia.org/wiki/Percy_Jackson_(character) (« son of the mortal Sally Jackson and the Greek god Poseidon ») | — |
| 44 | God of War III (Sony, PS3, 2010) : Kratos tue Poséidon au début, les océans submergent la Grèce | ✅ | https://en.wikipedia.org/wiki/God_of_War_III (PS3, 16 mars 2010 ; « Poseidon … is killed by Kratos, causing the oceans to flood Greece ») | Option : la scène est très violente ; « tue » suffit, ne pas détailler. |
| 45 | Hades (Supergiant Games, 2020) : bienfaits de Poséidon à effet de vague repoussante ; héros Zagreus | ✅ | https://en.wikipedia.org/wiki/Hades_(video_game) (sortie complète le 17 septembre 2020, accès anticipé en décembre 2018 ; « push-back wave effects » ; Zagreus) | — |

#### « Pour aller plus loin » et « Sources » (dates)

| # | Affirmation (résumée) | Verdict | Source consultée (URL) | Correction proposée |
|---|---|---|---|---|
| 46 | Zeus, « le petit frère devenu roi » | ⚠️ | Exact chez Hésiode ([TH] v. 478 : ὁπλότατον παίδων, « le plus jeune »). Mais chez Homère, que la fiche cite pour le partage, Zeus est l'aîné : [IL] XIII, 355 (Ζεὺς πρότερος γεγόνει) ; XV, 166 et 182 (γενεῇ πρότερος) — URL [IL] | Proposer : « Le frère devenu roi : le partage du monde vu de son côté » ; ou bien « le petit frère (chez Hésiode ; l'aîné chez Homère) ». |
| 47 | Athéna, « la nièce » | ✅ | [TH] v. 924 (née de la tête de Zeus) ; [APG] I, 3, 6 — URL [TH] | — |
| 48 | Homère « vers le VIIIe siècle av. J.-C. » | ⚠️ | Wikipédia EN, « Homer » : « around the late eighth or early seventh century BC » — https://en.wikipedia.org/wiki/Homer | « vers la fin du VIIIe ou le début du VIIe siècle av. J.-C. » |
| 49 | Hésiode « vers 700 av. J.-C. » | ✅ | Wikipédia EN, « Hesiod » : « fl. c. 700 BC », actif entre 750 et 650 — https://en.wikipedia.org/wiki/Hesiod | — |
| 50 | Hymne homérique 22 : « date incertaine » | ✅ | Wikipédia EN, « Homeric Hymns » : Hymne 22 daté de « c. 7th – c. 6th century BCE » — https://en.wikipedia.org/wiki/Homeric_Hymns | Option : « date incertaine (VIIe–VIe s. av. J.-C. ?) ». |
| 51 | Bacchylide, *Dithyrambe* 17, « Ve siècle av. J.-C. » | ✅ | [BAC] : poème n° 17, titre Ἠίθεοι ἢ Θησεύς — URL [BAC] ; Wikipédia FR « Bacchylide » : « début du Ve siècle av. J.-C. » — https://fr.wikipedia.org/wiki/Bacchylide | Le numéro 17 est confirmé dans l'édition Perseus. Le doute 6 de l'auteur sur une ancienne numérotation « 16 » n'est pas tranché ; garder 17. |
| 52 | Augustin, Ve siècle | ✅ | Wikipédia FR, « La Cité de Dieu » : rédigée de 413 à 426 — https://fr.wikipedia.org/wiki/La_Cité_de_Dieu | — |

#### YAML : épithètes, symboles, relations

| # | Affirmation (résumée) | Verdict | Source consultée (URL) | Correction proposée |
|---|---|---|---|---|
| 53 | Ennosigaios : Th. 456 ; Il. XV, 184 ; HH22 v. 4 | ✅ | [TH] v. 456 (Ἐννοσίγαιον) ; [IL] XV, 184 (κλυτὸς ἐννοσίγαιος) ; [HH22] v. 4 (Ἐννοσίγαιε) — URL [HH22] | — |
| 54 | Enosichthôn : Il. XX, 63 ; Od. I, 74 | ✅ | [IL] XX, 63 ; [OD] I, 74 (Ποσειδάων ἐνοσίχθων) — URL [OD] | — |
| 55 | Gaiêochos : Od. I, 68 ; HH22 v. 6 (sens discuté) | ✅ | [OD] I, 68 (Ποσειδάων γαιήοχος) ; [HH22] v. 6 (Ποσείδαον γαιήοχε) — URL [HH22] | Les loci sont exacts. Le « sens discuté » est bien réservé au YAML. |
| 56 | Kyanochaitês : Th. 278 ; Od. IX, 528 | ✅ | [TH] v. 278 (Κυανοχαίτης) ; [OD] IX, 528 (κυανοχαῖτα), aussi IX, 536 et III, 6 — URL [TH] | À Th. 278, le mot désigne Poséidon sans le nommer (identification usuelle, déjà notée dans la fiche Méduse). |
| 57 | Hippios : Paus. VIII, 25, 7 ; I, 30, 4 | ✅ | [PAU] VIII, 25, 7 ; I, 30, 4 — URL [PAU] | — |
| 58 | Symbole taureau : taureaux noirs à Pylos (Od. III, 5–6) | ✅ | [OD] III, 5–6 (ταύρους παμμέλανας, ἐνοσίχθονι κυανοχαίτῃ) — URL [OD] | — |
| 59 | Relations `poseidon → pegasus/chrysaor` : « Apollodore II, 4, 3 (union : Théogonie v. 278–281) » | ⚠️ | La phrase « τούτους δὲ ἐγέννησεν ἐκ Ποσειδῶνος » ouvre II, 4, 3 dans le grec ([APG]), mais clôt II, 4, 2 dans la traduction Frazer ([APE]). La fiche Méduse v2 cite « II, 4, 2 » et « v. 278–279 » pour les mêmes relations. — https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-grc2.xml | Harmoniser les deux fiches. Proposer partout « Apollodore, Bibliothèque, II, 4, 2–3 » et « Hésiode, Théogonie, v. 278–281 » (union v. 278–279, naissance v. 280–281). Ces relations existent déjà dans la fiche Méduse : le directeur doit les dédoublonner dans le graphe. |
| 60 | Thésée (`variant`) : Bacchylide 17, v. 33–36 et 58–60 ; Apollodore III, 15, 7 ; Pausanias I, 17, 3 | ✅ | [BAC] v. 33–36 (Πιτθέος θυγάτηρ … πλαθεῖσα ποντίῳ τέκεν Ποσειδᾶνι), v. 58–60 (Τροιζηνία σεισίχθονι φύτευσεν Αἴθρα Ποσειδᾶνι) ; [APG] III, 15, 7 (τῇ δὲ αὐτῇ νυκτὶ καὶ Ποσειδῶν) ; [PAU] I, 17, 3 — URL [BAC] | — |
| 61 | `poseidon enemy-of athena` en `variant` (alliés ailleurs) | ✅ | [IL] XX, 33–34 : Héra, Athéna et Poséidon dans le même camp, côté achéen — URL [IL] | La réserve de l'auteur est fondée. |
| 62 | `poseidon helped peleus` (Balios et Xanthos) | ✅ | [APG] III, 13, 5 ; [IL] XXIII, 277–278 — URL [APG] | Ajouter *Il.* XXIII, 277–278 à la source. |
| 63 | Commentaires YAML : rivalités avec Héra pour l'Argolide (Paus. II, 15, 5 ; II, 22, 4) et avec Hélios pour Corinthe (II, 1, 6) | ✅ | [PAU] II, 15, 5 ; II, 22, 4 (Poséidon Prosclystios) ; II, 1, 6 (arbitrage de Briarée) — URL [PAU] | — |

---

### Problèmes de forme et de ton

- **Pas de tutoiement.** Le guide l'exige (§ 3), mais aucun « tu » ne figure dans le MDX. Ajouter au moins une adresse au lecteur, par exemple dans l'accroche de « Son histoire » ou dans « Le saviez-vous ? ».
- **Gabarit respecté.** « Son histoire » fait environ 193 mots en 4 paragraphes (cible 120–250). Le plus long paragraphe fait environ 53 mots (limite 60). Il y a 5 puces de pouvoirs, 3 anecdotes, 3 œuvres et 3 portes conformes au brief (Zeus, Athéna, Ulysse). Le rôle fait moins de 12 mots.
- **Couches.** Les étiquettes 🏺/🔍/🎬 sont correctes. Aucune œuvre moderne n'apparaît hors de la section Culture populaire. Le grec et le romain sont bien signalés (Ovide « poète romain », Varron « érudit romain », Augustin « auteurs latins »).
- **Méduse absente du MDX.** Le brief demande un renvoi à la fiche Méduse « avec le même traitement sobre ». Aucune balise `<E id="medusa">` n'existe. Une mention neutre suffit, sans détailler les versions (Hésiode : prairie ; Ovide : viol dans le temple), qui sont traitées dans la fiche Méduse.
- **Cohérence YAML ↔ MDX.** Plusieurs sources du YAML ne servent pas dans le MDX : Sophocle *OC* v. 707–719, Pausanias I, 24, 5 et I, 30, 4, *Iliade* XXI, 441–457 et XXIII, ainsi que Théogonie v. 139–141 et 501–506. Il faut soit les exploiter (Sophocle illustre bien Hippios), soit les retirer de `sources`. À l'inverse, la liste MDX « Sources » ne mentionne pas Apollodore II, 4, 2–3 (Pégase et Chrysaor) ni Pausanias I, 30, 4.
- **« Le saviez-vous ? » n° 1 et « Son histoire ».** La légende du poulain contredit volontairement le « à peine né, Poséidon est avalé ». C'est acceptable, puisque la légende est présentée comme arcadienne. On peut renforcer avec « Autre version : … ».
- **Typographie.** Les guillemets « » sont corrects. Les espaces insécables avant « : ; ? ! » ne sont pas contrôlables dans le source : à vérifier au rendu (doute 13 de l'auteur).
- **Ton.** L'accroche est bonne et l'humour sobre (« Mauvais départ dans la vie »). Rien d'infantilisant.

### Questions pour le directeur éditorial

1. **Trident.** Le brief disait « forgé par les Cyclopes (probablement Apollodore) ». Apollodore dit seulement « donnent », et Callimaque (Hymne à Délos, v. 30–31) attribue la fabrication aux Telchines. Faut-il mentionner cette variante, ou s'en tenir à « donné par les Cyclopes selon Apollodore » ? Il faut le même choix dans les fiches Zeus (foudre : Hésiode dit bien « fabriquée », v. 141) et Hadès (casque).
2. **Rang de Zeus dans la fratrie.** Il est le cadet chez Hésiode et l'aîné chez Homère (*Il.* XIII, 355 ; XV, 166). Le traitement doit être identique dans les fiches Zeus, Poséidon et Hadès.
3. **Références de Pégase et Chrysaor.** Faut-il adopter « Apollodore II, 4, 2–3 » et « Théogonie v. 278–281 » dans les deux fiches ? Quelle fiche porte les relations `poseidon → pegasus/chrysaor`, pour éviter les doublons dans le graphe ?
4. **Couche `interpretation` non attribuée.** Faut-il exiger un nom ou un ouvrage, ou bien le conditionnel suffit-il ?
5. **Validations structurelles.** Le bloc `deity:` du YAML et les nouveaux ids (`amphitrite`, `triton`, `thoosa`, `polyphemus`, `odysseus`, `theseus`, `pegasus`, `chrysaor`, `aigai`, `peleus`) restent à valider.
6. **Relation `poseidon enemy-of athena`.** Faut-il la garder en `variant` ou la supprimer ? Les deux dieux sont alliés dans l'*Iliade* (XX, 33–34).
