# Rapport de vérification : fiche « Athéna » (lot 1, vague A)

- **Fiche vérifiée :** `/home/claude/editorial/drafts/athena.draft.md` (YAML + MDX)
- **Brief :** `/home/claude/editorial/briefs/lot1-vagueA.md` (en-tête de lot + section ATHÉNA)
- **Décisions de lot appliquées :** `/home/claude/editorial/DECISIONS_LOT1.md` (D4 égide, D5 Méduse, D8 sources secondaires, D9 tutoiement, D10 dates)
- **Fiches croisées :** `/home/claude/editorial/drafts/meduse.v2.md` (égide, bouclier) ; `/home/claude/editorial/drafts/poseidon.draft.md` (dispute de l'Attique, relation `enemy-of`)
- **Vérificateur :** agent indépendant, 2026-10-15
- **Méthode :** j'ai découpé la fiche en affirmations et contrôlé chacune en ligne. Pour les textes grecs, j'ai lu moi-même le **texte original numéroté** des fichiers TEI PerseusDL (raw.githubusercontent.com). Pour le latin, j'ai utilisé PerseusDL `canonical-latinLit` pour Ovide, Penelope (Thayer) pour Pline et The Latin Library pour Augustin. Pour les dates et la culture populaire, j'ai consulté Wikipédia EN, Britannica, la presse spécialisée et Ubisoft. Les « Sources consultées » de l'auteur ne m'ont servi que d'indices.

**URL des textes originaux (abrégées dans le tableau) :**
- [HES] Hésiode, *Théogonie*, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml ; trad. Evelyn-White : https://www.theoi.com/Text/HesiodTheogony.html
- [HES-fr343] Fragment 343 M.-W. (Galien citant Chrysippe) : https://sententiaeantiquae.com/2016/11/17/the-consumption-of-metis-birth-of-athena-and-creation-of-the-aegis-hes-frag-343/
- [IL] *Iliade*, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml
- [OD] *Odyssée*, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg002/tlg0012.tlg002.perseus-grc2.xml
- [HH28] Hymne homérique 28 : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg028/tlg0013.tlg028.perseus-grc2.xml
- [HH5] Hymne homérique 5 : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg005/tlg0013.tlg005.perseus-grc2.xml
- [PIN] Pindare, *Olympiques* : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0033/tlg001/tlg0033.tlg001.perseus-grc2.xml
- [ION] Euripide, *Ion* : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0006/tlg010/tlg0006.tlg010.perseus-grc2.xml
- [HDT] Hérodote : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0016/tlg001/tlg0016.tlg001.perseus-grc2.xml (+ trad. Godley `perseus-eng2`, même dossier)
- [THU] Thucydide : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0003/tlg001/tlg0003.tlg001.perseus-grc2.xml
- [AR] Aristophane, *Oiseaux* : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0019/tlg006/tlg0019.tlg006.perseus-grc2.xml
- [PLU] Plutarque, *Périclès* : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0007/tlg012/tlg0007.tlg012.perseus-grc2.xml
- [PAU] Pausanias : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0525/tlg001/tlg0525.tlg001.perseus-grc2.xml (+ trad. Jones `perseus-eng2`, même dossier)
- [APD] Apollodore, *Bibliothèque* : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-grc2.xml
- [OV] Ovide, *Métamorphoses*, latin numéroté : https://raw.githubusercontent.com/PerseusDL/canonical-latinLit/master/data/phi0959/phi006/phi0959.phi006.perseus-lat2.xml
- [PLI] Pline, *HN* XXXVI : https://penelope.uchicago.edu/Thayer/L/Roman/Texts/Pliny_the_Elder/36*.html
- [AUG] Augustin, *Cité de Dieu* XVIII : https://www.thelatinlibrary.com/augustine/civ18.shtml

---

### Verdict global
**PUBLIABLE APRÈS CORRECTIONS**

La fiche est solide. Les numéros de vers et de sections sont presque tous exacts, je les ai relus un par un dans le texte original. Les cinq versions de la naissance et les trois versions de la dispute sont fidèles à leurs sources, et les auteurs romains sont signalés comme tels. Je n'ai rien trouvé de bloquant. J'ai appliqué les décisions communes du lot (DECISIONS_LOT1.md), qui priment sur le brief.

Corrections indispensables avant publication :
1. **Version d'Hésiode incohérente.** Le « fleuve Triton » ne se trouve pas dans le texte principal de la *Théogonie* (v. 886–900, 924–929). Il vient d'un fragment d'une autre recension, cité par Galien (fr. 343, v. 929a–t). Or ce même fragment fait naître Athéna « avec ses armes de guerre ». La fiche mêle donc deux textes, et sa phrase « Hésiode ne décrit pas d'armure » devient fausse pour le passage qu'elle cite (n° 9).
2. **Arachné : le rôle de la challengeuse est inversé.** Chez Ovide, c'est Arachné qui défie la déesse (« certet mecum », v. 25), pas Minerve (n° 41). Il faut aussi nuancer l'affirmation « aucune version grecque » : Lucien y fait allusion en grec, et un vase corinthien archaïque est discuté (n° 46).
3. **Relation `enemy-of` Athéna → Poséidon en `canonical`.** Elle contredit la fiche Poséidon (`variant`) et l'*Iliade*, où les deux dieux agissent ensemble (n° 31).

Autres corrections : l'interprétation « l'olivier contre la mer » n'est attribuée à personne (❓, à retirer). Le bloc YAML `deity:` ne suit pas le schéma du guide. Le texte ne tutoie jamais le lecteur (contraire à D9). La note commune sur l'égide (D4) manque, et la date d'Homère ne suit pas D10. Les trois [À VÉRIFIER] se règlent comme indiqué ci-dessous.

**Décompte : 58 ✅ · 11 ⚠️ · 2 ❌ · 1 ❓** (72 affirmations ; le n° 69 regroupe les 4 entrées de culture populaire)

---

### Tableau des affirmations

#### A. En-tête, « En bref » et YAML (noms, filiation, attributs)

| # | Affirmation (résumée) | Verdict | Source consultée (URL) | Correction proposée |
|---|---|---|---|---|
| 1 | Athéna est la fille de Zeus et de Métis | ✅ | [HES] v. 886–889 (Μῆτιν… ἔμελλε θεὰν γλαυκῶπιν Ἀθήνην τέξεσθαι) ; [APD] I, 3, 6 (μίγνυται δὲ Ζεὺς Μήτιδι) | — |
| 2 | Métis est la « première épouse » de Zeus (v. 886) | ✅ | [HES] v. 886 (πρώτην ἄλοχον θέτο Μῆτιν) | — |
| 3 | Métis est « celle qui en sait le plus parmi les dieux et les hommes » (trad. de la rédaction) | ✅ | [HES] v. 887 (πλεῖστα θεῶν εἰδυῖαν ἰδὲ θνητῶν ἀνθρώπων) | Traduction exacte. Préciser « v. 887 » si on cite le vers. |
| 4 | Domaines : sagesse, conseil, stratégie, guerre, artisanat, tissage, protection des cités | ✅ | https://www.theoi.com/Olympios/Athena.html ; [HH5] v. 10–15 (guerre, artisans, ouvrages des jeunes filles) ; [HH28] v. 3 (ἐρυσίπτολιν, « qui protège les cités ») | — |
| 5 | Elle est vierge (*parthénos*) | ✅ | [HH28] v. 3 (παρθένον αἰδοίην) | — |
| 6 | Symboles : chouette, olivier, égide, gorgonéion | ✅ | https://en.wikipedia.org/wiki/Athena (« her major symbols include owls, olive trees, snakes, and the gorgoneion ») ; [IL] V, 738–742 (égide, Γοργείη κεφαλή) | — |
| 7 | Épithètes : Pallas, Parthénos, Polias, Promachos, Glaukôpis, Tritogénie | ✅ | [IL] V, 856 (Παλλὰς Ἀθήνη) ; [HES] v. 888 (γλαυκῶπιν), 895 (Τριτογένειαν) ; https://en.wikipedia.org/wiki/Athena (Polias, Promachos, Parthenos) | — |
| 8 | Nom romain : Minerve | ✅ | [AUG] XVIII, 9 (« Minerua… quae Graece Athena dicitur ») | — |

#### B. Naissance : « Son histoire » et les cinq versions

| # | Affirmation (résumée) | Verdict | Source consultée (URL) | Correction proposée |
|---|---|---|---|---|
| 9 | **Version Hésiode :** naissance « au bord du fleuve Triton » ; « Hésiode ne nomme aucun assistant et ne décrit pas d'armure » | ❌ | [HES] v. 924–929 : pas de Triton. Le fleuve n'apparaît qu'aux v. 929a–t, en `<add>` dans l'édition Perseus, au v. 929m (πὰρ κορυφὴν Τρίτωνος ἐπ' ὄχθῃσιν ποταμοῖο). Ces vers appartiennent à une autre recension citée par Chrysippe chez Galien (theoi.com, n. 30 ; [HES-fr343]). Le même passage dit, au v. 929t : πολεμήια τεύχε' ἔχουσαν (« avec ses armes de guerre »). | Supprimer « au bord du fleuve Triton » de la version d'Hésiode et garder « ne décrit pas d'armure » (vrai pour le texte principal). Si l'on tient au Triton, on peut l'attribuer à Apollodore, qui le mentionne. Autre option : ajouter une ligne « fragment attribué à Hésiode (cité par Galien) : Triton + armes ». Corriger aussi `locus` (« v. 886–900 ; 924–929 », sans 929a). |
| 10 | Une prophétie : après une fille, Métis doit enfanter un fils roi des dieux | ✅ | [HES] v. 891–898 (conseil de Gaïa et Ouranos ; παῖδα θεῶν βασιλῆα καὶ ἀνδρῶν) | Hésiode attribue la prophétie à Gaïa et Ouranos. On peut les nommer. |
| 11 | Zeus avale Métis enceinte | ✅ | [HES] v. 888–890 et 899 (ἑὴν ἐσκάτθετο νηδύν) ; [APD] I, 3, 6 (ἔγκυον καταπίνει) | — |
| 12 | Cronos avalait ses enfants | ✅ | [HES] v. 459 (τοὺς μὲν κατέπινε μέγας Κρόνος) | — |
| 13 | Zeus enfante Athéna lui-même « par sa tête » | ✅ | [HES] v. 924 (αὐτὸς δ' ἐκ κεφαλῆς) | — |
| 14 | Égale à son père « en force et en sage conseil » | ✅ | [HES] v. 896 (ἶσον ἔχουσαν πατρὶ μένος καὶ ἐπίφρονα βουλήν) | — |
| 15 | Héra, furieuse, donne seule naissance à Héphaïstos | ✅ | [HES] v. 927–928 (οὐ φιλότητι μιγεῖσα γείνατο, καὶ ζαμένησε) | — |
| 16 | (YAML, commentaire) Héphaïstos naît « en réponse à la naissance d'Athéna » | ⚠️ | [HES] v. 927–929 : le texte principal juxtapose les deux naissances sans lien causal explicite. Le lien (« de cette querelle ») n'est explicite qu'au v. 929b, dans la recension variante. | Écrire « juste après, Héra… » ou signaler que le lien causal vient de la variante. |
| 17 | Hésiode, « vers 700 av. J.-C. » | ✅ | https://www.britannica.com/biography/Hesiod (« Flourished c. 700 bc ») | — |
| 18 | **Hymne 28 :** jaillit de la tête en armes d'or étincelantes, brandissant une lance ; l'Olympe tremble, la mer se soulève, le Soleil arrête ses chevaux | ✅ | [HH28] v. 4–14 (ἐκ κεφαλῆς, τεύχε'… χρύσεα παμφανόωντα, σείσασ' ὀξὺν ἄκοντα, ἐλελίζετ' Ὄλυμπος, ἐκινήθη δ' ἄρα πόντος, στῆσεν… ἵππους) | « Lance » : le grec dit ἄκων, « javelot ». Tolérable. |
| 19 | Hymne 28 « peut-être Ve siècle av. J.-C. » | ✅ | https://en.wikipedia.org/wiki/Homeric_Hymns (« Possibly 5th century BCE ») | La prudence de la formulation est correcte. |
| 20 | **Pindare, O. VII, 35–38 :** Héphaïstos ouvre le crâne d'un coup de hache de bronze ; Athéna pousse un immense cri de guerre | ✅ | [PIN] O. 7, 35–37 (Ἁφαίστου τέχναισιν χαλκελάτῳ πελέκει… ἀλάλαξεν ὑπερμάκει βοᾷ) | Le YAML dit « 35–37 » et les sources « 35–38 » : harmoniser (35–38 inclut le frisson d'Ouranos et de Gaïa). |
| 21 | Pindare, Olympique VII, 464 av. J.-C. | ✅ | https://en.wikipedia.org/wiki/Olympian_7 (« 464 BC », Diagoras de Rhodes) | — |
| 22 | **Euripide, Ion, v. 452–457 :** le chœur attribue l'accouchement à Prométhée | ✅ | [ION] v. 452–457 (Χορός : Προμηθεῖ Τιτᾶνι λοχευθεῖσαν κατ' ἀκροτάτας κορυφᾶς Διός) | — |
| 23 | Ion, « fin du Ve siècle av. J.-C. » | ✅ | https://en.wikipedia.org/wiki/Ion_(play) (418/7, 414/3 ou 412) | — |
| 24 | **Apollodore I, 3, 6 :** Prométhée « ou, selon d'autres, Héphaïstos » ; Métis change de forme pour échapper à Zeus | ✅ | [APD] I, 3, 6 (μεταβαλλούσῃ εἰς πολλὰς ἰδέας ὑπὲρ τοῦ μὴ συνελθεῖν… πελέκει Προμηθέως ἢ καθάπερ ἄλλοι λέγουσιν Ἡφαίστου… ἐπὶ ποταμοῦ Τρίτωνος, Ἀθηνᾶ σὺν ὅπλοις ἀνέθορεν) | On pourrait ajouter ici le Triton et les armes (cf. n° 9). |
| 25 | Apollodore, « Ier–IIe siècle apr. J.-C. » | ✅ | https://en.wikipedia.org/wiki/Bibliotheca_(Pseudo-Apollodorus) (« first or second centuries AD ») | — |
| 26 | Accroche : « Un coup de hache sur le crâne de Zeus » | ⚠️ | [PIN] v. 36 ; [APD] I, 3, 6 ; la hache est absente de [HES] et de [HH28] | Acceptable pour une accroche, puisque le bloc `<Versions>` suit. On peut écrire « Un coup de hache (selon certains) ». C'est un choix éditorial (voir Questions). |

#### C. Homère, Hymne à Aphrodite, pouvoirs et protégés

| # | Affirmation (résumée) | Verdict | Source consultée (URL) | Correction proposée |
|---|---|---|---|---|
| 27 | Elle combat aux côtés des Grecs devant Troie | ✅ | [IL] XX, 33–34 (Héra, Athéna, Poséidon… vont vers les nefs, côté achéen) | — |
| 28 | Elle terrasse Arès d'un coup de pierre (Il. XXI, 403–408) | ✅ | [IL] XXI, 403–408 (λίθον εἵλετο… τῷ βάλε θοῦρον Ἄρηα) | — |
| 29 | Elle guide la lance de Diomède contre Arès (Il. V, 855–861) | ✅ | [IL] V, 855–861 (ἐπέρεισε δὲ Παλλὰς Ἀθήνη) | — |
| 30 | Arès est son demi-frère | ✅ | [HES] v. 921–922 (Héra donne à Zeus Hébé, Arès, Ilithyie) | — |
| 31 | **YAML : `athena enemy-of poseidon`, `canonical`** | ⚠️ | [HDT] VIII, 55 et [APD] III, 14, 1 : une rivalité pour l'Attique. Mais [IL] XXI, 284–286 : Poséidon et Athéna viennent ensemble rassurer Achille (χειρὶ δὲ χεῖρα λαβόντες) ; [IL] XX, 33–34 : même camp. La fiche Poséidon (l. 47) note la relation inverse en `variant`. | Passer en `certainty: variant`, avec la mention « rivalité ponctuelle pour l'Attique », comme dans la fiche Poséidon. Ou supprimer la relation (voir Questions). Une seule direction suffit dans le graphe. |
| 32 | Elle guide Persée (Apollodore II, 4, 2) | ✅ | [APD] II, 4, 2 (κατευθυνούσης τὴν χεῖρα Ἀθηνᾶς) | — |
| 33 | Elle soutient Héraclès dans ses travaux (Il. VIII, 362–365 ; crotales, Apd. II, 5, 6) | ✅ | [IL] VIII, 362–365 (σώεσκον ὑπ' Εὐρυσθῆος ἀέθλων) ; [APD] II, 5, 6 (χάλκεα κρόταλα… Ἀθηνᾶ παρὰ Ἡφαίστου λαβοῦσα) | — |
| 34 | Elle veille sur Ulysse (Od. XIII, 296–302) | ✅ | [OD] XIII, 300–301 (ἥ τέ τοι αἰεὶ ἐν πάντεσσι πόνοισι παρίσταμαι ἠδὲ φυλάσσω) | — |
| 35 | Odyssée : « réputée parmi tous les dieux pour sa ruse (*mètis*) et ses astuces » | ✅ | [OD] XIII, 298–299 (ἐγὼ δ' ἐν πᾶσι θεοῖσι μήτι τε κλέομαι καὶ κέρδεσιν) | Préciser « XIII, 298–299 ». |
| 36 | L'Iliade la montre revêtant l'égide avant la bataille | ✅ | [IL] V, 738 (ἀμφὶ δ' ἄρ' ὤμοισιν βάλετ' αἰγίδα) | — |
| 37 | « L'égide, une peau-bouclier » | ⚠️ | [IL] V, 738 : l'égide se jette « sur les épaules » et porte des franges (θυσσανόεσσαν). C'est plutôt un manteau ou une pièce d'armure qu'un bouclier. Homère ne dit pas qu'elle est en peau. | Écrire « l'égide, une sorte de manteau-armure terrifiant ». |
| 38 | Hymne à Aphrodite : elle enseigna aux artisans chars et voitures, aux jeunes filles les beaux ouvrages | ✅ | [HH5] v. 12–15 (τέκτονας ἄνδρας… σατίνας τε καὶ ἅρματα… παρθενικὰς… ἀγλαὰ ἔργ' ἐδίδαξεν) | Locus exact : v. 12–15 (v. 7–11 : elle est insensible à Aphrodite). |
| 39 | Chez Homère, elle tisse sa robe et celle d'Héra | ✅ | [IL] V, 734–735 (πέπλον… ὅν ῥ' αὐτὴ ποιήσατο καὶ κάμε χερσίν) ; XIV, 178–179 (ἑανὸν ἕσαθ', ὅν οἱ Ἀθήνη ἔξυσ' ἀσκήσασα) | — |
| 40 | Elle prend une apparence humaine pour conseiller Ulysse | ✅ | [OD] XIII, 221–222 (ἀνδρὶ δέμας εἰκυῖα νέῳ, ἐπιβώτορι μήλων) ; VII, 19–20 (jeune fille) ; II, 267–268 (Mentor, pour Télémaque) | — |

#### D. Arachné

| # | Affirmation (résumée) | Verdict | Source consultée (URL) | Correction proposée |
|---|---|---|---|---|
| 41 | « Arachné se dit meilleure tisseuse que la déesse. **Minerve la défie.** » | ❌ | [OV] VI, 24–25 : c'est Arachné qui lance le défi (« certet » ait « mecum : nihil est, quod victa recusem »). Pallas vient déguisée en vieille femme (v. 26–27) pour l'avertir, puis se révèle (v. 43) et accepte le concours. | « Arachné se vante d'être meilleure tisseuse que la déesse et la met au défi. Minerve vient la mettre en garde, déguisée en vieille femme, puis accepte le concours. » |
| 42 | Arachné est une jeune Lydienne ; Ovide, livre VI, vers 8 apr. J.-C. | ✅ | [OV] VI, 5 (Maeoniae… Arachnes), 11 (Lydas per urbes) ; https://en.wikipedia.org/wiki/Metamorphoses (« First published in 8 CE ») | — |
| 43 | La tapisserie de la déesse montre sa victoire sur Neptune : un olivier jaillit | ✅ | [OV] VI, 70–82 (antiquam de terrae nomine litem… fetum canentis olivae… operis Victoria finis) | — |
| 44 | Arachné tisse les tromperies des dieux ; son ouvrage est sans défaut | ✅ | [OV] VI, 103–128 (Europe, Léda, Danaé…) ; v. 129–131 (non illud Pallas, non illud carpere Livor possit opus… caelestia crimina) | — |
| 45 | La déesse déchire l'ouvrage, la frappe avec sa navette ; Arachné tente de se pendre ; changée en araignée | ✅ | [OV] VI, 131–145 (rupit… radium… ter quater… percussit ; laqueoque… ligavit guttura ; sucis Hecateidos herbae… aranea) | Ovide dit « Pallas » ou « Tritonia » (v. 1, 26), jamais « Minerva » dans ce passage. « Minerve » reste acceptable en français. Ovide ne dit pas « furieuse » mais « doluit successu » (elle souffre de ce succès). Nuance facultative. |
| 46 | **[À VÉRIFIER]** « Aucune version grecque complète de ce récit ne nous est parvenue » ; titre « Arachné, une histoire romaine » | ⚠️ | https://en.wikipedia.org/wiki/Arachne : Lucien, *La Goutte* (*Podagra*, grec, IIe s. apr. J.-C., Loeb 432, p. 318–319) mentionne Arachné, « vierge méonienne » qui se crut l'égale d'Athéna et devint araignée. Élien évoque aussi les araignées et l'art d'Athéna. Un aryballe corinthien (vers 580–560 av. J.-C.) pourrait figurer le concours, mais cette lecture est discutée. theoi.com (https://www.theoi.com/Olympios/AthenaWrath.html) et le Smith (https://cts.perseids.org/read/pdlrefwk/viaf88890045/003/perseus-eng1/A.arachne_1) ne citent qu'Ovide et Virgile (*Géorgiques* IV, 246). Je n'ai pas pu lire le texte grec de Lucien moi-même (catalogue Perseus seul accessible). | La phrase est exacte au sens strict (aucun récit grec complet), mais elle est trop sèche. Proposition : « Le récit complet n'est connu que par Ovide. En grec, on n'en trouve que de brèves allusions, plus tardives (Lucien, IIe s. apr. J.-C.) ; un vase corinthien du VIe s. av. J.-C. la représente peut-être. » Retirer la balise. Titre : « Arachné, une histoire racontée par un Romain ». |
| 47 | YAML `athena punished arachne`, `variant`, Ovide VI, 129–145 | ✅ | [OV] VI, 129–145 | — |

#### E. Dispute de l'Attique (trois versions + interprétation)

| # | Affirmation (résumée) | Verdict | Source consultée (URL) | Correction proposée |
|---|---|---|---|---|
| 48 | **Hérodote VIII, 55 :** sur l'Acropole, un sanctuaire abrite un olivier et une « mer », témoignages de la querelle selon les Athéniens | ✅ | [HDT] VIII, 55 (Ἐρεχθέος… νηός, ἐν τῷ ἐλαίη τε καὶ θάλασσα ἔνι, τὰ λόγος παρὰ Ἀθηναίων… ἐρίσαντας περὶ τῆς χώρης μαρτύρια θέσθαι) | On peut préciser « le temple d'Érechthée », comme la fiche Poséidon. |
| 49 | Hérodote, « Ve siècle av. J.-C. » | ✅ | https://en.wikipedia.org/wiki/Herodotus (c. 484 – c. 425 BC) | — |
| 50 | **Apollodore III, 14, 1 :** trident, « mer » sur l'Acropole ; olivier planté devant Cécrops témoin ; douze dieux juges désignés par Zeus ; Poséidon inonde la plaine | ✅ | [APD] III, 14, 1 (πλήξας τῇ τριαίνῃ… ἀπέφηνε θάλασσαν… Κέκροπα μάρτυρα ἐφύτευσεν ἐλαίαν… κριτὰς ἔδωκεν… θεοὺς τοὺς δώδεκα… τὸ Θριάσιον πεδίον ἐπέκλυσε) | Facultatif : nommer la plaine thriasienne. Apollodore justifie le verdict par le témoignage de Cécrops (elle a planté la première). |
| 51 | **Augustin XVIII, 9 (d'après Varron) :** vote des citoyens, hommes pour Neptune, femmes pour Minerve, victoire d'une voix ; les femmes perdent le droit de vote | ✅ | [AUG] XVIII, 9 (mares pro Neptuno, feminae pro Minerua… una plus inuenta est feminarum… ut nulla ulterius ferrent suffragia) | Augustin ajoute que Neptune ravage les terres par la mer (« marinis fluctibus… populatus est ») et cite deux autres punitions. La fiche Poséidon mentionne le ravage : harmoniser. |
| 52 | Augustin, auteur latin chrétien, Ve s. ; Varron, romain | ✅ | https://en.wikipedia.org/wiki/The_City_of_God (« early 5th century AD », 426) | — |
| 53 | Les sources du bloc sont les mêmes que dans la fiche Poséidon (exigence du brief) | ⚠️ | La fiche Poséidon (l. 109–112) donne quatre versions, dont Ovide VI, 70–82. La fiche Athéna n'en donne que trois et renvoie Ovide à la section Arachné. | Ajouter une ligne Ovide au bloc, ou renvoyer explicitement à la tapisserie d'Arachné. Le brief demande les « mêmes sources ». |
| 54 | **[À VÉRIFIER] Interprétation :** « On interprète souvent ce choix comme celui d'une cité qui préfère l'olivier, richesse agricole, à la mer… Athènes deviendra aussi une grande puissance navale » | ❓ | Recherche web (« contest Athena Poseidon olive versus sea interpretation… ») : seulement des sites de vulgarisation non académiques (greekmyths-greekmythology.com, historyskills.com…). Aucune lecture attribuable à un auteur identifié. Le cadrage en « deux dons » n'est pas dans les textes : Apollodore parle de prise de possession (κατάληψις) et de témoignage. Le guide (§2, règle 6) exige qu'une interprétation soit attribuée ou au conditionnel. Retirer la `<Version layer="interpretation">`, ou — selon **D8** — la remplacer par une thèse savante attribuée et au conditionnel (« selon l'historien X… »), avec « cité d'après » dans les sources. Garder le titre du bloc est possible : il décrit le contenu des versions, pas une thèse. |

#### F. « Le saviez-vous ? »

| # | Affirmation (résumée) | Verdict | Source consultée (URL) | Correction proposée |
|---|---|---|---|---|
| 55 | Dès la fin du VIe s. av. J.-C., la chouette orne les pièces d'argent d'Athènes | ✅ | https://en.wikipedia.org/wiki/Owl_of_Athena (« common obverse of the Athenian tetradrachms after 510 BC ») | — |
| 56 | La pièce grecque de 1 € reprend ce motif | ✅ | https://en.wikipedia.org/wiki/Greek_euro_coins (« Picture of a 5th-century BC Athenian tetradrachm ») ; https://mymodernmet.com/greece-euro-coins/ (chouette) | Pour être exact : la pièce reprend une tétradrachme du Ve s. |
| 57 | Aristophane, *Oiseaux*, v. 301 : « Qui a amené une chouette à Athènes ? » | ✅ | [AR] v. 301 (τίς γλαῦκ' Ἀθήναζ' ἤγαγεν; ; numéroté 301b dans l'édition Perseus) | — |
| 58 | Les Oiseaux, 414 av. J.-C. | ✅ | https://en.wikipedia.org/wiki/The_Birds_(play) (« performed in 414 BC at the City Dionysia ») | — |
| 59 | « Elles y pullulaient déjà » | ⚠️ | https://en.wikipedia.org/wiki/Owl_of_Athena (Aristophane note la profusion de chevêches) | C'est une glose : signaler qu'il s'agit d'une expression proverbiale (« apporter des chouettes à Athènes »). Elle joue peut-être aussi sur les pièces (« chouettes »). L'anecdote fait 36 mots, pour une limite de 35. |
| 60 | Apollodore I, 6, 2 : Athéna écorche le géant Pallas et se protège de sa peau | ✅ | [APD] I, 6, 2 (Πάλλαντος δὲ τὴν δορὰν ἐκτεμοῦσα ταύτῃ κατὰ τὴν μάχην τὸ ἴδιον ἐπέσκεπε σῶμα) | — |

#### G. Parthénon et statue de Phidias

| # | Affirmation (résumée) | Verdict | Source consultée (URL) | Correction proposée |
|---|---|---|---|---|
| 61 | Le Parthénon est commencé en 447 av. J.-C. ; son nom vient de *parthénos* | ✅ | https://en.wikipedia.org/wiki/Parthenon (« Construction started in 447 BC » ; parthénos) | — |
| 62 | Pausanias : le fronton **ouest** montrait la dispute, « l'autre » la naissance | ⚠️ | [PAU] I, 24, 5 (trad. Jones) : le fronton qu'on voit en entrant montre la naissance d'Athéna, celui de l'arrière la dispute. Pausanias ne parle ni d'est ni d'ouest. L'entrée étant à l'est, la déduction est juste. | « Selon Pausanias, le fronton de l'entrée montrait la naissance d'Athéna, celui de l'arrière (à l'ouest) la dispute avec Poséidon. » |
| 63 | Pausanias, IIe s. apr. J.-C. | ✅ | https://en.wikipedia.org/wiki/Pausanias_(geographer) (c. 110 – c. 180) | — |
| 64 | L'Athéna Parthénos est de Phidias | ✅ | [PLU] *Périclès* 13, 9 (ὁ δὲ Φειδίας εἰργάζετο μὲν τῆς θεοῦ τὸ χρυσοῦν ἕδος) ; [PLI] XXXVI, 18. Pausanias ne nomme pas Phidias ici (doute 11 de l'auteur : confirmé). | Plutarque n'est pas daté dans les Sources du MDX : ajouter « (vers 50 – après 120 apr. J.-C.) » (https://en.wikipedia.org/wiki/Plutarch). |
| 65 | Consacrée vers 438 av. J.-C. ; ivoire et or | ✅ | https://en.wikipedia.org/wiki/Athena_Parthenos (« completed in 438 BCE ») ; https://en.wikipedia.org/wiki/Parthenon (« 439 or 438 BC ») ; [PAU] I, 24, 5 (ivoire et or) | — |
| 66 | Thucydide : 40 talents d'or, détachables | ✅ | [THU] II, 13, 5 (τὸ ἄγαλμα τεσσαράκοντα τάλαντα σταθμὸν χρυσίου ἀπέφθου, καὶ περιαιρετὸν εἶναι ἅπαν) ; dates : https://en.wikipedia.org/wiki/Thucydides (c. 460 – c. 400) | — |
| 67 | Pausanias : tête de Méduse en ivoire sur la poitrine, Victoire dans une main, lance, bouclier, serpent à ses pieds | ✅ | [PAU] I, 24, 7 (κατὰ τὸ στέρνον ἡ κεφαλὴ Μεδούσης ἐλέφαντος… Νίκην… δόρυ… πρὸς τοῖς ποσὶν ἀσπίς… πλησίον τοῦ δόρατος δράκων) | Détail : chez Pausanias, le bouclier est aux pieds et le serpent près de la lance. Le commentaire YAML (« serpent aux pieds ») est à ajuster. |
| 68 | Pline (auteur romain) : 26 coudées, environ 11,5 m ; statue aujourd'hui perdue | ✅ | [PLI] XXXVI, 18 (« cubitorum XXVI… ebore haec et auro constat ») ; https://en.wikipedia.org/wiki/Athena_Parthenos (« 26 cubits (about 11.50 m)… probably including the base » ; « lost… in the first millennium ») ; Pline : https://en.wikipedia.org/wiki/Pliny_the_Elder (23/24 – 79 apr. J.-C.) | Facultatif : « socle compris, probablement ». |

#### H. Culture populaire, cohérence avec Méduse, relation de résidence

| # | Affirmation (résumée) | Verdict | Source consultée (URL) | Correction proposée |
|---|---|---|---|---|
| 69 | **Culture populaire (4 entrées) :** Annabeth, fille d'Athéna (invention moderne), Daddario au cinéma, Leah Sava Jeffries dans la série Disney+ (2023) ; *Hades*, Supergiant 2020, dons qui renvoient les attaques ; *AC Odyssey*, Ubisoft 2018, guerre du Péloponnèse, statue visitable ; réplique de Nashville, LeQuire 1990 | ⚠️ | Annabeth : https://en.wikipedia.org/wiki/Annabeth_Chase ; https://en.wikipedia.org/wiki/Percy_Jackson_and_the_Olympians_(TV_series) (Disney+, 19 déc. 2023, Leah Sava Jeffries) ✅. *Hades* : https://en.wikipedia.org/wiki/Hades_(video_game) (Supergiant ; accès anticipé déc. 2018, version 1.0 le 17 sept. 2020) ; renvoi confirmé hors wiki de fans par PC Gamer : https://pcgamer.com/hades-guide-tips-and-tricks (« deflect their attacks ») ✅. *AC Odyssey* : https://en.wikipedia.org/wiki/Assassin%27s_Creed_Odyssey (Ubisoft Québec, 5 oct. 2018, 431–422 av. J.-C.) ; statue confirmée par Ubisoft : https://news.ubisoft.com/en-us/article/355102/open-world-museum-mode-comes-to-assassins-creed-odyssey-on-september-10 (« Visit the ivory-and-gold statue of Athena inside the Parthenon ») ✅. Nashville : https://en.wikipedia.org/wiki/Athena_Parthenos (« life-size replica… 1990… Alan LeQuire ») ✅. | Tous les faits tiennent, mais deux appuis sont à changer : remplacer les wikis de fans (hades.fandom, accesstheanimus) par PC Gamer et Ubisoft dans les sources consultées. Pour *Hades*, on peut préciser « 2020 (après un accès anticipé en 2018) ». La réplique de Nashville est un monument, pas une œuvre de pop culture : voir Questions. |
| 70 | **Égide et cohérence avec Méduse :** `athena owns aegis` en `canonical` ; « Gorgone » sur l'égide (Homère), tête au milieu du bouclier (Apollodore), sur la poitrine de la statue (Pausanias) | ⚠️ | [IL] V, 738–742 (Athéna revêt l'égide, Γοργείη κεφαλή, Méduse non nommée ; v. 742 Διὸς τέρας αἰγιόχοιο) ; [IL] XV, 307–310 (égide donnée à Zeus par Héphaïstos) ; [APD] II, 4, 3 (ἐν μέσῃ τῇ ἀσπίδι τῆς Γοργόνος τὴν κεφαλήν). **D4** : `athena owns aegis` = canonical → la certitude de la fiche est **conforme** (ne pas l'aligner sur le `variant` de meduse.v2 : c'est meduse.v2 qui devra suivre D4). Écarts restants : (a) la **note commune D4** (« L'égide appartient à Zeus, qui la prête à Athéna ; c'est elle qu'on voit le plus souvent la porter ») est absente du MDX — En bref et « Ses pouvoirs » présentent l'égide comme le seul attribut d'Athéna ; (b) la porte Méduse (« sur l'égide **et** le bouclier ») additionne deux versions, alors que D4/D5 renvoient à la formule « Homère : la Gorgone ; Apollodore : tête au milieu du bouclier ». | (a) Insérer la note commune D4 dans « Ses pouvoirs » (puce Guerre) ou en « En bref ». (b) « La Gorgone dont la tête orne l'égide (Homère) ou le bouclier (Apollodore) d'Athéna. » Signaler au rédacteur Méduse que meduse.v2 (`variant`, l. 41) doit passer en `canonical` selon D4. |
| 71 | **[À VÉRIFIER] YAML `athena lives-in mount-olympus`** (« Iliade, passim ») | ✅ | [IL] I, 221–222 (ἣ δ' Οὔλυμπον δὲ βεβήκει δώματ' ἐς αἰγιόχοιο Διὸς μετὰ δαίμονας ἄλλους) ; [OD] VI, 41–42 (Οὔλυμπόνδ', ὅθι φασὶ θεῶν ἕδος ἀσφαλὲς αἰεί) | `source: "Homère, Iliade, I, 221–222 ; Odyssée, VI, 41–42"` ; retirer la balise ; ajouter aussi `deity.residence: mount-olympus` (schéma §4). |
| 72 | Date d'Homère : « vers le VIIIe siècle av. J.-C. » (Sources du MDX) | ⚠️ | https://www.britannica.com/biography/Homer-Greek-poet (« 9th or 8th century bce? ») — compatible, mais **D10** impose la formule commune | Écrire « fin du VIIIe – début du VIIe siècle av. J.-C. » (D10). Hésiode « vers 700 av. J.-C. » est déjà conforme. |

**Autres relations du YAML :** `zeus parent-of athena` et `metis parent-of athena` sont confirmées par les n° 1 et 13. `hephaestus helped zeus` (variant) par les n° 20 et 24. `prometheus helped zeus` (variant) par les n° 22 et 24. `athena defeated ares` par les n° 28 et 29. Les ids `prometheus`, `perseus`, `odysseus`, `arachne` et `medusa` ne figurent pas dans la liste du lot : c'est normal pour des portes vers d'autres lots, mais le directeur doit les valider.

**Dates des sources du MDX (doute 7 de l'auteur) :** je les ai toutes contrôlées. Hérodote, Pausanias, Pline, Augustin, Thucydide, Apollodore, Hésiode et Ovide sont ✅ (n° 17, 25, 42, 49, 52, 63, 66, 68). Homère « vers le VIIIe s. » est compatible avec Britannica mais doit suivre la formule D10 (n° 72). Plutarque n'est pas daté (n° 64).

---

### Problèmes de forme et de ton

- **Tutoiement absent (D9).** Le MDX ne s'adresse jamais au lecteur (aucun « tu/ton/te »). D9 rend le tutoiement **obligatoire quand le texte s'adresse au lecteur : accroche, transitions, « Le saviez-vous ? »**. L'accroche (« Littéralement. ») et les trois anecdotes sont donc à reprendre avec au moins une adresse directe chacune (ex. « Regarde une pièce grecque de 1 € : … »). Les passages narratifs (Son histoire, Versions) peuvent rester impersonnels.
- **Bloc YAML `deity:` non conforme au schéma.** Le doute 5 de l'auteur part d'une prémisse fausse : le guide §4 *donne* bien un modèle `deity:`. La fiche s'en écarte sur quatre points :
  - `domains` et `symbols` sont en français, alors que le guide demande des clés anglaises kebab-case (`wisdom`, `strategy`, `war`, `crafts`, `weaving`, `city-protection` ; `owl`, `olive-tree`, `aegis`, `gorgoneion`, `spear`, `helmet`) ;
  - le champ `city: athens` n'existe pas dans le schéma ;
  - `residence: mount-olympus` manque ;
  - `epithets` doit être une liste d'objets `{ greek, transliteration, source }`, pas de simples chaînes. Par exemple `{ greek: Γλαυκῶπις, transliteration: Glaukōpis, source: "Hésiode, Théogonie, v. 888" }` et `{ greek: Τριτογένεια, …, source: "Hésiode, Théogonie, v. 895" }`.
- **Sections hors gabarit.** « Arachné, une histoire romaine » et « Le Parthénon et sa statue » ne figurent pas dans le gabarit §5 (doute 1 de l'auteur, à trancher).
- **Couche « interpretation » non attribuée** (n° 54), contraire à la règle 6 du guide.
- **Longueurs.** Tous les paragraphes font 60 mots ou moins (le plus long : 56). « Son histoire » fait 176 mots, dans la fourchette. L'anecdote Aristophane fait 36 mots, pour une limite de 35. Le `role` (11 mots) respecte la limite de 12. Il y a 4 œuvres en culture populaire, ce qui reste dans la limite.
- **Couches 🎬.** Aucun élément moderne hors de la section Culture populaire. ✅
- **Locus à harmoniser entre le YAML, le MDX et les Sources :**
  - Pindare : « VII, 35–37 » dans le YAML, « 35–38 » ailleurs ;
  - Hymne à Aphrodite : écrire « v. 12–15 » plutôt que « v. 7–15 » ;
  - *Odyssée* VII, 110–111 figure dans les sources mais n'est pas exploité dans le MDX : soit le supprimer, soit l'utiliser pour le tissage (Athéna donne aux Phéaciennes l'art du métier).
- **URL non profondes dans `sources`.** Écrire `https://github.com/PerseusDL/canonical-greekLit (tlg…)` ne mène à aucun texte. Mieux vaut l'URL raw complète ou une traduction theoi.com.
- **Graphie « Tritogénie »** dans les alias. C'est rare en français. « Tritogénie » ou « Tritogénéia » sont attestés tous les deux : à choisir et à garder partout.

### Questions pour le directeur éditorial

1. **Sections supplémentaires.** Garde-t-on « Arachné » et « Le Parthénon » comme sections propres ? Le brief exige ces deux points, mais le gabarit ne les prévoit pas. On peut aussi les fondre dans « Son histoire » et « Le saviez-vous ? ».
2. **Relation Athéna ↔ Poséidon** (non couverte par DECISIONS_LOT1). Faut-il une seule relation `enemy-of` en `variant`, portée par l'une des deux fiches ? Ou faut-il la supprimer, puisque les deux dieux sont alliés dans l'*Iliade* ? Les fiches Athéna (`canonical`) et Poséidon (`variant`) se contredisent aujourd'hui.
3. **Fleuve Triton.** Le mentionne-t-on, en l'attribuant à Apollodore et au fragment hésiodique cité par Galien ? Ou le retire-t-on de la version d'Hésiode ?
4. **Accroche.** « Un coup de hache » reprend la version de Pindare et d'Apollodore. Accepte-t-on qu'une accroche choisisse une version, puisque le bloc `<Versions>` corrige juste après ?
5. **Nashville.** La réplique de LeQuire est un monument. A-t-elle sa place en « Culture populaire », ou plutôt dans « Le saviez-vous ? » ou dans la section Parthénon ?
6. **Égide et bouclier.** Tranché par D4 pour la certitude (`canonical` pour Zeus et Athéna). Reste à confirmer que la fiche Méduse (meduse.v2, `variant`) sera corrigée en conséquence, et que la formule « égide (Homère) ou bouclier (Apollodore) » vaut pour toutes les portes vers `medusa`.
7. **Arachné.** Mentionne-t-on l'aryballe corinthien dont la lecture est discutée ? C'est intéressant, mais incertain.
