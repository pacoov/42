# Rapport de vérification : fiche « Héra » (lot 1, vague A)

- **Fiche vérifiée :** `/home/claude/editorial/drafts/hera.draft.md` (YAML + MDX)
- **Brief :** `/home/claude/editorial/briefs/lot1-vagueA.md`, en-tête et section « HÉRA »
- **Règles appliquées :** `GUIDE_VERIFICATION.md` et `DECISIONS_LOT1.md` (en particulier D6 sur les unions, D9 sur le tutoiement, D10 sur les dates)
- **Vérificateur :** agent indépendant, 2026-10-15
- **Méthode :** la fiche a été découpée en affirmations. Pour les textes antiques, j'ai lu le **texte original numéroté** des fichiers TEI PerseusDL (raw.githubusercontent.com), avec un script qui extrait les vers et sections par leur numéro. J'ai recoupé avec les traductions de theoi.com et de LacusCurtius. perseus.tufts.edu n'a pas été utilisé. Les « Sources consultées » et les « Doutes » de l'auteur ont servi d'indices, jamais de preuves.

**URL des textes consultés (abrégées dans le tableau) :**
- [HES] Hésiode, *Théogonie*, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml
- [IL] Homère, *Iliade*, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml
- [OD] Homère, *Odyssée*, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg002/tlg0012.tlg002.perseus-grc2.xml
- [H12] *Hymne homérique XII* : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg012/tlg0013.tlg012.perseus-grc2.xml
- [H3] *Hymne homérique à Apollon* : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg003/tlg0013.tlg003.perseus-grc2.xml
- [APD] Apollodore, *Bibliothèque*, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-grc2.xml
- [OV] Ovide, *Métamorphoses*, latin numéroté : https://raw.githubusercontent.com/PerseusDL/canonical-latinLit/master/data/phi0959/phi006/phi0959.phi006.perseus-lat2.xml
- [PAUS] Pausanias, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0525/tlg001/tlg0525.tlg001.perseus-grc2.xml, recoupé avec la trad. Jones : https://www.theoi.com/Text/Pausanias2B.html
- [HDT] Hérodote, trad. Godley : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0016/tlg001/tlg0016.tlg001.perseus-eng2.xml
- [ATH] Athénée, trad. Yonge : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0008/tlg001/tlg0008.tlg001.perseus-eng2.xml
- [DIOD] Diodore IV, trad. Oldfather : https://penelope.uchicago.edu/Thayer/E/Roman/Texts/Diodorus_Siculus/4B*.html
- [PIND] Pindare, *Néméennes*, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0033/tlg003/tlg0033.tlg003.perseus-grc2.xml
- [ESCH] Eschyle, *Suppliantes*, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0085/tlg001/tlg0085.tlg001.perseus-grc2.xml
- [MOS] Moschos, *Europe*, trad. : https://www.theoi.com/Text/Moschus.html
- [LSJ] https://lsj.gr/wiki/βοῶπις
- [BRIT] https://www.britannica.com/topic/Hera
- [THEOI] https://www.theoi.com/Olympios/Hera.html
- [BÄR] https://ancienthistorybulletin.org/wp-content/uploads/2014/09/AHBReviewsBärOnStafford.pdf
- [EM] https://sententiaeantiquae.com/2016/04/20/disrepute-from-hera-etymologies-for-herakles/ (cite le grec de l'*Etymologicum Magnum*)

---

### Verdict global
**PUBLIABLE APRÈS CORRECTIONS**

La fiche est solide et très bien sourcée. Les filiations, les numéros de vers et les attributions sont presque tous exacts, et vérifiés sur le grec ou le latin. Je n'ai trouvé **aucune affirmation fausse**. Il faut corriger avant publication :
1. **Le paon.** Le lien entre Argos et le paon n'est pas une invention romaine. Le poète grec Moschos (vers 150 av. J.-C.) fait déjà naître du sang d'Argos un oiseau à la queue déployée. Pausanias (II, 17, 6) dit que le paon est « l'oiseau sacré d'Héra ». Le titre « Coucou avant paon » suggère une chronologie que rien ne démontre. (Le brief part de la même prémisse : à corriger aussi.)
2. **Io.** Le récit ne donne qu'une version de la métamorphose. Chez Eschyle, c'est Héra qui change Io en vache. Le verbe « abuse » doit être validé au regard de la charte et de D6.
3. **Le ton.** Le MDX ne contient aucun tutoiement, alors que D9 l'exige dans l'accroche, les transitions et « Le saviez-vous ? ». S'y ajoutent la date d'Homère (D10) et des retouches mineures.

---

### Tableau des affirmations

| # | Affirmation (résumée) | Verdict | Source consultée (URL) | Correction proposée |
|---|---|---|---|---|
| 1 | Héra est fille de Cronos et Rhéa | ✅ | [HES] v. 453–454 (Ῥείη δὲ δμηθεῖσα Κρόνῳ τέκε… Ἥρην χρυσοπέδιλον) ; [IL] IV, 59 (με… τέκετο Κρόνος) ; [H12] v. 1 (ἣν τέκε Ῥείη) ; [APD] I, 1, 5 | — |
| 2 | Sœur et épouse de Zeus | ✅ | [IL] XVI, 432 et XVIII, 356 (κασιγνήτην ἄλοχόν τε) ; [H12] v. 3 | — (doute n° 3 : la traduction « sœur et épouse » est exacte) |
| 3 | YAML : frères et sœurs Hestia, Déméter, Hadès, Poséidon, Zeus | ✅ | [HES] v. 454–457 | Doute n° 8 : en *Iliade* IV, 59, Héra se dit πρεσβυτάτην (« la plus âgée » ou « la plus vénérable »), alors que l'aînée est Hestia chez Hésiode (v. 454) et chez Apollodore (I, 1, 5). Ce n'est pas exploité : pas de correction |
| 4 | Cronos avale ses enfants un à un, de peur d'être détrôné | ✅ | [HES] v. 459–465 (κατέπινε… ἵνα μή τις… ἔχοι βασιληίδα τιμήν ; oracle de Gaïa et Ouranos) | — |
| 5 | Elle est « recrachée plus tard » | ✅ | [HES] v. 494–497 | Facultatif : formule D2, « par une ruse de Gaïa chez Hésiode, par une drogue de Métis chez Apollodore » |
| 6 | Elle devient la dernière épouse de Zeus | ✅ | [HES] v. 921 (λοισθοτάτην δ' Ἥρην… ποιήσατ' ἄκοιτιν) | — |
| 7 | Trois enfants : Hébé, Arès, Ilithyie | ✅ | [HES] v. 922–923 ; [APD] I, 3, 1 (τεκνοῖ Ἥβην Εἰλείθυιαν Ἄρην) | — |
| 8 | Hébé, « la Jeunesse » | ✅ | [HES] v. 950 : l'édition Perseus imprime ἥβην en minuscule, le nom de la déesse étant le nom commun ἥβη, « jeunesse » | — |
| 9 | Hésiode, « vers 700 av. J.-C. » | ✅ | `DECISIONS_LOT1.md` D10 | — |
| 10 | Homère, « vers le VIIIe siècle av. J.-C. » (Histoire et Sources) | ⚠️ | `DECISIONS_LOT1.md` D10 | Écrire « fin du VIIIe – début du VIIe siècle av. J.-C. » aux deux endroits |
| 11 | Dans l'*Iliade*, elle tient tête à Zeus et soutient les Grecs | ✅ | [IL] I, 55–56 (κήδετο γὰρ Δαναῶν) ; I, 540–543 (reproches à Zeus) ; IV, 50–61 (Argos, Sparte, Mycènes) | — |
| 12 | Elle emprunte à Aphrodite une « bande brodée qui rend irrésistible » | ✅ | [IL] XIV, 198–199 et 214–217 (κεστὸν ἱμάντα ποικίλον… θελκτήρια πάντα) | Doute n° 4 : « bande brodée » est exact (ἱμάς = courroie, bande ; ποικίλος = brodé, bigarré). Option : ajouter « (souvent traduite “ceinture”) » pour les lecteurs qui connaissent cette traduction |
| 13 | Le but est de séduire Zeus et de l'endormir | ✅ | [IL] XIV, 233–236 (elle demande à Hypnos d'endormir Zeus) ; XIV, 352–353 | Remarque : c'est Hypnos qui endort Zeus. La formule reste juste, car elle décrit le projet d'Héra |
| 14 | Zeus lui rappelle qu'il l'a suspendue, deux enclumes aux pieds | ✅ | [IL] XV, 18–21 (ἄκμονας ἧκα δύω) ; [APD] I, 3, 5 et II, 7, 1 | — |
| 15 | Selon Apollodore, elle pourchasse Léto sur toute la terre | ✅ | [APD] I, 4, 1 (κατὰ τὴν γῆν ἅπασαν ὑφ' Ἥρας ἠλαύνετο) | — |
| 16 | Io est une prêtresse d'Héra | ✅ | [APD] II, 1, 3 (ἱερωσύνην τῆς Ἥρας ἔχουσαν) ; [ESCH] v. 291–292 (κλῃδοῦχον Ἥρας, « gardienne des clés ») | — |
| 17 | « Zeus abuse d'Io » | ⚠️ | [APD] II, 1, 3 (ἔφθειρε, « déshonore, séduit ») ; [ESCH] v. 295 (μειχθῆναι, « s'unir ») ; [OV] I, 597–600 (elle fuit ; *rapuitque pudorem*, version **romaine** sans ambiguïté) | Le choix de ne pas romantiser est juste (charte, D6). Mais « abuse » s'appuie implicitement sur Ovide. Deux options : « Zeus déshonore Io », plus proche d'Apollodore, ou garder « abuse » en ajoutant « (chez Ovide, elle tente de le fuir) ». Arbitrage du directeur (doute n° 9) |
| 18 | « … puis la change en vache » (Zeus) | ⚠️ | [APD] II, 1, 3 (Zeus la change en vache blanche) ; [OV] I, 610–611 (Jupiter) ; **contra** [ESCH] v. 299 : βοῦν τὴν γυναῖκ' ἔθηκεν Ἀργεία θεός, « la déesse d'Argos fit de la femme une vache » | Présenter les deux versions : « Zeus la change en vache pour la cacher (Apollodore) ; chez Eschyle, c'est Héra elle-même qui la transforme. » |
| 19 | Héra la fait surveiller, puis la harcèle avec un taon | ✅ | [APD] II, 1, 3 (Argos Panoptès ; après sa mort, οἶστρον ἐμβάλλει) ; [ESCH] v. 303–305 | — |
| 20 | « Elle frappe la victime, pas le coupable » | ✅ | [APD] II, 1, 3 et I, 4, 1 (Io et Léto poursuivies ; aucune punition de Zeus) | C'est un jugement de la rédaction, appuyé par les textes. Acceptable comme chute de paragraphe |
| 21 | « Sa colère vise surtout les femmes que Zeus approche » | ⚠️ | D6 ; [APD] II, 1, 3 | « approche » est un euphémisme dans un paragraphe qui parle ensuite d'abus. Proposer : « les femmes que Zeus séduit ou contraint » |
| 22 | *Iliade* : elle retarde la naissance d'Héraclès pour qu'Eurysthée règne à sa place | ✅ | [IL] XIX, 95–124 (serment de Zeus ; σχέθε δ' Εἰλειθυίας v. 119 ; Eurysthée né au 7e mois) ; [APD] II, 4, 5 | — |
| 23 | « Apollodore **ajoute** des serpents dans son berceau » | ⚠️ | [APD] II, 4, 8 ; **plus ancien** : [PIND] *Néméenne* I, 37–47 (Héra « au trône d'or » envoie les serpents ; Ve s. av. J.-C.) ; [APD] II, 4, 8 rapporte aussi la variante de Phérécyde : c'est Amphitryon qui met les serpents | « ajoute » laisse croire à un détail tardif. Proposer : « Le poète Pindare (Ve s. av. J.-C.) raconte déjà les serpents qu'elle envoie au berceau ; Apollodore ajoute la folie… » |
| 24 | Folie où le héros tue ses enfants | ✅ | [APD] II, 4, 12 (κατὰ ζῆλον Ἥρας μανῆναι… τοὺς ἰδίους παῖδας… εἰς πῦρ ἐμβαλεῖν) | Traitement sobre : OK |
| 25 | Réconciliation après la mort d'Héraclès | ✅ | [APD] II, 7, 7 (τυχὼν ἀθανασίας καὶ διαλλαγεὶς Ἥρᾳ… Ἥβην ἔγημεν) ; [HES] v. 950–953 (mariage avec Hébé) | — |
| 26 | Dans l'*Iliade*, les Ilithyies envoient les douleurs et sont « filles d'Héra » | ✅ | [IL] XI, 269–271 (μογοστόκοι Εἰλείθυιαι Ἥρης θυγατέρες πικρὰς ὠδῖνας ἔχουσαι) | — |
| 27 | Elle retient les Ilithyies (*Iliade*, XIX) | ✅ | [IL] XIX, 119 | — |
| 28 | Pouvoirs : elle enfante Héphaïstos seule chez Hésiode | ✅ | [HES] v. 927–929 (οὐ φιλότητι μιγεῖσα) | — |
| 29 | Typhon, fils d'Héra seule dans l'*Hymne à Apollon* ; fils de Gaïa chez Hésiode | ✅ | [H3] v. 305–307, 338 (νόσφι Διός), 351–354 ; [HES] v. 821–822 (Gaïa et Tartare) | La fiche donne « Gaïa » dans le MDX et « Gaïa et le Tartare » dans le YAML : cohérent |
| 30 | Elle envoie une tempête contre Héraclès « au retour de Troie » | ✅ | [IL] XV, 26–28 (avec Borée) ; XIV, 249–256 ; [APD] II, 7, 1 | Clarté : un lecteur de 15 ans pensera à la guerre de Troie. Préciser « après qu'il a pris Troie, une génération avant la guerre de Troie » |
| 31 | Selon Hésiode, elle nourrit l'Hydre de Lerne par rancune contre Héraclès | ✅ | [HES] v. 313–315 (ἣν θρέψε… κοτέουσα βίῃ Ἡρακληείῃ) | — |
| 32 | Version Hésiode : Héphaïstos naît seul, par colère, pendant une querelle, après la naissance d'Athéna | ✅ | [HES] v. 924–929 (Athéna de la tête, puis ζαμένησε καὶ ἤρισε ᾧ παρακοίτῃ) ; plus explicite dans le fragment v. 929a–c (φιλότητος ἄτερ Διός) | Le lien de cause avec Athéna est explicite dans le fragment et dans l'*Hymne à Apollon*, mais seulement juxtaposé dans les v. 924–929. Acceptable |
| 33 | *Iliade* I : Héphaïstos dit « mère chérie » et « père chéri » | ✅ | [IL] I, 572 (μητρὶ φίλῃ), 578 (πατρὶ φίλῳ… Διί) ; voir aussi XIV, 338–339 (φίλος υἱός) | — |
| 34 | *Odyssée* VIII : il accuse ses « deux parents » d'être nés boiteux | ✅ | [OD] VIII, 308–312 (χωλὸν ἐόντα… ἠπεδανὸς γενόμην… τοκῆε δύω) | — |
| 35 | *Hymne à Apollon* : Héra « dit avoir enfanté **seule** » ce fils | ⚠️ | [H3] v. 317 : ὃν τέκον αὐτή, « que j'ai enfanté **moi-même** » | Le texte ne dit pas « seule » pour Héphaïstos. Seul Typhon est explicitement conçu « sans Zeus » (v. 338). Écrire « Héra parle de ce fils aux pieds tordus “que j'ai moi-même enfanté” » |
| 36 | Jeté à la mer, recueilli par la Néréide Thétis | ✅ | [H3] v. 318–320 (ἔμβαλον εὐρέι πόντῳ ; Νηρῆος θυγάτηρ Θέτις) | Doute n° 2 levé : le v. 317a est bien une conjecture (Allen-Sikes), non utilisée |
| 37 | *Iliade* XVIII : une mère qui voulait le cacher parce qu'il boitait | ✅ | [IL] XVIII, 395–398 (μητρὸς… ἥ μ' ἐθέλησε κρύψαι χωλὸν ἐόντα) | Option : Homère cite **Eurynomé et** Thétis (v. 398) |
| 38 | Zeus le jette du ciel parce qu'il défendait sa mère ; il tombe sur Lemnos | ✅ | [IL] I, 586–594 ; [APD] I, 3, 5 | — |
| 39 | Apollodore : sans union, « mais selon Homère » de Zeus | ✅ | [APD] I, 3, 5 (χωρὶς εὐνῆς… ὡς δὲ Ὅμηρος λέγει, καὶ τοῦτον ἐκ Διός) | — |
| 40 | Apollodore, Ier–IIe s. apr. J.-C., « (Pseudo-)Apollodore » | ✅ | https://en.wikipedia.org/wiki/Bibliotheca_(Pseudo-Apollodorus) | — |
| 41 | Diodore : le bébé s'appelait Alcée ; après les serpents, les Argiens le nomment Héraclès, gloire (kléos) acquise grâce à Héra | ✅ | [DIOD] IV, 10, 1 (renommage juste après les serpents) ; IV, 9, 6 | — |
| 42 | Diodore, Ier s. av. J.-C. | ✅ | https://www.britannica.com/biography/Diodorus-Siculus | — |
| 43 | Apollodore : la Pythie l'appelle Héraclès pour la première fois ; avant, Alcide | ✅ | [APD] II, 4, 12 (ἡ δὲ Πυθία τότε πρῶτον Ἡρακλέα… Ἀλκείδης) | — |
| 44 | L'*Etymologicum Magnum* rejette « gloire d'Héra » et propose notamment « déshonneur venu d'Héra » | ✅ | [EM] (grec cité : οὐ παρὰ τὸ ἐκ τῆς Ἥρας τὸ κλέος… ἀλλὰ μᾶλλον παρὰ τὸ ἀπὸ τῆς Ἥρας ἀκλεᾶ εἶναι) | Source de seconde main avec le grec cité : à signaler « cité d'après » (D8) dans les Sources |
| 45 | *Etymologicum Magnum*, dictionnaire byzantin, vers 1150 | ✅ | https://en.wikipedia.org/wiki/Etymologicum_Magnum (« Constantinople… around 1150 AD ») | — |
| 46 | Bär (2014) : « question épineuse » ; le nom signifierait « gloire obtenue par Héra » ; « le philologue » | ⚠️ | [BÄR] p. 111 : « vexed question », « need not necessarily mean “glory of Hera” », « glory [achieved] through Hera » | « obtenue par Héra » est ambigu : on peut comprendre qu'Héra obtient la gloire. Écrire « gloire acquise à travers Héra », c'est-à-dire malgré elle. Le titre « philologue » n'est pas vérifié : écrire « le chercheur Silvio Bär ». Le conditionnel et l'attribution sont corrects |
| 47 | *boôpis*, « aux grands yeux », un compliment ; épithète fréquente (*Il.* I, 551) | ✅ | [LSJ] (« ox-eyed, i.e. having large, full eyes ») ; [IL] I, 551 et 568, IV, 50 | — |
| 48 | Homère l'applique aussi à Clyméné, servante d'Hélène (*Il.* III, 144) | ✅ | [IL] III, 143–144 (ἀμφίπολοι… Κλυμένη τε βοῶπις) ; aussi VII, 10 et XVIII, 40 ([LSJ]) | — |
| 49 | La statue d'Argos tenait une grenade et un sceptre surmonté d'un coucou (Pausanias) | ✅ | [PAUS] II, 17, 4 (καρπὸν… ῥοιᾶς… κόκκυγα δὲ ἐπὶ τῷ σκήπτρῳ ; Zeus changé en coucou) | — |
| 50 | Titre « **Coucou avant paon** » (chronologie implicite) | ⚠️ | [PAUS] II, 17, 6 : au même Héraion, Hadrien offre un paon d'or et de pierres, « parce qu'on tient cet oiseau pour sacré d'Héra » (ὅτι τὴν ὄρνιθα ἱερὰν τῆς Ἥρας νομίζουσι) ; [ATH] XIV, 70 : le poète comique Antiphanes (IVe s. av. J.-C.) associe déjà le paon à l'Héra de Samos ; [BRIT] « first the cuckoo, later the peacock » (affirmation moderne, sans source antique) | La priorité du coucou n'est attestée que par Britannica. Titre neutre proposé : « **Coucou et paon** », ou attribuer la chronologie (« selon l'encyclopédie Britannica… »). Ajouter Pausanias II, 17, 6 dans les sources du paon |
| 51 | « Les yeux d'Argos sur la queue du paon viennent du poète romain Ovide » | ⚠️ | [OV] I, 722–723 ; **antérieur et grec** : [MOS] *Europe* (Moschos, vers 150 av. J.-C., https://en.wikipedia.org/wiki/Moschus) : sur la corbeille d'Europe, Argos tué par Hermès, et « de son sang pourpre s'élève un oiseau » qui déploie sa queue aux couleurs fleuries | L'image précise des yeux posés sur les plumes vient bien d'Ovide. Mais le lien Argos–paon existe déjà chez un poète **grec**. Proposer : « Le poète grec Moschos fait déjà naître un paon du sang d'Argos ; c'est le Romain Ovide qui raconte qu'Héra pose ses cent yeux sur sa queue. » La prémisse du brief (« Ovide → romaine ») est aussi à corriger |
| 52 | Loci d'Ovide : *Mét.* I, 720–723 ; II, 531–533 | ✅ | [OV] I, 720–721 (mort d'Argos), 722–723 (*volucrisque suae Saturnia pennis / collocat*) ; II, 531–533 (char de Junon tiré par des paons « peints » des yeux d'Argos : *pavonibus pictis… caeso pavonibus Argo*) | Doute n° 1 levé : les numéros sont exacts. Précision : au livre II, Ovide **nomme** le paon (*pavo*) ; au livre I, il dit seulement « son oiseau » |
| 53 | Ovide, poète romain, vers 8 apr. J.-C. | ✅ | https://en.wikipedia.org/wiki/Metamorphoses (« from 8 CE ») | — |
| 54 | YAML : paon sacré à Samos selon Ménodote cité par Athénée | ✅ | [ATH] livre XIV, chap. 70 de la numérotation Perseus (« The peacocks are sacred to Juno… Samos ») | La trad. Yonge écrit « Juno » pour Héra (doute n° 7) : sans conséquence |
| 55 | Athénée, vers 200 apr. J.-C. ; Pausanias, IIe s. apr. J.-C. | ✅ | https://www.britannica.com/biography/Athenaeus ; https://www.britannica.com/biography/Pausanias-Greek-geographer | — |
| 56 | Stymphale : trois sanctuaires, Héra « Fille », « Femme accomplie », « Veuve » après une dispute avec Zeus | ✅ | [PAUS] VIII, 22, 2 (ἱερὰ… τρία ; Παιδί, Τελείαν, Χήραν ; διενεχθεῖσαν… ἐς τὸν Δία) | Doute n° 3 levé : le grec confirme Pais, Teleia, Chèra. Option : préciser que c'est un récit des Stymphaliens, attribué à Téménos |
| 57 | Symbole « couronne » (MDX) / `diadem` (YAML) | ⚠️ | [PAUS] II, 17, 4 (στέφανος avec Charites et Heures) ; [THEOI] (« crown or a diadem ») | Doute n° 5 : le texte antique dit στέφανος, « couronne ». Remplacer `diadem` par `crown` dans le YAML, pour la cohérence avec le MDX |
| 58 | Symbole « vache » | ⚠️ | [BRIT] (« The animal especially sacred to Hera was the cow ») ; indices antiques indirects : *boôpis* ([LSJ]), Io-vache ([APD] II, 1, 3 ; [ESCH] v. 299), bœufs du sanctuaire d'Argos ([HDT] I, 31, 2) | Doute n° 6 : défendable, mais aucun texte antique ne dit « la vache est l'animal d'Héra ». Dans « En bref », écrire « animal sacré : la vache » et garder le commentaire YAML qui cite Britannica (« cité d'après », D8) |
| 59 | Accroche : un des plus grands temples de leur monde | ✅ | [HDT] III, 60, 4 (Samos : « the greatest of all the temples of which we know », Rhoécos) | — |
| 60 | Hérodote, « Ve siècle av. J.-C. » | ❓ | Non contrôlé en ligne pendant cette vérification (donnée courante) | À confirmer rapidement (Britannica, « Herodotus ») ; aucune réécriture attendue |
| 61 | Domaines : mariage, femmes mariées, naissances | ✅ | [BRIT] (« goddess of marriage and of the life of women », « protectress of women in childbirth ») | — |
| 62 | Chez les Romains : Junon (`roman: Iuno`) | ✅ | [BRIT] (« The Romans identified her with their own Juno ») | Cohérence de lot : voir les questions au directeur |
| 63 | Grands sanctuaires d'Argos et de Samos | ✅ | [BRIT] ; [PAUS] II, 17, 1–4 ; VII, 4, 4 ; [HDT] III, 60, 4 | — |
| 64 | Épithètes YAML : boôpis (*Il.* I, 551), leukôlenos (I, 55), chrysopedilos (*Th.* 454), chrysothronos (*H. XII*, 1) | ✅ | [IL] I, 55 et 551 ; [HES] v. 454 ; [H12] v. 1 | — |
| 65 | Dates : *Hymne XII*, VIIe–VIe s. ; *Hymne à Apollon*, VIe s. av. J.-C. | ✅ | https://en.wikipedia.org/wiki/Homeric_Hymns (tableau : « c. 7th – c. 6th century BCE » ; « 522 BCE ») | — |
| 66 | YAML : Héraclès blesse Héra d'une flèche | ✅ | [IL] V, 392–394 (ὀϊστῷ τριγλώχινι) | — |
| 67 | YAML : Zeus punit Héra | ✅ | [IL] XV, 18–24 ; [APD] I, 3, 5 ; II, 7, 1 | — |
| 68 | YAML : Zeus père d'Ilithyie (canonical) | ✅ | [HES] v. 922–923 ; [APD] I, 3, 1 | [THEOI] signale aussi une Ilithyie sans père (Homère, Pindare, Pausanias). « canonical » reste acceptable |
| 69 | YAML : Héphaïstos fils d'Héra (canonical), de Zeus (variant) | ✅ | Voir n° 32–39 | Typage cohérent avec le bloc `<Versions>` |
| 70 | Disney *Hercule* (1997) : Héra mère aimante d'Hercule, aux côtés de Zeus | ✅ | https://en.wikipedia.org/wiki/Hercules_(1997_film) (« Hercules's birth mother » ; Musker et Clements) | — |
| 71 | Ron Clements : l'enfant illégitime, sujet difficile pour Disney | ✅ | Même page (« illegitimacy would be difficult subject matter for a Disney movie ») | — |
| 72 | *Héros de l'Olympe*, tome 1 (2010) : Héra prisonnière de Gaïa ; trois demi-dieux, dont Jason, son champion | ✅ | https://en.wikipedia.org/wiki/The_Lost_Hero (12 oct. 2010 ; « rescue Hera… from the clutches of Gaea » ; « her champion ») ; titre français : https://fr.vikidia.org/wiki/Le_H%C3%A9ros_perdu | — |
| 73 | *God of War III* (Santa Monica Studio, 2010) : reine ivre et méprisante ; tuée par Kratos ; fin de la vie végétale | ✅ | https://en.wikipedia.org/wiki/God_of_War_III (« the drunken Hera » ; « kills Hera for insulting Pandora, ending all Greek plant life ») | « méprisante » est déduit de l'insulte à Pandore : acceptable |
| 74 | « Persécuté du berceau jusqu'au bûcher » (Pour aller plus loin) | ✅ | [IL] XVIII, 117–119 (Héraclès vaincu par le destin « et la colère terrible d'Héra ») ; [PIND] *Ném.* I, 37–40 (berceau) | — |
| 75 | Athénée XIV, 70–71 (numérotation Perseus) | ✅ | [ATH] : passage de Ménodote au chapitre 70 du livre XIV | — |

**Bilan : 63 ✅ · 11 ⚠️ · 0 ❌ · 1 ❓** (75 affirmations)

---

### Problèmes de forme et de ton
- **Aucun tutoiement (D9, obligatoire).** Le MDX ne contient pas un seul « tu/te/toi/ton ». À reprendre au minimum dans l'accroche (« Tu la connais sûrement comme “l'épouse jalouse”… »), dans une transition de « Son histoire » et dans « Le saviez-vous ? ».
- **Date d'Homère (D10).** Voir n° 10.
- **Typographie.** Aucune espace insécable dans le MDX (0 U+00A0 ou U+202F trouvée), alors que la fiche contient 66 occurrences de « : ; ? ! « » » précédées ou suivies d'une espace ordinaire. Le doute n° 15 annonçait une insertion automatique : elle n'a pas eu lieu dans le fichier.
- **Longueurs.** « Son histoire » : 212 mots, 4 paragraphes de 49 à 56 mots ✅. « Le saviez-vous ? » : la 1re anecdote fait 36 mots, contre 35 au maximum. Retirer « comme » ou « (*Iliade*, III, 144) » de la phrase et le mettre dans une note.
- **Couches.** Les éléments 🎬 sont tous dans « Culture populaire » ✅. Le bloc d'étymologie porte bien la couche `interpretation`, au conditionnel et attribuée ✅.
- **Cohérence YAML / MDX.** `diadem` contre « couronne » (n° 57). Pausanias VII, 4, 4 (naissance à Samos) et Diodore IV, 9, 6 figurent dans les sources mais ne sont pas exploités dans le MDX. C'est acceptable, ou on peut les retirer.
- **Sources de seconde main.** Pour l'*Etymologicum Magnum*, ajouter « cité d'après Sententiae Antiquae ». Pour la vache, « cité d'après Britannica » (D8).
- **Ton.** Les accroches et l'humour sont bons (« Autre chute, autre coupable »). « Pour aller plus loin » est efficace.

### Questions pour le directeur éditorial
1. **Io (charte et D6).** Faut-il garder « Zeus abuse d'Io », qui suit en fait le sens d'Ovide, ou écrire « Zeus déshonore Io », plus proche d'Apollodore ? Et faut-il montrer la variante d'Eschyle, où Héra elle-même change Io en vache (n° 17–18) ?
2. **Paon.** Accepter la reformulation avec Moschos (grec, IIe s. av. J.-C.) et Pausanias II, 17, 6 ? Corriger en conséquence le brief, qui présente l'histoire comme purement romaine, et prévenir les autres fiches qui reprendraient cette prémisse (n° 50–51).
3. **Symbole couronne/diadème.** Choisir la clé YAML commune (`crown` ou `diadem`).
4. **Nouveaux ids.** `io` et `leto` sont validés par D6. `hebe`, `eileithyia`, `aphrodite` et `typhon` ne figurent ni dans la liste du lot ni dans D6 : à créer ou valider (doute n° 12).
5. **Typage des relations** (doute n° 13) : `heracles → hera` en `enemy-of` et `zeus → hera` en `punished`. Ces types me paraissent fidèles aux textes (n° 66–67), mais la décision revient au graphe central.
6. **Clé « reine des dieux »** absente de `domains` (doute n° 14) : faut-il créer une clé `queenship` ?
7. **Cohérence des noms romains dans le lot.** Les fiches emploient `Iuno`, `Minerva` et `Neptunus` (forme latine), mais `Jupiter` (forme francisée ou anglaise) dans la fiche Zeus. Une convention commune est à fixer.
