# Rapport de vérification : fiche « Zeus » (lot 1, vague A)

- **Fiche vérifiée :** `/home/claude/editorial/drafts/zeus.draft.md` (YAML + MDX)
- **Brief :** `/home/claude/editorial/briefs/lot1-vagueA.md`, en-tête de lot et section « ZEUS »
- **Vérificateur :** agent indépendant, 2026-10-15
- **Méthode :** j'ai découpé le texte en affirmations et contrôlé chacune en ligne. Pour les textes antiques, j'ai lu le **texte grec numéroté** des éditions Perseus, que j'ai téléchargées moi-même depuis le dépôt `PerseusDL/canonical-greekLit` (raw.githubusercontent.com). J'ai recoupé avec les traductions de theoi.com. Pour Callimaque, j'ai lu le texte grec numéroté de Perseus (éd. Wilamowitz), qui était accessible. Les « Sources consultées » et les « Doutes » de l'auteur m'ont servi d'indices, pas de preuves.

**URL abrégées dans le tableau :**
- [HES] Hésiode, *Théogonie*, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml
- [TJ] Hésiode, *Travaux et Jours*, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg002/tlg0020.tlg002.perseus-grc2.xml
- [IL] Homère, *Iliade*, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml
- [OD] Homère, *Odyssée*, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg002/tlg0012.tlg002.perseus-grc2.xml
- [APD] Apollodore, *Bibliothèque*, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-grc2.xml
- [CAL-GR] Callimaque, *Hymne I*, grec numéroté : https://www.perseus.tufts.edu/hopper/text?doc=Perseus:text:2008.01.0481:hymn=1
- [CAL-EN] Callimaque, *Hymne I*, trad. Mair : https://www.theoi.com/Text/CallimachusHymns1.html (et https://topostext.org/work/120)
- [PAUS] Pausanias V, 24, 9, trad. Jones : https://www.theoi.com/Text/Pausanias5B.html
- [STR] Strabon VIII, 3, 30 : https://penelope.uchicago.edu/Thayer/E/Roman/Texts/Strabo/8C*.html

---

### Verdict global
**PUBLIABLE APRÈS CORRECTIONS**

Le travail des sources est solide : presque tous les numéros de vers et de sections sont exacts au vers près dans le grec. Les unions sont traitées sobrement, et le grec et le romain ne sont jamais confondus. Les versions du partage du monde sont bien présentées. Aucune erreur ne bloque la publication. Avant de publier, il faut corriger :
1. **Les balises `[À VÉRIFIER]` encore présentes.** Les numéros de Callimaque sont maintenant établis (v. 6–9, 46–54, 60–67). Burkert est sourçable (*The Orientalizing Revolution*, 1992, p. 88–91).
2. **« Chez Homère, Zeus est l'aîné des frères » va trop loin.** Homère dit seulement que Zeus est « né avant » Poséidon (*Il.* XIII, 355 ; XV, 166 et 182). Il ne dit rien de son rang par rapport à Hadès, et rien sur l'ensemble des enfants.
3. **Le mont Ida, demandé par le brief, est absent.** Il est attesté chez Callimaque (v. 6 et 51–52).
4. Plusieurs petites imprécisions sont détaillées dans le tableau : la prophétie sur Métis, la formule « Europe enlevée par un taureau », le locus de *Travaux et Jours*, la date de Phidias, « éclair maître » et le locus de `lives-in`.

---

### Tableau des affirmations

| # | Affirmation (résumée) | Verdict | Source consultée (URL) | Correction proposée |
|---|---|---|---|---|
| **MDX : En bref** |||||
| 1 | Zeus est fils des Titans Cronos et Rhéa | ✅ | [HES] v. 133–137 (Rhéa et Cronos parmi les enfants d'Ouranos), v. 207 (« Titans »), v. 453 et 457 ; [IL] XV, 187 (ἐκ Κρόνου… οὓς τέκετο Ῥέα) | — |
| 2 | Il est frère d'Hestia, Déméter, Héra, Hadès et Poséidon | ✅ | [HES] v. 454–457 ; [APD] I, 1, 5 | — |
| 3 | Ses domaines : ciel, foudre, justice, hospitalité, serments | ✅ | [IL] XV, 192 (le ciel) ; [HES] v. 72, 504–505 (la foudre) ; [TJ] v. 238–239, 256–262 (la justice) ; [OD] IX, 270–271 (ξείνιος) ; [PAUS] V, 24, 9 (Horkios) ; https://www.britannica.com/topic/Zeus | — |
| 4 | La foudre lui est « offerte par les Cyclopes » | ✅ | [HES] v. 139–141 (οἳ Ζηνὶ βροντήν τε δόσαν τεῦξάν τε κεραυνόν) ; [APD] I, 2, 1 | — |
| 5 | Ses symboles : foudre, aigle, chêne, égide partagée avec Athéna | ✅ | [IL] XXIV, 310–311 (l'aigle) ; [OD] XIV, 327–328 (le chêne de Dodone) ; [IL] XV, 308–310 et XVII, 593 (l'égide de Zeus) ; [IL] II, 447 et V, 738 (Athéna porte l'égide) | — |
| 6 | Il réside sur le mont Olympe | ✅ | [IL] I, 498–499 (Zeus assis sur le plus haut sommet de l'Olympe) ; [HES] v. 884 (Ὀλύμπιον) | — |
| 7 | Héra est sa sœur, « la septième et dernière épouse divine » chez Hésiode | ⚠️ | [HES] v. 886–921 : Hésiode énumère sept unions (Métis, Thémis, Eurynomé, Déméter, Mnémosyne, Létô, Héra). Héra est bien la dernière : λοισθοτάτην… ἄκοιτιν, v. 921. Mais seules Métis (ἄλοχον, v. 886) et Héra sont dites épouses ; Thémis est « emmenée » (ἠγάγετο, v. 901). | Écrire : « la septième et dernière union divine chez Hésiode, et la seule qui dure ». |
| 8 | Son équivalent romain est Jupiter | ✅ | https://www.britannica.com/topic/Zeus (« identical with the Roman god Jupiter ») | — |
| **MDX : Son histoire** |||||
| 9 | Une prophétie annonce à Cronos qu'un de ses enfants le renversera | ✅ | [HES] v. 463–465 (révélé par Gaïa et Ouranos) ; [APD] I, 1, 5 | — |
| 10 | Cronos avale Hestia, Déméter, Héra, Hadès et Poséidon | ✅ | [HES] v. 459–467 ; [APD] I, 1, 5, avec le même ordre | — |
| 11 | Pour le dernier, Rhéa tend à Cronos une pierre emmaillotée, qu'il avale sans rien remarquer | ✅ | [HES] v. 485–488 (σπαργανίσασα μέγαν λίθον… οὐδʼ ἐνόησε) ; [APD] I, 1, 7 | — |
| 12 | Hésiode est un poète grec « vers 700 av. J.-C. » | ✅ | https://fr.wikipedia.org/wiki/Hésiode (« fin du VIIIe ou début du VIIe siècle av. J.-C. ») | — |
| 13 | Chez Hésiode, Zeus grandit dans une grotte près de Lyctos | ✅ | [HES] v. 477–484 : envoyé à Lyctos, puis caché dans une grotte « sur le mont Aigaion » (Αἰγαίῳ ἐν ὄρει, v. 484) | Le nom du mont n'est pas donné, ce qui est acceptable. Voir aussi la ligne 16. |
| 14 | Apollodore place la grotte au mont Dicté | ✅ | [APD] I, 1, 6 (γεννᾷ δὲ ἐν ἄντρῳ τῆς Δίκτης) ; trad. Frazer : https://www.theoi.com/Text/Apollodorus1.html | — |
| 15 | Les Courètes, des guerriers, frappent leurs boucliers pour couvrir ses pleurs | ✅ | [APD] I, 1, 7 (ils entrechoquent leurs lances et leurs boucliers pour que Cronos n'entende pas) ; aussi [CAL-GR] v. 52–54 | Préciser « avec leurs lances » est facultatif. |
| 16 | Le mont Ida est absent du texte alors que le brief le demande | ⚠️ | [CAL-GR] v. 6 (« Zeus, on dit que tu es né sur les monts de l'Ida ») et v. 51 (Panacra, sur l'Ida) ; [CAL-EN] § 4 et § 42 | Ajouter une demi-phrase : « Le poète Callimaque évoque aussi le mont Ida… et rappelle que les Arcadiens revendiquent sa naissance. » |
| 17 | Adulte, Zeus « force son père à recracher ses enfants » | ⚠️ | [HES] v. 494–496 (Cronos est trompé par les conseils de Gaïa et « vaincu par les ruses et la force de son fils ») ; [APD] I, 2, 1 (une drogue donnée par Métis) | C'est acceptable en version courte. Mieux : « Par la ruse, Zeus pousse son père à recracher… » |
| 18 | La Titanomachie dure dix ans | ✅ | [HES] v. 636 (δέκα πλείους ἐνιαυτούς, « dix années pleines ») ; [APD] I, 2, 1 (ἐνιαυτοὺς δέκα) | — |
| 19 | Zeus libère les Cyclopes, qui lui offrent le tonnerre et la foudre | ✅ | [HES] v. 501–505 (les « frères de son père, fils d'Ouranos », c'est-à-dire les Cyclopes de v. 139–141, lui donnent tonnerre, foudre et éclair) ; [APD] I, 2, 1 (Zeus tue Campé, et les Cyclopes donnent tonnerre, éclair et foudre) | Chez Hésiode, la libération a lieu avant la guerre ; chez Apollodore, pendant. Le texte reste vrai, aucune correction n'est obligatoire. |
| 20 | Les Titans vaincus sont enchaînés dans le Tartare, aussi loin sous la terre que le ciel est au-dessus | ✅ | [HES] v. 717–721 (δεσμοῖσιν… ἔδησαν ; τόσσον ἔνερθʼ ὑπὸ γῆς ὅσον οὐρανός ἐστʼ ἀπὸ γαίης), v. 729–730 | — |
| 21 | On prédit à sa première épouse Métis un fils plus fort que lui, et Zeus l'avale | ⚠️ | [HES] v. 886–900 : la prophétie vient de Gaïa et Ouranos et elle est faite **à Zeus** (v. 891–892) ; le fils serait « roi des dieux et des hommes ». [APD] I, 3, 6 : Gaïa annonce un fils qui sera « maître du ciel ». | Écrire : « On lui prédit que Métis, sa première épouse, lui donnera un fils capable de le détrôner : il l'avale. » |
| 22 | Athéna naîtra de la tête de Zeus | ✅ | [HES] v. 924 (αὐτὸς δʼ ἐκ κεφαλῆς) ; [APD] I, 3, 6 | — |
| 23 | Europe est « enlevée par un taureau » | ⚠️ | [APD] III, 1, 1 : c'est Zeus lui-même, changé en taureau apprivoisé, qui l'emporte en Crète. | Écrire : « Europe, enlevée par Zeus changé en taureau ». Sinon le lecteur peut croire à un vrai taureau. |
| 24 | Callisto est « prise contre son gré » | ✅ | [APD] III, 8, 2 (Ζεὺς δὲ ἐρασθεὶς ἀκούσῃ συνευνάζεται) | — |
| 25 | Les unions sont « souvent par la ruse ou la force » ; le ton est sobre et non romantisé | ✅ | [APD] III, 8, 2 (la force) ; III, 10, 7 (Léda, Zeus changé en cygne) ; II, 4, 1 (Danaé, pluie d'or) ; III, 1, 1 (Europe) | Le traitement est conforme au brief. |
| **MDX : Ses pouvoirs** |||||
| 26 | Ses éclairs embrasent la terre et font bouillir la mer | ✅ | [HES] v. 693–696 (γαῖα… καιομένη ; ἔζεε δὲ χθὼν πᾶσα… πόντος) | — |
| 27 | Dikè, sa fille, siège près de lui et lui dénonce les juges malhonnêtes | ✅ | [TJ] v. 256 (Δίκη, Διὸς ἐκγεγαυῖα), v. 259–262 (assise près de Zeus, elle proclame l'injustice des rois qui faussent les jugements) | Locus : voir la ligne 47. |
| 28 | Zeus Xénios veille sur l'hospitalité et venge les voyageurs maltraités (*Odyssée* IX) | ✅ | [OD] IX, 270–271 (Ζεὺς δʼ ἐπιτιμήτωρ ἱκετάων τε ξείνων τε, ξείνιος) ; voir aussi VI, 207–208 | — |
| 29 | À Olympie, Zeus Horkios tenait une foudre dans chaque main, et c'était la statue la plus terrifiante pour les coupables | ✅ | [PAUS] V, 24, 9 (« in each hand he holds a thunderbolt » ; « the one most likely to strike terror into the hearts of sinners ») | La statue se trouvait dans le Bouleutérion : la précision est facultative. |
| 30 | Pausanias date du IIe s. apr. J.-C. | ✅ | https://fr.wikipedia.org/wiki/Pausanias_le_Périégète (vers 115 – vers 180) | — |
| 31 | L'aigle est « le plus cher des oiseaux » pour Zeus (*Iliade* XXIV) | ✅ | [IL] XXIV, 310–311 (σοὶ αὐτῷ φίλτατος οἰωνῶν) | Le locus exact, XXIV, 310–311, est bien dans le YAML. |
| 32 | Zeus rend ses oracles par le chêne de Dodone (*Odyssée* XIV) | ✅ | [OD] XIV, 327–328 (ἐς Δωδώνην… ἐκ δρυὸς ὑψικόμοιο Διὸς βουλὴν) ; repris en XIX, 296–297 | — |
| **MDX : Versions** |||||
| 33 | Homère, *Iliade* XV, 187–193 : tirage au sort ; la mer à Poséidon, les ténèbres à Hadès, le ciel à Zeus ; la terre et l'Olympe restent communs ; « partagé en trois » | ✅ | [IL] XV, 187–193 (τριχθὰ δὲ πάντα δέδασται ; ἔλαχον / ἔλαχε ; γαῖα δʼ ἔτι ξυνὴ πάντων καὶ μακρὸς Ὄλυμπος) ; https://www.theoi.com/Text/HomerIliad15.html | — |
| 34 | Homère date « vers le VIIIe s. av. J.-C. » | ⚠️ | La datation courante est VIIIe–VIIe s. ; voir la datation d'Hésiode, https://fr.wikipedia.org/wiki/Hésiode, et la chronologie relative usuelle | Écrire « VIIIe–VIIe s. av. J.-C. » ou garder « vers le VIIIe s. ». La prudence du « vers » est déjà là, la correction est mineure. |
| 35 | Hésiode, v. 881–885 : pas de tirage au sort ; sur le conseil de Gaïa, les dieux pressent Zeus de régner, puis il distribue les honneurs | ✅ | [HES] v. 881–885 (ὤτρυνον βασιλευέμεν… Γαίης φραδμοσύνῃσιν… διεδάσσατο τιμάς) | — |
| 36 | Apollodore, I, 2, 1 : tirage au sort ; le ciel à Zeus, la mer à Poséidon, le monde souterrain à Pluton | ✅ | [APD] I, 2, 1 (διακληροῦνται περὶ τῆς ἀρχῆς… Πλούτων δὲ τὴν ἐν Ἅιδου) | — |
| 37 | Apollodore date du Ier–IIe s. apr. J.-C. | ✅ | https://en.wikipedia.org/wiki/Pseudo-Apollodorus (« first or second centuries AD ») | — |
| 38 | Callimaque se moque du tirage au sort : seul un sot jouerait l'Olympe contre l'Hadès ; Zeus est roi par ses exploits et sa force | ✅ | [CAL-GR] v. 60–67 (v. 62–63 τίς δέ κʼ ἐπʼ Οὐλύμπῳ τε καὶ Ἄιδι κλῆρον ἐρύσσαι, ὃς μάλα μὴ νενίηλος ; v. 66–67 οὔ σε θεῶν ἐσσῆνα πάλοι θέσαν, ἔργα δὲ χειρῶν, σή τε βίη τό τε κάρτος) ; [CAL-EN] § 54/61 | Remplacer `[vers À VÉRIFIER]` par « v. 60–67 ». |
| 39 | « Chez Homère, Zeus est l'aîné des frères » (*Iliade* XIII, 355) | ⚠️ | [IL] XIII, 355 (Ζεὺς πρότερος γεγόνει), XV, 166 et 182 (γενεῇ πρότερος). Dans ces trois passages, Zeus est plus âgé **que Poséidon**. Homère ne situe jamais Zeus par rapport à Hadès. | Écrire : « chez Homère, Zeus est né avant Poséidon » et citer XIII, 355 et XV, 166. |
| 40 | Chez Hésiode, Zeus est le plus jeune des enfants de Rhéa (v. 478) | ✅ | [HES] v. 478 (ὁππότʼ ἄρʼ ὁπλότατον παίδων) | On peut ajouter que Callimaque en fait aussi le cadet : ses frères sont « nés avant » lui ([CAL-GR] v. 58, γνωτοὶ προτερηγενέες). |
| 41 | Burkert rapproche le tirage au sort homérique de l'épopée d'Atrahasis, où les dieux se partagent ciel, terre et eaux par le sort | ⚠️ | Note citant W. Burkert, *The Orientalizing Revolution*, 1992, p. 88–91 : https://en.wikipedia.org/wiki/Atrahasis. Article savant qui cite Burkert, p. 90 (« a lottery is used to apportion sky to Anu, earth to Enlil », les eaux d'en bas à Enki) : https://www.lesetudesclassiques.be/index.php/lec/article/viewFile/631/541 | La thèse est attestée par deux sources secondaires, mais je n'ai pas lu Burkert directement. La formulation au conditionnel (« rappellerait ») convient. Retirer `[À VÉRIFIER]` et ajouter la référence « W. Burkert, *The Orientalizing Revolution*, 1992, p. 88–91 » dans `source=` et dans la liste des Sources. |
| **MDX : Le saviez-vous ?** |||||
| 42 | En 1614, Simon Marius, sur une idée de Kepler, nomme les quatre lunes Io, Europe, Ganymède et Callisto | ✅ | https://en.wikipedia.org/wiki/Galilean_moons ; https://www.lindahall.org/about/news/scientist-of-the-day/simon-marius/ (*Mundus Iovialis*, 1614, noms « passed on to him by Kepler ») | Ajout facultatif : ces noms ne se sont imposés qu'au XXe siècle. |
| 43 | « Tous ont été séduits, trompés ou enlevés par Zeus » | ✅ | Io : [APD] II, 1, 3 (ἔφθειρε). Europe : [APD] III, 1, 1. Callisto : [APD] III, 8, 2. Ganymède : [APD] III, 12, 2 (ἀναρπάσας… διʼ ἀετοῦ) | Le titre « galerie de victimes » est un choix éditorial cohérent avec le brief. |
| 44 | Vers 435 av. J.-C., Phidias sculpte à Olympie un Zeus assis, en or et ivoire, d'environ 12 m | ⚠️ | https://en.wikipedia.org/wiki/Statue_of_Zeus_at_Olympia (vers 435 ; 12,4 m) ; https://www.britannica.com/topic/Statue-of-Zeus (« about 430 bce », « almost 12 m ») | Les deux sources divergent. Écrire « vers 435–430 av. J.-C. » ou « vers 430 ». « Environ 12 m » est confirmé. |
| 45 | Strabon note que, debout, la statue emporterait le toit | ✅ | [STR] VIII, 3, 30 (« if Zeus arose and stood erect he would unroof the temple ») | — |
| 46 | Les Crétois montraient un tombeau de Zeus ; Callimaque : « Les Crétois, toujours menteurs ! », car Zeus ne meurt jamais | ✅ | [CAL-GR] v. 8–9 (Κρῆτες ἀεὶ ψεῦσται· καὶ γὰρ τάφον, ἄνα, σεῖο Κρῆτες ἐτεκτήναντο· σὺ δʼ οὐ θάνες, ἐσσὶ γὰρ αἰεί) ; [CAL-EN] § 4 | La traduction est fidèle. À savoir : chez Callimaque, la formule est déjà une citation, traditionnellement attribuée à Épiménide. Une note est facultative. |
| **YAML : relations et sources** (je ne liste que ce qui n'apparaît pas déjà plus haut) |||||
| 47 | Locus de *Travaux et Jours* : « v. 238–239, 256–259 » | ⚠️ | [TJ] v. 259–262 : la dénonciation des juges injustes (affirmation 27) se trouve aux v. 260–262. | Écrire « v. 238–239, 256–262 », dans le YAML et dans la liste des Sources du MDX. |
| 48 | Callimaque, locus « § 4, 10, 42–54, 61 de l'édition en ligne [vers exacts À VÉRIFIER] » | ⚠️ | [CAL-GR] ; [CAL-EN]. Les « § » sont des repères de paragraphe de topostext ou theoi, pas des numéros de vers. | Écrire « v. 6–9 (Ida, Arcadie, tombeau), 46–54 (Dicté, Courètes, Amalthée, Panacra), 58–67 (rejet du tirage au sort) ». Utiliser comme URL https://www.perseus.tufts.edu/hopper/text?doc=Perseus:text:2008.01.0481:hymn=1 |
| 49 | `zeus lives-in mount-olympus` : « Homère, Iliade, XV, 193 » | ⚠️ | [IL] XV, 193 dit que l'Olympe est **commun aux trois frères**, pas que Zeus y habite. [IL] I, 498–499 montre Zeus assis au sommet de l'Olympe. | Remplacer par « Iliade, I, 498–499 ». |
| 50 | `hephaestus → aegis` : « (fragment hésiodique, Théogonie v. 929s : fabriquée par Métis) » | ⚠️ | [HES] lignes 929a–t de l'édition Perseus (αἰγίδα ποιήσασα… ἔντος Ἀθήνης). Ce morceau est un fragment transmis à part, pas un vers de la *Théogonie* ; il attribue l'égide à Métis et la donne **à Athéna**. | Séparer cette variante en note ou dans une relation distincte ; ne pas l'enfermer dans la source « Homère ». Écrire « fragment hésiodique (Théogonie 929a–t éd. Perseus) ». |
| 51 | `zeus owns aegis` est marqué `certainty: variant` | ⚠️ | [IL] XV, 308–310 et XVII, 593–595 : Homère attribue l'égide à Zeus sans variante ; l'épithète αἰγίοχος apparaît par exemple en [HES] v. 735. | Écrire `canonical`. Le partage avec Athéna peut rester en commentaire. Voir les questions pour le directeur. |
| 52 | Relations de filiation et d'alliance avec leurs loci : Cronos et Rhéa (Hés. 453–458 ; *Il.* XV, 187–188 ; Apd. I, 1, 5–6) ; frères et sœurs (Hés. 453–457) ; Métis (886–900) ; Héra (921 ; Apd. I, 3, 1) ; Athéna (886–900, 924–926) ; Arès (921–923) ; Perséphone (912–914) ; Héraclès (*Il.* XIV, 323–324) ; Persée (*Il.* XIV, 319–320 ; Apd. II, 4, 1 « selon certains ») | ✅ | [HES], [IL], [APD], tous contrôlés vers par vers. Apd. II, 4, 1 dit bien ὡς δὲ ἔνιοί φασι, et précise que d'autres attribuent Persée à Proïtos. | — |
| 53 | Défaites et châtiments : Cronos (Hés. 71–73, 490–496) ; Titans (687–735 ; Apd. I, 2, 1) ; enchaînés « par la volonté de Zeus » (v. 730) ; Cyclopes (501–506, 139–141) ; foudre (72, 504–506, 687–699) | ✅ | [HES] v. 73 (κάρτει νικήσας πατέρα Κρόνον), v. 730 (βουλῇσι Διὸς), etc. ; [APD] I, 2, 1 | Nuance facultative : chez Hésiode, ce sont les Hécatonchires qui enchaînent les Titans (v. 717–719). |
| 54 | Égide chez Homère : Héphaïstos l'a forgée pour Zeus (XV, 309–310) ; Zeus la secoue (XVII, 593) ; Athéna la porte (II, 447 ; V, 738) | ✅ | [IL] passages cités | — |
| 55 | Commentaire YAML sur les unions : Europe III, 1, 1 (Minos, Sarpédon, Rhadamanthe) ; Callisto III, 8, 2 (ἀκούσῃ, Arcas) ; Io II, 1, 3 (Épaphos) ; Léda III, 10, 7 (Pollux, Hélène) ; Ganymède *Il.* XX, 232–235 (« les dieux ») et Apd. III, 12, 2 (Zeus, aigle) | ✅ | [APD] sections citées ; [IL] XX, 234 (ἀνηρείψαντο θεοί) | — |
| 56 | Perséphone « donnée » à Hadès par Zeus (Théog. 913–914) | ✅ | [HES] v. 913–914 (ἥρπασε… ἔδωκε δὲ μητίετα Ζεύς) | — |
| 57 | *Odyssée* VI, 207–208 et XIV, 57–58 : les étrangers viennent de Zeus | ✅ | [OD] VI, 207–208 ; XIV, 57–58 (πρὸς γὰρ Διός εἰσιν ἅπαντες ξεῖνοί τε πτωχοί τε) | — |
| 58 | *Iliade* I, 528–530 (signe de tête de Zeus) et III, 276–280 (serment invoquant Zeus) | ✅ | [IL] I, 528–530 ; III, 276–280 | Ces passages figurent dans les Sources mais ne sont pas exploités dans le texte. On peut les garder. |
| 59 | Strabon : « début du Ier siècle apr. J.-C. » | ✅ | https://fr.wikipedia.org/wiki/Strabon (né vers 60 av. J.-C. ; il révise la *Géographie* jusque vers 23 apr. J.-C.) | — |
| **MDX : Culture populaire** |||||
| 60 | *Percy Jackson et le Voleur de foudre* (Rick Riordan, 2005) : l'arme de Zeus a disparu et tout accuse Percy | ✅ | https://en.wikipedia.org/wiki/The_Lightning_Thief (parution le 1er juillet 2005 ; Master Bolt) ; https://en.wikipedia.org/wiki/Percy_Jackson_%26_the_Olympians:_The_Lightning_Thief (« Zeus accuses… Percy Jackson, of stealing his master lightning bolt ») | — |
| 61 | Le nom français de l'objet est « éclair maître » | ⚠️ | https://fr.vikidia.org/wiki/Le_Voleur_de_foudre : la traduction française dit « éclair primitif » | Écrire « l'éclair primitif de Zeus » (nom de la traduction française) ou simplement « la foudre de Zeus ». |
| 62 | Série Disney+ (2023) : Zeus est joué par Lance Reddick, mort avant la diffusion | ✅ | https://en.wikipedia.org/wiki/Percy_Jackson_and_the_Olympians_(TV_series) (première le 19 décembre 2023 ; Reddick mort en mars 2023 ; Zeus en saison 1) ; https://www.thedailybeast.com/obsessed/percy-jackson-and-the-olympians-finale-recap-lance-reddick-is-epic | — |
| 63 | *Hercule* (Disney, 1997) : Zeus en père jovial, Héra mère d'Hercule ; dans le mythe, la mère est Alcmène et Héra le déteste | ✅ | https://en.wikipedia.org/wiki/Hercules_(1997_film) ; [IL] XIV, 323–324 (Alcmène) ; [IL] XIX, 96–124 (Héra retarde la naissance d'Héraclès par la ruse) | — |
| 64 | *God of War III* (2010, PlayStation 3) : Kratos tue Zeus | ✅ | https://en.wikipedia.org/wiki/God_of_War_III | — |

**Décompte :** 49 ✅ · 15 ⚠️ · 0 ❌ · 0 ❓ (64 lignes)

---

### Problèmes de forme et de ton
- **Balises de travail encore présentes :** `[À VÉRIFIER]` apparaît dans deux `<Version>` (Callimaque, Burkert) et dans le `locus` de Callimaque du YAML. Il faut les supprimer après correction (lignes 38, 41 et 48).
- **Pas de tutoiement.** Le guide demande « accroche, tutoiement ». Le texte ne s'adresse jamais au lecteur : « Bienvenue dans la famille… » n'est pas un tutoiement. Ajouter une ou deux adresses directes, par exemple dans l'accroche ou dans « Son histoire ». Le ton est par ailleurs réussi : vif, pas scolaire, pas infantilisant.
- **Longueur des paragraphes :** tous font 55 mots ou moins après retrait des balises. C'est conforme.
- **Couches :** les `<Version>` sont bien `ancient` et `interpretation`. La culture populaire est cantonnée à sa section, et aucun élément 🎬 n'apparaît dans les faits. C'est conforme.
- **Cohérence entre le YAML et le MDX :** Callimaque, Pausanias et Strabon figurent dans les deux. Burkert apparaît dans le MDX mais pas dans `sources:` du YAML, à ajouter. Les loci de *Travaux et Jours* sont à aligner (ligne 47). Le MDX ne cite pas Burkert dans « Sources ».
- **Brief :** tous les points obligatoires sont traités, **sauf le mont Ida** (ligne 16). Les portes (Cronos, Titanomachie, Héra) sont conformes. Les ids sont conformes au lot.
- **« Une galerie de victimes dans le ciel » :** le titre est fort mais il est justifié par les sources (ligne 43). À garder si le directeur l'assume.
- **Typographie :** les espaces insécables avant `:` `;` `!` `?` et dans `« »` restent à contrôler au rendu, comme l'auteur le signale.

### Questions pour le directeur éditorial
1. **Le champ `deity:`** (domains, symbols, home) n'est pas prévu par le guide, qui ne donne que `creature:`. Faut-il valider ce schéma pour tout le lot ?
2. **`certainty` de l'égide :** `zeus owns aegis` doit-il être `canonical` (Homère est sans ambiguïté) avec le partage avec Athéna en note, ou `variant` comme proposé ? Il faut décider de façon cohérente avec la fiche Athéna.
3. **Le mont Ida :** faut-il ajouter Callimaque, avec Ida et Arcadie, dans « Son histoire » (+ 15 à 20 mots), ou ouvrir un bloc `<Versions>` sur le lieu de naissance (Lyctos et le mont Aigaion / Dicté / Ida / Arcadie) ?
4. **Les variantes de libération des enfants** (ruse de Gaïa ou drogue de Métis) : faut-il un bloc `<Versions>` supplémentaire, ou s'en tenir à la formule courte ?
5. **Burkert :** une thèse savante attestée seulement par des sources secondaires (Wikipédia et un article des *Études classiques*) suffit-elle, avec une formulation au conditionnel ? Ou exige-t-on la lecture de *The Orientalizing Revolution*, p. 88–91 ?
6. **Relations sans id :** les unions (Europe, Callisto, Io, Danaé, Léda, Ganymède) et l'événement `titanomachy` n'ont pas de relation dans le YAML, faute d'ids ou de types autorisés. Faut-il créer ces ids ou un type `participated-in` ?
