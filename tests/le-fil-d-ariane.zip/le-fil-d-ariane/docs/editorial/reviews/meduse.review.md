# Rapport de vérification : fiche « Méduse » (pilote)

- **Fiche vérifiée :** `/home/claude/editorial/drafts/meduse.draft.md` (YAML + MDX)
- **Brief :** `/home/claude/editorial/briefs/meduse.md`
- **Vérificateur :** agent indépendant, 2026-10-15
- **Méthode :** chaque affirmation a été contrôlée en ligne. Pour les textes antiques, j'ai travaillé sur le **texte original numéroté** (fichiers TEI du dépôt PerseusDL `canonical-greekLit` / `canonical-latinLit`, sur raw.githubusercontent.com), recoupé avec les traductions de theoi.com. Je n'ai pas pu accéder à perseus.tufts.edu par WebFetch (robots.txt). J'ai donc utilisé les mêmes éditions Perseus par leur dépôt GitHub. Les URL des fichiers sont données ci-dessous.

**URL des textes originaux consultés (abrégées dans le tableau) :**
- [HES-GR] Hésiode, *Théogonie*, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml
- [HES-EN] Hésiode, *Théogonie*, trad. Evelyn-White : https://www.theoi.com/Text/HesiodTheogony.html
- [APD-GR] Apollodore, *Bibliothèque*, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-grc2.xml
- [APD-EN] Apollodore, trad. Frazer : https://www.theoi.com/Text/Apollodorus2.html
- [OV-LA] Ovide, *Métamorphoses*, latin numéroté : https://raw.githubusercontent.com/PerseusDL/canonical-latinLit/master/data/phi0959/phi006/phi0959.phi006.perseus-lat2.xml (recoupé avec https://www.thelatinlibrary.com/ovid/ovid.met4.shtml)
- [IL-GR] Homère, *Iliade*, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml (recoupé avec https://www.theoi.com/Text/HomerIliad5.html)
- [SC-GR] *Bouclier d'Héraclès*, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg003/tlg0020.tlg003.perseus-grc2.xml
- [PIN-GR] Pindare, *Pythiques*, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0033/tlg002/tlg0033.tlg002.perseus-grc2.xml (recoupé avec https://en.wikisource.org/wiki/Odes_of_Pindar_(Myers)/Pythian_Odes/12)
- [AES-GR] Eschyle (?), *Prométhée enchaîné*, grec : https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0085/tlg003/tlg0085.tlg003.perseus-grc2.xml (recoupé avec https://www.theoi.com/Text/AeschylusPrometheus.html)
- [MET] M. Glennon, « Medusa in Ancient Greek Art », Met, mars 2017 : https://www.metmuseum.org/en/essays/medusa-in-ancient-greek-art

---

### Verdict global
**PUBLIABLE APRÈS CORRECTIONS**

Aucune erreur factuelle grave. La fiche est solide et respecte bien la distinction entre le grec et le romain. Elle présente la version d'Ovide comme romaine et tardive. Avant publication, il faut corriger :
- les numéros de vers et les balises `[À VÉRIFIER]` encore présentes dans le YAML et le MDX ;
- une interprétation trop affirmative sur Hésiode ;
- quelques attributions textuelles imprécises (*Bouclier*, « cou », égide chez Apollodore, « flûte »).

---

### Tableau des affirmations

| # | Affirmation (résumée) | Verdict | Source consultée (URL) | Correction proposée |
|---|---|---|---|---|
| 1 | Méduse est la fille de Phorcys et de Céto, deux divinités marines | ✅ | [HES-GR] v. 270 et 274 (Φόρκυϊ δ' αὖ Κητὼ… Γοργούς θ'). Pour le rôle marin : https://www.theoi.com/Pontios/Phorkys.html (« ancient sea-god » ; Céto, déesse des monstres marins) | — |
| 2 | Les Gorgones sont trois sœurs : Sthéno, Euryale, Méduse | ✅ | [HES-GR] v. 276 (Σθεννώ τ' Εὐρυάλη τε Μέδουσά τε) ; [APD-GR] 2.4.2 (Σθενὼ Εὐρυάλη Μέδουσα) | — (« Sthéno » est la graphie française usuelle ; Hésiode écrit Σθεννώ) |
| 3 | Méduse est la seule Gorgone mortelle | ✅ | [HES-GR] v. 277 (ἣ μὲν ἔην θνητή) ; [APD-GR] 2.4.2 (μόνη δὲ ἦν θνητὴ Μέδουσα) | — |
| 4 | Ses sœurs sont immortelles et ne vieillissent pas | ✅ | [HES-GR] v. 277–278 (ἀθάνατοι καὶ ἀγήρῳ, αἱ δύο) | — |
| 5 | Hésiode, « vers 700 av. J.-C. » | ✅ | https://www.britannica.com/biography/Hesiod (« flourished c. 700 BC ») | — |
| 6 | Lieu : « au-delà de l'Océan », au bout du monde, du côté de la Nuit | ✅ | [HES-GR] v. 274–275 (πέρην κλυτοῦ Ὠκεανοῖο / ἐσχατιῇ πρὸς Νυκτός) ; [HES-EN] | Possibilité d'ajouter « près des Hespérides » (v. 275) |
| 7 | YAML, commentaire habitat : île de Sarpédon (*Chants cypriens*) | ✅ | https://www.theoi.com/Pontios/Gorgones.html (*Cypria* fr., via Hérodien : « Sarpedon, a rocky island in deep-eddying Okeanos ») | — |
| 8 | Méduse s'unit au « dieu aux cheveux sombres », c'est-à-dire Poséidon | ✅ | [HES-GR] v. 278 (παρελέξατο Κυανοχαίτης) ; [HES-EN] note 14 « i.e. Poseidon » | — (doute n° 3 levé) |
| 9 | Citation : « dans une prairie tendre, parmi les fleurs du printemps » | ⚠️ | [HES-GR] v. 279 (ἐν μαλακῷ λειμῶνι καὶ ἄνθεσιν εἰαρινοῖσιν) : la traduction est fidèle | Le MDX doit signaler que c'est une traduction de la rédaction (règle 9 du guide de rédaction), par ex. « (trad. de la rédaction) » dans l'attribut source, ou une note |
| 10 | Chez Hésiode : « pas de temple, pas de punition », Gorgone de naissance | ✅ | [HES-GR] v. 270–283 : Méduse figure parmi les enfants de Céto, sans aucun récit de transformation | — |
| 11 | Locus d'Hésiode : « v. 270 et suiv. » (YAML : « [À VÉRIFIER : env. 274–283] ») | ⚠️ | [HES-GR] : Grées v. 270–273 ; Gorgones v. 274 ; Méduse v. 276 ; mortelle v. 277 ; union v. 278–279 ; décapitation v. 280 ; Chrysaor et Pégase v. 281–283 | Écrire **« Théogonie, v. 270–283 »** (ou 274–283 pour Méduse seule) dans le YAML, la balise `Version` et les Sources, puis supprimer `[À VÉRIFIER]` (doute n° 1 levé) |
| 12 | Apollodore, « mythographe », I<sup>er</sup>–II<sup>e</sup> s. apr. J.-C., « bien plus tard » | ⚠️ | https://en.wikipedia.org/wiki/Bibliotheca_(Pseudo-Apollodorus) (« generally dated to the first or second centuries AD », attribution au « Pseudo-Apollodorus ») | Dans les Sources, écrire « (Pseudo-)Apollodore » comme pour le *Bouclier*. Dans le texte, « Apollodore » peut rester pour la lisibilité |
| 13 | Polydectès veut éloigner Persée, qui part chercher la tête | ✅ | [APD-GR] 2.4.2 : Polydectès, épris de Danaé, ne peut l'approcher ; au repas de l'éranos (dons pour les noces d'Hippodamie), Persée dit qu'il ne refuserait pas même la tête de la Gorgone, et Polydectès la lui ordonne | Simplification acceptable (doute n° 6 levé). Option : « Persée se vante de pouvoir rapporter la tête de Méduse ; le roi le prend au mot. » |
| 14 | Des nymphes lui donnent sandales ailées, besace (kibisis) et casque d'Hadès qui rend invisible | ✅ | [APD-GR] 2.4.2 (πτηνὰ πέδιλα, κίβισιν… πήραν, τὴν Ἄϊδος κυνῆν… ὑπὸ ἄλλων δὲ οὐχ ἑωρᾶτο) | — (version attribuée à Apollodore, ce que le texte dit bien ; voir aussi la remarque sur le doute n° 5 ci-dessous) |
| 15 | Hermès lui donne une faucille en adamant | ✅ | [APD-GR] 2.4.2 (παρὰ Ἑρμοῦ ἀδαμαντίνην ἅρπην) | — |
| 16 | L'adamant est « un métal réputé indestructible » | ⚠️ | https://en.wikipedia.org/wiki/Adamant (*adamas* = « indomptable » ; matière légendaire, pas un métal identifié) | « un matériau légendaire réputé indestructible (*adamas*, “l'indomptable”) » |
| 17 | Persée surprend les Gorgones endormies | ✅ | [APD-GR] 2.4.2 (κατέλαβε τὰς Γοργόνας κοιμωμένας) ; [OV-LA] IV, 784 | — |
| 18 | Athéna guide sa main | ✅ | [APD-GR] 2.4.2 (κατευθυνούσης τὴν χεῖρα Ἀθηνᾶς) | — |
| 19 | Il regarde le reflet de Méduse dans un bouclier de bronze | ✅ | [APD-GR] 2.4.2 (βλέπων εἰς ἀσπίδα χαλκῆν, δι' ἧς τὴν εἰκόνα… ἔβλεπεν) ; [OV-LA] IV, 782–783 (*clipei… aere repercusso*) | Correct, car le détail est attribué à Apollodore. **Origine du motif** (doute n° 4) : premier texte conservé = Ovide (8 apr. J.-C.), puis Apollodore. Dans l'art archaïque et classique, Persée **détourne la tête** ([MET]). Le reflet apparaît vers 400–385 av. J.-C. sur un cratère apulien (Peintre de Tarporley, Boston MFA 1970.237), mais pour regarder la **tête déjà coupée** dans le bouclier d'Athéna : https://www.theoi.com/Gallery/P23.2.html. Suggestion : préciser « détail tardif » pour éviter qu'on le croie archaïque |
| 20 | Pégase et Chrysaor sont « nés de son cou tranché » / « du cou jaillissent » | ⚠️ | [HES-GR] v. 280–281 : ils « bondissent » (ἔκθορε) quand Persée tranche la tête, sans mention du cou ; [APD-GR] 2.4.2 : « de la Gorgone » (ἐκ τῆς Γοργόνος) ; [OV-LA] IV, 786 : « nés du sang de leur mère » (*matris de sanguine natos*) | « nés au moment où Persée lui tranche la tête » (Hésiode) ; « nés de son sang » si l'on suit Ovide |
| 21 | Chrysaor, « le guerrier à l'épée d'or » ; Pégase, cheval ailé | ✅ | [HES-GR] v. 283 (ἄορ χρύσειον ἔχων) ; [APD-GR] 2.4.2 (Πήγασος πτηνὸς ἵππος) | « guerrier » est une glose, mais acceptable |
| 22 | Pégase et Chrysaor ont pour père Poséidon (YAML) | ✅ | [APD-GR] 2.4.2 (τούτους δὲ ἐγέννησεν ἐκ Ποσειδῶνος) | — |
| 23 | De retour, Persée change Polydectès et sa cour en pierre | ✅ | [APD-GR] 2.4.3 (συγκαλέσαντος τοῦ Πολυδέκτου τοὺς φίλους… ἀπελιθώθη) | — |
| 24 | Persée offre la tête à Athéna | ✅ | [APD-GR] 2.4.3 (τὴν δὲ κεφαλὴν τῆς Γοργόνος Ἀθηνᾷ) | — |
| 25 | Le regard pétrifie, et la tête coupée garde ce pouvoir | ✅ | [APD-GR] 2.4.2 (τοὺς δὲ ἰδόντας λίθους ἐποίουν) et 2.4.3 (Phinée, Polydectès) | Note : Apollodore attribue la pétrification aux **trois** Gorgones, pas à Méduse seule. Hésiode ne parle pas de pétrification |
| 26 | Selon Apollodore : écailles de serpent sur la tête, défenses de sanglier, mains de bronze, ailes d'or | ✅ | [APD-GR] 2.4.2 (φολίσι δρακόντων, ὀδόντας… ὡς συῶν, χεῖρας χαλκᾶς, πτέρυγας χρυσᾶς) | — |
| 27 | Ces ailes leur permettent de voler | ✅ | [APD-GR] 2.4.2 (δι' ὧν ἐπέτοντο) | — |
| 28 | Dans le *Bouclier d'Héraclès*, Sthéno et Euryale poursuivent Persée dans les airs | ⚠️ | [SC-GR] v. 229–237 : « les Gorgones » le poursuivent (Γοργόνες… ἐρρώοντο), **sans être nommées**. Elles courent sur la surface du bouclier (scène ciselée, ἐκφρασις), et seul Persée est dit « voler » (v. 222, ἐποτᾶτο) | « Dans le *Bouclier d'Héraclès*, poème qui décrit une scène ciselée, les deux autres Gorgones s'élancent à la poursuite de Persée. » Pour le vol, citer Apollodore |
| 29 | « Mortelle, Méduse est pourtant la seule des trois qu'on puisse tuer » | ✅ | [APD-GR] 2.4.2 (μόνη δὲ ἦν θνητὴ… διὰ τοῦτο… Περσεὺς ἐπέμφθη) | Le fait est juste, mais « pourtant » est illogique (voir la forme) |
| 30 | Version d'Hésiode : née Gorgone, union dans une prairie, ni temple ni punition ni beauté perdue | ✅ | [HES-GR] v. 274–279 | Corriger le locus en « v. 274–283 » |
| 31 | Version d'Apollodore : selon certains, Athéna aurait voulu sa mort à cause d'une rivalité de beauté | ✅ | [APD-GR] 2.4.3 (λέγεται δὲ ὑπ' ἐνίων ὅτι δι' Ἀθηνᾶν ἡ Μέδουσα ἐκαρατομήθη· φασὶ δὲ ὅτι καὶ περὶ κάλλους ἠθέλησεν ἡ Γοργὼ αὐτῇ συγκριθῆναι) | — (le conditionnel est bien employé) |
| 32 | Ovide : jeune femme très belle, violée par le dieu de la mer dans le temple de Minerve ; la déesse détourne les yeux, puis change ses cheveux en serpents (IV, 794–803) | ✅ | [OV-LA] IV, 794 (*clarissima forma*), 798 (*pelagi rector templo vitiasse Minervae*), 799–800 (*aversa est et castos aegide vultus… texit*), 801 (*Gorgoneum crinem turpes mutavit in hydros*), 802–803 | Les numéros sont exacts. Ovide introduit le viol par *dicitur* (« dit-on ») et le fait raconter par Persée : on peut ajouter « raconte-t-on » |
| 33 | Ovide, poète romain, vers 8 apr. J.-C. ; version romaine tardive | ✅ | https://en.wikipedia.org/wiki/Metamorphoses (« first published in 8 CE ») ; https://en.wikipedia.org/wiki/Medusa (« a late version… no earlier versions mention this ») | — |
| 34 | Depuis le XX<sup>e</sup> siècle, des lectures font de Méduse une victime | ✅ | https://en.wikipedia.org/wiki/Medusa (réévaluations féministes du XX<sup>e</sup> siècle ; Seelig, Johnston lisent Ovide comme un récit de viol) | — (bien placé en couche 🔍) |
| 35 | Cixous, *Le Rire de la Méduse*, 1975 | ✅ | https://en.wikipedia.org/wiki/The_Laugh_of_the_Medusa (« Published: 1975 », France ; trad. anglaise 1976) | Supprimer `[À VÉRIFIER]` (doute n° 9 levé). La revue (*L'Arc*) n'a pas été confirmée par une source accessible : ne pas l'ajouter |
| 36 | « Cette lecture s'appuie surtout sur Ovide : chez Hésiode, Méduse est un monstre dès l'origine » | ⚠️ | [HES-GR] v. 276 : Hésiode ne décrit pas son apparence, mais dit qu'elle « a subi un sort funeste » (λυγρὰ παθοῦσα). [PIN-GR] *Pyth.* XII, 16 l'appelle déjà « Méduse aux belles joues » (εὐπαράου… Μεδοίσας, vers 490 av. J.-C.). L'essai de Cixous ne repose pas sur Ovide (Wikipédia ne le relie pas à Ovide) | « La lecture “victime” s'appuie surtout sur Ovide. Chez Hésiode, Méduse est Gorgone dès sa naissance, sans récit de transformation. » Éviter de rattacher Cixous à Ovide |
| 37 | Pindare, *Pyth.* XII : Athéna invente un air en imitant la lamentation des Gorgones ; elle le nomme l'air « aux nombreuses têtes » | ✅ | [PIN-GR] v. 6–8 (Παλλὰς ἐφεῦρε θρασειᾶν Γοργόνων οὔλιον θρῆνον), v. 19–23 (Εὐρυάλας… γόον ; κεφαλᾶν πολλᾶν νόμον) ; Myers sur Wikisource (« the many-headed air ») | Option : préciser que c'est surtout la plainte d'**Euryale** (v. 20) |
| 38 | *Pyth.* XII, début du V<sup>e</sup> siècle av. J.-C. | ✅ | https://en.wikisource.org/wiki/Odes_of_Pindar_(Myers)/Pythian_Odes/12 (« the victory was won either in 494 or 490 ») ; https://en.wikipedia.org/wiki/Medusa (« an ode written in 490 BC ») | Supprimer `[date exacte À VÉRIFIER]` (doute n° 7 levé) |
| 39 | « un air de flûte » | ⚠️ | [PIN-GR] v. 19 (αὐλῶν… μέλος) ; https://en.wikipedia.org/wiki/Aulos (« often translated as “flute”… usually double-reeded ») | « un air d'aulos, sorte de hautbois double » (ou garder « flûte » entre guillemets avec une glose) |
| 40 | Art archaïque : Gorgone à barbe, crocs, langue tirée | ✅ | [MET] (« beard, gaping mouth, extended tongue, sharp teeth ») | — |
| 41 | À partir du V<sup>e</sup> s. av. J.-C., elle est représentée de plus en plus comme une belle jeune femme | ✅ | [MET] (changement à partir du V<sup>e</sup> s., figure féminine à l'époque hellénistique) | — |
| 42 | « Le premier gorgonéion d'Athéna est chez Homère » : *Iliade* V, 733 et suiv., la tête de la Gorgone orne déjà l'égide | ⚠️ | [IL-GR] V, 738–742 : égide (v. 738), Γοργείη κεφαλὴ (v. 741). Les v. 733–737 décrivent le péplos. Homère ne nomme ni Méduse ni Persée (https://www.theoi.com/Text/HomerIliad5.html) | Locus : **V, 738–742**. Titre : « La plus ancienne mention… ». Ajouter : « Homère parle de “la Gorgone”, sans nommer Méduse ni raconter son histoire. » Retirer « déjà », qui laisse croire que l'épisode de Persée est connu d'Homère (doute n° 12) |
| 43 | Homère, VIII<sup>e</sup> siècle av. J.-C. (Sources) | ⚠️ | https://www.britannica.com/biography/Homer-Greek-poet (« 9th or 8th century BCE? ») | « vers le VIII<sup>e</sup> siècle av. J.-C. » |
| 44 | Le gorgonéion figure sur les boucliers et les temples (motif protecteur) | ✅ | [MET] (casques, boucliers, antéfixes, frontons du temple C de Sélinonte ; fonction apotropaïque) ; https://en.wikipedia.org/wiki/Gorgoneion (frontons, boucliers, fronton de Corfou) | « gravée » peut devenir « représentée » (peinte ou sculptée) |
| 45 | *Bouclier d'Héraclès*, v. 216–237, VI<sup>e</sup> siècle av. J.-C. | ⚠️ | [SC-GR] v. 216–237 : le locus est confirmé (Persée, sandales, κίβισις d'argent, casque d'Hadès, poursuite) ; https://en.wikipedia.org/wiki/Shield_of_Heracles (« end of the 7th to the middle of the 6th century BCE ») | « fin VII<sup>e</sup>–milieu VI<sup>e</sup> siècle av. J.-C. », et supprimer `[À VÉRIFIER]` (doute n° 8) |
| 46 | Eschyle, *Prométhée enchaîné*, v. 790 et suiv. (YAML et Sources) | ⚠️ | [AES-GR] v. 794–800 (Phorcides ; Gorgones ailées aux cheveux de serpents, « nul mortel ne les voit sans perdre le souffle ») ; https://en.wikipedia.org/wiki/Prometheus_Bound (attribution à Eschyle discutée, « no consensus ») | Locus « v. 794–800 ». Écrire « (attribué à) Eschyle ». La source n'est utilisée nulle part dans le MDX : la citer dans le texte ou la retirer |
| 47 | YAML : `aegis part-of`, source « Apollodore 2.4.3 (tête au centre du bouclier d'Athéna) ; Ovide 4.803 » | ⚠️ | [APD-GR] 2.4.3 : ἐν μέσῃ τῇ **ἀσπίδι** (bouclier, pas égide) ; [OV-LA] IV, 803 : ce sont les **serpents** qu'elle porte sur la poitrine ; [IL-GR] V, 741 : la tête de la Gorgone sur l'égide | Sources : « Homère, Iliade V, 741 (égide, Gorgone non nommée) ; Apollodore 2.4.3 (bouclier) ; Ovide IV, 802–803 ». Certitude : `variant` (bouclier ou égide selon les sources) |
| 48 | YAML : Poséidon `partner-of`, Ovide 4.798, « union forcée » | ✅ | [OV-LA] IV, 798 | — |
| 49 | YAML : Méduse sœur des Grées (`graeae`) | ✅ | [HES-GR] v. 270–274 ; [APD-GR] 2.4.2 (Γοργόνων ἀδελφαί) | — |
| 50 | Vaincue par Persée avec l'aide d'Athéna et d'Hermès | ✅ | [APD-GR] 2.4.2 (Ἑρμοῦ καὶ Ἀθηνᾶς προκαθηγουμένων) | — |
| 51 | Athéna « porte la tête de Méduse sur sa poitrine » (Pour aller plus loin) | ✅ | [OV-LA] IV, 802–803 (*pectore in adverso*) ; [IL-GR] V, 738–741 (égide sur les épaules) | — |
| 52 | *Percy Jackson et le Voleur de foudre*, Rick Riordan, 2005 : « Aunty Em » tient un magasin de statues de jardin, et ses statues sont ses victimes | ✅ | https://en.wikipedia.org/wiki/The_Lightning_Thief (1<sup>er</sup> juillet 2005) ; https://litcharts.com/lit/the-lightning-thief/chapter-11 (« Aunty Em's Garden Gnome Emporium » ; statues = victimes, fortement suggéré : « make a new statue ») | — |
| 53 | Le nom « Aunty Em » dans l'édition française | ❓ | Aucune source trouvée (recherche sur la VF sans résultat probant) | Écrire « sous le nom d'“Aunty Em” (en VO) », ou vérifier sur un exemplaire de la VF (doute n° 10) |
| 54 | *Le Choc des Titans*, Desmond Davis, 1981 : Méduse animée image par image par Ray Harryhausen | ✅ | https://en.wikipedia.org/wiki/Clash_of_the_Titans_(1981_film) | — (le film de 1981 utilise lui aussi le reflet dans le bouclier) |
| 55 | Remake de 2010 (Louis Leterrier), qui reprend le reflet dans le bouclier | ✅ | https://en.wikipedia.org/wiki/Clash_of_the_Titans_(2010_film) (« using the reflective underside of his shield ») | — |
| 56 | *Hades*, Supergiant Games, 2020 : Dusa, tête de Gorgone volante, femme de ménage au palais d'Hadès | ✅ | https://en.wikipedia.org/wiki/Dusa_(Hades) (« a floating gorgon head… a maid who serves Hades ») ; https://en.wikipedia.org/wiki/Hades_(video_game) (sortie le 17 sept. 2020 ; accès anticipé en 2018) | « flottante » est plus exact que « volante » (détail) |
| 57 | Versace, maison de mode italienne, a la tête de Méduse pour emblème | ✅ | https://en.wikipedia.org/wiki/Versace (« an Italian luxury… company » ; logo « inspired by Medusa ») | — (ne pas ajouter de date d'adoption : non confirmée, doute n° 11) |
| 58 | M. Glennon, « Medusa in Ancient Greek Art », Met, 2017 | ✅ | [MET] (essai daté de mars 2017) | — |

**Décompte : 44 ✅ · 13 ⚠️ · 0 ❌ · 1 ❓** (58 affirmations)

#### Réponses aux 15 doutes de l'auteur
1. **Vers d'Hésiode** : levé. Grées v. 270–273, Gorgones v. 274–283 ([HES-GR]). Voir n° 11.
2. **Citation de la prairie** : fidèle au grec v. 279. Il faut la signaler comme traduction de la rédaction (n° 9).
3. **Κυανοχαίτης = Poséidon** : confirmé par le grec v. 278 et la note de theoi (n° 8).
4. **Origine du reflet** : premier texte conservé chez Ovide (IV, 782–783), puis Apollodore. Dans l'art, Persée détourne la tête ([MET]). Le premier reflet connu est sur un cratère apulien vers 400–385 av. J.-C. (Boston 1970.237), où Athéna montre le reflet de la tête **coupée**. C'est donc un détail tardif dans les textes (n° 19).
5. **Donateurs des objets** : la version d'Apollodore est confirmée (nymphes + Hermès). Variantes trouvées : Hygin, *Astronomiques* 2.12, où Mercure donne sandales et casque et Vulcain une arme en adamant ; Pausanias 3.17.3, où des nymphes donnent bonnet et chaussures (via https://www.theoi.com/Pontios/Gorgones.html). Je n'ai pas consulté le fragment de Phérécyde. Un bloc `<Versions>` dans la fiche « Persée » est pertinent.
6. **Promesse à Polydectès** : levé. Persée propose lui-même la tête au repas de l'éranos, et Polydectès l'exige (n° 13).
7. **Date de *Pyth.* XII** : 494 ou 490 av. J.-C., donc « début du V<sup>e</sup> siècle » est correct (n° 38).
8. **Date du *Bouclier*** : fin VII<sup>e</sup>–milieu VI<sup>e</sup> siècle (n° 45).
9. **Cixous** : 1975 pour l'original, 1976 pour la traduction anglaise (n° 35).
10. **Percy Jackson en VF** : non résolu (n° 53).
11. **Versace** : l'emblème est confirmé, la date ne l'est pas. Ne pas l'ajouter.
12. **Égide chez Homère** : Homère dit « la Gorgone » sans nommer Méduse. La formulation « déjà » est trompeuse (n° 42).
13. **Ovide VI, 119** : vérifié dans le latin, *sensit volucrem crinita colubris / mater equi volucris* : la mère aux cheveux de serpents du cheval ailé a connu Neptune sous la forme d'un **oiseau** (VI, 119–120, [OV-LA]). L'information est utilisable, mais facultative.
14. **Ids et types de relations** : impossible à vérifier, aucun fichier de graphe central dans `/home/claude/editorial/`. La question est renvoyée au directeur.
15. **Ton** : renvoyé au directeur (voir ci-dessous).

---

### Problèmes de forme et de ton
- **Balises `[À VÉRIFIER]` encore présentes** dans le YAML (locus d'Hésiode) et le MDX (Cixous, Pindare, *Bouclier*). Elles sont toutes levées par ce rapport. Il faut les supprimer avant publication.
- **Longueurs** :
  - le bloc `<Version>` d'Ovide fait 65 mots (limite : 60 par paragraphe) ;
  - deux puces de « Le saviez-vous ? » dépassent 35 mots (Pindare 45, « Laide, puis belle » 40). « Son histoire » fait 184 mots en 4 paragraphes : c'est conforme.
- **Logique** : « Mortelle, Méduse est **pourtant** la seule… qu'on puisse tuer » doit devenir « **C'est pourquoi** » ou être supprimé. Cette puce répète aussi « En bref », et ce n'est pas un pouvoir. On peut la remplacer par la poursuite des sœurs (Apollodore) ou par la pétrification attribuée aux trois Gorgones.
- **Couches** : l'accroche (`hook`) mentionne « un monstre de jeu vidéo ». C'est un léger glissement 🎬 hors de la section Culture populaire. C'est acceptable pour une accroche, mais à valider.
- **Couche 🔍** : la phrase de conclusion sur Hésiode (« monstre dès l'origine ») est une interprétation présentée comme un fait (n° 36).
- **Cohérence YAML/MDX** : l'essai du Met figure dans les Sources du MDX mais pas dans `sources` du YAML. Eschyle figure dans les deux mais n'est jamais utilisé dans le texte. Hermès et Chrysaor ne sont pas balisés `<E>` (à vérifier selon l'existence de leurs fiches).
- **Brief** : il demande un lien vers le mythe `perseus-and-medusa` et éventuellement `gorgons`, qui sont absents de « Pour aller plus loin ». Le gabarit limite à 3 portes : arbitrage à faire.
- **Typographie** : les espaces insécables ne sont pas contrôlables dans le texte brut. À vérifier au rendu.
- **Contenus sensibles** : l'épisode d'Ovide est traité de façon factuelle et sobre (« la viole »), sans détail graphique. C'est conforme. Le traitement 🔍 « victime » est bien attribué et nuancé.

---

### Questions pour le directeur éditorial
1. **Pindare, « Méduse aux belles joues »** (*Pyth.* XII, 16, vers 490 av. J.-C.) : faut-il l'ajouter au bloc `<Versions>` ou à la couche 🔍 ? Ce détail montre que la beauté de Méduse n'est **pas** une invention d'Ovide, ce qui renforce l'angle « Tu pensais que… ».
2. **Hésiode, λυγρὰ παθοῦσα** (« qui subit un sort funeste », v. 276) : faut-il citer cette nuance ? Elle est absente de la fiche et utile pour ne pas faire d'Hésiode le simple tenant d'une « Méduse monstre ».
3. **Reflet dans le bouclier** : faut-il ajouter une mention « détail tardif (Ovide, Apollodore) ; dans l'art archaïque, Persée détourne simplement la tête » ? C'est cohérent avec le piège « tardif ≠ ancien ».
4. **Ids et types de relations du YAML** (`partner-of`, `enemy-of`, `part-of`, `ceto`, `graeae`, `aegis`, `chrysaor`, `stheno`, `euryale`) : je n'ai pas accès au graphe central, c'est donc à valider.
5. **Ton** : « Plus inoffensif, tu meurs » (jeu sur la mort dans *Hades*) et le mot « mythographe » glosé. Les deux me semblent conformes au guide (un trait d'humour par section, mot savant expliqué), mais la décision vous revient.
6. **Ovide VI, 119–120** (Neptune sous forme d'oiseau) : faut-il l'ajouter ? C'est une curiosité vérifiée, mais pas indispensable.
