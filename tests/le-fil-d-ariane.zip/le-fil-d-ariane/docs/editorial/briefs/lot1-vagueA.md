# BRIEFS — Lot 1, vague A : les Olympiens les plus cherchés

Type commun : `deity`, category `gods`, era `olympians`, importance 1.
Règle de lot : ces 5 fiches se répondent. Utilise les mêmes ids : `zeus`, `hera`, `poseidon`, `hades`, `athena`, `cronos`, `rhea`, `hestia`, `demeter`, `persephone`, `metis`, `hephaestus`, `ares`, `heracles`, `cyclopes`, `titans`, `mount-olympus`, `underworld`, `thunderbolt`, `trident`, `helm-of-hades`, `aegis`, `titanomachy`.

Pour la culture populaire, n'affirme que ce que tu as vérifié. Œuvres possibles : Percy Jackson (romans et série), *Hercule* de Disney (1997), *Hades* (jeu), God of War, Marvel, Assassin's Creed Odyssey.

---

## ZEUS — `zeus`
**Angle** : le roi des dieux… arrivé au pouvoir par un coup d'État familial.
**Points obligatoires** :
- Naissance : Cronos avale ses enfants, Rhéa le trompe avec une pierre emmaillotée ; Zeus caché en Crète (lieux selon les versions : mont Ida, mont Dicté…).
- Libération des frères et sœurs, la Titanomachie ; la foudre fournie par les Cyclopes (vérifier chez Hésiode).
- Le partage du monde avec Poséidon et Hadès : tirage au sort chez Homère (*Iliade* XV) ; version différente chez Hésiode. **Plusieurs versions** à montrer.
- Domaines : ciel, foudre, justice, hospitalité (xenia), serments. Symboles : foudre, aigle, chêne, égide (l'égide est aussi associée à Athéna : rester nuancé).
- Ses unions sont nombreuses : rester factuel et bref ; certaines sont des enlèvements ou des tromperies → ne pas romantiser.
- Romain : Jupiter. Le saviez-vous possible : les lunes de Jupiter (Io, Europe, Ganymède, Callisto) portent des noms de personnages liés à Zeus.
**Portes** : Cronos, Titanomachie, Héra (ou Poséidon).

## HÉRA — `hera`
**Angle** : bien plus que « l'épouse jalouse » : la reine des dieux, déesse du mariage.
**Points obligatoires** :
- Fille de Cronos et Rhéa ; épouse et sœur de Zeus.
- Domaines : mariage, femmes mariées, naissances (avec sa fille Ilithyie). Symboles : paon (vérifier : l'histoire des yeux d'Argos sur le paon est chez Ovide → romaine), grenade, diadème, vache (épithète homérique « aux yeux de vache », βοῶπις : expliquer que c'est un compliment).
- Héphaïstos : né d'Héra seule chez Hésiode, fils de Zeus et Héra chez Homère → **plusieurs versions**.
- Son hostilité envers Héraclès ; l'étymologie « Héraclès = gloire d'Héra » est discutée : la présenter avec prudence.
- Pop culture : Disney *Hercule* en fait une mère aimante, inversion totale du mythe.
**Portes** : Zeus, Héraclès, Héphaïstos.

## POSÉIDON — `poseidon`
**Angle** : le dieu de la mer… et des tremblements de terre et des chevaux.
**Points obligatoires** :
- Fils de Cronos et Rhéa ; la mer lui revient lors du partage (renvoyer aux versions de la fiche Zeus).
- Épithètes : « Ébranleur de la terre » (Ennosigaios), lien avec les chevaux (Hippios). Trident : forgé par les Cyclopes (vérifier la source, probablement Apollodore).
- La dispute avec Athéna pour l'Attique : source d'eau salée contre olivier (vérifier les sources : Hérodote, Apollodore…).
- Son rôle dans l'*Odyssée* : la colère contre Ulysse après l'aveuglement de Polyphème, son fils.
- Ses enfants notables : Polyphème, Pégase et Chrysaor (renvoyer à la fiche Méduse avec le même traitement sobre), Thésée selon certaines versions.
- Romain : Neptune.
- Pop culture : Percy Jackson est son fils dans les romans (invention moderne).
**Portes** : Zeus, Athéna, Ulysse (ou Polyphème).

## HADÈS — `hades`
**Angle** : « Spoiler : Hadès n'est pas le méchant. »
**Points obligatoires** :
- Fils de Cronos et Rhéa ; reçoit le monde souterrain lors du partage.
- Ce n'est pas un dieu du mal ni de la mort (Thanatos est un autre personnage) : il gouverne les morts, sévère mais juste.
- Le nom d'Hadès sert aussi à désigner le lieu ; on l'appelle aussi Pluton (Ploutôn, « le riche ») : vérifier l'explication (richesses du sous-sol, récoltes).
- Casque (kunée) qui rend invisible, donné par les Cyclopes selon Apollodore (vérifier).
- L'enlèvement de Perséphone (*Hymne homérique à Déméter*), avec Zeus complice ; les graines de grenade. Traitement factuel et sobre.
- Il n'est généralement pas compté parmi les Douze Olympiens : expliquer pourquoi.
- Cerbère, gardien des Enfers.
- Pop culture : méchant chez Disney, roi bougon mais pas maléfique dans *Hades*, et dans Percy Jackson.
**Portes** : Perséphone, Enfers (lieu), Cerbère.

## ATHÉNA — `athena`
**Angle** : née tout armée du crâne de son père. Littéralement.
**Points obligatoires** :
- Métis avalée par Zeus (Hésiode) ; naissance par la tête de Zeus, avec l'aide d'Héphaïstos ou de Prométhée selon les versions → **plusieurs versions**.
- Domaines : sagesse, stratégie et guerre réfléchie (opposée à Arès), artisanat et tissage, protectrice d'Athènes. Symboles : chouette, olivier, égide avec le gorgonéion (cohérence avec la fiche Méduse : chez Homère « la Gorgone » sur l'égide ; chez Apollodore la tête sur son bouclier).
- Vierge (Parthénos) ; le Parthénon ; la statue chryséléphantine de Phidias (vérifier les éléments).
- La dispute avec Poséidon pour l'Attique (mêmes sources que la fiche Poséidon).
- Protectrice des héros : Ulysse, Persée, Héraclès.
- Arachné : histoire racontée chez Ovide, poète romain → le signaler.
- Romain : Minerve.
- Pop culture : Annabeth, fille d'Athéna dans Percy Jackson (invention moderne) ; Assassin's Creed.
**Portes** : Zeus (sa naissance), Méduse (déjà rédigée, id `medusa`), Poséidon (la dispute).
