# BRIEFS — Lot 1, vague B : le reste du Panthéon

Type commun : `deity`, category `gods`, era `olympians`. Importance 1 sauf mention.
Bloc `deity:` obligatoire (format du guide). Ids communs déjà connus : `zeus`, `hera`, `poseidon`, `hades`, `athena`, `hermes`, `hestia`, `demeter`, `persephone`, `hephaestus`, `ares`, `aphrodite`, `apollo`, `artemis`, `dionysus`, `leto`, `cronos`, `rhea`, `uranus`, `metis`, `heracles`, `perseus`, `medusa`, `cerberus`, `thanatos`, `mount-olympus`, `underworld`, `delphi`.
Lecture conseillée avant d'écrire : la fiche de référence /home/claude/editorial/drafts/meduse.v2.md.

Règles transversales de la vague :
- Les « Douze » varient selon les sources (Hestia ou Dionysos) : ne pas l'affirmer comme une liste fixe.
- Nombreuses unions et enlèvements : factuel, sobre, jamais romantisé ; jamais `lover-of` pour une union non consentie.
- Noms romains signalés (Cérès, Vesta, Mars, Vénus, Apollon, Diane, Mercure, Vulcain, Bacchus/Liber) sans confondre les mythes.

---

## DÉMÉTER — `demeter`
**Angle** : la déesse qui a mis le monde en pause pour retrouver sa fille.
- Fille de Cronos et Rhéa ; mère de Perséphone (avec Zeus).
- L'enlèvement de Perséphone vu du côté de la mère (*Hymne homérique à Déméter*) : la recherche, Éleusis, la famine menacée, le compromis. Cohérence avec la fiche Hadès.
- Les Mystères d'Éleusis (ce qu'on en sait, et ce qu'on ignore, car ils étaient secrets).
- Symboles : épi de blé, torches. Romain : Cérès (→ « céréales », à vérifier).
**Portes** : Perséphone, Hadès, Éleusis (lieu, annoncé).

## PERSÉPHONE — `persephone` (importance 1)
**Angle** : reine des Enfers, pas seulement « la fille enlevée ».
- Fille de Zeus et Déméter ; appelée aussi Korè (« la jeune fille »).
- Enlèvement, grenade, partage de l'année : renvoyer aux versions déjà vérifiées dans la fiche Hadès (rester cohérent).
- Son rôle de reine des Enfers dans les textes (Odyssée XI, Orphée et Eurydice, etc. — vérifier chaque mention).
- Pop culture : *Lore Olympus* (webtoon), *Hades* (jeu) — vérifier.
**Portes** : Déméter, Hadès, Orphée (annoncé).

## HESTIA — `hestia` (importance 2)
**Angle** : la déesse la plus discrète… et la plus honorée au quotidien.
- Aînée des enfants de Cronos et Rhéa : première avalée, dernière recrachée (Hymne homérique à Aphrodite, vérifier).
- Le foyer, la flamme ; refuse Poséidon et Apollon, reste vierge (vérifier la source).
- Elle cède sa place à Dionysos parmi les Douze : tradition MODERNE souvent répétée, sans source antique claire → à vérifier et, si non attestée, le dire.
- Romain : Vesta, les Vestales.
**Portes** : Zeus, Dionysos, Rhéa.

## ARÈS — `ares`
**Angle** : le dieu de la guerre… que même son père ne supporte pas.
- Fils de Zeus et Héra. Zeus le dit « le plus odieux » des dieux (*Iliade* V, vérifier les vers).
- Blessé par Diomède avec l'aide d'Athéna (*Iliade* V) ; contraste Arès (violence) / Athéna (stratégie).
- L'épisode du filet d'Héphaïstos avec Aphrodite (*Odyssée* VIII) — traitement léger mais sans détail graphique.
- Enfants : Phobos et Deimos → lunes de Mars (lien vers le « Le saviez-vous ? »). Romain : Mars, très différent (père de Romulus) : le signaler.
**Portes** : Athéna, Aphrodite, Héphaïstos.

## APHRODITE — `aphrodite`
**Angle** : deux naissances pour une seule déesse.
- **Plusieurs versions** : née de l'écume autour du sexe tranché d'Ouranos (Hésiode) / fille de Zeus et Dioné (Homère). Rester factuel et sobre sur la castration (fait du récit, pas de détail).
- Épouse d'Héphaïstos ; Arès ; Éros (filiation variable selon les sources).
- Le jugement de Pâris et la guerre de Troie (sources : Chants cypriens résumés par Proclos, Euripide… vérifier).
- Romain : Vénus ; la *Naissance de Vénus* de Botticelli (Renaissance, culture).
**Portes** : Héphaïstos, Arès, Ouranos (annoncé).

## APOLLON — `apollo`
**Angle** : le dieu à tout faire (lumière, musique, oracles, flèches… et épidémies).
- Fils de Zeus et Létô, jumeau d'Artémis ; naissance à Délos (Hymne homérique à Apollon).
- Delphes : Python, la Pythie, « Connais-toi toi-même » (inscription : vérifier la source antique, Pausanias / Platon).
- La peste au début de l'*Iliade* (chant I).
- Daphné : récit surtout connu par Ovide (romain) → le signaler.
- Assimilation tardive avec Hélios : à nuancer.
**Portes** : Artémis, Delphes (annoncé), Daphné (mythe annoncé).

## ARTÉMIS — `artemis`
**Angle** : chasseresse, protectrice… et redoutable.
- Fille de Zeus et Létô, jumelle d'Apollon. Arc, biche, forêts ; protectrice des jeunes filles et des accouchements.
- Actéon (versions : Callimaque, Ovide…), Niobé (*Iliade* XXIV), Iphigénie (versions selon les tragiques).
- Romain : Diane. Pop : Percy Jackson (les Chasseresses) — vérifier.
**Portes** : Apollon, Létô (annoncé), Actéon (annoncé).

## HERMÈS — `hermes`
**Angle** : bébé, il vole déjà le troupeau d'Apollon.
- Fils de Zeus et Maïa ; l'*Hymne homérique à Hermès* : vol des bœufs, invention de la lyre avec une carapace de tortue.
- Messager, guide des âmes (psychopompe), dieu des voyageurs, des marchands… et des voleurs.
- Attributs : pétase, sandales ailées, caducée (kérykeion). Le caducée de la médecine moderne est souvent confondu avec le bâton d'Asclépios : bon « Le saviez-vous ? » à vérifier.
- Aide de Persée (cohérence avec la fiche Méduse) ; d'Ulysse (moly, *Odyssée* X).
- Romain : Mercure. Pop : Percy Jackson (Luke, fils d'Hermès — invention moderne).
**Portes** : Apollon, Persée, Ulysse (annoncé).

## HÉPHAÏSTOS — `hephaestus`
**Angle** : le dieu boiteux qui forge les armes des dieux.
- **Plusieurs versions** de sa naissance (déjà vérifiées dans la fiche Héra : rester cohérent).
- Jeté de l'Olympe (deux versions dans l'*Iliade* : par Héra, chant XVIII ; par Zeus, chant I) → **Versions**.
- Forge (Lemnos, et sous l'Etna selon des traditions plus tardives), automates, le bouclier d'Achille (*Iliade* XVIII).
- Pandore façonnée par lui (Hésiode). Épouse : Aphrodite (Odyssée) / Charis ou Aglaé (Iliade, Hésiode) → **Versions**.
- Romain : Vulcain (→ « volcan », à vérifier).
**Portes** : Héra, Aphrodite, Achille (annoncé).

## DIONYSOS — `dionysus`
**Angle** : né deux fois, et pas qu'une fois l'invité qui dérange.
- Fils de Zeus et de la mortelle Sémélé ; Sémélé foudroyée, Dionysos cousu dans la cuisse de Zeus (sources à vérifier : Euripide, *Bacchantes* ; Apollodore).
- Vin, théâtre (Dionysies d'Athènes), transe, ménades ; les *Bacchantes* d'Euripide (Penthée) — sobre.
- Les pirates changés en dauphins (Hymne homérique 7).
- Tradition orphique (Zagreus) → renvoyer, sans approfondir.
- Romain : Bacchus / Liber.
**Portes** : Zeus, Héra (sa persécution), Ariane (annoncée — clin d'œil au nom du site, vérifier les versions : Dionysos l'épouse à Naxos).
