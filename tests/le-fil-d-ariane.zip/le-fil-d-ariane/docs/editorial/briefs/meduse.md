# BRIEF — Fiche « Méduse » (pilote)

**Type** : créature (`creature`, kind: monster, danger 3) · **Importance** : 1 · **Id** : `medusa`

## Angle éditorial
Méduse est la porte d'entrée idéale : tout le monde la connaît, presque personne ne connaît son histoire. L'objectif est l'effet « Tu pensais que Méduse était juste un monstre ? ».

## Points obligatoires
- Les **Gorgones** (Sthéno, Euryale, Méduse) ; Méduse seule mortelle (vérifier chez Hésiode).
- Les **deux grandes traditions** sur son origine : Méduse née monstre (Hésiode) vs jeune femme transformée (Ovide, *Métamorphoses*, poète romain). Traiter l'épisode du temple d'Athéna avec la charte « contenus sensibles » : factuel, sobre.
- La **mort par Persée** : aide divine (Athéna, Hermès), objets reçus (vérifier lesquels et selon quelles sources), le reflet sur le bouclier (vérifier l'origine de ce détail), le roi Polydectès.
- Ce qui **naît de son sang/cou** : Pégase et Chrysaor (vérifier la version d'Hésiode).
- Ce que devient la **tête** : utilisée par Persée, puis sur l'égide d'Athéna (vérifier).
- Le **gorgonéion** comme motif protecteur dans l'art grec (interprétation/usage, à sourcer).

## Culture populaire (🎬, section dédiée uniquement)
Percy Jackson (Méduse tient une boutique de statues de jardin — tome 1), Hades (jeu), Clash of the Titans, usage comme logo d'une maison de mode (mentionner sans logo). Courtes mentions, pas d'erreur de fait sur les œuvres.

## Liens à créer (prochaines portes)
`perseus`, `athena`, `poseidon`, `pegasus`, `gorgons` (si utile), mythe `perseus-and-medusa`.

## Pièges connus
- Ne pas présenter la version d'Ovide comme « la vraie histoire ».
- Ne pas affirmer que Méduse « a toujours été une victime » : c'est une interprétation moderne (🔍).
- Vérifier si Hésiode mentionne Poséidon en lien avec Méduse (il y a quelque chose sur une union « dans une prairie » — à vérifier précisément).
