# DÉCISIONS ÉDITORIALES COMMUNES — Lot 1 (Olympiens)

Ces règles s'appliquent à TOUTES les fiches du lot. En cas de conflit avec un brief, elles l'emportent.

## D1. Rang de naissance de Zeus
- Hésiode : Zeus est le **dernier-né** des enfants de Cronos et Rhéa.
- Homère : Zeus est **né avant Poséidon** (*Iliade* XIII, 355 ; XV, 166). Homère ne dit rien de son rang par rapport à Hadès.
- Formule commune : « Chez Hésiode, Zeus est le petit dernier ; chez Homère, il est l'aîné de Poséidon. » Jamais « l'aîné des frères » sans précision.

## D2. Libération des enfants avalés
- Hésiode : Cronos les recrache, vaincu par la **ruse de Gaïa** (et la force de Zeus).
- Apollodore : **drogue (vomitif) donnée par Métis**.
- Formule commune : « Cronos est forcé de les recracher (par une ruse de Gaïa chez Hésiode, par une drogue de Métis chez Apollodore). »

## D3. Les dons des Cyclopes
- Foudre de Zeus : **fabriquée** par les Cyclopes (Hésiode, *Théogonie*, v. 139–141 et 501–505).
- Trident de Poséidon et casque d'Hadès : **donnés** par les Cyclopes chez Apollodore (I, 2, 1). Ne jamais écrire « forgés ».
- Callimaque (*Hymne à Délos*, v. 30–31) attribue la fabrication du trident aux **Telchines** : peut figurer dans un bloc `<Versions>` ou un « Le saviez-vous ? ».

## D4. L'égide
- `zeus owns aegis` : **canonical** (Homère appelle Zeus « porte-égide », αἰγίοχος).
- `athena owns aegis` : **canonical** aussi (Homère la lui fait porter).
- Note commune : « L'égide appartient à Zeus, qui la prête à Athéna ; c'est elle qu'on voit le plus souvent la porter. » Gorgone : voir la fiche Méduse (Homère : « la Gorgone » ; Apollodore : tête au milieu du bouclier).

## D5. Méduse, Poséidon, Pégase et Chrysaor
- Les relations Méduse/Poséidon → Pégase/Chrysaor vivent **uniquement dans la fiche Méduse**.
- Les autres fiches mentionnent Méduse sobrement, avec `<E id="medusa">Méduse</E>`.
- Références communes : **Apollodore, *Bibliothèque*, II, 4, 2–3** ; **Hésiode, *Théogonie*, v. 278–281**.

## D6. Unions de Zeus et des autres dieux
- Ids validés (entités annoncées) : `europa`, `callisto`, `io`, `danae`, `leda`, `ganymede`, `semele`, `maia`, `leto`, `dione`.
- Union non consentie ou obtenue par ruse : pas de `lover-of` ; seule la **filiation** (`parent-of`) est déclarée.
- Rédaction : factuelle (« Zeus, changé en taureau, enlève Europe »), jamais romantisée.

## D7. Événements (Titanomachie, guerre de Troie…)
- Pas de type de relation « participe à » : on lie l'événement dans le texte avec `<E id="titanomachy">`. Le graphe des événements viendra avec les fiches de mythes.

## D8. Sources secondaires savantes
- Une thèse moderne (ex. Burkert) attestée seulement par des sources secondaires fiables est acceptée **au conditionnel et attribuée** (« selon l'historien Walter Burkert… »), avec la mention « cité d'après » dans les sources.

## D9. Ton
- **Tutoiement obligatoire** quand le texte s'adresse au lecteur (accroche, transitions, « Le saviez-vous ? »).

## D10. Dates
- Homère : « fin du VIIIe – début du VIIe siècle av. J.-C. » ; Hésiode : « vers 700 av. J.-C. ».

## D11. Athéna et Poséidon
- Ils se disputent l'Attique, mais sont du même camp à Troie (*Iliade* XX, 33–34 ; XXI, 284–286).
- Une seule relation `enemy-of` en **variant**, portée par la fiche Poséidon. La fiche Athéna n'en déclare pas (le build fusionne le graphe).
- Formule : « rivaux pour l'Attique », jamais « ennemis » tout court.

## D12. Sections hors gabarit
- Pas de nouvelle section `##` dans une fiche d'entité : un épisode important va dans « Son histoire » ; une curiosité dans « Le saviez-vous ? ». Les épisodes longs (Arachné, Parthénon…) auront leur propre page de mythe ou de lieu plus tard.

## D13. Accroches
- Une accroche peut s'appuyer sur la version la plus spectaculaire si le texte la signale comme une version (« selon certains récits ») et si le bloc `<Versions>` suit.

## D14. Noms romains
- `names.roman` contient la **forme française usuelle** : Jupiter, Junon, Neptune, Pluton, Minerve, Mars, Vénus, Apollon, Diane, Mercure, Vulcain, Cérès, Vesta, Bacchus. La forme latine (Iuno, Neptunus…) peut apparaître dans le texte si elle est utile.

## D15. Unions de Zeus : vocabulaire
- Dire ce que dit la source, sans euphémisme ni surenchère : « séduit » (Apollodore), « force » (Ovide), « enlève » (Europe). Jamais « les femmes que Zeus approche ».
- Quand les sources divergent sur le consentement ou la métamorphose (ex. Io : Héra la change en vache chez Eschyle, Zeus chez d'autres), le signaler.
