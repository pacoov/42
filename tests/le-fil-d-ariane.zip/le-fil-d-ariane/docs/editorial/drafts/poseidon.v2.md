# Livrable rédacteur — Fiche « Poséidon » (lot 1, vague A) — v2

### YAML

```yaml
id: poseidon
type: deity
category: gods
names:
  greek: Ποσειδῶν
  transliteration: Poseidôn
  roman: Neptunus
  aliases: [Poséidon, Poseidon, Neptune, Ennosigaios, Ébranleur de la terre, Hippios]
era: olympians
importance: 1
deity:
  domains: [sea, earthquakes, horses]
  symbols: [trident, horse, bull]        # bull : taureaux noirs sacrifiés à Pylos (Odyssée, III, 5–6)
  olympian: true
  residence: aigai                       # palais d'or au fond de la mer (Iliade, XIII, 21–22 ; Odyssée, V, 381)
  epithets:
    - { greek: Ἐννοσίγαιος, transliteration: Ennosigaios, source: "Hésiode, Théogonie, v. 456 ; Homère, Iliade, XV, 184 ; Hymne homérique 22, v. 4" }
    - { greek: ἐνοσίχθων, transliteration: Enosichthôn, source: "Homère, Iliade, XX, 63 ; Odyssée, I, 74" }
    - { greek: γαιήοχος, transliteration: Gaiêochos, source: "Homère, Odyssée, I, 68 ; Hymne homérique 22, v. 6" }
    - { greek: κυανοχαίτης, transliteration: Kyanochaitês, source: "Hésiode, Théogonie, v. 278 ; Homère, Odyssée, IX, 528" }
    - { greek: Ἵππιος, transliteration: Hippios, source: "Pausanias, I, 30, 4 ; VIII, 25, 7" }
relations:                 # sens : from → to
  - { from: cronos, to: poseidon, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–456 ; Homère, Iliade, XV, 187 ; Apollodore, Bibliothèque, I, 1, 5" }
  - { from: rhea, to: poseidon, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–456 ; Homère, Iliade, XV, 187" }
  - { from: poseidon, to: zeus, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–457 ; Homère, Iliade, XV, 187–188" }
  - { from: poseidon, to: hades, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–456 ; Homère, Iliade, XV, 187–188" }
  - { from: poseidon, to: hera, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–456 ; Apollodore, Bibliothèque, I, 1, 5" }
  - { from: poseidon, to: hestia, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–456 ; Apollodore, Bibliothèque, I, 1, 5" }
  - { from: poseidon, to: demeter, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–456 ; Apollodore, Bibliothèque, I, 1, 5" }
  - { from: cyclopes, to: poseidon, type: helped, certainty: canonical, source: "Apollodore, Bibliothèque, I, 2, 1 (lui donnent le trident ; D3)" }
  - { from: poseidon, to: trident, type: owns, certainty: canonical, source: "Homère, Odyssée, V, 292 ; Apollodore, Bibliothèque, I, 2, 1" }
  - { from: poseidon, to: aigai, type: lives-in, certainty: canonical, source: "Homère, Iliade, XIII, 21–22 ; Odyssée, V, 381" }
  - { from: poseidon, to: amphitrite, type: spouse-of, certainty: canonical, source: "Hésiode, Théogonie, v. 930–933 ; Apollodore, Bibliothèque, I, 4, 5" }
  - { from: poseidon, to: triton, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 930–933 ; Apollodore, Bibliothèque, I, 4, 5" }
  - { from: amphitrite, to: triton, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 930–933" }
  - { from: poseidon, to: polyphemus, type: parent-of, certainty: canonical, source: "Homère, Odyssée, I, 68–73 ; IX, 528–529" }
  - { from: thoosa, to: polyphemus, type: parent-of, certainty: canonical, source: "Homère, Odyssée, I, 71–73" }
  - { from: poseidon, to: pegasus, type: parent-of, certainty: canonical, source: "Apollodore, Bibliothèque, II, 4, 2–3 ; Hésiode, Théogonie, v. 278–281" }   # doublon de la fiche Méduse (D5), fusionné au build
  - { from: poseidon, to: theseus, type: parent-of, certainty: variant, source: "Bacchylide, Dithyrambe 17, v. 33–36 et 58–60 ; Apollodore, Bibliothèque, III, 15, 7 (double paternité avec Égée) ; Pausanias, I, 17, 3" }
  - { from: odysseus, to: polyphemus, type: defeated, certainty: canonical, source: "Homère, Odyssée, I, 69 ; IX, 528–536" }
  - { from: poseidon, to: odysseus, type: enemy-of, certainty: canonical, source: "Homère, Odyssée, I, 19–21 et 68–75 ; V, 282–294 et 366–381" }
  - { from: poseidon, to: athena, type: enemy-of, certainty: variant, source: "Hérodote, Histoires, VIII, 55 ; Apollodore, Bibliothèque, III, 14, 1 (rivalité ponctuelle pour l'Attique)" }
  - { from: poseidon, to: peleus, type: helped, certainty: canonical, source: "Homère, Iliade, XXIII, 277–278 ; Apollodore, Bibliothèque, III, 13, 5 (chevaux immortels Balios et Xanthos)" }
# Non exprimable avec les types autorisés, consigné ici :
#   - Partage du monde : tirage au sort chez Homère (Iliade, XV, 187–193) et Apollodore (I, 2, 1) ;
#     chez Hésiode (Théogonie, v. 881–885), Zeus, proclamé roi, répartit les honneurs → fiche `zeus`.
#   - Trident (D3) : « donné » par les Cyclopes chez Apollodore (I, 2, 1) ; fabriqué par les Telchines
#     chez Callimaque (Hymne IV, À Délos, v. 30–31). Pas de relation `created` proposée.
#   - Pégase et Chrysaor par Méduse : relations portées par la fiche `medusa` (D5).
#   - Rivalités territoriales hors Attique (Pausanias) : avec Héra pour l'Argolide (II, 15, 5 ; II, 22, 4),
#     avec Hélios pour Corinthe (II, 1, 6) ; non traitées dans le MDX.
sources:
  - { source: "Hésiode, Théogonie", locus: "v. 278–281, 453–467, 478, 494–497, 881–885, 930–933", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml" }
  - { source: "Homère, Iliade", locus: "XIII, 17–22, 355 ; XV, 166, 184–193 ; XX, 56–66 ; XXIII, 277–278", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml" }
  - { source: "Homère, Odyssée", locus: "I, 19–21, 68–75 ; III, 5–6 ; V, 282–294, 366–381 ; IX, 528–536 ; XIII, 159–164", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg002/tlg0012.tlg002.perseus-grc2.xml" }
  - { source: "Hymne homérique 22, À Poséidon", locus: "v. 1–7", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg022/tlg0013.tlg022.perseus-grc2.xml" }
  - { source: "Bacchylide, Dithyrambe 17 (Les Jeunes gens, ou Thésée)", locus: "v. 33–36, 58–60", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0199/tlg002/tlg0199.tlg002.perseus-grc2.xml" }
  - { source: "Hérodote, Histoires", locus: "VIII, 55", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0016/tlg001/tlg0016.tlg001.perseus-grc2.xml" }
  - { source: "Sophocle, Œdipe à Colone", locus: "v. 707–716", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0011/tlg007/tlg0011.tlg007.perseus-grc2.xml" }
  - { source: "Callimaque, Hymne IV, À Délos (trad. Mair)", locus: "v. 30–31", url: "https://topostext.org/work/123" }
  - { source: "(Pseudo-)Apollodore, Bibliothèque", locus: "I, 1, 5–7 ; I, 2, 1 ; I, 4, 5 ; II, 4, 2–3 ; III, 13, 5 ; III, 14, 1 ; III, 15, 7", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-grc2.xml" }
  - { source: "Pausanias, Description de la Grèce", locus: "I, 17, 3 ; I, 24, 5 ; I, 26, 5 ; I, 30, 4 ; VIII, 8, 2 ; VIII, 25, 7", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0525/tlg001/tlg0525.tlg001.perseus-eng2.xml" }
  - { source: "Ovide, Métamorphoses (poète romain)", locus: "VI, 70–82", url: "https://www.thelatinlibrary.com/ovid/ovid.met6.shtml" }
  - { source: "Augustin, La Cité de Dieu, citant Varron (auteurs latins)", locus: "XVIII, 9", url: "https://www.thelatinlibrary.com/augustine/civ18.shtml" }
review: { status: draft }
```

### MDX

```mdx
---
name: Poséidon
role: Le dieu de la mer, des séismes et des chevaux
hook: Quand il marche, les montagnes tremblent. Vexe-le, et tu rentres chez toi avec des années de retard : demande à Ulysse.
---

## En bref

- **Famille :** fils de <E id="cronos">Cronos</E> et <E id="rhea">Rhéa</E> ; frère de <E id="zeus">Zeus</E>, d'<E id="hades">Hadès</E>, d'<E id="hera">Héra</E>, d'<E id="hestia">Hestia</E> et de <E id="demeter">Déméter</E> ; époux d'<E id="amphitrite">Amphitrite</E>
- **Domaines :** la mer, les tremblements de terre, les chevaux
- **Surnoms :** Ennosigaios et Enosichthôn (« l'Ébranleur de la terre »), Gaiêochos (« qui tient la terre », sens discuté), Kyanochaitês (« aux cheveux sombres »), Hippios (« le dieu des chevaux »)
- **Symboles :** le <E id="trident">trident</E>, donné par les <E id="cyclopes">Cyclopes</E> selon Apollodore ; le cheval ; le taureau, qu'on lui sacrifie
- **Lieu :** un palais d'or au fond de la mer, à Aigai
- **Enfants célèbres :** <E id="triton">Triton</E>, <E id="polyphemus">Polyphème</E>, <E id="pegasus">Pégase</E> et <E id="chrysaor">Chrysaor</E>, nés de <E id="medusa">Méduse</E>, et, selon certaines versions, <E id="theseus">Thésée</E>
- **Chez les Romains :** Neptune

## Son histoire

Mauvais départ dans la vie : à peine né, Poséidon est avalé par son père. <E id="cronos">Cronos</E> craint d'être renversé par un de ses enfants, alors il les engloutit tous. Seul <E id="zeus">Zeus</E> y échappe. Plus tard, Cronos est forcé de recracher toute la fratrie (par une ruse de Gaïa chez Hésiode, par une drogue de <E id="metis">Métis</E> chez Apollodore).

Chez Hésiode, Zeus est le petit dernier ; chez Homère, il est l'aîné de Poséidon. Après la guerre contre les <E id="titans">Titans</E>, on partage le monde. Dans l'*Iliade*, c'est un tirage au sort : « Le sort m'a donné la mer grise, pour l'habiter à jamais » (XV, 190–191, trad. de la rédaction). Chez Hésiode, Zeus devenu roi distribue les honneurs.

Et la mer, tu vas voir, n'est qu'un début. Les poètes l'appellent Ennosigaios, « l'Ébranleur de la terre » : les séismes, c'est lui. On l'honore aussi comme Hippios, le dieu des chevaux. Chez Sophocle, il a établi le mors, la pièce qui guide le cheval, sur les routes de Colone, près d'Athènes.

Dans l'*Odyssée*, c'est le pire ennemi d'<E id="odysseus">Ulysse</E>. Le héros a aveuglé le Cyclope <E id="polyphemus">Polyphème</E>, fils de Poséidon et de la nymphe Thoosa. Le Cyclope prie son père : qu'Ulysse rentre tard, seul et dans le malheur. Poséidon ne le tue pas, il le fait errer. Et quand Ulysse croit enfin s'en sortir, il brise son radeau d'une vague géante.

## Ses pouvoirs

- Il ébranle la terre : dans l'*Iliade* (XX, 57–60), il secoue le sol immense et les sommets des montagnes.
- Il déchaîne la mer : trident en main, il rassemble les nuages et lève tous les vents contre Ulysse (*Odyssée*, V, 291–294).
- Il pétrifie : il change en rocher le navire des Phéaciens qui a ramené Ulysse chez lui (*Odyssée*, XIII, 159–164).
- Il règne sur les chevaux : l'*Hymne homérique à Poséidon* le dit « dompteur de chevaux et sauveur des navires » (v. 5, trad. de la rédaction).
- Il fait des cadeaux de dieu : il offre deux chevaux immortels à Pélée, père d'Achille (*Iliade*, XXIII, 277–278) ; Apollodore les nomme Balios et Xanthos.

<Versions title="Athènes : qui a gagné, et comment ?">
  <Version layer="ancient" source="Hérodote, Histoires, VIII, 55 (vers 430 av. J.-C.)">L'historien grec Hérodote rapporte une tradition athénienne : Poséidon et <E id="athena">Athéna</E> se sont disputé le pays. Sur l'Acropole, dans le temple d'Érechthée, un olivier et une « mer » — de l'eau salée — en sont les témoins. Il ne raconte ni le jugement ni le vainqueur.</Version>
  <Version layer="ancient" source="Apollodore, Bibliothèque, III, 14, 1 (Ier–IIe s. apr. J.-C.)">Poséidon arrive le premier : d'un coup de trident sur l'Acropole, il fait jaillir une « mer ». Athéna plante ensuite un olivier, devant le roi Cécrops. Les douze dieux jugent : le pays revient à Athéna, qui a planté la première. Furieux, Poséidon inonde la plaine de Thria et submerge l'Attique.</Version>
  <Version layer="ancient" source="Augustin, La Cité de Dieu, XVIII, 9, citant Varron (auteurs latins)">Chez l'érudit romain Varron (Ier s. av. J.-C.), un olivier et une source surgissent. Les citoyens votent : les hommes pour Neptune, les femmes pour Minerve, qui gagne d'une voix. Neptune inonde le pays. Les femmes sont punies : plus de droit de vote, plus d'enfants portant le nom de leur mère, plus de titre d'« Athéniennes ».</Version>
  <Version layer="ancient" source="Ovide, Métamorphoses, VI, 70–82 (poète romain, vers 8 apr. J.-C.)">Chez le poète romain Ovide, Minerve tisse elle-même la scène lors de son concours contre Arachné. Douze dieux siègent autour de Jupiter. Le dieu de la mer fait jaillir de l'eau de mer du rocher ; Minerve fait pousser un olivier. La Victoire couronne son œuvre.</Version>
  <Version layer="ancient" source="Pausanias, Description de la Grèce, I, 24, 5 et I, 26, 5 (IIe s. apr. J.-C.)">Le voyageur grec Pausanias visite l'Acropole. Dans l'Érechthéion, on lui montre un puits d'eau de mer et la marque d'un trident sur la roche. Selon la légende, ce sont les preuves de la revendication de Poséidon. Le fronton arrière du Parthénon représente la dispute.</Version>
</Versions>

## Le saviez-vous ?

- **Le coup du poulain.** Tu connais la pierre avalée à la place de Zeus ? Selon une légende arcadienne (Pausanias, VIII, 8, 2), Rhéa cache Poséidon parmi des agneaux et fait avaler un poulain à Cronos.
- **Hadès en sursaute.** Imagine la scène (*Iliade*, XX, 61–65) : Poséidon secoue si fort la terre qu'Hadès bondit de son trône en criant, de peur que son royaume s'ouvre.
- **Qui a fait le trident ?** Tu as sans doute lu « forgé par les Cyclopes ». Chez Apollodore, ils le lui donnent seulement. Chez Callimaque (IIIe s. av. J.-C.), ce sont les Telchines, artisans légendaires du métal, qui le fabriquent.

## Dans la culture populaire

- **Percy Jackson** (Rick Riordan, romans depuis 2005 ; série Disney+ depuis 2023) : le héros est un demi-dieu, fils de Poséidon et d'une mortelle. Une invention moderne.
- **God of War III** (Sony, PlayStation 3, 2010) : Kratos tue Poséidon dès le début du jeu, et les océans submergent la Grèce.
- **Hades** (Supergiant Games, 2020) : Poséidon offre au héros, Zagreus, des « bienfaits » qui repoussent les ennemis par des vagues.

## Pour aller plus loin

- <E id="zeus">Zeus</E> — Le frère devenu roi : le partage du monde vu de son côté.
- <E id="athena">Athéna</E> — La nièce qui lui a soufflé Athènes avec un simple olivier.
- <E id="odysseus">Ulysse</E> — Le héros qui a mis le dieu de la mer en colère pour des années.

## Sources

- Homère, *Iliade* (fin du VIIIe – début du VIIe siècle av. J.-C.) : XIII, 17–22 et 355 ; XV, 166 et 184–193 ; XX, 56–66 ; XXIII, 277–278
- Homère, *Odyssée* (fin du VIIIe – début du VIIe siècle av. J.-C.) : I, 19–21 et 68–75 ; III, 5–6 ; V, 282–294 et 366–381 ; IX, 528–536 ; XIII, 159–164
- Hésiode, *Théogonie*, v. 278–281, 453–467, 478, 494–497, 881–885, 930–933 (vers 700 av. J.-C.)
- *Hymne homérique 22, À Poséidon*, v. 1–7 (date incertaine)
- Bacchylide, *Dithyrambe* 17, v. 33–36 et 58–60 (Ve siècle av. J.-C.)
- Hérodote, *Histoires*, VIII, 55 (vers 430 av. J.-C.)
- Sophocle, *Œdipe à Colone*, v. 707–716 (fin du Ve siècle av. J.-C.)
- Callimaque, *Hymne à Délos*, v. 30–31 (IIIe siècle av. J.-C.)
- (Pseudo-)Apollodore, *Bibliothèque*, I, 1, 5 – I, 2, 1 ; I, 4, 5 ; II, 4, 2–3 ; III, 13, 5 ; III, 14, 1 ; III, 15, 7 (Ier–IIe siècle apr. J.-C.)
- Pausanias, *Description de la Grèce*, I, 17, 3 ; I, 24, 5 ; I, 26, 5 ; I, 30, 4 ; VIII, 8, 2 ; VIII, 25, 7 (IIe siècle apr. J.-C.)
- Ovide, *Métamorphoses*, VI, 70–82 (poète romain, vers 8 apr. J.-C.)
- Augustin, *La Cité de Dieu*, XVIII, 9, citant Varron (auteurs latins, Ve et Ier siècles)
```

### Sources consultées

Vérifications v1 (toujours valables) :
- https://www.theoi.com/Olympios/Poseidon.html — point de départ (filiation, épithètes, loci, légende du poulain).
- https://www.theoi.com/Text/Apollodorus1.html — Bibliothèque I, 1, 5–7 ; I, 2, 1 ; I, 4, 5.
- https://www.theoi.com/Text/Apollodorus3.html — III, 13, 5 ; III, 14, 1.
- https://www.theoi.com/Text/HomerIliad15.html, https://www.theoi.com/Text/HomerOdyssey1.html, https://www.theoi.com/Text/HomerOdyssey9.html — traductions Murray (partage, colère de Poséidon, prière de Polyphème).
- https://www.theoi.com/Text/Pausanias2A.html — Pausanias II, 1, 6.
- Textes TEI numérotés du dépôt PerseusDL (raw.githubusercontent.com/PerseusDL/canonical-greekLit), lus vers par vers : Iliade (tlg0012.tlg001), Odyssée (tlg0012.tlg002), Théogonie (tlg0020.tlg001), Hymne homérique 22 (tlg0013.tlg022), Hérodote (tlg0016.tlg001), Sophocle *OC* (tlg0011.tlg007, grec et trad.), Apollodore (tlg0548.tlg001), Bacchylide (tlg0199.tlg002), Pausanias (tlg0525.tlg001, grec et trad. Jones).
- https://www.thelatinlibrary.com/ovid/ovid.met6.shtml — Ovide, Mét. VI, 70–82.
- https://www.thelatinlibrary.com/augustine/civ18.shtml — Augustin, XVIII, 9 (vote, Minerve gagne d'une voix, triple punition des femmes : « ut nulla ulterius ferrent suffragia, ut nullus nascentium maternum nomen acciperet, ut ne quis eas Athenaeas uocaret »).
- https://en.wikipedia.org/wiki/Poseidon, https://www.britannica.com/topic/Poseidon — points de départ.
- https://en.wikipedia.org/wiki/Percy_Jackson_(character), https://en.wikipedia.org/wiki/God_of_War_III, https://en.wikipedia.org/wiki/Hades_(video_game) — culture populaire.

Nouvelles vérifications v2 (PerseusDL, extraction par script) :
- Iliade XIII, 354–356 (Ζεὺς πρότερος γεγόνει) et XV, 165–167 (γενεῇ πρότερος) — D1 ; Iliade XXIII, 276–279 (ἀθάνατοί τε γάρ εἰσι, Ποσειδάων δὲ πόρʼ αὐτοὺς πατρὶ ἐμῷ Πηλῆϊ) — chevaux de Pélée.
- Théogonie v. 477–479 (ὁπλότατον παίδων, Zeus le plus jeune) — D1 ; v. 492–497 (Γαίης ἐννεσίῃσι … δολωθείς) — D2.
- Odyssée V, 366–372 : la vague de Poséidon disperse les poutres du radeau (une seule tempête de Poséidon, V, 282–381).
- Apollodore I, 2, 1 (grec) : Métis donne à Cronos un φάρμακον — D2.
- https://topostext.org/work/123 — Callimaque, Hymne à Délos, § 30 (trad. Mair) : « the mighty god smote the mountains with the three-forked sword which the Telchines fashioned for him ».
- https://en.wikipedia.org/wiki/Telchines — Telchines, métallurgistes légendaires ; trident de Poséidon, renvoi à Callimaque, Hymne 4, v. 28 et suiv.
- Essai infructueux : les Hymnes de Callimaque ne figurent pas dans le dépôt PerseusDL (tlg0533.tlg003 et tlg004 ne contiennent que les épigrammes).

### Doutes

1. **Callimaque et les Telchines** : la traduction Mair (ToposText, § 30) parle du « grand dieu » sans nommer Poséidon. Je n'ai pas pu lire le grec. L'identification à Poséidon et la référence « v. 30–31 » viennent de D3, du rapport du vérificateur et de Wikipédia (*Telchines*). La glose « artisans légendaires du métal » vient de Wikipédia EN.
2. **Callimaque « IIIe s. av. J.-C. »** et **Sophocle, *Œdipe à Colone*, « fin du Ve siècle »** : dates de connaissance générale, non revérifiées en ligne dans cette session.
3. **Sophocle et le mors** : « ἵπποισιν τὸν ἀκεστῆρα χαλινὸν πρώταισι ταῖσδε κτίσας ἀγυιαῖς » (v. 715–716), soit « ayant établi le premier, sur ces routes-ci, le mors qui dompte les chevaux ». Le texte lie l'invention à Colone ; je n'ai pas écrit qu'il a donné le mors « aux hommes » en général.
4. **Fronton du Parthénon** : Pausanias (I, 24, 5) dit « rear pediment ». J'écris « fronton arrière » sans préciser l'orientation, que je n'ai pas vérifiée dans une source.
5. **`residence: aigai`** : Homère situe son palais à Aigai, mais Poséidon siège aussi sur l'Olympe dans l'*Iliade*. Choix à valider (`aigai` ou `mount-olympus`).
6. **`olympian: true`** : conforme à la tradition courante des Douze. Je n'ai pas vérifié de liste antique précise.
7. **Ids nouveaux** à valider : `amphitrite`, `triton`, `thoosa`, `polyphemus`, `odysseus`, `theseus`, `pegasus`, `chrysaor`, `aigai`, `peleus`, `metis` (dans la liste du lot), `bull` et `horse` (clés de symboles).
8. **Gaïa** : aucun id dans la liste du lot, donc pas de balise `<E>` (texte simple).
9. **Hymne homérique 22** : je garde « date incertaine ». Le vérificateur propose « VIIe–VIe s. av. J.-C. ? », d'après Wikipédia, que je n'ai pas consulté moi-même.
10. **Typographie** : espaces insécables à contrôler au rendu.

### Changements v1 → v2

- **Accroche (D9, ⚠️ n° 2)** : « Vexe-le, et tu rentres chez toi avec des années de retard : demande à Ulysse. » Ulysse finit bien par rentrer.
- **Méduse (D5, ⚠️ n° 9 et 59)** : « Pégase et Chrysaor, nés de `<E id="medusa">Méduse</E>` » dans « En bref ». Relation `poseidon → chrysaor` retirée. `poseidon parent-of pegasus` est conservée avec la source commune « Apollodore II, 4, 2–3 ; Hésiode v. 278–281 ». Apollodore II, 4, 2–3 est ajouté aux Sources.
- **Libération (D2, ⚠️ n° 15)** : « Cronos est forcé de recracher… (ruse de Gaïa chez Hésiode, drogue de Métis chez Apollodore) » remplace « il force Cronos ».
- **Rang de naissance (D1, ⚠️ n° 46)** : formule commune ajoutée dans « Son histoire ». La porte Zeus devient « Le frère devenu roi ».
- **Trident (D3)** : « donné » est conservé. Nouvelle anecdote « Qui a fait le trident ? » sur les Telchines de Callimaque, qui remplace l'anecdote de l'Érechthéion, déplacée dans `<Versions>`.
- **Tempête (⚠️ n° 25)** : « tempête après tempête » supprimé. Il ne reste que la vague qui brise le radeau (*Od.* V, 366–370).
- **Varron (⚠️ n° 35)** : les trois punitions des femmes sont citées.
- **Interprétation non attribuée (⚠️ n° 39)** : couche `interpretation` supprimée. Elle est remplacée par une version `ancient` de Pausanias (I, 26, 5 : « preuves » sur l'Acropole ; I, 24, 5 : fronton du Parthénon).
- **Sources inutilisées** : Sophocle est exploité (Hippios, le mors). Pausanias I, 24, 5 et I, 26, 5 sont exploités dans `<Versions>`, et I, 30, 4 sert de source de l'épithète Hippios. Retirés : Théogonie v. 139–141 et 501–506, Iliade XII, 27, XXI, 441–457 et XXIII, 306–308, 584–585, Odyssée IV, 505–511 et IX, 366–412. Les listes YAML et MDX sont alignées.
- **Chevaux de Pélée (⚠️ n° 30 et 62)** : *Iliade* XXIII, 277–278 est cité comme source la plus ancienne, dans le MDX et dans la relation.
- **Dates d'Homère (D10, ⚠️ n° 48)** : « fin du VIIIe – début du VIIe siècle av. J.-C. ».
- **Bloc `deity:` officiel** : domains et symbols passent en clés anglaises (`sea`, `earthquakes`, `horses` ; `trident`, `horse`, `bull`). Ajout de `olympian: true` et `residence: aigai`. Les sens des épithètes sont retirés du YAML et placés dans « En bref » (ligne « Surnoms »). Retrait du champ `home`.
- **Tutoiement (D9)** : dans l'accroche, une transition (« tu vas voir ») et les trois « Le saviez-vous ? ».
- **Divers** : Amphitrite intégrée à la ligne « Famille » et Triton aux « Enfants célèbres » (« En bref » limité à 7 lignes). « (v. 5) » ajouté pour l'Hymne 22, et « XV, 190–191 » pour la citation de l'*Iliade*.
