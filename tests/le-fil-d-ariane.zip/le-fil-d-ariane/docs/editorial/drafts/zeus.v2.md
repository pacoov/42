# Livrable rédacteur — Fiche « Zeus » (lot 1, vague A) — v2

### YAML

```yaml
id: zeus
type: deity
category: gods
names:
  greek: Ζεύς
  transliteration: Zeus
  roman: Jupiter
  aliases: [Zeus, Jupiter, Kronidès, Cronide, Zeus Xénios, Zeus Horkios]
era: olympians
importance: 1
deity:
  domains: [sky, thunder, justice, hospitality, oaths, kingship]
  symbols: [thunderbolt, eagle, oak, aegis]
  olympian: true
  residence: mount-olympus
  epithets:
    - { greek: Ξείνιος, transliteration: Xeinios, source: "Homère, Odyssée, IX, 270–271" }
    - { greek: Ὅρκιος, transliteration: Horkios, source: "Pausanias, Description de la Grèce, V, 24, 9" }
    - { greek: Ὀλύμπιος, transliteration: Olympios, source: "Hésiode, Théogonie, v. 884" }
relations:                 # sens : from → to
  # Famille
  - { from: cronos, to: zeus, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–458 ; Homère, Iliade, XV, 187–188 ; Apollodore, Bibliothèque, I, 1, 5–6" }
  - { from: rhea, to: zeus, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–458 ; Homère, Iliade, XV, 187–188" }
  - { from: zeus, to: hestia, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–457" }
  - { from: zeus, to: demeter, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–457" }
  - { from: zeus, to: hera, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–457" }
  - { from: zeus, to: hades, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–457 ; Homère, Iliade, XV, 187–188" }
  - { from: zeus, to: poseidon, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–457 ; Homère, Iliade, XV, 187–188" }
  # Épouses divines
  - { from: zeus, to: metis, type: spouse-of, certainty: canonical, source: "Hésiode, Théogonie, v. 886–900 (première épouse, avalée)" }
  - { from: zeus, to: hera, type: spouse-of, certainty: canonical, source: "Hésiode, Théogonie, v. 921 (dernière union) ; Apollodore, Bibliothèque, I, 3, 1" }
  # Enfants (ids existants ou validés D6)
  - { from: zeus, to: athena, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 886–900 et 924–926" }
  - { from: metis, to: athena, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 886–900" }
  - { from: zeus, to: ares, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 921–923 ; Apollodore, Bibliothèque, I, 3, 1" }
  - { from: zeus, to: hebe, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 921–923 ; Apollodore, Bibliothèque, I, 3, 1" }
  - { from: zeus, to: eileithyia, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 921–923 ; Apollodore, Bibliothèque, I, 3, 1" }
  - { from: zeus, to: persephone, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 912–914 (avec Déméter)" }
  - { from: zeus, to: hermes, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 938–939 (avec Maïa)" }
  - { from: maia, to: hermes, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 938–939" }
  - { from: zeus, to: heracles, type: parent-of, certainty: canonical, source: "Homère, Iliade, XIV, 323–324 (avec la mortelle Alcmène)" }
  - { from: zeus, to: perseus, type: parent-of, certainty: canonical, source: "Homère, Iliade, XIV, 319–320 ; Apollodore, Bibliothèque, II, 4, 1 (pluie d'or « selon certains » ; d'autres nomment Proïtos)" }
  - { from: danae, to: perseus, type: parent-of, certainty: canonical, source: "Homère, Iliade, XIV, 319–320 ; Apollodore, Bibliothèque, II, 4, 1" }
  # Unions obtenues par la ruse ou la force (D6) : aucune relation lover-of. Enfants dont l'id n'existe pas encore,
  # filiation à déclarer quand les fiches seront créées :
  #   - europa : Apollodore, III, 1, 1 (Zeus changé en taureau ; Minos, Sarpédon, Rhadamanthe) ;
  #   - callisto : Apollodore, III, 8, 2 (ἀκούσῃ, « contre son gré » ; Arcas) ;
  #   - io : Apollodore, II, 1, 3 (Épaphos) ;
  #   - leda : Apollodore, III, 10, 7 (Zeus changé en cygne ; Pollux, Hélène) ;
  #   - leto : Hésiode, Théogonie, v. 918–920 (Apollon, Artémis) ;
  #   - semele : Hésiode, Théogonie, v. 940–942 (Dionysos) ;
  #   - ganymede : pas d'enfant ; enlevé par « les dieux » (Iliade, XX, 232–235), par Zeus au moyen d'un aigle (Apollodore, III, 12, 2).
  # Perséphone : Zeus « la donna » à Hadès (Théogonie, v. 913–914) — aucun type autorisé ne l'exprime.
  # Titanomachie : événement, lié uniquement dans le texte via <E> (D7).
  # Victoires et châtiments
  - { from: zeus, to: cronos, type: defeated, certainty: canonical, source: "Hésiode, Théogonie, v. 71–73 et 490–496" }
  - { from: zeus, to: titans, type: defeated, certainty: canonical, source: "Hésiode, Théogonie, v. 687–735 ; Apollodore, Bibliothèque, I, 2, 1" }
  - { from: zeus, to: titans, type: punished, certainty: canonical, source: "Hésiode, Théogonie, v. 717–731 (enchaînés par les Hécatonchires, v. 717–719, dans le Tartare « par la volonté de Zeus », v. 730)" }
  # Cyclopes et foudre (D3)
  - { from: zeus, to: cyclopes, type: helped, certainty: canonical, source: "Hésiode, Théogonie, v. 501–502 (libère « les frères de son père », fils d'Ouranos) ; Apollodore, Bibliothèque, I, 2, 1" }
  - { from: cyclopes, to: zeus, type: helped, certainty: canonical, source: "Hésiode, Théogonie, v. 139–141 et 503–506 ; Apollodore, Bibliothèque, I, 2, 1" }
  - { from: cyclopes, to: thunderbolt, type: created, certainty: canonical, source: "Hésiode, Théogonie, v. 141 (τεῦξάν τε κεραυνόν, « ils fabriquèrent la foudre »)" }
  - { from: zeus, to: thunderbolt, type: owns, certainty: canonical, source: "Hésiode, Théogonie, v. 72, 504–506, 687–699" }
  # Égide (D4) : appartient à Zeus, qui la prête à Athéna (athena owns aegis : canonical, fiche Athéna)
  - { from: zeus, to: aegis, type: owns, certainty: canonical, source: "Homère, Iliade, XV, 308–310 ; XVII, 593–595 ; épithète αἰγίοχος, p. ex. Hésiode, Théogonie, v. 735" }
  - { from: hephaestus, to: aegis, type: created, certainty: canonical, source: "Homère, Iliade, XV, 309–310 (forgée par Héphaïstos pour Zeus)" }
  - { from: metis, to: aegis, type: created, certainty: variant, source: "Fragment hésiodique (Théogonie 929a–t, éd. Perseus), v. 929s : Métis fabrique l'égide, armure d'Athéna" }
  # Résidence
  - { from: zeus, to: mount-olympus, type: lives-in, certainty: canonical, source: "Homère, Iliade, I, 498–499 (assis au plus haut sommet de l'Olympe) ; Hésiode, Théogonie, v. 884 (Ὀλύμπιον)" }
sources:
  - { source: "Hésiode, Théogonie", locus: "v. 71–74, 139–146, 453–506, 617–735, 881–942 (dont fragment 929a–t)", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml" }
  - { source: "Hésiode, Théogonie (trad. Evelyn-White)", locus: "idem", url: "https://www.theoi.com/Text/HesiodTheogony.html" }
  - { source: "Hésiode, Les Travaux et les Jours", locus: "v. 238–239, 256–262", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg002/tlg0020.tlg002.perseus-grc2.xml" }
  - { source: "Homère, Iliade", locus: "I, 498–499 et 528–530 ; II, 447 ; III, 276–280 ; V, 738–742 ; XIII, 354–355 ; XIV, 315–328 ; XV, 166, 182, 187–193 et 308–310 ; XVII, 593–596 ; XX, 232–235 ; XXIV, 308–311", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml" }
  - { source: "Homère, Iliade, XV (trad. Murray)", locus: "XV, 187–193", url: "https://www.theoi.com/Text/HomerIliad15.html" }
  - { source: "Homère, Odyssée", locus: "VI, 207–208 ; IX, 269–271 ; XIV, 57–58 et 327–328", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg002/tlg0012.tlg002.perseus-grc2.xml" }
  - { source: "(Pseudo-)Apollodore, Bibliothèque", locus: "I, 1, 5–7 ; I, 2, 1 ; I, 3, 1 et 6 ; II, 1, 3 ; II, 4, 1 ; III, 1, 1 ; III, 8, 2 ; III, 10, 7 ; III, 12, 2", url: "https://www.theoi.com/Text/Apollodorus1.html" }
  - { source: "Callimaque, Hymne I, À Zeus", locus: "v. 6–10 (Ida, Arcadie, tombeau, Parrhasie), 46–54 (Dicté, Amalthée, Panacra, Courètes), 58–67 (frères aînés, rejet du tirage au sort)", url: "https://www.perseus.tufts.edu/hopper/text?doc=Perseus:text:2008.01.0481:hymn=1" }
  - { source: "Pausanias, Description de la Grèce", locus: "V, 24, 9 (Zeus Horkios)", url: "https://www.theoi.com/Text/Pausanias5B.html" }
  - { source: "Strabon, Géographie", locus: "VIII, 3, 30 (statue de Phidias)", url: "https://penelope.uchicago.edu/Thayer/E/Roman/Texts/Strabo/8C*.html" }
  - { source: "W. Burkert, The Orientalizing Revolution, 1992 (cité d'après J. Larson, « Amphitrite In and Out of the Olympian Pantheon », Les Études classiques 87, 2019, p. 31, n. 3, et Wikipédia EN « Atrahasis »)", locus: "p. 88–91 (p. 90 selon Larson)", url: "https://www.lesetudesclassiques.be/index.php/lec/article/viewFile/631/541" }
review: { status: draft }
```

### MDX

```mdx
---
name: Zeus
role: Le roi des dieux, arrivé au trône par un coup d'État
hook: Tu trouves ta famille compliquée ? Celle de Zeus commence par un père qui avale ses enfants… et finit par une guerre de dix ans pour le trône du monde.
---

## En bref

- **Famille :** fils des Titans <E id="cronos">Cronos</E> et <E id="rhea">Rhéa</E> ; frère d'<E id="hestia">Hestia</E>, <E id="demeter">Déméter</E>, <E id="hera">Héra</E>, <E id="hades">Hadès</E> et <E id="poseidon">Poséidon</E>
- **Domaines :** le ciel, la foudre, la justice, l'hospitalité, les serments
- **Arme :** la <E id="thunderbolt">foudre</E>, fabriquée par les <E id="cyclopes">Cyclopes</E>
- **Symboles :** la foudre, l'aigle, le chêne, l'<E id="aegis">égide</E>, qu'il prête à sa fille Athéna
- **Résidence :** le <E id="mount-olympus">mont Olympe</E>
- **Épouse :** Héra, sa sœur — la septième et dernière union divine chez Hésiode, et la seule qui dure
- **Chez les Romains :** Jupiter

## Son histoire

Cronos a un problème : une prophétie annonce qu'un de ses enfants le renversera. Sa solution ? Les avaler à la naissance. Hestia, Déméter, Héra, Hadès, Poséidon : tous y passent. Pour le dernier, <E id="rhea">Rhéa</E> ruse. Elle tend à son mari une grosse pierre emmaillotée. Il l'avale sans rien remarquer.

Le bébé grandit en secret en Crète, dans une grotte. Des guerriers, les Courètes, entrechoquent lances et boucliers pour couvrir ses pleurs, raconte le mythographe — compilateur de mythes — Apollodore. Où exactement ? Les auteurs ne sont pas d'accord, tu le verras plus bas.

Adulte, Zeus délivre ses frères et sœurs. Cronos est forcé de les recracher (par une ruse de Gaïa chez Hésiode, par une drogue de <E id="metis">Métis</E> chez Apollodore). Commence la <E id="titanomachy">Titanomachie</E> : dix ans de guerre contre les <E id="titans">Titans</E>. Les Cyclopes, libérés par Zeus, lui offrent le tonnerre et la foudre.

Vaincus, les Titans finissent enchaînés dans le Tartare, gouffre aussi loin sous la terre que le ciel est au-dessus. Tu devines la suite : Zeus rejoue le scénario familial. On lui prédit que Métis, sa première épouse, lui donnera un fils capable de le détrôner. Il l'avale. Leur fille <E id="athena">Athéna</E> naîtra de sa tête.

Zeus multiplie aussi les unions avec des mortelles, souvent par la ruse ou la force. Zeus, changé en taureau, enlève Europe ; Callisto est prise contre son gré.

## Ses pouvoirs

- **Maître du ciel et de la foudre :** contre les Titans, ses éclairs embrasent la terre et font bouillir la mer, selon Hésiode.
- **Garant de la justice :** sa fille Dikè, la Justice, siège près de lui et lui dénonce les juges malhonnêtes (Hésiode, *Les Travaux et les Jours*).
- **Protecteur des étrangers :** Zeus Xénios veille sur la xenia — le devoir sacré d'accueillir l'étranger — et venge les voyageurs maltraités (*Odyssée*, IX).
- **Gardien des serments :** à Olympie, sa statue de Zeus Horkios, « des serments », tenait une foudre dans chaque main. De toutes, c'était la plus terrifiante pour les coupables, selon Pausanias (IIe s. apr. J.-C.).
- **Ses emblèmes :** l'aigle, « le plus cher des oiseaux » pour lui (*Iliade*, XXIV), et le chêne de Dodone, par lequel il rendait ses oracles (*Odyssée*, XIV).

<Versions title="Où est né Zeus ?">
  <Version layer="ancient" source="Hésiode, Théogonie, v. 477–484 (vers 700 av. J.-C.)">Rhéa est envoyée à Lyctos, en Crète. Gaïa cache le nouveau-né dans une grotte profonde, sur le mont Aigaion, couvert de forêts. L'emplacement de ce mont reste incertain.</Version>
  <Version layer="ancient" source="Apollodore, Bibliothèque, I, 1, 6–7 (Ier–IIe s. apr. J.-C.)">Rhéa accouche dans une grotte du mont Dicté, en Crète. Les nymphes Adrastée et Ida nourrissent l'enfant du lait d'Amalthée, et les Courètes montent la garde.</Version>
  <Version layer="ancient" source="Callimaque, Hymne à Zeus, v. 6–10 et 46–54 (IIIe s. av. J.-C., trad. de la rédaction)">Le poète grec Callimaque hésite : « On dit que tu es né sur les monts de l'Ida », d'autres disent en Arcadie. Il tranche pour la Parrhasie, en Arcadie, et lance : « Les Crétois, toujours menteurs ! » Ils montrent un tombeau de Zeus… qui est immortel. L'enfant est ensuite élevé en Crète, entre le Dicté et l'Ida.</Version>
</Versions>

<Versions title="Le partage du monde : tirage au sort ou élection ?">
  <Version layer="ancient" source="Homère, Iliade, XV, 187–193 (fin du VIIIe – début du VIIe s. av. J.-C., trad. de la rédaction)">Poséidon raconte : les trois fils de Cronos ont tiré au sort. Il a reçu la mer, Hadès les ténèbres, Zeus le vaste ciel. La terre et l'Olympe restent communs aux trois. Le monde « a été partagé en trois ».</Version>
  <Version layer="ancient" source="Hésiode, Théogonie, v. 881–885 (vers 700 av. J.-C.)">Pas de tirage au sort. Après la victoire, sur le conseil de Gaïa, les dieux pressent Zeus de devenir roi. C'est lui qui distribue ensuite les honneurs à chacun.</Version>
  <Version layer="ancient" source="Apollodore, Bibliothèque, I, 2, 1 (Ier–IIe s. apr. J.-C.)">Après la Titanomachie, les trois frères tirent au sort le pouvoir : le ciel à Zeus, la mer à Poséidon, le royaume souterrain à Pluton, autre nom d'Hadès.</Version>
  <Version layer="ancient" source="Callimaque, Hymne à Zeus, v. 60–67 (IIIe s. av. J.-C.)">Callimaque se moque du tirage au sort : seul un sot jouerait l'Olympe contre l'Hadès. Zeus serait roi par ses exploits et sa force.</Version>
  <Version layer="ancient" source="Hésiode, Théogonie, v. 478 ; Homère, Iliade, XIII, 355 et XV, 166 ; Callimaque, Hymne à Zeus, v. 58">Autre divergence : chez Hésiode, Zeus est le petit dernier ; chez Homère, il est l'aîné de Poséidon. Callimaque, lui, le fait aussi naître après ses frères.</Version>
  <Version layer="interpretation" source="W. Burkert, The Orientalizing Revolution, 1992, p. 88–91 (cité d'après J. Larson, 2019)">Selon l'historien Walter Burkert, le tirage au sort homérique viendrait d'un récit mésopotamien, l'épopée d'Atrahasis. Les grands dieux s'y partagent le monde par le sort : le ciel à Anu, la terre à Enlil, les eaux à Enki.</Version>
</Versions>

## Le saviez-vous ?

- **Une galerie de victimes dans le ciel.** Les quatre grandes lunes de Jupiter ? Io, Europe, Ganymède et Callisto, nommées en 1614 par Simon Marius sur une idée de Kepler. Tous ont été séduits, trompés ou enlevés par Zeus.
- **Une statue trop grande pour son temple.** Imagine un Zeus assis d'or et d'ivoire, haut d'environ 12 m, sculpté par Phidias à Olympie vers 435–430 av. J.-C. S'il se levait, note Strabon, il emporterait le toit.
- **La pierre de Cronos, souvenir officiel.** Et la pierre avalée par Cronos ? Selon Hésiode, Zeus la plante à Pytho (Delphes), au pied du Parnasse, « merveille pour les mortels » (trad. de la rédaction).

## Dans la culture populaire

- **Percy Jackson et le Voleur de foudre** (Rick Riordan, 2005) : l'éclair primitif de Zeus a disparu, et tout accuse Percy. Dans la série Disney+ (2023), Zeus est joué par Lance Reddick, mort avant la diffusion.
- **Hercule** (Disney, 1997) : Zeus y est un papa jovial, et Héra la mère d'Hercule. Dans le mythe, la mère d'Héraclès est une mortelle, Alcmène… et Héra le déteste.
- **God of War III** (2010) : sur PlayStation 3, le guerrier Kratos affronte Zeus et finit par le tuer. Le roi des dieux en patron de fin de jeu.

## Pour aller plus loin

- <E id="cronos">Cronos</E> — Le père qui avalait ses enfants, et la pierre qu'il n'a jamais vue venir.
- <E id="titanomachy">Titanomachie</E> — Dix ans de guerre entre deux générations de dieux pour le trône du monde.
- <E id="hera">Héra</E> — Reine des dieux, sœur et épouse de Zeus : bien plus qu'une femme jalouse.

## Sources

- Hésiode, *Théogonie*, v. 71–74, 139–146, 453–506, 617–735, 881–942 (vers 700 av. J.-C.)
- Hésiode, *Les Travaux et les Jours*, v. 238–239, 256–262 (vers 700 av. J.-C.)
- Homère, *Iliade*, I, 498–499 ; III, 276–280 ; XIII, 354–355 ; XIV, 315–328 ; XV, 166, 187–193 et 308–310 ; XVII, 593 ; XXIV, 308–311 (fin du VIIIe – début du VIIe siècle av. J.-C.)
- Homère, *Odyssée*, IX, 269–271 ; XIV, 327–328 (fin du VIIIe – début du VIIe siècle av. J.-C.)
- Callimaque, *Hymne à Zeus*, v. 6–10, 46–54, 58–67 (IIIe siècle av. J.-C.)
- (Pseudo-)Apollodore, *Bibliothèque*, I, 1, 5–7 ; I, 2, 1 ; I, 3, 1 et 6 ; III, 1, 1 ; III, 8, 2 (Ier–IIe siècle apr. J.-C.)
- Pausanias, *Description de la Grèce*, V, 24, 9 (IIe siècle apr. J.-C.)
- Strabon, *Géographie*, VIII, 3, 30 (début du Ier siècle apr. J.-C.)
- W. Burkert, *The Orientalizing Revolution*, 1992, p. 88–91 (cité d'après J. Larson, *Les Études classiques*, 2019)
```

### Sources consultées

Visitées pour la v1 :
- https://www.theoi.com/Text/HesiodTheogony.html — Théogonie (trad. Evelyn-White) : Cyclopes et foudre, avalement, pierre, Lyctos, mont « Aegeum », pierre à Pytho, Hécatonchires, Tartare, Zeus pressé de régner, liste des épouses.
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml — Théogonie, grec numéroté : v. 71–74, 139–146, 453–506 (dont 478, 484, 497–500), 617–638, 687–700, 715–735, 881–929 et fragment 929a–t.
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg002/tlg0020.tlg002.perseus-grc2.xml — Travaux et Jours, v. 238–240 et 256–259.
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml — Iliade, grec numéroté (passages listés dans le YAML).
- https://www.theoi.com/Text/HomerIliad15.html — Iliade XV (trad. Murray), partage par les sorts.
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg002/tlg0012.tlg002.perseus-grc2.xml — Odyssée : VI, 207–208 ; IX, 269–271 ; XIV, 57–58 et 327–328.
- https://www.theoi.com/Text/Apollodorus1.html — Bibliothèque I (trad. Frazer).
- Grec d'Apollodore (urn:cts:greekLit:tlg0548.tlg001.perseus-grc2), copie locale du scratchpad : I, 1, 5–7 ; I, 2, 1 ; I, 3, 1 et 6 ; II, 1, 3 ; II, 4, 1 ; III, 1, 1 ; III, 8, 2 ; III, 10, 7 ; III, 12, 2.
- https://www.theoi.com/Text/CallimachusHymns1.html et https://topostext.org/work/120 — Callimaque, Hymne I (trad. Mair).
- https://www.theoi.com/Text/Pausanias5B.html — Pausanias V, 24, 9.
- https://penelope.uchicago.edu/Thayer/E/Roman/Texts/Strabo/8C*.html — Strabon VIII, 3, 30.
- https://en.wikipedia.org/wiki/Statue_of_Zeus_at_Olympia ; https://en.wikipedia.org/wiki/Zeus ; https://www.britannica.com/topic/Zeus.
- https://en.wikipedia.org/wiki/Galilean_moons ; https://www.lindahall.org/about/news/scientist-of-the-day/simon-marius/.
- https://en.wikipedia.org/wiki/Atrahasis ; https://jewishchristianlit.com/?p=157.
- https://en.wikipedia.org/wiki/The_Lightning_Thief ; https://www.shmoop.com/study-guides/percy-jackson-lightning-thief/chapter-9-summary.html ; https://en.wikipedia.org/wiki/Percy_Jackson_and_the_Olympians_(TV_series) ; https://whatsondisneyplus.com/courtney-b-vance-replacing-the-late-lance-reddick-in-percy-jackson-and-the-olympians-disney-series/ ; https://en.wikipedia.org/wiki/Hercules_(1997_film) ; https://en.wikipedia.org/wiki/God_of_War_III.

Visitées ou relues pour la v2 :
- Iliade (grec, même fichier) : I, 498–499 (Zeus au sommet de l'Olympe) ; XV, 165–167 et 181–183 (γενεῇ πρότερος, Zeus né avant Poséidon).
- Théogonie (grec, même fichier) : v. 918–920 (Létô), 938–942 (Maïa et Hermès, Sémélé et Dionysos).
- https://www.perseus.tufts.edu/hopper/text?doc=Perseus:text:2008.01.0481:hymn=1 — Callimaque, grec numéroté : v. 4, 6, 7, 8, 10, 47, 49, 50, 51, 58, 61, 62, 66.
- https://www.theoi.com/Text/CallimachusHymns1.html (relu) — Callimaque se range à l'Arcadie (Parrhasie), puis l'enfant est porté en Crète.
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0525/tlg001/tlg0525.tlg001.perseus-grc2.xml — Pausanias V, 24, 9 en grec : μάλιστα ἐς ἔκπληξιν ἀδίκων ἀνδρῶν ; ἐπίκλησις… Ὅρκιος ; κεραυνὸν dans chaque main.
- https://www.lesetudesclassiques.be/index.php/lec/article/viewFile/631/541 — J. Larson, 2019, p. 31, n. 3 : cite Burkert 1992, p. 90 (loterie : ciel à Anu, terre à Enlil, eaux d'en bas à Enki ; parallèle avec Iliade XV).
- https://fr.vikidia.org/wiki/Le_Voleur_de_foudre — « éclair primitif » dans la traduction française.
- https://www.britannica.com/topic/Statue-of-Zeus — vers 430 av. J.-C., près de 12 m.

### Doutes

1. **Burkert** : thèse lue seulement à travers deux sources secondaires (Larson 2019, qui cite la p. 90 ; Wikipédia EN, qui cite p. 88–91). Je n'ai pas lu *The Orientalizing Revolution*. C'est accepté au conditionnel selon D8. « Viendrait de » est plus fort que « rappellerait » : Larson parle d'emprunt au mythe du Proche-Orient. À ramener à « rappellerait » si le directeur préfère la prudence.
2. **Callimaque et l'Arcadie** : Callimaque tranche pour la Parrhasie (v. 10), puis l'enfant est porté en Crète. Je n'ai pas relevé le numéro du vers du transport par Néda. Le texte dit donc seulement « ensuite élevé en Crète », et ne cite que les v. 46–54.
3. **Citations de Callimaque** (« On dit que tu es né sur les monts de l'Ida », « Les Crétois, toujours menteurs ! ») : traductions de la rédaction, faites d'après le grec (v. 6 et 8) lu sur Perseus. La seconde formule est une citation proverbiale, traditionnellement attribuée à Épiménide (relevé du vérificateur, non vérifié par moi). Non mentionné dans le texte.
4. **Citation d'Hésiode sur la pierre** (« merveille pour les mortels », θαῦμα θνητοῖσι βροτοῖσιν, v. 500) : traduction de la rédaction. L'équivalence Pytho = Delphes est courante, mais ce n'est pas Hésiode qui la formule.
5. **Mont Aigaion** : la localisation reste incertaine ; le texte le dit.
6. **Relations `hebe`, `eileithyia`, `hermes`, `maia`, `danae`** : `hebe` et `eileithyia` sont utilisés dans la fiche Héra, `hermes` dans la fiche Méduse ; `maia` et `danae` sont validés par D6. Ces ids sont à confirmer dans le graphe central. Alcmène (`alcmene`) n'est pas validée : pas de relation mère → Héraclès.
7. **`metis → aegis` (variant)** : le fragment 929a–t n'est pas un vers de la *Théogonie* au sens strict ; relation à garder ou à retirer selon la politique du graphe.
8. **Typographie** : espaces insécables à contrôler au rendu.

### Changements v1 → v2

- **Balises `[À VÉRIFIER]`** : toutes supprimées. Callimaque est cité au vers près (v. 6–10, 46–54, 58–67, 60–67), avec l'URL Perseus en grec. Burkert est attribué et daté au conditionnel, avec « cité d'après » (D8), et ajouté aux `sources` du YAML et du MDX.
- **Rang de naissance (D1)** : « l'aîné des frères » devient « chez Hésiode, Zeus est le petit dernier ; chez Homère, il est l'aîné de Poséidon » (Il. XIII, 355 ; XV, 166). J'ai ajouté Callimaque, v. 58.
- **Libération des enfants (D2)** : la formule commune est appliquée (ruse de Gaïa ou drogue de Métis), sans bloc supplémentaire (Q4).
- **Prophétie de Métis** : elle est faite à Zeus, et le fils serait « capable de le détrôner ».
- **Europe** : « Zeus, changé en taureau, enlève Europe » (D6).
- **Nouveau bloc `<Versions>` sur le lieu de naissance (Q3)** : Lyctos et le mont Aigaion (Hésiode), Dicté (Apollodore), Ida, Arcadie et Parrhasie (Callimaque), avec la pique « Crétois toujours menteurs » et le tombeau. Le « Le saviez-vous ? » du tombeau, qui faisait doublon, est remplacé par la pierre de Cronos à Pytho (Théogonie, v. 497–500). Le paragraphe 2 de « Son histoire » renvoie au bloc.
- **Travaux et Jours** : v. 256–262 (YAML et Sources).
- **`lives-in`** : sourcé par Iliade I, 498–499 (vérifié dans le grec) ; Iliade XV, 193 est retiré.
- **Phidias** : « vers 435–430 av. J.-C. » (Wikipédia et Britannica recoupés).
- **Percy Jackson** : « éclair primitif » (traduction française, vérifiée sur Vikidia).
- **Homère daté** « fin du VIIIe – début du VIIe s. av. J.-C. » (D10).
- **En bref** : « septième et dernière union divine… et la seule qui dure » ; la foudre est « fabriquée » par les Cyclopes (D3) ; l'égide est « qu'il prête à sa fille Athéna » (D4).
- **YAML** : bloc `deity:` au format officiel (`residence`, `olympian: true`, épithètes Xeinios, Horkios et Olympios sourcées ; `home` est supprimé). `zeus owns aegis` passe en `canonical` (D4). `hephaestus → aegis` reste `canonical` (Homère) ; la variante de Métis est isolée dans sa propre relation `variant`. Ajout des relations `parent-of` vers Hébé, Ilithyie et Hermès, et de Maïa → Hermès et Danaé → Persée (D6). Les autres unions, dont les enfants n'ont pas d'id, restent en commentaire. La Titanomachie est liée seulement via `<E>` (D7). Les Hécatonchires sont précisés dans la relation `punished`.
- **Tutoiement (D9)** : nouvelle accroche (« Tu trouves ta famille compliquée ? »), transitions (« tu le verras plus bas », « Tu devines la suite ») et « Le saviez-vous ? » réécrits à la deuxième personne.
- **Pausanias** : la paraphrase est contrôlée sur le grec (ἐς ἔκπληξιν ἀδίκων ἀνδρῶν).
