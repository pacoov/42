# Livrable rédacteur — Fiche « Athéna » (lot 1, vague A) — draft

### YAML

```yaml
id: athena
type: deity
category: gods
names:
  greek: Ἀθηνᾶ               # forme épique : Ἀθήνη ; Παλλὰς Ἀθήνη
  transliteration: Athēna
  roman: Minerva
  aliases: [Athéna, Athéné, Pallas, Pallas Athéna, Parthénos, Tritogénie, Minerve]
era: olympians
importance: 1
deity:                       # bloc de spécialisation proposé (le guide ne donne que l'exemple `creature`) — à valider
  olympian: true
  domains: [sagesse, conseil, stratégie, guerre, artisanat, tissage, protection des cités]
  symbols: [chouette, olivier, égide, gorgonéion, lance, casque]
  city: athens
  epithets: [Pallas, Parthénos, Polias, Promachos, Glaukôpis, Tritogénie]
relations:                   # sens : from → to
  - { from: zeus, to: athena, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 886–900 et 924 ; Apollodore, Bibliothèque, I, 3, 6" }
  - { from: metis, to: athena, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 886–900 ; Apollodore, Bibliothèque, I, 3, 6" }
  - { from: zeus, to: metis, type: spouse-of, certainty: canonical, source: "Hésiode, Théogonie, v. 886 (« première épouse »)" }
  - { from: hephaestus, to: zeus, type: helped, certainty: variant, source: "Pindare, Olympiques, VII, 35–37 ; Apollodore, Bibliothèque, I, 3, 6 (« selon d'autres »)" }
  - { from: prometheus, to: zeus, type: helped, certainty: variant, source: "Euripide, Ion, v. 452–457 ; Apollodore, Bibliothèque, I, 3, 6" }
  - { from: athena, to: poseidon, type: enemy-of, certainty: canonical, source: "Hérodote, Histoires, VIII, 55 ; Apollodore, Bibliothèque, III, 14, 1 (rivalité pour l'Attique)" }
  - { from: athena, to: ares, type: defeated, certainty: canonical, source: "Homère, Iliade, XXI, 403–408 (le terrasse d'une pierre) ; V, 855–861 (guide la lance de Diomède)" }
  - { from: athena, to: perseus, type: helped, certainty: canonical, source: "Apollodore, Bibliothèque, II, 4, 2" }
  - { from: athena, to: heracles, type: helped, certainty: canonical, source: "Homère, Iliade, VIII, 362–365 ; Apollodore, Bibliothèque, II, 5, 6 (crotales de bronze)" }
  - { from: athena, to: odysseus, type: helped, certainty: canonical, source: "Homère, Odyssée, XIII, 296–302" }
  - { from: athena, to: arachne, type: punished, certainty: variant, source: "Ovide, Métamorphoses, VI, 129–145 (poète romain)" }
  - { from: athena, to: aegis, type: owns, certainty: canonical, source: "Homère, Iliade, V, 738–742 (elle la revêt ; en XV, 307–310 l'égide est celle de Zeus, forgée par Héphaïstos)" }
  - { from: athena, to: mount-olympus, type: lives-in, certainty: canonical, source: "Homère, Iliade, passim [À VÉRIFIER : locus précis]" }
# Non exprimable avec les types autorisés, consigné ici :
#   - Héphaïstos, né d'Héra seule « en colère » contre Zeus, en réponse à la naissance d'Athéna (Hésiode, Théogonie, v. 927–929) ;
#   - Athéna fait pousser l'olivier sur l'Acropole (`created` vers un id `olive-tree` hors liste du lot) ;
#   - Athéna « nourrit » Érechthée, né de la terre (Iliade, II, 547–548) ; serpent Érichthonios aux pieds de la statue (Pausanias, I, 24, 7).
#   - Tête de Méduse : sur l'égide (« la Gorgone », Homère) / au milieu du bouclier (Apollodore, II, 4, 3) / sur la poitrine de la statue (Pausanias, I, 24, 7). Cohérent avec la fiche `medusa`.
sources:
  - { source: "Hésiode, Théogonie", locus: "v. 886–900 ; 924–929", url: "https://www.theoi.com/Text/HesiodTheogony.html" }
  - { source: "Homère, Iliade", locus: "V, 733–742 ; V, 855–861 ; VIII, 362–365 ; XIV, 178–179 ; XV, 307–310 ; XXI, 403–408", url: "https://github.com/PerseusDL/canonical-greekLit (tlg0012.tlg001.perseus-grc2)" }
  - { source: "Homère, Odyssée", locus: "VII, 110–111 ; XIII, 296–302", url: "https://github.com/PerseusDL/canonical-greekLit (tlg0012.tlg002.perseus-grc2)" }
  - { source: "Hymne homérique 28, À Athéna", locus: "v. 1–16", url: "https://github.com/PerseusDL/canonical-greekLit (tlg0013.tlg028.perseus-grc2)" }
  - { source: "Hymne homérique 5, À Aphrodite", locus: "v. 7–15", url: "https://github.com/PerseusDL/canonical-greekLit (tlg0013.tlg005.perseus-grc2)" }
  - { source: "Pindare, Olympiques", locus: "VII, 35–38", url: "https://github.com/PerseusDL/canonical-greekLit (tlg0033.tlg001.perseus-grc2)" }
  - { source: "Euripide, Ion", locus: "v. 452–457", url: "https://github.com/PerseusDL/canonical-greekLit (tlg0006.tlg010.perseus-grc2)" }
  - { source: "Hérodote, Histoires", locus: "VIII, 55", url: "https://github.com/PerseusDL/canonical-greekLit (tlg0016.tlg001.perseus-grc2)" }
  - { source: "Thucydide, Guerre du Péloponnèse", locus: "II, 13, 5", url: "https://github.com/PerseusDL/canonical-greekLit (tlg0003.tlg001.perseus-grc2)" }
  - { source: "Aristophane, Les Oiseaux", locus: "v. 301", url: "https://github.com/PerseusDL/canonical-greekLit (tlg0019.tlg006.perseus-grc2)" }
  - { source: "(Pseudo-)Apollodore, Bibliothèque", locus: "I, 3, 6 ; I, 6, 2 ; II, 4, 2–3 ; II, 5, 6 ; III, 14, 1", url: "https://www.theoi.com/Text/Apollodorus1.html" }
  - { source: "Plutarque, Vie de Périclès", locus: "13, 9", url: "https://github.com/PerseusDL/canonical-greekLit (tlg0007.tlg012.perseus-grc2)" }
  - { source: "Pausanias, Description de la Grèce", locus: "I, 24, 5–7", url: "https://www.theoi.com/Text/Pausanias1B.html" }
  - { source: "Pline l'Ancien, Histoire naturelle (auteur romain)", locus: "XXXVI, 18", url: "https://penelope.uchicago.edu/Thayer/L/Roman/Texts/Pliny_the_Elder/36*.html" }
  - { source: "Ovide, Métamorphoses (poète romain)", locus: "VI, 1–145 (olivier : v. 80–81)", url: "https://www.thelatinlibrary.com/ovid/ovid.met6.shtml" }
  - { source: "Augustin, La Cité de Dieu (auteur latin chrétien, d'après Varron)", locus: "XVIII, 9", url: "https://www.thelatinlibrary.com/augustine/civ18.shtml" }
review: { status: draft }
```

### MDX

```mdx
---
name: Athéna
role: La déesse de la sagesse, née tout armée du crâne de Zeus
hook: Un coup de hache sur le crâne de Zeus, et une déesse en armure en jaillit. Littéralement.
---

## En bref

- **Famille :** fille de <E id="zeus">Zeus</E> et de <E id="metis">Métis</E>, la plus sage des divinités
- **Domaines :** sagesse et bon conseil, stratégie, guerre réfléchie, artisanat et tissage
- **Ville :** protectrice d'Athènes, où se dresse le Parthénon
- **Statut :** vierge (en grec *parthénos*), d'où son surnom Athéna Parthénos
- **Symboles :** la chouette, l'olivier, l'<E id="aegis">égide</E> ornée de la tête de la Gorgone
- **Protégés :** <E id="perseus">Persée</E>, <E id="heracles">Héraclès</E>, <E id="odysseus">Ulysse</E>
- **Chez les Romains :** Minerve

## Son histoire

Le poète grec Hésiode (vers 700 av. J.-C.) raconte que la première épouse de Zeus est Métis, « celle qui en sait le plus parmi les dieux et les hommes ». Une prophétie inquiète Zeus : après une fille, Métis doit enfanter un fils qui deviendra roi des dieux. (Traduction de la rédaction.)

Zeus a de qui tenir : son père <E id="cronos">Cronos</E> avalait ses enfants. Lui avale directement la mère, enceinte. Puis il met au monde Athéna lui-même, « par sa tête ». Hésiode la dit égale à son père « en force et en sage conseil ».

Chez Hésiode, le récit ne s'arrête pas là. <E id="hera">Héra</E>, furieuse, donne seule naissance à <E id="hephaestus">Héphaïstos</E>, sans s'unir à Zeus. Dans cette famille, on se répond à coups de naissances.

Athéna devient la protectrice d'Athènes après une dispute avec <E id="poseidon">Poséidon</E>. Chez Homère, elle combat aux côtés des Grecs devant Troie. Elle va jusqu'à terrasser <E id="ares">Arès</E>, son demi-frère, d'un coup de pierre. Elle guide Persée, soutient Héraclès dans ses travaux et veille sur Ulysse jusqu'à son retour.

## Ses pouvoirs

- **Intelligence stratégique :** dans l'*Odyssée*, elle se dit « réputée parmi tous les dieux pour sa ruse (*mètis*) et ses astuces ». (Trad. de la rédaction.)
- **Guerre :** l'*Iliade* la montre revêtant l'égide, une peau-bouclier terrifiante, avant d'entrer dans la bataille.
- **Artisanat :** l'*Hymne homérique à Aphrodite* dit qu'elle enseigna aux artisans à fabriquer chars et voitures, et aux jeunes filles les beaux ouvrages.
- **Tissage :** chez Homère, elle tisse elle-même sa robe et celle d'Héra.
- **Métamorphose :** elle prend volontiers une apparence humaine pour conseiller ses protégés, comme Ulysse.

<Versions title="Une naissance, plusieurs versions">
  <Version layer="ancient" source="Hésiode, Théogonie, v. 886–900 et 924 (vers 700 av. J.-C.)">Zeus avale Métis enceinte, puis enfante Athéna « par sa tête » au bord du fleuve Triton. Hésiode ne nomme aucun assistant et ne décrit pas d'armure.</Version>
  <Version layer="ancient" source="Hymne homérique 28, À Athéna (peut-être Ve siècle av. J.-C.)">Athéna jaillit de la tête de Zeus en armes d'or étincelantes, brandissant une lance. L'Olympe tremble, la mer se soulève et le Soleil arrête ses chevaux.</Version>
  <Version layer="ancient" source="Pindare, Olympiques, VII, 35–38 (464 av. J.-C.)">C'est <E id="hephaestus">Héphaïstos</E> qui ouvre le crâne de Zeus d'un coup de hache de bronze. Athéna en sort en poussant un immense cri de guerre.</Version>
  <Version layer="ancient" source="Euripide, Ion, v. 452–457 (fin du Ve siècle av. J.-C.)">Le chœur attribue l'accouchement au Titan Prométhée.</Version>
  <Version layer="ancient" source="Apollodore, Bibliothèque, I, 3, 6 (Ier–IIe siècle apr. J.-C.)">Le mythographe — compilateur de mythes — retient Prométhée, « ou, selon d'autres, Héphaïstos ». Il ajoute que Métis changeait de forme pour échapper à Zeus.</Version>
</Versions>

<Versions title="Athènes : l'olivier contre la mer">
  <Version layer="ancient" source="Hérodote, Histoires, VIII, 55 (Ve siècle av. J.-C.)">Sur l'Acropole, un sanctuaire abrite un olivier et une « mer », de l'eau salée. Selon les Athéniens, Poséidon et Athéna les y ont laissés comme témoignages de leur querelle pour le pays.</Version>
  <Version layer="ancient" source="Apollodore, Bibliothèque, III, 14, 1">Poséidon frappe l'Acropole de son <E id="trident">trident</E> et fait jaillir une mer. Athéna plante un olivier, devant le roi Cécrops comme témoin. Les douze dieux, juges désignés par Zeus, donnent le pays à Athéna. Furieux, Poséidon inonde la plaine voisine.</Version>
  <Version layer="ancient" source="Augustin, La Cité de Dieu, XVIII, 9 (auteur latin chrétien, Ve siècle apr. J.-C., d'après le Romain Varron)">Version romaine tardive : les citoyens votent. Les hommes choisissent Neptune, les femmes Minerve, qui gagne d'une voix. Pour apaiser Neptune, les femmes perdent alors le droit de vote.</Version>
  <Version layer="interpretation">On interprète souvent ce choix comme celui d'une cité qui préfère l'olivier, richesse agricole, à la mer. Mais l'olivier n'est qu'un des deux « dons » : Athènes deviendra aussi une grande puissance navale. [À VÉRIFIER : attribution de cette lecture]</Version>
</Versions>

## Arachné, une histoire romaine

C'est l'histoire la plus célèbre d'Athéna… et elle vient du poète romain Ovide (*Métamorphoses*, livre VI, vers 8 apr. J.-C.). Arachné, une jeune Lydienne, se dit meilleure tisseuse que la déesse. Minerve (Athéna chez les Romains) la défie. La tapisserie de la déesse montre sa victoire sur Neptune : un olivier qui jaillit de la terre.

Arachné, elle, tisse les tromperies des dieux. Son ouvrage est sans défaut. Furieuse, la déesse le déchire et la frappe avec sa navette. Arachné tente de se pendre. Minerve la change alors en araignée, condamnée à tisser pour toujours. Aucune version grecque complète de ce récit ne nous est parvenue. [À VÉRIFIER]

## Le saviez-vous ?

- **Des chouettes dans le porte-monnaie.** Dès la fin du VIe siècle av. J.-C., la chouette d'Athéna orne les pièces d'argent d'Athènes. La pièce grecque de 1 euro reprend ce motif.
- **Apporter des chouettes à Athènes.** Chez Aristophane (*Les Oiseaux*, v. 301, 414 av. J.-C.), un personnage s'étonne : « Qui a amené une chouette à Athènes ? » Elles y pullulaient déjà. (Trad. de la rédaction.)
- **Une armure en peau de géant.** Selon Apollodore (I, 6, 2), pendant la guerre contre les Géants, Athéna écorche le géant Pallas et se protège avec sa peau.

## Le Parthénon et sa statue

Le Parthénon, commencé en 447 av. J.-C., tire son nom de *parthénos*, « vierge ». Selon Pausanias (IIe siècle apr. J.-C.), son fronton ouest montrait la dispute avec Poséidon, et l'autre la naissance d'Athéna.

À l'intérieur se dressait l'Athéna Parthénos de Phidias, consacrée vers 438 av. J.-C. Elle était faite d'ivoire et d'or : quarante talents d'or, détachables, selon l'historien grec Thucydide.

Pausanias décrit la tête de Méduse en ivoire sur sa poitrine, une Victoire dans une main, une lance, un bouclier et un serpent à ses pieds. L'auteur romain Pline lui donne 26 coudées, environ 11,5 m. La statue est aujourd'hui perdue.

## Dans la culture populaire

- **Percy Jackson** (Rick Riordan) : Annabeth Chase est une fille d'Athéna, une invention moderne. Elle est jouée par Alexandra Daddario au cinéma et par Leah Sava Jeffries dans la série Disney+ (2023).
- **Hades** (Supergiant Games, 2020) : Athéna fait partie des Olympiens qui aident le héros. Ses dons lui permettent de renvoyer les attaques ennemies. Stratégie défensive, logique.
- **Assassin's Creed Odyssey** (Ubisoft, 2018) : le jeu se déroule pendant la guerre du Péloponnèse. On y visite Athènes et la statue d'Athéna Parthénos.
- **Nashville (États-Unis)** : une réplique grandeur nature de la statue, réalisée par Alan LeQuire en 1990, trône dans une copie du Parthénon.

## Pour aller plus loin

- <E id="zeus">Zeus</E> — Le père qui a avalé la mère… puis accouché par la tête.
- <E id="medusa">Méduse</E> — La Gorgone dont la tête finit sur l'égide et le bouclier d'Athéna.
- <E id="poseidon">Poséidon</E> — Le rival qui a perdu Athènes, et ne l'a pas très bien pris.

## Sources

- Hésiode, *Théogonie*, v. 886–900 et 924–929 (vers 700 av. J.-C.)
- Homère, *Iliade*, V, 733–742 et 855–861 ; VIII, 362–365 ; XIV, 178–179 ; XV, 307–310 ; XXI, 403–408 (vers le VIIIe siècle av. J.-C.)
- Homère, *Odyssée*, VII, 110–111 ; XIII, 296–302
- *Hymnes homériques* 5 (À Aphrodite), v. 7–15, et 28 (À Athéna), v. 1–16
- Pindare, *Olympiques*, VII, 35–38 (464 av. J.-C.)
- Euripide, *Ion*, v. 452–457 (fin du Ve siècle av. J.-C.)
- Hérodote, *Histoires*, VIII, 55 (Ve siècle av. J.-C.)
- Thucydide, *Guerre du Péloponnèse*, II, 13, 5 (fin du Ve siècle av. J.-C.)
- Aristophane, *Les Oiseaux*, v. 301 (414 av. J.-C.)
- (Pseudo-)Apollodore, *Bibliothèque*, I, 3, 6 ; I, 6, 2 ; II, 4, 2–3 ; II, 5, 6 ; III, 14, 1 (Ier–IIe siècle apr. J.-C.)
- Plutarque, *Vie de Périclès*, 13, 9
- Pausanias, *Description de la Grèce*, I, 24, 5–7 (IIe siècle apr. J.-C.)
- Pline l'Ancien, *Histoire naturelle*, XXXVI, 18 (auteur romain, Ier siècle apr. J.-C.)
- Ovide, *Métamorphoses*, VI, 1–145 (poète romain, vers 8 apr. J.-C.)
- Augustin, *La Cité de Dieu*, XVIII, 9 (auteur latin, Ve siècle apr. J.-C.)
```

### Sources consultées

Textes antiques (grec lu directement dans les fichiers PerseusDL, numérotation de l'édition) :
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml — Hésiode, Théogonie v. 886–900 (Métis « πλεῖστα θεῶν εἰδυῖαν », prophétie du fils, v. 896 « ἶσον… μένος καὶ ἐπίφρονα βουλήν ») ; v. 924–929 (« αὐτὸς δ' ἐκ κεφαλῆς », Héphaïstos né d'Héra seule, « ζαμένησε »).
- https://www.theoi.com/Text/HesiodTheogony.html — même passage en traduction Evelyn-White ; mention du fleuve Triton (929a, recension variante).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml — Iliade V, 733–742 (péplos tissé par elle, égide, Γοργείη κεφαλή) ; V, 855–861 (lance de Diomède contre Arès) ; VIII, 362–369 (secours à Héraclès) ; XIV, 178–179 (robe d'Héra) ; XV, 307–310 (égide de Zeus forgée par Héphaïstos) ; XXI, 403–408 (Arès terrassé d'une pierre) ; II, 546–549 (Érechthée).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg002/tlg0012.tlg002.perseus-grc2.xml — Odyssée XIII, 296–302 (« μήτι τε κλέομαι καὶ κέρδεσιν ») ; VII, 110–111 (tissage des Phéaciennes).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg028/tlg0013.tlg028.perseus-grc2.xml — Hymne 28 (armes d'or, lance, Olympe qui tremble, mer, Soleil qui arrête ses chevaux, παρθένον).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg005/tlg0013.tlg005.perseus-grc2.xml — Hymne à Aphrodite v. 7–15 (artisans, chars, ouvrages des jeunes filles).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0033/tlg001/tlg0033.tlg001.perseus-grc2.xml — Pindare, Olympique VII, 35–38 (Héphaïstos, hache de bronze, cri ἀλάλαξεν).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0006/tlg010/tlg0006.tlg010.perseus-grc2.xml — Euripide, Ion v. 452–457 (Prométhée).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0016/tlg001/tlg0016.tlg001.perseus-grc2.xml — Hérodote VIII, 55 (olivier et « mer » dans le temple d'Érechthée).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0003/tlg001/tlg0003.tlg001.perseus-grc2.xml — Thucydide II, 13, 5 (40 talents d'or, amovibles).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0019/tlg006/tlg0019.tlg006.perseus-grc2.xml — Aristophane, Oiseaux v. 301 (« τίς γλαῦκ' Ἀθήναζ' ἤγαγεν; »).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0007/tlg012/tlg0007.tlg012.perseus-grc2.xml — Plutarque, Périclès 13, 9 (Phidias, « τὸ χρυσοῦν ἕδος »).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0525/tlg001/tlg0525.tlg001.perseus-grc2.xml — Pausanias I, 24, 5–7 (frontons, ivoire et or, sphinx, griffons, tête de Méduse en ivoire, Victoire de 4 coudées, lance, bouclier, serpent Érichthonios, naissance de Pandore sur la base).
- Apollodore (fichier grec PerseusDL déjà téléchargé pour la fiche Méduse, éd. Frazer) — I, 3, 6 (Métis, métamorphoses, hache de Prométhée ou Héphaïstos, fleuve Triton) ; I, 6, 2 (peau de Pallas) ; II, 5, 6 (crotales) ; III, 14, 1 (dispute de l'Attique, douze dieux juges, inondation de la plaine thriasienne).
- https://www.theoi.com/Text/Apollodorus1.html — traduction Frazer de I, 3, 6.
- https://www.theoi.com/Text/Pausanias1B.html — traduction de I, 24, 5–7.
- https://www.thelatinlibrary.com/ovid/ovid.met6.shtml — Ovide, Met. VI : Hypaepa v. 14, déguisement v. 26, olivier v. 80–81, coups v. 130–133, pendaison et métamorphose v. 134–145.
- https://www.theoi.com/Olympios/AthenaWrath.html — résumé de l'épisode d'Arachné (Idmon de Colophon, teinturier ; tapisseries ; navette de buis).
- https://www.thelatinlibrary.com/augustine/civ18.shtml — Augustin, Cité de Dieu XVIII, 9 (Varron : vote, une voix d'écart, punition des femmes).
- https://penelope.uchicago.edu/Thayer/L/Roman/Texts/Pliny_the_Elder/36*.html — Pline, HN XXXVI, 18 (« cubitorum XXVI », ivoire et or) ; § 19 (Pandore).
- https://www.theoi.com/Olympios/Athena.html — vue d'ensemble (domaines, symboles, héros aidés).

Références modernes :
- https://en.wikipedia.org/wiki/Athena_Parthenos — 438 av. J.-C., ~11,5 m selon Pline, statue perdue, réplique de Nashville (Alan LeQuire, 1990).
- https://en.wikipedia.org/wiki/Parthenon — début en 447 av. J.-C., Ictinos et Callicratès, sens de *parthénos*, frontons.
- https://en.wikipedia.org/wiki/Owl_of_Athena — chevêche (*Athene noctua*), tétradrachmes après 510 av. J.-C.
- https://mymodernmet.com/greece-euro-coins/ — pièce grecque de 1 € inspirée du tétradrachme.
- https://en.wikipedia.org/wiki/Athena et https://fr.wikipedia.org/wiki/Athéna — épithètes (Pallas, Parthénos, Promachos, Polias), glaukôpis, Minerve, Arachné chez Ovide.
- https://en.wikipedia.org/wiki/Olympian_7 — date 464 av. J.-C., Diagoras de Rhodes.
- https://en.wikipedia.org/wiki/Ion_(play) — date discutée (418–412 av. J.-C.).
- https://en.wikipedia.org/wiki/Homeric_Hymns — Hymne 28 « possibly 5th century BCE ».
- https://en.wikipedia.org/wiki/The_Birds_(play) — 414 av. J.-C.
- https://en.wikipedia.org/wiki/Annabeth_Chase — fille d'Athéna, Alexandra Daddario.
- https://en.wikipedia.org/wiki/Percy_Jackson_and_the_Olympians_(TV_series) — première le 19 décembre 2023, Leah Sava Jeffries, Andra Day en Athéna (saison 2).
- https://en.wikipedia.org/wiki/Hades_(video_game) et https://hades.fandom.com/wiki/Athena — Supergiant Games, 2020 ; dons d'Athéna = renvoi (« Deflect »).
- https://en.wikipedia.org/wiki/Assassin%27s_Creed_Odyssey et https://assassinscreedwiki.accesstheanimus.com/wiki/Athena_Parthenos — 2018, guerre du Péloponnèse, Athènes, statue visitée par Kassandra.

### Doutes

1. **Section « Arachné » et « Le Parthénon »** : le gabarit §5 ne les prévoit pas. Je les ai ajoutées car le brief exige ces points. À fusionner dans « Son histoire » ou à garder, selon l'arbitrage du directeur.
2. **« Aucune version grecque complète ne nous est parvenue »** (Arachné) [À VÉRIFIER] : theoi.com ne cite que des sources latines (Ovide, Virgile), mais je n'ai pas vérifié l'absence de toute mention grecque (scholies, Nicandre…).
3. **Interprétation olivier/mer** dans le bloc `<Versions>` [À VÉRIFIER] : lecture répandue, mais je n'ai trouvé aucun auteur moderne précis à qui l'attribuer. À sourcer ou supprimer.
4. **Relation `lives-in mount-olympus`** [À VÉRIFIER] : évidente chez Homère, mais je n'ai pas relevé de locus précis.
5. **Bloc `deity:`** dans le YAML : structure proposée par moi, le guide ne donnant que l'exemple `creature`.
6. **`enemy-of` Athéna → Poséidon** : la relation décrit une rivalité ponctuelle (l'Attique). Ils sont alliés ailleurs (camp grec à Troie). Peut-être trop fort ; à arbitrer.
7. **Dates non vérifiées en ligne dans cette session** : Hérodote « Ve siècle av. J.-C. », Pausanias « IIe siècle apr. J.-C. », Plutarque (non daté dans la fiche), Augustin « Ve siècle », Pline « Ier siècle ». Elles sont données au siècle près, sans recherche dédiée. Les dates d'Hésiode, d'Apollodore et d'Ovide reprennent celles validées pour la fiche Méduse.
8. **Citations traduites par la rédaction** depuis le grec (Hésiode v. 887 et 896 ; Odyssée XIII, 299 ; Aristophane v. 301) : à relire par un helléniste.
9. **Hymne 28** : la datation « peut-être Ve siècle av. J.-C. » vient de Wikipédia EN seulement.
10. **Fleuve Triton chez Hésiode** : le v. 929a (recension variante, peut-être interpolée) ; je le mentionne dans la version d'Hésiode. Le grec PerseusDL principal (v. 924–929) ne le contient pas. À retirer si l'on s'en tient au texte principal.
11. **Statue de Phidias** : Pausanias ne nomme pas Phidias pour cette statue (I, 24, 5–7) ; l'attribution vient de Plutarque (Périclès 13, 9) et de Pline. Hauteur « environ 11,5 m » = conversion de Wikipédia EN. Le gorgonéion est sur la poitrine (Pausanias) ; la présence d'une égide sur la statue vient de Wikipédia, d'où la formulation prudente dans le MDX.
12. **Hades (jeu)** : la description des dons (« renvoyer les attaques ») vient d'un wiki de fans, faute de source officielle consultée.
13. **Assassin's Creed Odyssey** : la présence de la statue d'Athéna Parthénos vient d'un wiki de fans ; Wikipédia ne la mentionne pas.
14. **Héphaïstos comme « fils d'Héra seule »** : version d'Hésiode seulement (le MDX le précise). Chez Homère, il est fils de Zeus et Héra (cf. fiche Héra) ; Apollodore (I, 3, 5) signale lui aussi les deux versions.
14 bis. **Accroche** : la hache n'apparaît pas chez Hésiode (Pindare, Apollodore). L'accroche reprend donc une version, pas « la » version ; le bloc `<Versions>` le montre aussitôt.
15. **Arès « demi-frère »** : Athéna n'est pas fille d'Héra ; Arès est fils de Zeus et Héra (non vérifié dans cette session, voir fiche Arès).
16. **Typographie** : espaces insécables à contrôler au rendu.
