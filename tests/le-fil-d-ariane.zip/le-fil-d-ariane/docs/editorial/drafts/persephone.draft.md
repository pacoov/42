# Livrable rédacteur — Fiche « Perséphone » — Lot 1, vague B — draft v1

### YAML

```yaml
id: persephone
type: deity
category: gods
names:
  greek: Περσεφόνη            # forme épique : Περσεφόνεια (Homère, Hésiode)
  transliteration: Persephonē
  roman: Proserpina
  aliases: [Perséphone, Korè, Coré, Kore, Proserpine, Proserpina]
gender: f
era: olympians
importance: 1
deity:
  domains: [underworld, the-dead]           # le retour au printemps est un fait du récit (Hymne, v. 401–403), pas un « domaine » attesté : voir Doutes 4
  symbols: [pomegranate]
  olympian: false                            # reine des Enfers ; ne figure pas parmi les Douze dans la tradition courante
  residence: underworld                      # un tiers de l'année ; le reste auprès de sa mère et des dieux
  epithets:
    - { greek: ἐπαινή, transliteration: epainē, source: "Homère, Iliade, IX, 457 et 569 ; Odyssée, X, 491 et 534 ; XI, 47 ; Hésiode, Théogonie, v. 768 et 774" }
    - { greek: ἁγνή, transliteration: hagnē, source: "Homère, Odyssée, XI, 386 ; Hymne homérique à Déméter, v. 439 (κόρην Δήμητρος ἁγνήν)" }
    - { greek: ἀγαυή, transliteration: agauē, source: "Homère, Odyssée, XI, 213, 226 et 635" }
    - { greek: Κόρη, transliteration: Korē, source: "Euripide, Alceste, v. 852 ; Apollodore, Bibliothèque, I, 5, 3 et I, 9, 15" }
relations:                  # sens : from → to
  - { from: zeus, to: persephone, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 912–913 ; Homère, Odyssée, XI, 217 (« fille de Zeus ») ; Hymne homérique à Déméter, v. 2–3" }
  - { from: demeter, to: persephone, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 912–913 ; Hymne homérique à Déméter, v. 1–2 ; Apollodore, Bibliothèque, I, 5, 1–3" }
  # Variante isolée : Apollodore, I, 3, 1, la fait naître de Zeus et de Styx (ἐκ δὲ Στυγὸς Περσεφόνην). Pas de relation styx → persephone proposée (id non annoncé) ; mentionnée dans <Versions>.
  - { from: hades, to: persephone, type: spouse-of, certainty: canonical, source: "Hésiode, Théogonie, v. 767–768, 913–914 ; Hymne homérique à Déméter, v. 79, 343, 363" }
  # Union non consentie au départ (Hymne, v. 19 « contre son gré » ; v. 413 « elle dit avoir été forcée ») : PAS de lover-of. Cohérent avec la fiche Hadès.
  - { from: hermes, to: persephone, type: helped, certainty: canonical, source: "Hymne homérique à Déméter, v. 334–341, 375–385, 407–410 (envoyé par Zeus pour la ramener)" }
  - { from: hecate, to: persephone, type: helped, certainty: canonical, source: "Hymne homérique à Déméter, v. 438–440 (devient sa suivante et compagne)" }   # id `hecate` non annoncé : à valider
  - { from: persephone, to: orpheus, type: helped, certainty: variant, source: "Virgile, Géorgiques, IV, 486–487 (poète romain) ; Ovide, Métamorphoses, X, 15 et 46–52 (poète romain) — chez Apollodore, I, 3, 2, Orphée persuade Pluton seul" }
  - { from: persephone, to: underworld, type: lives-in, certainty: canonical, source: "Hymne homérique à Déméter, v. 398–400, 445–447 ; Homère, Odyssée, X, 491 ; Hésiode, Théogonie, v. 767–768" }
# Non exprimés faute de type adapté ou d'id annoncé : rôle de Zeus dans l'enlèvement (déjà `zeus → hades : helped` dans la fiche Hadès) ;
# Alceste renvoyée chez les vivants par Korè (Apollodore, I, 9, 15) ; Pirithoos venu la demander en mariage, puis enchaîné (Apollodore, II, 5, 12) ;
# Adonis et le partage de l'année avec Aphrodite (Apollodore, III, 14, 4) ; Ascalaphe (puni par Déméter : relève de la fiche Déméter).
sources:
  - { source: "Homère, Iliade", locus: "IX, 456–457 et 568–570", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml" }
  - { source: "Homère, Odyssée", locus: "X, 488–495, 508–512, 534 ; XI, 47, 213–227, 385–386, 633–635", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg002/tlg0012.tlg002.perseus-grc2.xml" }
  - { source: "Hésiode, Théogonie", locus: "v. 767–774, 912–914", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml" }
  - { source: "Hymne homérique à Déméter", locus: "v. 1–20, 77–87, 334–341, 360–374, 393–413, 414–433, 438–447", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg002/tlg0013.tlg002.perseus-grc2.xml" }
  - { source: "Euripide, Alceste", locus: "v. 357–362, 850–853", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0006/tlg002/tlg0006.tlg002.perseus-grc2.xml" }
  - { source: "(Pseudo-)Apollodore, Bibliothèque", locus: "I, 3, 1–2 ; I, 5, 1–3 ; I, 9, 15 ; II, 5, 12 ; III, 14, 4", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-grc2.xml" }
  - { source: "Virgile, Géorgiques (poète romain)", locus: "IV, 485–489", url: "https://raw.githubusercontent.com/PerseusDL/canonical-latinLit/master/data/phi0690/phi002/phi0690.phi002.perseus-lat2.xml" }
  - { source: "Ovide, Métamorphoses (poète romain)", locus: "V, 536–539, 564–567 ; X, 11–17, 46–52", url: "https://raw.githubusercontent.com/PerseusDL/canonical-latinLit/master/data/phi0959/phi006/phi0959.phi006.perseus-lat2.xml" }
  - { source: "LSJ (Liddell-Scott-Jones), s.v. ἐπαινός", locus: "—", url: "https://lsj.gr/wiki/ἐπαινός" }
review: { status: draft, version: 1 }
```

### MDX

```mdx
---
name: Perséphone
role: Reine des Enfers, fille de Déméter et de Zeus
hook: Tu la connais comme « la fille enlevée » ? En bas, c'est elle qui règne.
---

## En bref

- **Famille :** fille de <E id="zeus">Zeus</E> et de <E id="demeter">Déméter</E> ; épouse d'<E id="hades">Hadès</E>
- **Autres noms :** Korè (« la jeune fille ») ; Proserpine chez les Romains
- **Domaine :** le monde des morts, qu'elle gouverne aux côtés d'Hadès
- **Calendrier :** un tiers de l'année sous la terre, le reste avec sa mère et les dieux
- **Symbole :** la grenade, dont un seul grain l'a liée aux <E id="underworld">Enfers</E>
- **Chez Homère :** « la redoutable Perséphone », invoquée avec Hadès dans les malédictions
- **Olympienne ?** Non : sa place est sous la terre, pas sur l'<E id="mount-olympus">Olympe</E>

## Son histoire

Avant d'être reine, elle porte un autre nom : Korè, « la jeune fille ». Chez le poète grec Hésiode (vers 700 av. J.-C.), elle est la fille de Zeus et de Déméter. Dans l'*Hymne homérique à Déméter* (VIIe–VIe siècle av. J.-C.), elle cueille des fleurs avec des compagnes. Soudain, la terre s'ouvre.

Hadès surgit sur son char et l'emporte contre son gré. C'est Zeus qui la lui a « donnée », sans demander l'avis de sa mère. Déméter, désespérée, empêche les graines de pousser. Les humains vont mourir de faim : Zeus envoie <E id="hermes">Hermès</E> la chercher. Hadès obéit, mais lui fait d'abord manger en cachette un grain de grenade.

De retour auprès de sa mère, Perséphone raconte qu'il l'a forcée à le manger. Ce grain la lie au monde d'en bas : elle y passera un tiers de l'année, le reste avec sa mère. Quand la terre se couvre de fleurs au printemps, dit Déméter, elle remonte.

Sous la terre, elle n'a rien d'une prisonnière muette. Chez Homère, on l'invoque avec Hadès pour maudire quelqu'un. Dans l'*Odyssée*, c'est elle qui fait défiler les ombres devant Ulysse. Et chez le poète romain Virgile, c'est elle qui impose à <E id="orpheus">Orphée</E> la règle fatale : ne pas se retourner.

## Ses pouvoirs

- Elle règne sur les morts avec Hadès : dans l'*Iliade*, ce sont eux deux qui exaucent les malédictions (IX, 456–457 et 568–570).
- Elle commande aux ombres : dans l'*Odyssée*, elle envoie les âmes des femmes vers Ulysse, puis les disperse (XI, 225–227 et 385–386).
- Elle décide de ce que gardent les morts : chez Homère, elle a laissé au devin Tirésias sa pleine raison, alors que les autres ne sont que des ombres (*Odyssée*, X, 494–495).
- Elle peut rendre un mort aux vivants : selon Apollodore, Korè renvoie Alceste sur terre — ou bien, ajoute-t-il, Héraclès la ramène après avoir combattu Hadès.
- Dans l'*Hymne*, Hadès lui promet qu'elle régnera sur tout ce qui vit, et que ceux qui ne l'honorent pas par des sacrifices seront punis (v. 364–369).

<Versions title="Une histoire, plusieurs versions">
  <Version layer="ancient" source="Hymne homérique à Déméter, v. 371–374 et 411–413 (VIIe–VIe siècle av. J.-C.)">Hadès lui donne en secret un grain de grenade. Elle raconte ensuite à sa mère qu'il l'a forcée à le manger. Résultat : un tiers de l'année sous terre.</Version>
  <Version layer="ancient" source="Apollodore, Bibliothèque, I, 5, 1–3 (Ier–IIe siècle apr. J.-C.)">Pluton (Hadès) l'enlève « avec l'aide de Zeus ». Il lui donne un grain de grenade, qu'elle mange sans prévoir la suite. Ascalaphe, un habitant des Enfers, témoigne contre elle. Elle est contrainte de passer un tiers de l'année avec Pluton.</Version>
  <Version layer="ancient" source="Ovide, Métamorphoses, V, 536–539 et 564–567 (poète romain, vers 8 apr. J.-C.)">Chez le poète romain Ovide, Proserpine mange sept grains de grenade. Jupiter coupe l'année en deux moitiés égales.</Version>
  <Version layer="ancient" source="Apollodore, Bibliothèque, I, 3, 1">Une mère, deux versions : dans sa liste des enfants de Zeus, Apollodore fait naître Perséphone de Styx, déesse du fleuve infernal. Partout ailleurs, y compris plus loin chez lui, sa mère est Déméter.</Version>
  <Version layer="ancient" source="Apollodore, I, 3, 2 ; Virgile, Géorgiques, IV, 487 ; Ovide, Métamorphoses, X, 15–52">Qui laisse partir Eurydice ? Chez Apollodore, Orphée convainc Pluton seul. Chez les poètes romains Virgile et Ovide, Proserpine joue un rôle : chez Virgile, c'est elle qui fixe la règle de ne pas se retourner.</Version>
  <Version layer="interpretation">On la réduit souvent à « la fille enlevée ». Les textes la montrent aussi reine, invoquée et crainte. Beaucoup de lecteurs modernes voient dans ses allers-retours une image du cycle des saisons et des cultures [À VÉRIFIER].</Version>
</Versions>

## Le saviez-vous ?

- **Sortie précipitée.** À la fin de sa visite chez les morts, Ulysse prend peur : et si Perséphone lui envoyait la tête de la Gorgone ? Il file aussitôt vers son navire (*Odyssée*, XI, 633–635).
- **Garde partagée.** Selon Apollodore (III, 14, 4), Aphrodite cache le bébé Adonis dans un coffre et le confie à Perséphone. Celle-ci refuse de le rendre. Zeus coupe l'année en trois.
- **Une suivante de choix.** Dans l'*Hymne à Déméter* (v. 438–440), Hécate, déesse liée à la nuit, accueille Perséphone à son retour. Elle devient dès lors sa suivante et sa compagne.

## Dans la culture populaire

- **Lore Olympus** (Rachel Smythe, Webtoon, 2018–2024) : une réécriture du mythe dans un décor moderne, où Perséphone est la déesse du printemps. Le webcomic a reçu l'Eisner du meilleur webcomic en 2022 et en 2023.
- **Hades** (Supergiant Games, 2020) : Perséphone y est la mère de Zagreus, le héros. Elle a quitté les Enfers, et toute ton évasion consiste à la retrouver.

## Pour aller plus loin

- <E id="demeter">Déméter</E> — La mère qui a menacé d'affamer le monde pour retrouver sa fille.
- <E id="hades">Hadès</E> — Le roi des morts : ni méchant de dessin animé, ni héros.
- <E id="orpheus">Orphée</E> — Le chanteur qui a fait pleurer les Enfers… et s'est retourné trop tôt.

## Sources

- Homère, *Iliade*, IX, 456–457 et 568–570 ; *Odyssée*, X, 488–495, 508–512, 534 ; XI, 47, 213–227, 385–386, 633–635 (fin du VIIIe – début du VIIe siècle av. J.-C.)
- Hésiode, *Théogonie*, v. 767–774, 912–914 (vers 700 av. J.-C.)
- *Hymne homérique à Déméter*, v. 1–20, 77–87, 334–341, 360–374, 393–447 (VIIe–VIe siècle av. J.-C.)
- Euripide, *Alceste*, v. 357–362, 850–853 (Ve siècle av. J.-C.)
- (Pseudo-)Apollodore, *Bibliothèque*, I, 3, 1–2 ; I, 5, 1–3 ; I, 9, 15 ; II, 5, 12 ; III, 14, 4 (Ier–IIe siècle apr. J.-C.)
- Virgile, *Géorgiques*, IV, 485–489 (poète romain, Ier siècle av. J.-C.)
- Ovide, *Métamorphoses*, V, 536–539, 564–567 ; X, 11–52 (poète romain, vers 8 apr. J.-C.)
- Liddell, Scott, Jones, *Greek-English Lexicon* (LSJ), article ἐπαινός
```

### Sources consultées

Textes antiques numérotés (dépôts PerseusDL, téléchargés et lus vers par vers) :
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg002/tlg0013.tlg002.perseus-grc2.xml — *Hymne à Déméter* : v. 1–20 (Aïdoneus l'enlève, Zeus la « donne » νόσφιν Δήμητρος ; ἁρπάξας δʼ ἀέκουσαν, v. 19) ; v. 77–87 ; v. 360–369 (discours d'Hadès : δεσπόσσεις πάντων ὁπόσα ζώει τε καὶ ἕρπει, v. 365 ; punition de ceux qui ne l'apaisent pas, v. 367–369) ; v. 370–374 (ῥοιῆς κόκκον… λάθρῃ) ; v. 393–403 (Déméter : un tiers de l'année, retour au printemps v. 401–403) ; v. 411–413 (ἄκουσαν δὲ βίῃ με προσηνάγκασσε πάσασθαι) ; v. 414–433 (récit de Perséphone, πόλλʼ ἀεκαζομένην, v. 432) ; v. 438–440 (Hécate πρόπολος καὶ ὀπάων) ; v. 445–447 (partage confirmé par Zeus).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml — *Théogonie* v. 767–768 et 774 (ἐπαινῆς Περσεφονείης), v. 912–914 (fille de Zeus et Déméter, enlevée par Aïdoneus, ἔδωκε δὲ μητίετα Ζεύς).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg002/tlg0012.tlg002.perseus-grc2.xml — *Odyssée* X, 488–495 (Tirésias : νόον πόρε Περσεφόνεια), 509 (bois de Perséphone), 534 ; XI, 47, 213–227 (Περσεφόνεια Διὸς θυγάτηρ, v. 217 ; elle envoie les femmes, v. 226), 385–386 (ἁγνὴ Περσεφόνεια disperse les âmes), 633–635 (tête de la Gorgone).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml — *Iliade* IX, 456–457 (malédiction exaucée par Zeus souterrain et ἐπαινὴ Περσεφόνεια) ; IX, 568–570 (Althée invoque Hadès et Perséphone).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-grc2.xml — Apollodore I, 3, 1 (ἐκ δὲ Στυγὸς Περσεφόνην) ; I, 3, 2 (Orphée persuade Pluton) ; I, 5, 1 (Διὸς συνεργοῦντος) ; I, 5, 3 (grain, οὐ προϊδομένη, Ascalaphe, ἠναγκάσθη μένειν, un tiers) ; I, 9, 15 (ἀνέπεμψεν ἡ Κόρη / Héraclès) ; II, 5, 12 (Pirithoos enchaîné) ; III, 14, 4 (Adonis, année en trois).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0006/tlg002/tlg0006.tlg002.perseus-grc2.xml — Euripide, *Alceste* v. 357–362 (Orphée, « la fille de Déméter ou son époux ») ; v. 850–853 (Κόρης Ἄνακτός τ’).
- https://raw.githubusercontent.com/PerseusDL/canonical-latinLit/master/data/phi0690/phi002/phi0690.phi002.perseus-lat2.xml — Virgile, *Géorgiques* IV, 485–489 (namque hanc dederat Proserpina legem, v. 487).
- https://raw.githubusercontent.com/PerseusDL/canonical-latinLit/master/data/phi0959/phi006/phi0959.phi006.perseus-lat2.xml — Ovide, *Mét.* X, 11–17 (Persephonen adiit, v. 15) et 46–52 (regia coniunx… legem). Les vers V, 536–539 et 564–567 sont repris de la fiche Hadès v2 (vérifiés par son rédacteur sur ce même fichier), non relus par moi.
- https://lsj.gr/wiki/ἐπαινός — ἐπαινή, épithète de Perséphone, « awesome / dread » ; loci Il. 9.457, 9.569 ; Od. 10.491, 10.534, 11.47 ; Th. 768.

Culture populaire :
- https://en.wikipedia.org/wiki/Lore_Olympus — Rachel Smythe ; Webtoon (Canvas, 2018), fin le 2 juin 2024 ; Eisner Best Webcomic 2022 et 2023 ; décor moderne ; Perséphone déesse du printemps ; thèmes de violences abordés.
- https://en.wikipedia.org/wiki/Hades_(video_game) — Perséphone mère biologique de Zagreus, partie des Enfers ; Zagreus s'évade pour la retrouver.

Cohérence : /home/claude/editorial/drafts/hades.v2.md et /home/claude/editorial/reviews/hades.review.md (lignes 25 à 33 : enlèvement, grenade, v. 413, Apollodore).

Non accessibles pendant cette session (proxy 403 ou limite) : theoi.com/Khthonios/Persephone.html, thelatinlibrary.com. Toutes les vérifications ont été faites sur les textes PerseusDL ci-dessus.

### Doutes

1. **Interprétation « cycle des saisons »** : lecture moderne très répandue, mais je n'ai consulté aucune source secondaire qui l'atteste (D8 exige une attribution). Marquée [À VÉRIFIER] dans `<Versions>`. À attribuer à un auteur précis ou à supprimer. La saison exacte passée sous terre (hiver ou été sec) est débattue : volontairement non tranchée.
2. **Ovide, *Mét.* V, 536–539 et 564–567** : repris tels quels de la fiche Hadès v2 pour garantir la cohérence ; je ne les ai pas relus moi-même.
3. **Id `hecate`** et **`orpheus`** : `orpheus` est « annoncé » par le brief, `hecate` ne l'est pas. La relation `hecate → persephone : helped` est à valider ou à retirer. De même, `persephone → orpheus : helped` est en `variant` (absent d'Apollodore).
4. **`domains`** : seulement `underworld` et `the-dead`. Je n'ai pas ajouté `spring` ou `vegetation` : chez Lore Olympus elle est « déesse du printemps », mais dans les textes lus, le printemps marque son retour (Hymne, v. 401–403) sans en faire un domaine. À arbitrer.
5. **Enfants** (Zagreus, Mélinoé dans la tradition orphique) : non vérifiés, non mentionnés ; seul le jeu *Hades* fait de Zagreus son fils, ce qui est dit dans la section Culture populaire.
6. **Glose de ἐπαινή** : « redoutable » suit le LSJ (« awesome, dread »). Le LSJ signale aussi une lecture euphémistique ; non reprise.
7. **Glose de ἀγαυή et ἁγνή** (« illustre », « sainte, pure ») : traductions usuelles non vérifiées dans un dictionnaire ; elles ne figurent pas dans le MDX, seulement en YAML sans traduction.
8. **Dates** : Euripide « Ve siècle » et Virgile « Ier siècle av. J.-C. » laissées larges faute de vérification en ligne de la date précise (*Alceste*, 438 av. J.-C. ; *Géorgiques*, vers 29 av. J.-C. — de mémoire, non vérifiées).
9. **Lore Olympus** : les années 2018–2024 désignent la publication sur Webtoon Canvas (une première version circulait dès 2017 sur Tumblr / Webtoon Discover). Le webcomic aborde des violences sexuelles : à garder en tête si on le recommande à des 15 ans.
10. **« Toute ton évasion consiste à la retrouver »** (Hades) : simplification ; le jeu a d'autres ressorts. Formulation à adoucir si le vérificateur la juge trop forte.
11. **Typographie** : espaces insécables à appliquer au rendu.
