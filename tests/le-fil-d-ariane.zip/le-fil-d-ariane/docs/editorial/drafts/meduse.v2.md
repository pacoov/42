# Livrable rédacteur — Fiche « Méduse » (pilote) — v2

### YAML

```yaml
id: medusa
type: creature
category: creatures
names:
  greek: Μέδουσα
  transliteration: Medousa
  roman: Medusa
  aliases: [Méduse, Medusa, Gorgone, Gorgô]
era: heroes
importance: 1
creature:
  kind: monster
  danger: 3
  habitat: [land]          # « au-delà de l'Océan, vers la Nuit » (Hésiode, v. 274–275) ; île de Sarpédon (Chants cypriens, fr. cité par Hérodien)
  defeatedBy: [perseus]
relations:                 # sens : from → to
  - { from: phorcys, to: medusa, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 270–283 ; Apollodore, Bibliothèque, II, 4, 2" }
  - { from: ceto, to: medusa, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 270–283" }
  - { from: medusa, to: stheno, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 276" }
  - { from: medusa, to: euryale, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 276" }
  - { from: medusa, to: graeae, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 270–274 ; Apollodore, Bibliothèque, II, 4, 2" }
  - { from: medusa, to: pegasus, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 280–283 ; Apollodore, Bibliothèque, II, 4, 2 ; Ovide, Métamorphoses, IV, 786" }
  - { from: medusa, to: chrysaor, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 280–283 ; Apollodore, Bibliothèque, II, 4, 2" }
  - { from: poseidon, to: pegasus, type: parent-of, certainty: canonical, source: "Apollodore, Bibliothèque, II, 4, 2 (union avec Méduse : Hésiode, Théogonie, v. 278–279)" }
  - { from: poseidon, to: chrysaor, type: parent-of, certainty: canonical, source: "Apollodore, Bibliothèque, II, 4, 2 (union avec Méduse : Hésiode, Théogonie, v. 278–279)" }
  - { from: perseus, to: medusa, type: defeated, certainty: canonical, source: "Hésiode, Théogonie, v. 280 ; Apollodore, Bibliothèque, II, 4, 2" }
  - { from: athena, to: perseus, type: helped, certainty: canonical, source: "Apollodore, Bibliothèque, II, 4, 2 (guide sa main)" }
  - { from: hermes, to: perseus, type: helped, certainty: canonical, source: "Apollodore, Bibliothèque, II, 4, 2 (faucille en adamant)" }
  - { from: athena, to: medusa, type: punished, certainty: variant, source: "Ovide, Métamorphoses, IV, 798–801 (poète romain)" }
  - { from: athena, to: medusa, type: enemy-of, certainty: variant, source: "Apollodore, Bibliothèque, II, 4, 3 (« selon certains », rivalité de beauté)" }
  - { from: perseus, to: polydectes, type: defeated, certainty: canonical, source: "Apollodore, Bibliothèque, II, 4, 3 (pétrifié par la tête de Méduse)" }
# Devenir de la tête — aucun type de relation autorisé ne l'exprime ; consigné ici et dans `sources` :
#   - Homère, Iliade, V, 741 : la tête de « la Gorgone » (Méduse non nommée) sur l'égide d'Athéna ;
#   - Apollodore, Bibliothèque, II, 4, 3 : Athéna place la tête au milieu de son bouclier (ἀσπίς, pas l'égide) ;
#   - Ovide, Métamorphoses, IV, 802–803 : Minerve porte sur sa poitrine les serpents qu'elle a créés.
#   Lien avec `aegis` : variant (bouclier ou égide selon les sources).
sources:
  - { source: "Hésiode, Théogonie", locus: "v. 270–283", url: "https://www.theoi.com/Text/HesiodTheogony.html" }
  - { source: "Homère, Iliade", locus: "V, 738–742 (Gorgone sur l'égide, v. 741)", url: "https://www.theoi.com/Text/HomerIliad5.html" }
  - { source: "(Pseudo-)Hésiode, Bouclier d'Héraclès", locus: "v. 216–237", url: "https://www.theoi.com/Text/HesiodShield.html" }
  - { source: "Pindare, Pythiques", locus: "XII, 6–23 (« Méduse aux belles joues », v. 16)", url: "https://cts.perseids.org/read/greekLit/tlg0033/tlg002/perseus-eng3/12.1-12.30" }
  - { source: "(Pseudo-)Apollodore, Bibliothèque", locus: "II, 4, 2–3 (tête au milieu du bouclier d'Athéna, II, 4, 3)", url: "https://www.theoi.com/Text/Apollodorus2.html" }
  - { source: "Ovide, Métamorphoses (poète romain)", locus: "IV, 770–803 (serpents sur la poitrine de Minerve, IV, 802–803)", url: "https://www.thelatinlibrary.com/ovid/ovid.met4.shtml" }
  - { source: "M. Glennon, « Medusa in Ancient Greek Art », The Metropolitan Museum of Art", locus: "mars 2017", url: "https://www.metmuseum.org/en/essays/medusa-in-ancient-greek-art" }
review: { status: verified-ai, at: "2026-10-15", note: "Relecture humaine requise (fiche sensible)" }
```

### MDX

```mdx
---
name: Méduse
role: La Gorgone au regard qui pétrifie
hook: Un regard, et tu deviens statue. Tu pensais que Méduse n'était qu'un monstre ?
---

## En bref

- **Famille :** fille de Phorcys et Céto, deux divinités marines ; sœur de Sthéno et Euryale
- **Statut :** la seule Gorgone mortelle
- **Pouvoir :** quiconque la regarde est changé en pierre
- **Lieu :** au bout du monde, « au-delà de l'Océan », du côté de la Nuit
- **Vaincue par :** <E id="perseus">Persée</E>, avec l'aide d'<E id="athena">Athéna</E> et d'<E id="hermes">Hermès</E>
- **Enfants :** <E id="pegasus">Pégase</E> et <E id="chrysaor">Chrysaor</E>, nés quand Persée lui tranche la tête
- **Symbole :** sa tête, le gorgonéion, peinte ou sculptée sur les boucliers et les temples

## Son histoire

Elles sont trois sœurs, les Gorgones : Sthéno, Euryale et Méduse. Le poète grec Hésiode (vers 700 av. J.-C.) précise un détail qui change tout : Méduse est mortelle. Ses deux sœurs, elles, sont immortelles et ne vieillissent pas.

Hésiode dit seulement qu'elle « subit un sort funeste ». Il ne décrit pas son apparence. Elle s'unit au « dieu aux cheveux sombres », <E id="poseidon">Poséidon</E>, « dans une prairie tendre, parmi les fleurs du printemps ». Pas de temple, pas de punition : elle est Gorgone de naissance. (Citations traduites du grec par la rédaction.)

Bien plus tard, le mythographe — compilateur de mythes — Apollodore raconte la chasse. Lors d'un repas, Persée déclare qu'il pourrait rapporter la tête de la Gorgone. Le roi Polydectès le prend au mot. Des nymphes lui donnent des sandales ailées, une besace et le casque d'Hadès, qui rend invisible. Hermès ajoute une faucille en adamant, matériau légendaire réputé indestructible.

Persée surprend les Gorgones endormies. Athéna guide sa main ; lui regarde le reflet de Méduse dans un bouclier de bronze, et tranche. Pégase, le cheval ailé, et Chrysaor, le guerrier à l'épée d'or, jaillissent alors. De retour, Persée pétrifie Polydectès et ses invités. Puis il offre la tête à Athéna, qui la place au milieu de son bouclier.

## Ses pouvoirs

- Selon Apollodore, quiconque regarde les Gorgones — les trois sœurs, pas Méduse seule — est changé en pierre.
- Sa tête coupée garde ce pouvoir : Persée s'en sert contre Polydectès et ses invités.
- Apollodore leur prête des écailles de serpent sur la tête, des défenses de sanglier, des mains de bronze et des ailes d'or pour voler.
- Dans le *Bouclier d'Héraclès*, poème qui décrit une scène ciselée sur un bouclier, les deux autres Gorgones s'élancent à la poursuite de Persée.
- Même en image, sa tête protégeait : peint ou sculpté sur boucliers, casques et toits de temples, le gorgonéion devait, selon les historiens de l'art, repousser le mal.

<Versions title="Une histoire, plusieurs versions">
  <Version layer="ancient" source="Hésiode, Théogonie, v. 270–283 (trad. de la rédaction)">Méduse est Gorgone dès sa naissance, sans récit de transformation. Elle s'unit à Poséidon dans une prairie. Hésiode dit qu'elle « subit un sort funeste », mais ne décrit pas son apparence.</Version>
  <Version layer="ancient" source="Pindare, Pythiques, XII, 16 (vers 490 av. J.-C.)">Le poète grec Pindare l'appelle « Méduse aux belles joues ». Sa beauté est donc attestée près de cinq siècles avant Ovide.</Version>
  <Version layer="ancient" source="Apollodore, Bibliothèque, II, 4, 3">Apollodore rapporte que, selon certains, Athéna aurait voulu la mort de Méduse : la Gorgone prétendait rivaliser avec elle en beauté.</Version>
  <Version layer="ancient" source="Ovide, Métamorphoses, IV, 794–803 (poète romain, vers 8 apr. J.-C.)">Chez le poète romain Ovide, Méduse est d'abord une jeune femme d'une grande beauté. Le dieu de la mer, raconte-t-on, la viole dans le temple de Minerve (Athéna chez les Romains). La déesse détourne le regard, puis punit Méduse : ses cheveux deviennent des serpents. Version romaine tardive, pas « la » version grecque.</Version>
  <Version layer="interpretation">Depuis le XXe siècle, beaucoup de lectures font de Méduse une victime changée en monstre. Elles s'appuient surtout sur le récit d'Ovide. L'essai d'Hélène Cixous, *Le Rire de la Méduse* (1975), a par ailleurs fait d'elle un symbole féministe.</Version>
</Versions>

## Le saviez-vous ?

- **Une musique née d'une plainte.** Chez Pindare (Pythique XII, vers 490 av. J.-C.), Athéna transforme la plainte des Gorgones en air d'aulos, sorte de hautbois double. Elle le nomme l'air « aux nombreuses têtes ».
- **La plus ancienne mention.** Dans l'*Iliade* (V, 738–742), l'égide d'Athéna porte la tête de « la Gorgone ». Homère ne nomme pas Méduse et ne raconte pas son histoire.
- **Le reflet, un détail tardif.** Dans les textes, le bouclier-miroir n'apparaît que chez Ovide, puis Apollodore. Dans l'art grec archaïque, Persée détourne simplement la tête au moment de frapper.

## Dans la culture populaire

- **Percy Jackson et le Voleur de foudre** (Rick Riordan, 2005, tome 1) : Méduse se cache sous une fausse identité et tient une boutique de statues de jardin. Ses statues sont ses victimes pétrifiées.
- **Le Choc des Titans** (Desmond Davis, 1981) : la Méduse animée image par image par Ray Harryhausen est devenue culte. Le remake de 2010 (Louis Leterrier) reprend la scène du reflet dans le bouclier.
- **Hades** (Supergiant Games, 2020) : Dusa, une tête de Gorgone flottante, est femme de ménage dans le palais d'Hadès. Plus inoffensif, tu meurs.
- **Versace** : la maison de mode italienne a fait de la tête de Méduse son emblème.

## Pour aller plus loin

- <E id="perseus">Persée</E> — Le héros qui a tué Méduse sans jamais la regarder en face.
- <E id="pegasus">Pégase</E> — Le cheval ailé né au moment où tombe la tête de sa mère.
- <E id="athena">Athéna</E> — La déesse qui garde la Gorgone sur son bouclier et son égide.

## Sources

- Hésiode, *Théogonie*, v. 270–283 (vers 700 av. J.-C.)
- Homère, *Iliade*, V, 738–742 (vers le VIIIe siècle av. J.-C.)
- (Pseudo-)Hésiode, *Bouclier d'Héraclès*, v. 216–237 (fin VIIe – milieu VIe siècle av. J.-C.)
- Pindare, *Pythiques*, XII (vers 490 av. J.-C.)
- (Pseudo-)Apollodore, *Bibliothèque*, II, 4, 2–3 (Ier–IIe siècle apr. J.-C.)
- Ovide, *Métamorphoses*, IV, 770–803 (poète romain, vers 8 apr. J.-C.)
- M. Glennon, « Medusa in Ancient Greek Art », The Metropolitan Museum of Art, 2017
```

### Sources consultées

URL que j'ai visitées moi-même (v1) :
- https://www.theoi.com/Pontios/Gorgones.html — compilation des sources : parenté, mortalité, union avec Poséidon, Pégase/Chrysaor, Ovide (temple), Apollodore (objets, reflet, tête sur le bouclier), Iliade (égide), pétrification.
- https://www.theoi.com/Text/HesiodTheogony.html — Théogonie, bloc [270] : Gorgones, lieu, Méduse mortelle, « Dark-haired One » (note 14 : Poséidon), prairie, Chrysaor et Pégase à la décapitation.
- http://www.perseus.tufts.edu/hopper/text?doc=Perseus:text:1999.01.0130:card=270 — même passage (Evelyn-White).
- https://www.theatre-classique.fr/pages/pdf/HESIODE_THEOGONIE.pdf — ancienne traduction française (« Méduse était mortelle… », « Neptune aux noirs cheveux… molle prairie »).
- https://www.theoi.com/Text/Apollodorus2.html — Bibliothèque II, 4, 2–3 : Polydectès, filles de Phorcys, nymphes et objets, faucille d'Hermès, Athéna guide la main, bouclier de bronze, description des Gorgones, Pégase/Chrysaor par Poséidon, rivalité de beauté, tête au milieu du bouclier, pétrification.
- https://www.theoi.com/Text/OvidMetamorphoses4.html — Ovide, fin du livre IV (trad. Brookes More).
- https://www.thelatinlibrary.com/ovid/ovid.met4.shtml — latin et numéros de vers (775, 782–783, 786, 794, 798–803).
- https://www.theoi.com/Text/HomerIliad5.html — Iliade V : Gorgone sur l'égide.
- https://www.theoi.com/Text/HesiodShield.html — Bouclier d'Héraclès [216]–[237].
- https://www.theoi.com/Text/AeschylusPrometheus.html — Prométhée [790] (source retirée de la v2, non utilisée dans le texte).
- https://cts.perseids.org/read/greekLit/tlg0033/tlg002/perseus-eng3/12.1-12.30 — Pindare, Pythique XII (« beautiful Medusa », air « many-headed », Sériphos).
- https://en.wikipedia.org/wiki/Medusa — point de départ (date de la Pythique XII, Cixous, évolution iconographique).
- https://en.wikipedia.org/wiki/Gorgoneion — fonction apotropaïque, fronton de Corfou, Polygnotos, Méduse Rondanini.
- https://www.metmuseum.org/en/essays/medusa-in-ancient-greek-art — usage protecteur, évolution du monstrueux vers le beau, Persée qui détourne le regard.
- https://en.wikipedia.org/wiki/Perseus — Polydectès, variantes des donateurs.
- https://ebsco.com/research-starters/religion-and-philosophy/perseus-and-medusa — reflet chez Apollodore et Ovide.
- https://litcharts.com/lit/the-lightning-thief/chapter-11 — Percy Jackson, chap. 11.
- https://en.wikipedia.org/wiki/Dusa_(Hades) — Dusa dans Hades.
- https://en.wikipedia.org/wiki/Clash_of_the_Titans_(1981_film) et https://en.wikipedia.org/wiki/Clash_of_the_Titans_(2010_film) — réalisateurs, Harryhausen, reflet.
- https://www.adweek.com/brand-marketing/versaces-medusa-logo-breaks-every-design-rule-so-why-does-it-work/ et https://sixtysixmag.com/landing/what-does-the-versace-logo-mean/ — logo Versace.

Vérifications reprises du rapport du vérificateur (/home/claude/editorial/reviews/meduse.review.md), **non revisitées par moi** pour la v2 : texte grec numéroté d'Hésiode, d'Homère, du Bouclier, de Pindare et d'Apollodore (dépôts PerseusDL sur raw.githubusercontent.com) ; Wikipédia EN *Adamant*, *Aulos*, *Shield of Heracles*, *The Laugh of the Medusa*, *Metamorphoses*, *Versace* ; Britannica *Hesiod* et *Homer* ; Wikisource EN (Pindare, trad. Myers). Cela concerne en particulier : v. 270–283 et v. 276 (« sort funeste ») d'Hésiode, Iliade V, 738–742, Pythique XII, 16 (« aux belles joues ») et la date 490/494, la date du Bouclier, Cixous 1975, la glose de l'adamant et de l'aulos.

### Doutes

1. **« Subit un sort funeste »** (Hésiode, v. 276, λυγρὰ παθοῦσα) et **« aux belles joues »** (Pindare, v. 16, εὐπαράου) : traductions de la rédaction établies d'après le grec cité par le vérificateur ; je n'ai pas consulté moi-même le texte grec.
2. **Devenir de la tête dans le YAML** : aucun des types de relation autorisés (`owns`, `created`…) ne décrit « la tête sur l'égide/le bouclier ». J'ai consigné les trois nuances (Homère, Apollodore, Ovide) en commentaire et dans `sources`, sans relation vers `aegis`. Arbitrage à faire si le graphe doit porter ce lien.
3. **Format des relations** : j'ai ajouté un champ `from` pour respecter le sens « from → to ». Le gabarit du guide n'avait que `to` ; à valider.
4. **« Le saviez-vous ? »** : j'ai retiré l'anecdote « Laide, puis belle » (art archaïque vs Ve siècle, source : Met) pour rester à 3 anecdotes en ajoutant celle sur le reflet. Elle est vérifiée et peut être restaurée si le directeur accepte 4 anecdotes.
5. **Liens du brief** : `perseus-and-medusa` et `gorgons` ne figurent pas dans « Pour aller plus loin » (gabarit limité à 3 portes). À arbitrer.
6. **Accroche** : la v2 retire la mention « monstre de jeu vidéo » (glissement 🎬 signalé), au profit de l'angle « Tu pensais que… ».
7. **Typographie** : espaces insécables à contrôler au rendu.

### Changements v1 → v2

- Loci corrigés partout : Hésiode « v. 270–283 », Iliade « V, 738–742 », Apollodore noté « (Pseudo-)Apollodore » dans les Sources ; toutes les balises [À VÉRIFIER] levées par le rapport sont supprimées, dates intégrées (Pindare vers 490 av. J.-C., Bouclier fin VIIe–milieu VIe s., Cixous 1975, Homère « vers le VIIIe s. »).
- Pégase et Chrysaor : « nés de son cou » remplacé par « nés quand Persée lui tranche la tête » / « jaillissent alors ».
- Devenir de la tête précisé : bouclier chez Apollodore, serpents sur la poitrine chez Ovide, « la Gorgone » sur l'égide chez Homère (YAML et MDX) ; anecdote homérique reformulée sans « déjà ».
- Bouclier d'Héraclès : sœurs non nommées, scène ciselée, elles s'élancent (plus de vol) ; le vol est attribué à Apollodore.
- « Flûte » → « aulos, sorte de hautbois double » ; adamant → « matériau légendaire réputé indestructible ».
- Puce « pourtant » supprimée ; ajout d'une puce sur le gorgonéion protecteur (Met) et précision que la pétrification concerne les trois Gorgones chez Apollodore.
- Bloc `<Versions>` : ajout de Pindare (« Méduse aux belles joues ») ; Hésiode cité avec « subit un sort funeste » ; suppression de « monstre dès l'origine » ; Cixous dissociée d'Ovide ; version d'Ovide raccourcie à moins de 60 mots, avec « raconte-t-on ».
- Nouveau « Le saviez-vous ? » sur le reflet, détail tardif ; anecdotes ramenées sous 35 mots ; « Laide, puis belle » retirée.
- Citations d'Hésiode signalées comme traductions de la rédaction ; épisode de Polydectès précisé (Persée se dit capable de rapporter la tête, le roi le prend au mot).
- Percy Jackson : nom de la tante supprimé (fausse identité, tome 1) ; Hades : « flottante » au lieu de « volante ».
- YAML : relations réécrites avec les seuls types autorisés et les ids validés (filiation Poséidon/Méduse → Pégase, Chrysaor ; helped, defeated, punished, enemy-of) ; Eschyle retiré (non utilisé), essai du Met ajouté ; balises `<E>` pour Hermès et Chrysaor.
