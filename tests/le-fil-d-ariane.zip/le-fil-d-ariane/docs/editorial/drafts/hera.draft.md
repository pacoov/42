# Livrable rédacteur — Fiche « Héra » (lot 1, vague A) — draft

### YAML

```yaml
id: hera
type: deity
category: gods
names:
  greek: Ἥρα
  transliteration: Hera
  roman: Iuno
  aliases: [Héra, Hera, Junon, Juno, Hérê]
era: olympians
importance: 1
deity:
  domains: [marriage, married-women, childbirth]
  symbols: [pomegranate, cuckoo, diadem, cow, peacock]
  # pomegranate, cuckoo, couronne : Pausanias II, 17, 4 (statue de Polyclète, Héraion d'Argos)
  # cow : lien attesté par l'épithète boôpis et le mythe d'Io (Apollodore II, 1, 3) ; « animal surtout sacré » selon Britannica
  # peacock : sacré à Samos selon Ménodote cité par Athénée (vers 200 apr. J.-C.) ; yeux d'Argos = Ovide (romain)
  olympian: true
  residence: mount-olympus
  epithets:
    - { greek: βοῶπις, transliteration: boôpis, source: "Homère, Iliade, I, 551 (et passim)" }
    - { greek: λευκώλενος, transliteration: leukôlenos, source: "Homère, Iliade, I, 55" }
    - { greek: χρυσοπέδιλος, transliteration: chrysopedilos, source: "Hésiode, Théogonie, v. 454" }
    - { greek: χρυσόθρονος, transliteration: chrysothronos, source: "Hymne homérique XII (À Héra), v. 1" }
relations:                 # sens : from → to
  - { from: cronos, to: hera, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–454 ; Homère, Iliade, IV, 59 ; Apollodore, Bibliothèque, I, 1, 5" }
  - { from: rhea, to: hera, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–454 ; Hymne homérique XII, v. 1" }
  - { from: hera, to: zeus, type: sibling-of, certainty: canonical, source: "Homère, Iliade, XVI, 432 et XVIII, 356 (« sœur et épouse ») ; Hymne homérique XII, v. 3" }
  - { from: hera, to: hestia, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–457" }
  - { from: hera, to: demeter, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–457" }
  - { from: hera, to: hades, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–457" }
  - { from: hera, to: poseidon, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–457" }
  - { from: hera, to: zeus, type: spouse-of, certainty: canonical, source: "Hésiode, Théogonie, v. 921 ; Apollodore, Bibliothèque, I, 3, 1" }
  - { from: hera, to: ares, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 922–923 ; Apollodore, Bibliothèque, I, 3, 1" }
  - { from: hera, to: hebe, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 922–923 ; Apollodore, Bibliothèque, I, 3, 1" }
  - { from: hera, to: eileithyia, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 922–923 ; Homère, Iliade, XI, 270–271 (Ilithyies au pluriel)" }
  - { from: zeus, to: ares, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 921–923" }
  - { from: zeus, to: hebe, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 921–923 et 952" }
  - { from: zeus, to: eileithyia, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 921–923" }
  - { from: hera, to: hephaestus, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 927–929 ; Homère, Iliade, I, 571–572 ; Apollodore, Bibliothèque, I, 3, 5" }
  - { from: zeus, to: hephaestus, type: parent-of, certainty: variant, source: "Homère, Iliade, I, 577–578 ; Odyssée, VIII, 312 ; Apollodore, I, 3, 5 (« selon Homère »). Contra : Hésiode, Théogonie, v. 927–929 (Héra seule)" }
  - { from: hera, to: typhon, type: parent-of, certainty: variant, source: "Hymne homérique à Apollon, v. 305–355. Contra : Hésiode, Théogonie, v. 820–822 (fils de Gaïa et du Tartare)" }
  - { from: hera, to: heracles, type: enemy-of, certainty: canonical, source: "Homère, Iliade, XIX, 95–124 et XV, 25–30 ; Hésiode, Théogonie, v. 313–315 ; Apollodore, II, 4, 8 et II, 4, 12" }
  - { from: heracles, to: hera, type: enemy-of, certainty: canonical, source: "Homère, Iliade, V, 392–394 (il la blesse d'une flèche)" }
  - { from: hera, to: leto, type: enemy-of, certainty: canonical, source: "Apollodore, Bibliothèque, I, 4, 1" }
  - { from: hera, to: io, type: punished, certainty: canonical, source: "Apollodore, Bibliothèque, II, 1, 3 (le taon)" }
  - { from: zeus, to: hera, type: punished, certainty: canonical, source: "Homère, Iliade, XV, 18–24 ; Apollodore, Bibliothèque, I, 3, 5 et II, 7, 1" }
  - { from: hera, to: mount-olympus, type: lives-in, certainty: canonical, source: "Hymne homérique XII, v. 4–5" }
# Réconciliation Héra–Héraclès et mariage avec Hébé : Apollodore II, 7, 7 ; Hésiode, Théogonie, v. 950–953
# (relation heracles spouse-of hebe : à porter sur la fiche Héraclès, hors périmètre).
sources:
  - { source: "Hésiode, Théogonie", locus: "v. 313–315, 453–467, 492–497, 820–822, 921–929, 950–953", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml" }
  - { source: "Homère, Iliade", locus: "I, 55, 551, 571–594 ; IV, 50–61 ; V, 392–394 ; XI, 269–272 ; XIV, 153–351 ; XV, 18–30 ; XVI, 432 ; XVIII, 356, 394–399 ; XIX, 95–124", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml" }
  - { source: "Homère, Odyssée", locus: "VIII, 308–312", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg002/tlg0012.tlg002.perseus-grc2.xml" }
  - { source: "Hymne homérique XII, À Héra", locus: "v. 1–5", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg012/tlg0013.tlg012.perseus-grc2.xml" }
  - { source: "Hymne homérique III, À Apollon", locus: "v. 305–355", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg003/tlg0013.tlg003.perseus-grc2.xml" }
  - { source: "Hérodote, Histoires", locus: "III, 60, 4", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0016/tlg001/tlg0016.tlg001.perseus-eng2.xml" }
  - { source: "Diodore de Sicile, Bibliothèque historique", locus: "IV, 9, 6 et IV, 10, 1", url: "https://penelope.uchicago.edu/Thayer/E/Roman/Texts/Diodorus_Siculus/4B*.html" }
  - { source: "Ovide, Métamorphoses (poète romain)", locus: "I, 720–723 ; II, 531–533", url: "https://www.thelatinlibrary.com/ovid/ovid.met1.shtml" }
  - { source: "(Pseudo-)Apollodore, Bibliothèque", locus: "I, 1, 5 ; I, 3, 1 ; I, 3, 5 ; I, 4, 1 ; II, 1, 3 ; II, 4, 5 ; II, 4, 8 ; II, 4, 12 ; II, 7, 1 ; II, 7, 7", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-grc2.xml" }
  - { source: "Pausanias, Description de la Grèce", locus: "II, 17, 4 ; VII, 4, 4 ; VIII, 22, 2", url: "https://www.theoi.com/Text/Pausanias2B.html" }
  - { source: "Athénée, Deipnosophistes (citant Ménodote de Samos)", locus: "XIV, 70–71 (numérotation Perseus)", url: "https://cts.perseids.org/read/greekLit/tlg0008/tlg001/perseus-eng2/14.70-14.71" }
  - { source: "S. Bär, compte rendu de E. Stafford, Herakles (2012), Ancient History Bulletin Online Reviews 4", locus: "2014, p. 111–115", url: "https://ancienthistorybulletin.org/wp-content/uploads/2014/09/AHBReviewsBärOnStafford.pdf" }
review: { status: draft }
```

### MDX

```mdx
---
name: Héra
role: La reine des dieux, déesse du mariage
hook: Tout le monde la connaît comme « l'épouse jalouse ». Les Grecs, eux, lui ont bâti l'un des plus grands temples de leur monde.
---

## En bref

- **Famille :** fille de <E id="cronos">Cronos</E> et <E id="rhea">Rhéa</E> ; sœur et épouse de <E id="zeus">Zeus</E>
- **Domaines :** le mariage, les femmes mariées, les naissances
- **Enfants :** <E id="ares">Arès</E>, <E id="hebe">Hébé</E>, <E id="eileithyia">Ilithyie</E> ; <E id="hephaestus">Héphaïstos</E>, avec ou sans Zeus selon les versions
- **Lieux :** l'<E id="mount-olympus">Olympe</E> ; ses grands sanctuaires d'Argos et de Samos
- **Symboles :** grenade, coucou, couronne, vache… et le paon
- **Chez les Romains :** Junon

## Son histoire

Chez le poète grec Hésiode (vers 700 av. J.-C.), Héra naît de Cronos et Rhéa. Son père avale ses enfants un à un, de peur d'être détrôné. Recrachée plus tard, elle devient la dernière épouse de Zeus, son frère. Ils ont trois enfants : Hébé, la Jeunesse, Arès, la guerre, et Ilithyie, déesse des accouchements.

Dans l'*Iliade* d'Homère (vers le VIIIe siècle av. J.-C.), elle tient tête à son mari. Elle soutient les Grecs contre Troie. Elle emprunte même à <E id="aphrodite">Aphrodite</E> une bande brodée qui rend irrésistible, pour séduire Zeus et l'endormir. Zeus, lui, lui rappelle qu'il l'a déjà suspendue dans le ciel, deux enclumes aux pieds.

Sa colère vise surtout les femmes que Zeus approche, et leurs enfants. Selon le mythographe — compilateur de mythes — Apollodore, elle pourchasse <E id="leto">Léto</E> sur toute la terre. Zeus abuse d'Io, une prêtresse d'Héra, puis la change en vache. Héra la fait surveiller, puis la harcèle avec un taon. Elle frappe la victime, pas le coupable.

Sa cible favorite reste <E id="heracles">Héraclès</E>, fils de Zeus et d'une mortelle. Dans l'*Iliade*, elle retarde sa naissance pour qu'un autre, Eurysthée, règne à sa place. Apollodore ajoute des serpents dans son berceau et une folie où le héros tue ses enfants. Après la mort d'Héraclès, les deux se réconcilient.

## Ses pouvoirs

- Elle veille sur les naissances : dans l'*Iliade*, les Ilithyies, qui envoient les douleurs de l'accouchement, sont « filles d'Héra ».
- Elle peut aussi les bloquer : elle retient les Ilithyies pour retarder la naissance d'Héraclès (*Iliade*, XIX).
- Elle sait enfanter seule : Héphaïstos chez Hésiode, le monstre Typhon dans l'*Hymne homérique à Apollon* (chez Hésiode, Typhon est fils de Gaïa).
- Elle déchaîne les vents : elle envoie une tempête contre Héraclès au retour de Troie (*Iliade*, XV ; Apollodore).
- Elle élève des monstres : selon Hésiode, elle nourrit l'Hydre de Lerne par rancune contre Héraclès.

<Versions title="Héphaïstos : qui est son père ?">
  <Version layer="ancient" source="Hésiode, Théogonie, v. 927–929">Héra met au monde Héphaïstos seule, sans s'unir à personne. Elle le fait par colère, en pleine querelle avec son époux, qui vient d'enfanter Athéna de sa tête.</Version>
  <Version layer="ancient" source="Homère, Iliade, I, 571–578 ; Odyssée, VIII, 312">Héphaïstos appelle Héra « mère chérie » et Zeus « père chéri ». Dans l'*Odyssée*, il accuse ses « deux parents » de l'avoir fait naître boiteux.</Version>
  <Version layer="ancient" source="Hymne homérique à Apollon, v. 316–320 ; Iliade, XVIII, 395–397">Héra dit avoir enfanté seule un fils aux pieds tordus, puis l'avoir jeté à la mer. La Néréide Thétis le recueille. L'*Iliade* évoque aussi une mère qui voulait le cacher parce qu'il boitait.</Version>
  <Version layer="ancient" source="Homère, Iliade, I, 590–594">Autre chute, autre coupable : ici, c'est Zeus qui le jette du ciel, parce qu'il défendait sa mère. Il tombe sur l'île de Lemnos.</Version>
  <Version layer="ancient" source="Apollodore, Bibliothèque, I, 3, 5 (Ier–IIe siècle apr. J.-C.)">Apollodore aligne les deux récits : Héra l'enfante sans union, « mais selon Homère », elle l'a eu de Zeus.</Version>
</Versions>

<Versions title="Héraclès, « gloire d'Héra » ?">
  <Version layer="ancient" source="Diodore de Sicile, Bibliothèque historique, IV, 10, 1 (Ier siècle av. J.-C.)">Le bébé s'appelait d'abord Alcée. Après l'épisode des serpents, les Argiens l'auraient renommé Héraclès, car il avait acquis la gloire (kléos) grâce à Héra.</Version>
  <Version layer="ancient" source="Apollodore, Bibliothèque, II, 4, 12">Autre version : c'est la Pythie, la prêtresse de Delphes, qui l'appelle Héraclès pour la première fois. Avant, on le nommait Alcide.</Version>
  <Version layer="ancient" source="Etymologicum Magnum (dictionnaire byzantin, vers 1150)">Ce dictionnaire rejette déjà « gloire d'Héra » et propose d'autres explications, dont un nom de « déshonneur venu d'Héra ».</Version>
  <Version layer="interpretation">Pour les chercheurs, l'origine du nom reste discutée. Le philologue Silvio Bär (2014) parle d'une « question épineuse » : le nom pourrait signifier « gloire obtenue par Héra » plutôt que « gloire d'Héra ».</Version>
</Versions>

## Le saviez-vous ?

- **« Aux yeux de vache », un compliment.** Homère appelle souvent Héra *boôpis*. Le mot signifie « aux grands yeux », et Homère l'applique aussi à des mortelles, comme Clyméné, servante d'Hélène (*Iliade*, III, 144).
- **Coucou avant paon.** Sa statue d'Argos tenait une grenade et un sceptre surmonté d'un coucou (Pausanias, IIe s. apr. J.-C.). Les yeux d'Argos sur la queue du paon viennent du poète romain Ovide.
- **Trois Héra en une.** À Stymphale, en Arcadie, Pausanias décrit trois sanctuaires : Héra « Fille », Héra « Femme accomplie », et Héra « Veuve », après une dispute avec Zeus.

## Dans la culture populaire

- **Hercule** (Disney, 1997) : Héra devient la mère aimante d'Hercule, aux côtés de Zeus. Inversion totale du mythe : selon le coréalisateur Ron Clements, l'enfant illégitime était un sujet difficile pour Disney.
- **Héros de l'Olympe** (Rick Riordan) : dans le tome 1 (2010), Héra est prisonnière de Gaïa. Trois jeunes demi-dieux, dont Jason, son champion, partent la délivrer.
- **God of War III** (Santa Monica Studio, 2010) : Héra y apparaît en reine ivre et méprisante. Kratos la tue, et toute vie végétale disparaît avec elle.

## Pour aller plus loin

- <E id="zeus">Zeus</E> — Son frère, son mari, et la source de presque toutes ses colères.
- <E id="heracles">Héraclès</E> — Le héros qu'elle a persécuté du berceau jusqu'au bûcher.
- <E id="hephaestus">Héphaïstos</E> — Le fils qu'elle a peut-être fait seule… et jeté du ciel.

## Sources

- Homère, *Iliade* et *Odyssée* (vers le VIIIe siècle av. J.-C.)
- Hésiode, *Théogonie*, v. 313–315, 453–497, 820–822, 921–929, 950–953 (vers 700 av. J.-C.)
- *Hymne homérique XII, À Héra* (VIIe–VIe siècle av. J.-C.) et *Hymne homérique à Apollon*, v. 305–355 (VIe siècle av. J.-C.)
- Hérodote, *Histoires*, III, 60, 4 (Ve siècle av. J.-C.)
- Diodore de Sicile, *Bibliothèque historique*, IV, 9–10 (Ier siècle av. J.-C.)
- Ovide, *Métamorphoses*, I, 720–723 ; II, 531–533 (poète romain, vers 8 apr. J.-C.)
- (Pseudo-)Apollodore, *Bibliothèque*, I, 1, 5 – II, 7, 7 (Ier–IIe siècle apr. J.-C.)
- Pausanias, *Description de la Grèce*, II, 17, 4 ; VII, 4, 4 ; VIII, 22, 2 (IIe siècle apr. J.-C.)
- Athénée, *Deipnosophistes*, XIV (vers 200 apr. J.-C.), citant Ménodote de Samos
- *Etymologicum Magnum* (vers 1150), s. v. Héraclès
- S. Bär, compte rendu de E. Stafford, *Herakles*, *Ancient History Bulletin Online Reviews* 4, 2014
```

### Sources consultées

Textes antiques (lus directement) :
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml — Théogonie, grec numéroté : v. 313–318 (Héra nourrit l'Hydre par rancune contre Héraclès), 453–458 (Rhéa enfante Hestia, Déméter, Héra « aux sandales d'or », Hadès, Poséidon, Zeus), 459–467 (Cronos avale ses enfants, peur d'être détrôné), 492–497 (il les recrache), 820–822 (Typhon fils de Gaïa et du Tartare), 886–921 (Héra « en dernier » épouse de Zeus, v. 921), 922–923 (Hébé, Arès, Ilithyie), 924–929 (Athéna de la tête ; Héphaïstos sans union, par colère et querelle ; variante 929a–t), 950–953 (Héraclès épouse Hébé).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-eng2.xml — traduction anglaise (téléchargée, contrôle ponctuel).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml — Iliade, grec numéroté : I, 55 (λευκώλενος, soutien aux Danaens), I, 551 (βοῶπις πότνια Ἥρη), I, 571–579 (Héphaïstos : « mère chérie », « père chéri »), I, 586–594 (Zeus jette Héphaïstos, chute sur Lemnos) ; III, 144, VII, 10, XVIII, 40 (βοῶπις pour des mortelles et une Néréide) ; IV, 50–61 (Argos, Sparte, Mycènes ; « Cronos m'engendra… ») ; V, 392–394 (Héraclès blesse Héra d'une flèche) ; XI, 269–272 (Ilithyies « filles d'Héra ») ; XIV, 153–217 (projet de séduire Zeus, ceinture/bande d'Aphrodite), 294–296, 338–339 (« ton fils Héphaïstos »), 346–351 ; XV, 18–30 (Héra suspendue avec deux enclumes ; tempête contre Héraclès, Cos) ; XVI, 432 et XVIII, 356 (« sœur et épouse ») ; XVIII, 394–399 (mère qui voulait le cacher, boiteux ; Eurynomé et Thétis) ; XIX, 95–124 (Héra trompe Zeus, retient les Ilithyies, Eurysthée né à sept mois).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg002/tlg0012.tlg002.perseus-grc2.xml — Odyssée VIII, 308–312 (« mes deux parents »).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg012/tlg0013.tlg012.perseus-grc2.xml et …perseus-eng2.xml — Hymne XII, v. 1–5 (fille de Rhéa, « au trône d'or », reine des immortels, sœur et épouse de Zeus, honorée dans l'Olympe).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg003/tlg0013.tlg003.perseus-grc2.xml — Hymne à Apollon v. 305–355 (colère d'Héra après la naissance d'Athéna ; Héphaïstos aux pieds tordus « que j'ai enfanté moi-même », jeté à la mer, recueilli par Thétis ; Héra enfante Typhaon seule et le confie à la dragonne).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-grc2.xml — Apollodore, grec : I, 1, 5–6 ; I, 3, 1 ; I, 3, 5 (Héphaïstos sans union / « selon Homère » de Zeus ; Héra suspendue pour la tempête contre Héraclès ; Thétis) ; I, 4, 1 (Léto chassée) ; I, 6, 2 ; II, 1, 3 (Io prêtresse d'Héra, vache blanche, Argos Panoptès, Hermès, taon) ; II, 4, 5 (Ilithyie, Eurysthée à sept mois) ; II, 4, 8 (serpents ; variante de Phérécyde) ; II, 4, 12 (folie, la Pythie le nomme Héraclès, avant Alcide) ; II, 7, 1 ; II, 7, 7 (réconciliation, Hébé).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0016/tlg001/tlg0016.tlg001.perseus-eng2.xml — Hérodote III, 60, 4 (le temple de Samos, « le plus grand de tous les temples que nous connaissions », premier architecte Rhoécos).
- https://www.thelatinlibrary.com/ovid/ovid.met1.shtml — Ovide, Mét. I, 720–723 (yeux d'Argos placés sur les plumes de l'oiseau de Saturnia ; le paon n'est pas nommé).
- https://www.thelatinlibrary.com/ovid/ovid.met2.shtml — Mét. II, 531–533 (char tiré par des paons).
- https://www.theoi.com/Text/Pausanias2B.html — Pausanias II, 17, 1 et 17, 4 (Héraion : statue de Polyclète en or et ivoire, couronne avec Charites et Heures, grenade « mystère sacré », coucou sur le sceptre, Zeus changé en coucou).
- https://www.theoi.com/Text/Pausanias7A.html — Pausanias VII, 4, 4 (Héra née à Samos, près de l'Imbrasos, sous un gattilier).
- https://www.theoi.com/Text/Pausanias8B.html — Pausanias VIII, 22, 2 (Stymphale : « Girl », « Grown-up », « Widow », trad. Jones).
- https://penelope.uchicago.edu/Thayer/E/Roman/Texts/Diodorus_Siculus/4B*.html — Diodore IV, 9, 6 (Héra allaite le bébé et le rejette) ; IV, 10, 1 (les Argiens le nomment Héraclès, gloire acquise grâce à Héra ; auparavant Alcée).
- https://cts.perseids.org/read/greekLit/tlg0008/tlg001/perseus-eng2/14.70-14.71 — Athénée citant Ménodote de Samos : paons sacrés à Junon/Héra, Samos peut-être lieu d'origine.
- https://cts.perseids.org/read/greekLit/tlg0008/tlg001/perseus-eng2/14.71-14.75 — section voisine (sans paon).

Références :
- https://www.theoi.com/Olympios/Hera.html — attributs, cultes, sources citées (grenade, coucou, couronne ; Argos, Samos ; Ilithyies).
- https://en.wikipedia.org/wiki/Hera — point de départ : étymologie obscure de « Héra », boôpis, Stymphale, Héraion de Samos et d'Olympie.
- https://www.britannica.com/topic/Hera — domaines (mariage, vie des femmes, naissance), Junon, Argos et Samos, vache, « d'abord le coucou, plus tard le paon ».
- https://lsj.gr/wiki/βοῶπις — « aux grands yeux », usages (Il. III, 144 ; VII, 10 ; XVIII, 40).
- https://en.wikipedia.org/wiki/Heracles — nom Alcée/Alcide, glose « gloire d'Héra ».
- https://ancienthistorybulletin.org/wp-content/uploads/2014/09/AHBReviewsBärOnStafford.pdf — S. Bär, « vexed question » du nom d'Héraclès, alternative « gloire obtenue par Héra ».
- https://sententiaeantiquae.com/tag/hercules/ — étymologies de l'Etymologicum Magnum (rejet de « gloire d'Héra », « déshonneur venu d'Héra »).
- https://en.wikipedia.org/wiki/Etymologicum_Magnum — date (vers 1150, Constantinople).
- https://en.wikipedia.org/wiki/Eileithyia — filiation, Ilithyies.
- https://en.wikipedia.org/wiki/Homeric_Hymns — datations (Hymne XII : VIIe–VIe s. ; Hymne à Apollon : 522 av. J.-C. dans le tableau).
- https://en.wikipedia.org/wiki/Heraion_of_Samos — Hérodote, Rhoécos, naissance sous le gattilier.
- https://www.britannica.com/biography/Pausanias-Greek-geographer, https://www.britannica.com/biography/Diodorus-Siculus, https://www.britannica.com/biography/Athenaeus — dates.
- https://en.wikipedia.org/wiki/Hercules_(1997_film) — Héra mère d'Hercule, voix de Samantha Eggar, propos de Ron Clements, réalisateurs Musker et Clements.
- https://en.wikipedia.org/wiki/The_Lost_Hero — 2010, Héra captive de Gaïa, Jason/Piper/Leo, Jason champion d'Héra.
- https://en.wikipedia.org/wiki/God_of_War_III — 2010, Santa Monica Studio, « drunken Hera », tuée par Kratos, fin de la vie végétale.
- https://en.wikipedia.org/wiki/Hades_(video_game) — Héra non mentionnée : œuvre non retenue.

Accès échoués : perseus.tufts.edu (robots), theoi.com/Text/HomericHymns2.html (mauvaise page), Wiktionary (erreur), www.thelatinlibrary.com en curl (proxy ; lu via WebFetch).

### Doutes

1. **Numéros de vers d'Ovide** : I, 720 est marqué dans l'édition consultée ; 722–723 et II, 531–533 sont déduits des repères tous les cinq vers. À contrôler sur une édition numérotée.
2. **Hymne à Apollon** : les v. 316–320 (Héphaïstos jeté à la mer, Thétis) sont lus dans le grec numéroté (Perseus) ; le v. 317a est une conjecture d'éditeur, non utilisée. La date de 522 av. J.-C. (Wikipédia) vaut pour l'hymne entier ; j'écris prudemment « VIe siècle av. J.-C. ».
3. **Traductions** : « mère chérie », « père chéri », « deux parents », « filles d'Héra », « sœur et épouse » sont des traductions de la rédaction, faites sur le grec lu. Les noms des sanctuaires de Stymphale (« Fille », « Femme accomplie », « Veuve ») viennent de la traduction anglaise de Jones (Girl, Grown-up, Widow) ; le grec (Pais, Teleia, Chèra selon Wikipédia) n'a pas été vérifié dans Pausanias.
4. **« Bande brodée » d'Aphrodite** (κεστὸς ἱμάς, Il. XIV, 214) : traduite d'après le grec ; souvent rendue par « ceinture ». À valider.
5. **Couronne ou diadème** : Pausanias parle d'une couronne (trad. anglaise « crown »). Le brief dit « diadème » ; le terme ne vient que d'un dictionnaire moderne. J'ai écrit « couronne » dans le MDX et gardé `diadem` dans les symboles du YAML. Arbitrage à faire.
6. **Vache** : aucune source antique directe pour « la vache, animal d'Héra » ; seulement l'épithète, Io (Apollodore) et Britannica. Rien n'est affirmé dans le MDX au-delà de « Symboles : vache ».
7. **Paon** : Ménodote de Samos, cité par Athénée, n'est pas daté par mes sources ; la trad. anglaise écrit « Juno ». Je présente le paon comme symbole sans dater son apparition, et je réserve la seule histoire des yeux d'Argos à Ovide.
8. **Iliade, IV, 59** (πρεσβυτάτην, « la plus âgée » ou « la plus vénérable ») : non exploité, mais cité en source de filiation. Hésiode cite Hestia en premier ; Apollodore dit Hestia avalée en premier.
9. **« Zeus abuse d'Io »** : le verbe d'Apollodore (ἔφθειρε) signifie « séduire, déshonorer ». Ma formulation est volontairement nette (règle anti-romantisation) ; à valider par le directeur pour une fiche sensible.
10. **Héros de l'Olympe** : le titre français « Le Héros perdu » vient seulement des résultats de recherche (non retenu dans le texte). Le rôle de Jason comme « champion » d'Héra vient de Wikipédia EN.
11. **Hades (jeu)** : non retenu, car la page consultée ne mentionne pas Héra.
12. **Nouveaux ids** hors liste du lot : `aphrodite`, `leto`, `hebe`, `eileithyia`, `io`, `typhon`. À créer ou valider dans le graphe central.
13. **Relation `heracles → hera` (enemy-of)** et **`zeus → hera` (punished)** : choix de typage à valider.
14. **Domaine « reine des dieux »** : il n'y a pas de clé `queenship` ; je l'ai laissé hors de `domains`. À arbitrer.
15. **Typographie** : espaces insécables insérées automatiquement ; à contrôler au rendu.
