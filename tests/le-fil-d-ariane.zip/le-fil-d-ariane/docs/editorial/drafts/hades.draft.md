# Livrable rédacteur — Fiche « Hadès » — Lot 1, vague A — draft v1

### YAML

```yaml
id: hades
type: deity
category: gods
names:
  greek: ᾍδης              # forme épique : Ἀΐδης ; aussi Ἀιδωνεύς (Aïdoneus)
  transliteration: Hadēs
  roman: Pluto              # les Romains disent aussi Dis (Ovide) et Orcus (Cicéron)
  aliases: [Hadès, Aïdoneus, Pluton, Ploutôn, Polydegmôn, Zeus souterrain, Dis, Orcus]
era: olympians
importance: 1
deity:                      # spécialisation proposée (le guide ne donne que le gabarit `creature`) — à valider
  domains: [monde souterrain, morts, richesses du sous-sol]
  symbols: [helm-of-hades, cerberus]   # kunée (casque d'invisibilité), Cerbère
  olympian: false           # vit sous la terre (Hésiode, Théogonie, v. 455) ; rarement compté parmi les Douze
relations:                  # sens : from → to
  - { from: cronos, to: hades, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–455 ; Homère, Iliade, XV, 187–188 ; Apollodore, Bibliothèque, I, 1, 5" }
  - { from: rhea, to: hades, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–455 ; Homère, Iliade, XV, 187–188" }
  - { from: hades, to: zeus, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–457 ; Homère, Iliade, XV, 187–188" }
  - { from: hades, to: poseidon, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–456 ; Homère, Iliade, XV, 187–188" }
  - { from: hades, to: hera, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–455" }
  - { from: hades, to: demeter, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–455" }
  - { from: hades, to: hestia, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–455" }
  - { from: hades, to: persephone, type: spouse-of, certainty: canonical, source: "Hésiode, Théogonie, v. 767–768, 913–914 ; Hymne homérique à Déméter, v. 79, 343" }
  # Union non consentie au départ (enlèvement, Hymne à Déméter, v. 19 « contre son gré ») : PAS de lover-of.
  - { from: zeus, to: hades, type: helped, certainty: canonical, source: "Hymne homérique à Déméter, v. 3, 8–9, 77–79 ; Hésiode, Théogonie, v. 914 ; Apollodore, Bibliothèque, I, 5, 1 (enlèvement de Perséphone)" }
  - { from: cyclopes, to: hades, type: helped, certainty: variant, source: "Apollodore, Bibliothèque, I, 2, 1 (lui donnent le casque pendant la guerre contre les Titans)" }
  - { from: hades, to: helm-of-hades, type: owns, certainty: canonical, source: "Homère, Iliade, V, 845 (« le casque d'Hadès ») ; Bouclier d'Héraclès, v. 227 ; Apollodore, Bibliothèque, I, 2, 1" }
  - { from: hades, to: cerberus, type: owns, certainty: canonical, source: "Hésiode, Théogonie, v. 311 (« le chien d'Hadès ») ; Apollodore, Bibliothèque, II, 5, 12" }
  - { from: hades, to: underworld, type: lives-in, certainty: canonical, source: "Hésiode, Théogonie, v. 455 ; Homère, Iliade, XV, 191" }
  - { from: hades, to: titans, type: enemy-of, certainty: canonical, source: "Apollodore, Bibliothèque, I, 2, 1 (les enfants recrachés font la guerre aux Titans avec Zeus)" }
  - { from: heracles, to: hades, type: enemy-of, certainty: variant, source: "Homère, Iliade, V, 395–402 (le blesse d'une flèche à Pylos) ; Apollodore, Bibliothèque, II, 5, 12 (Hadès lui laisse emmener Cerbère : relation ambivalente)" }
# Non exprimé faute de type adapté : le partage du monde (tirage au sort) — voir sources ; Hermès envoyé par Zeus pour ramener Perséphone (Hymne, v. 334–356).
sources:
  - { source: "Hésiode, Théogonie", locus: "v. 139–141, 211–212, 310–312, 453–506, 758–774, 881–885, 912–914", url: "https://www.theoi.com/Text/HesiodTheogony.html" }
  - { source: "Homère, Iliade", locus: "V, 395–402 et 844–845 ; IX, 158–159 et 457 ; XV, 187–193 ; XX, 61–65 ; XXIII, 19", url: "https://www.theoi.com/Text/HomerIliad15.html" }
  - { source: "Hymne homérique à Déméter", locus: "v. 1–20, 77–87, 334–374, 393–400, 411–413, 445–447", url: "https://www.theoi.com/Text/HomericHymns1.html" }
  - { source: "(Pseudo-)Hésiode, Bouclier d'Héraclès", locus: "v. 226–227", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg003/tlg0020.tlg003.perseus-grc2.xml" }
  - { source: "Eschyle, Euménides", locus: "v. 273–275", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0085/tlg007/tlg0085.tlg007.perseus-grc2.xml" }
  - { source: "Eschyle, Suppliantes", locus: "v. 230–231", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0085/tlg001/tlg0085.tlg001.perseus-grc2.xml" }
  - { source: "Platon, Cratyle", locus: "403a", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0059/tlg005/tlg0059.tlg005.perseus-grc2.xml" }
  - { source: "Platon, Lois", locus: "VIII, 828c", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0059/tlg034/tlg0059.tlg034.perseus-grc2.xml" }
  - { source: "(Pseudo-)Apollodore, Bibliothèque", locus: "I, 1, 5–7 ; I, 2, 1 ; I, 5, 1–3 ; II, 5, 12", url: "https://www.theoi.com/Text/Apollodorus1.html" }
  - { source: "Pausanias, Description de la Grèce", locus: "VI, 25, 2–3", url: "https://www.theoi.com/Text/Pausanias6B.html" }
  - { source: "Ovide, Métamorphoses (poète romain)", locus: "V, 366–383, 536–539, 565–567", url: "https://www.thelatinlibrary.com/ovid/ovid.met5.shtml" }
review: { status: draft }
```

### MDX

```mdx
---
name: Hadès
role: Le roi des morts, maître du monde souterrain
hook: Spoiler : Hadès n'est pas le méchant. Il garde les morts… et ne laisse sortir personne.
---

## En bref

- **Famille :** fils de <E id="cronos">Cronos</E> et <E id="rhea">Rhéa</E> ; frère de <E id="zeus">Zeus</E>, <E id="poseidon">Poséidon</E>, <E id="hera">Héra</E>, <E id="demeter">Déméter</E> et <E id="hestia">Hestia</E>
- **Domaine :** le monde des morts, sous la terre
- **Épouse :** <E id="persephone">Perséphone</E>, fille de Déméter
- **Autres noms :** Aïdoneus ; Pluton (Ploutôn, « le riche ») ; chez les Romains, Pluton, Dis ou Orcus
- **Attributs :** la kunée, casque qui rend invisible ; le chien <E id="cerberus">Cerbère</E>
- **N'est pas :** la Mort en personne — c'est <E id="thanatos">Thanatos</E>, fils de la Nuit
- **Olympien ?** Rarement compté parmi les Douze : il vit sous la terre, pas sur l'<E id="mount-olympus">Olympe</E>

## Son histoire

À sa naissance, Hadès finit dans le ventre de son père. Cronos, qui sait qu'un de ses enfants le renversera, avale chaque nouveau-né. Seul Zeus y échappe : Rhéa fait avaler une pierre emmaillotée à sa place. Plus tard, Cronos recrache tout le monde. Hadès et les siens font alors la guerre aux <E id="titans">Titans</E> aux côtés de Zeus.

Après la victoire, il faut se partager le monde. Chez Homère, les trois frères tirent au sort. Zeus gagne le ciel, Poséidon la mer, et Hadès « l'ombre brumeuse ». La terre et l'Olympe restent communs aux trois. Hadès devient le roi des morts, dans les <E id="underworld">Enfers</E>.

Son épisode le plus célèbre est un enlèvement. Dans l'*Hymne homérique à Déméter* (VIIe–VIe siècle av. J.-C.), Perséphone cueille des fleurs. La terre s'ouvre, Hadès surgit sur son char et l'emporte contre son gré. C'est Zeus qui la lui a « donnée », sans demander l'avis de sa mère. Déméter, désespérée, empêche les graines de pousser.

Les humains meurent de faim, les dieux n'ont plus d'offrandes. Zeus envoie <E id="hermes">Hermès</E> chercher Perséphone. Hadès obéit, mais lui fait d'abord manger en cachette un grain de grenade. Ce grain la lie au monde d'en bas : elle y passera un tiers de l'année, et le reste avec sa mère.

## Ses pouvoirs

- Il règne sur les morts : Homère l'appelle « celui qui règne sur ceux d'en bas » (*Iliade*, XV, 188 ; trad. de la rédaction).
- Personne ne ressort de chez lui : chez Hésiode, son chien accueille les arrivants en remuant la queue, puis dévore ceux qui tentent de sortir.
- Sa kunée, un casque, rend invisible. Dans l'*Iliade*, Athéna l'enfile pour que le dieu Arès ne la voie pas.
- Il est aussi « le riche » : selon Platon (IVe siècle av. J.-C.), on l'appelle Pluton parce que la richesse monte du sous-sol.
- Il juge : chez Eschyle (Ve siècle av. J.-C.), les Érinyes — déesses de la vengeance — disent qu'il surveille les mortels et note tout dans son esprit.

<Versions title="Une histoire, plusieurs versions">
  <Version layer="ancient" source="Homère, Iliade, XV, 187–193 (vers le VIIIe siècle av. J.-C.)">Les trois fils de Cronos tirent le monde au sort. Hadès obtient « l'ombre brumeuse », Poséidon la mer, Zeus le ciel. La terre et l'Olympe restent à tous.</Version>
  <Version layer="ancient" source="Hésiode, Théogonie, v. 881–885 (vers 700 av. J.-C.)">Pas de tirage au sort : après la victoire sur les Titans, les dieux poussent Zeus à régner, et c'est lui qui répartit les honneurs entre eux.</Version>
  <Version layer="ancient" source="Hymne homérique à Déméter, v. 371–374 et 411–413">Hadès donne en secret à Perséphone un grain de grenade. Plus tard, elle raconte à sa mère qu'il l'a forcée à le manger. Résultat : un tiers de l'année sous terre.</Version>
  <Version layer="ancient" source="Apollodore, Bibliothèque, I, 5, 1–3 (Ier–IIe siècle apr. J.-C.)">Hadès enlève Perséphone « avec l'aide de Zeus ». Il lui donne un grain de grenade ; Ascalaphe, un habitant des Enfers, témoigne qu'elle l'a mangé. Elle passe un tiers de l'année avec Hadès.</Version>
  <Version layer="ancient" source="Ovide, Métamorphoses, V, 366–383, 536–539, 565–567 (poète romain, vers 8 apr. J.-C.)">Chez le poète romain Ovide, c'est Cupidon qui, sur ordre de Vénus, frappe Dis (Hadès) d'une flèche. Proserpine (Perséphone) mange sept grains de grenade. Jupiter coupe l'année en deux moitiés égales.</Version>
  <Version layer="interpretation">Les textes anciens ne le montrent pas cruel : ils le disent implacable. Homère le juge « le plus détesté des dieux » parce qu'on ne peut pas le fléchir. Beaucoup de lectures modernes en font donc un dieu sévère mais juste, pas un dieu du mal.</Version>
</Versions>

## Le saviez-vous ?

- **Un nom qui devient une adresse.** Chez Homère, les morts vont « dans la maison d'Hadès » (*Iliade*, XXIII, 19). Avec le temps, le nom du dieu a fini par désigner le lieu lui-même. [À VÉRIFIER]
- **Pas vraiment Olympien.** Il vit « sous la terre » (Hésiode, *Théogonie*, v. 455). Pourtant, blessé par une flèche d'Héraclès, il monte se faire soigner sur l'Olympe (*Iliade*, V, 395–402).
- **Un temple ouvert un jour par an.** Selon Pausanias (IIe siècle apr. J.-C.), les habitants d'Élis sont les seuls qu'il connaisse à rendre un culte à Hadès. Raison avancée : on ne descend chez Hadès qu'une fois.

## Dans la culture populaire

- **Hercule** (Disney, 1997) : Hadès devient le grand méchant, aux cheveux de flammes. Il complote pour renverser Zeus et régner sur l'Olympe — tout ce que le mythe ne raconte pas.
- **Percy Jackson et le Voleur de foudre** (Rick Riordan, 2005) : tout le monde soupçonne Hadès d'avoir volé la foudre de Zeus. Il est innocent, et on lui a même volé son propre casque.
- **Hades** (Supergiant Games, 2020) : tu joues Zagreus, son fils, qui tente de s'évader des Enfers. Hadès y est un père sévère et distant, et le boss final.

## Pour aller plus loin

- <E id="persephone">Perséphone</E> — Reine des Enfers un tiers de l'année, et tout ça pour un grain de grenade.
- <E id="underworld">Les Enfers</E> — Fleuves, juges et châtiments : visite guidée du royaume des morts.
- <E id="cerberus">Cerbère</E> — Trois têtes ou cinquante ? Le chien de garde change selon les auteurs.

## Sources

- Homère, *Iliade*, V, 395–402 et 844–845 ; IX, 158–159 ; XV, 187–193 ; XXIII, 19 (vers le VIIIe siècle av. J.-C.)
- Hésiode, *Théogonie*, v. 211–212, 310–312, 453–506, 758–774, 881–885, 912–914 (vers 700 av. J.-C.)
- *Hymne homérique à Déméter*, v. 1–20, 77–87, 334–374, 393–400, 411–413, 445–447 (VIIe–VIe siècle av. J.-C.)
- Eschyle, *Euménides*, v. 273–275 (Ve siècle av. J.-C.)
- Platon, *Cratyle*, 403a ; *Lois*, VIII, 828c (IVe siècle av. J.-C.)
- (Pseudo-)Apollodore, *Bibliothèque*, I, 1, 5–7 ; I, 2, 1 ; I, 5, 1–3 ; II, 5, 12 (Ier–IIe siècle apr. J.-C.)
- Pausanias, *Description de la Grèce*, VI, 25, 2–3 (IIe siècle apr. J.-C.)
- Ovide, *Métamorphoses*, V, 366–383, 536–539, 565–567 (poète romain, vers 8 apr. J.-C.)
```

### Sources consultées

Textes antiques (traductions) :
- https://www.theoi.com/Khthonios/Haides.html — compilation : naissance, partage, casque, Pluton (Platon, Cratyle), Cerbère, caractère (Iliade IX), culte à Élis, blessure par Héraclès, épithètes.
- https://www.theoi.com/Text/HomerIliad15.html — Iliade XV [184] : trois frères, tirage au sort, terre et Olympe communs (trad. anglaise).
- https://www.theoi.com/Text/HomerIliad5.html — Iliade V [381] blessure à Pylos et guérison sur l'Olympe par Péan ; [835] Athéna met « le casque d'Hadès ».
- https://www.theoi.com/Text/HomerIliad9.html — Iliade IX [141] : Hadès inflexible, le plus détesté des dieux.
- https://www.theoi.com/Text/HesiodTheogony.html — Théogonie : enfants de Rhéa, Cronos avale, pierre, Cyclopes et foudre, Cerbère, maison d'Hadès et du chien, partage des honneurs par Zeus, Perséphone enlevée « mais Zeus la lui donna ».
- https://www.theoi.com/Text/HomericHymns1.html — Hymne à Déméter (trad. Evelyn-White) : ouverture, Hélios, grain de grenade, promesse d'Hadès, tiers de l'année.
- https://www.theoi.com/Text/Apollodorus1.html — Bibliothèque I, 1, 5–7 ; I, 2, 1 (Cyclopes : foudre à Zeus, casque à Pluton, trident à Poséidon ; tirage au sort) ; I, 5, 1–3 (enlèvement avec l'aide de Zeus, grain de grenade, Ascalaphe, tiers de l'année).
- https://www.theoi.com/Text/Apollodorus2.html — II, 5, 12 : Cerbère (trois têtes de chien, queue de dragon), Pluton autorise Héraclès à l'emmener sans armes.
- https://www.theoi.com/Text/Pausanias6B.html — VI, 25, 2–3 : enclos et temple d'Hadès à Élis, ouverts une fois l'an, seuls Éléens à l'honorer.
- https://www.thelatinlibrary.com/ovid/ovid.met5.shtml — Ovide, Mét. V : Cupidon et Dis (366–367, 383), sept grains (536–539), année partagée (565, 567).

Textes grecs numérotés (dépôt PerseusDL/canonical-greekLit, raw.githubusercontent.com), lus par moi :
- tlg0012.tlg001 (Iliade) — V, 395–402 ; V, 844–845 (Ἄϊδος κυνέην) ; IX, 158–159 (ἀμείλιχος ἠδʼ ἀδάμαστος… ἔχθιστος) ; IX, 457 (Ζεὺς καταχθόνιος) ; XV, 185–193 (ἔλαχον, ζόφον ἠερόεντα, v. 191) ; XX, 61–65 ; XXIII, 19.
- tlg0020.tlg001 (Théogonie) — v. 139–141, 211–212, 310–312, 453–460, 501–506, 758–774, 850, 881–885, 912–914.
- tlg0020.tlg003 (Bouclier) — v. 226–227 (κυνέη d'Hadès sur la tête de Persée).
- tlg0013.tlg002 (Hymne à Déméter) — v. 1–20 (ἀέκουσαν, v. 19 ; Πολυδέγμων, v. 17), 77–87 (γαμβρός, Πολυσημάντωρ, partage en trois), 334–374, 393–400, 411–413, 445–447.
- tlg0085.tlg007 (Euménides) — v. 267–275 (μέγας Ἅιδης… εὔθυνος βροτῶν… δελτογράφῳ φρενί).
- tlg0085.tlg001 (Suppliantes) — v. 228–231 (« un autre Zeus » qui juge chez les morts).
- tlg0059.tlg005 (Cratyle) — 403a : Pluton « d'après le don de la richesse, qui monte d'en bas, de la terre » ; peur du nom Hadès.
- tlg0059.tlg034 (Lois) — VIII, 828c : rites des dieux chthoniens séparés, placés dans le douzième mois, celui de Pluton.
- tlg0548.tlg001 (Apollodore) — I, 1, 5 ; I, 2, 1 (Πλούτωνι δὲ κυνέην ; διακληροῦνται) ; I, 5, 1 et 3 ; II, 5, 12.

Références (point de départ) :
- https://en.wikipedia.org/wiki/Hades — euphémisme Ploutôn (vers le Ve s. av. J.-C.), « pas un dieu du mal… sévère mais juste », Thanatos personnification de la mort, corne d'abondance.
- https://www.britannica.com/topic/Hades-Greek-mythology — Pluton « le Riche », sévère et impitoyable, épithètes euphémiques.
- https://en.wikipedia.org/wiki/Twelve_Olympians — pas de liste canonique ; Hadès rarement compté car son royaume est loin de l'Olympe ; Platon, Lois 828.
- https://en.wikipedia.org/wiki/Cap_of_invisibility — kunée « peau de chien d'Hadès » ; utilisateurs (Athéna, Hermès, Persée).
- https://en.wikipedia.org/wiki/Thanatos — fils de Nyx, jumeau d'Hypnos.
- https://en.wikipedia.org/wiki/Homeric_Hymn_to_Demeter (redirigé) et https://human.libretexts.org/…/5.06%3A_The_Homeric_Hymn_to_Demeter — datation (VIIe siècle probable, pas après le début du VIe).
- https://en.wikipedia.org/wiki/Hercules_(1997_film) — Hadès méchant, veut renverser Zeus et régner sur l'Olympe, cheveux de flammes.
- https://en.wikipedia.org/wiki/The_Lightning_Thief — Hadès suspecté, innocent, son casque volé (par Luke).
- https://en.wikipedia.org/wiki/Hades_(video_game) — Supergiant Games, 2020, Zagreus fils d'Hadès, père sévère, boss final.

### Doutes

1. **« Un nom qui devient une adresse »** [À VÉRIFIER] : l'emploi homérique « dans la maison d'Hadès » est vérifié (Iliade XXIII, 19). Je n'ai pas trouvé de source datant précisément le moment où « Hadès » désigne le lieu seul. Formulation volontairement vague (« avec le temps ») ; à confirmer ou à dater.
2. **Glose de « kunée »** : je n'ai pas mis « bonnet en peau de chien » dans le texte. Seul Wikipédia (*Cap of invisibility*) donne « lit. dog-skin » ; le LSJ (Perseus) est bloqué. Ajout possible après vérification.
3. **Invisibilité du casque** : Iliade V, 845 dit seulement qu'Athéna le met « pour qu'Arès ne la voie pas ». L'effet d'invisibilité explicite est chez Apollodore (II, 4, 2, déjà vérifié pour la fiche Méduse). Formulation de la puce à valider.
4. **« Il juge »** : la puce s'appuie sur Eschyle, *Euménides*, v. 273–275 (paroles des Érinyes, trad. de la rédaction : « grand contrôleur des mortels sous la terre », δελτογράφῳ φρενί, « esprit qui écrit comme sur des tablettes »). Les *Suppliantes* (v. 230–231) parlent d'« un autre Zeus » qui juge chez les morts, mais sans le nommer : non utilisé. Les juges des morts (Minos, Éaque, Rhadamanthe) ne sont pas traités ici.
5. **Version « interpretation »** : l'expression « sévère mais juste » vient de la synthèse de Wikipédia EN (référence moderne non identifiée). Je n'ai pas de source savante nommée ; à attribuer si le vérificateur en trouve une.
6. **Pas un Olympien** : l'explication (il vit sous la terre ; pas de liste canonique des Douze) s'appuie sur Hésiode v. 455 et Wikipédia EN. Platon (*Lois*, 828c) range les dieux chthoniens dans le mois de Pluton ; Wikipédia en déduit qu'Hadès y figurerait parmi les Douze, lecture que je n'ai pas reprise dans le texte. L'idée de sacrifices différents (fosses vs autels) n'est pas utilisée faute de source antique consultée.
7. **Ploutôn = « le riche »** : glose fondée sur Platon (Cratyle 403a, « don de la richesse ») et Britannica (« the Wealthy One »). Le lien avec les récoltes (céréales stockées sous terre) n'est pas dans le texte : non vérifié dans une source antique.
8. **Romains** : Dis (Ovide, vérifié), Orcus (Cicéron, *De natura deorum*, III, 17, via theoi, non lu en latin), Pluto (Hygin, préface, via theoi). « Dis Pater » non vérifié, donc non écrit.
9. **Datations** : Eschyle et Platon datés au siècle seulement ; Pausanias au IIe siècle apr. J.-C. de mémoire (non revérifié en ligne) ; Hymne à Déméter VIIe–VIe siècle (LibreTexts/Wikipédia).
10. **Ids hors liste du lot** : `cerberus`, `thanatos`, `hermes` (déjà utilisé dans Méduse), `titans` (dans la liste). `cerberus` et `thanatos` sont à créer ou valider.
11. **Format YAML** : bloc de spécialisation `deity:` inventé sur le modèle de `creature:` ; à valider. Relation `cyclopes → hades : helped` (variant) faute de type « a donné » ; `heracles → hades : enemy-of` (variant) discutable.
12. **Cerbère, « Trois têtes ou cinquante ? »** (porte) : cinquante têtes chez Hésiode (v. 312), trois têtes de chien chez Apollodore (II, 5, 12) : vérifié.
13. **Pop culture** : la série Percy Jackson (Disney+) et les autres œuvres du brief (God of War, Marvel, Assassin's Creed) ne sont pas traitées, faute de vérification. Le doublage (James Woods en VO) a été vérifié mais n'est pas cité.
14. **Anecdote non retenue** (vérifiée, disponible) : *Iliade*, XX, 61–65 — pendant le combat des dieux, Aïdoneus bondit de son trône en criant, de peur que Poséidon fasse éclater la terre et révèle ses demeures.
15. **Typographie** : espaces insécables non saisies explicitement dans le bloc MDX ; à appliquer ou à contrôler au rendu.
