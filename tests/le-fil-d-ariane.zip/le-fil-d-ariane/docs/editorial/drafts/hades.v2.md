# Livrable rédacteur — Fiche « Hadès » — Lot 1, vague A — v2

### YAML

```yaml
id: hades
type: deity
category: gods
names:
  greek: ᾍδης              # forme épique : Ἀΐδης ; aussi Ἀιδωνεύς (Aïdoneus)
  transliteration: Hadēs
  roman: Pluto              # les Romains disent aussi Dis (Ovide) et Orcus (Cicéron)
  aliases: [Hadès, Aïdoneus, Pluton, Ploutôn, Polydegmôn, Zeus souterrain, Dis, Orcus]
era: olympians
importance: 1
deity:
  domains: [underworld, the-dead, wealth]
  symbols: [helm-of-hades, cerberus]
  olympian: false           # vit sous la terre (Hésiode, Théogonie, v. 455) ; rarement compté parmi les Douze
  residence: underworld
  epithets:
    - { greek: Ἀιδωνεύς, transliteration: Aidōneus, source: "Hymne homérique à Déméter, v. 2, 84, 357 ; Hésiode, Théogonie, v. 913 ; Homère, Iliade, XX, 61" }
    - { greek: Πλούτων, transliteration: Ploutōn, source: "Platon, Cratyle, 403a ; Apollodore, Bibliothèque, I, 1, 5" }
    - { greek: Ζεὺς καταχθόνιος, transliteration: Zeus katachthonios, source: "Homère, Iliade, IX, 457" }
    - { greek: Πολυδέγμων, transliteration: Polydegmōn, source: "Hymne homérique à Déméter, v. 17, 31" }
relations:                  # sens : from → to
  - { from: cronos, to: hades, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–455 ; Homère, Iliade, XV, 187–188 ; Apollodore, Bibliothèque, I, 1, 5" }
  - { from: rhea, to: hades, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–455 ; Homère, Iliade, XV, 187–188" }
  - { from: hades, to: zeus, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–457 ; Homère, Iliade, XV, 187–188" }
  - { from: hades, to: poseidon, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–456 ; Homère, Iliade, XV, 187–188" }
  - { from: hades, to: hera, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–455" }
  - { from: hades, to: demeter, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–455" }
  - { from: hades, to: hestia, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–455" }
  - { from: hades, to: persephone, type: spouse-of, certainty: canonical, source: "Hésiode, Théogonie, v. 767–768, 913–914 ; Hymne homérique à Déméter, v. 79, 343" }
  # Union non consentie au départ (enlèvement, Hymne à Déméter, v. 19 « contre son gré ») : PAS de lover-of.
  - { from: zeus, to: hades, type: helped, certainty: canonical, source: "Hymne homérique à Déméter, v. 3–4, 8–9, 77–79 ; Hésiode, Théogonie, v. 914 ; Apollodore, Bibliothèque, I, 5, 1 (enlèvement de Perséphone)" }
  - { from: cyclopes, to: hades, type: helped, certainty: variant, source: "Apollodore, Bibliothèque, I, 2, 1 (lui donnent le casque pendant la guerre contre les Titans)" }
  - { from: hades, to: helm-of-hades, type: owns, certainty: canonical, source: "Homère, Iliade, V, 845 (« le casque d'Hadès ») ; Bouclier d'Héraclès, v. 226–227 ; Apollodore, Bibliothèque, I, 2, 1" }
  - { from: hades, to: cerberus, type: owns, certainty: canonical, source: "Hésiode, Théogonie, v. 311 (« le chien d'Hadès ») ; Apollodore, Bibliothèque, II, 5, 12" }
  - { from: hades, to: underworld, type: lives-in, certainty: canonical, source: "Hésiode, Théogonie, v. 455 ; Homère, Iliade, XV, 191" }
  - { from: hades, to: titans, type: enemy-of, certainty: canonical, source: "Hésiode, Théogonie, v. 624–634 (vérif.) ; Apollodore, Bibliothèque, I, 2, 1" }
  # Conflit direct attesté (critère de l'arbitrage Q4) : Héraclès le blesse d'une flèche à Pylos (Iliade) ;
  # Pausanias dit qu'Hadès vint aider les Pyliens « par hostilité envers Héraclès » (τῇ ἀπεχθείᾳ τοῦ Ἡρακλέους). Relation conservée.
  - { from: heracles, to: hades, type: enemy-of, certainty: variant, source: "Homère, Iliade, V, 395–402 ; Pausanias, VI, 25, 2–3 (hostilité explicite) ; Apollodore, Bibliothèque, II, 5, 12 (Hadès le laisse emmener Cerbère : relation ambivalente)" }
# Non exprimé faute de type adapté : le partage du monde (tirage au sort) ; Hermès envoyé par Zeus pour ramener Perséphone (Hymne, v. 334–356).
sources:                    # alignées sur la liste « Sources » du MDX (+ Iliade IX, 457 pour l'épithète)
  - { source: "Homère, Iliade", locus: "V, 395–402 et 844–845 ; IX, 158–159 et 457 ; XV, 187–193 ; XX, 61–65 ; XXIII, 19 et 244", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml" }
  - { source: "Hésiode, Théogonie", locus: "v. 211–212, 310–312, 453–506, 767–774, 850, 881–885, 912–914", url: "https://www.theoi.com/Text/HesiodTheogony.html" }
  - { source: "(Pseudo-)Hésiode, Bouclier d'Héraclès", locus: "v. 226–227", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg003/tlg0020.tlg003.perseus-grc2.xml" }
  - { source: "Hymne homérique à Déméter", locus: "v. 1–20, 30–32, 77–87, 305–313, 334–374, 393–400, 411–413, 445–447", url: "https://www.theoi.com/Text/HomericHymns1.html" }
  - { source: "Eschyle, Euménides", locus: "v. 273–275", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0085/tlg007/tlg0085.tlg007.perseus-grc2.xml" }
  - { source: "Platon, Cratyle", locus: "403a", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0059/tlg005/tlg0059.tlg005.perseus-grc2.xml" }
  - { source: "(Pseudo-)Apollodore, Bibliothèque", locus: "I, 1, 5–7 ; I, 2, 1 ; I, 5, 1–3 ; II, 5, 12", url: "https://www.theoi.com/Text/Apollodorus1.html" }
  - { source: "Pausanias, Description de la Grèce", locus: "VI, 25, 2–3", url: "https://www.theoi.com/Text/Pausanias6B.html" }
  - { source: "Ovide, Métamorphoses (poète romain)", locus: "V, 365–384, 536–539, 564–567", url: "https://www.thelatinlibrary.com/ovid/ovid.met5.shtml" }
  - { source: "LSJ (Liddell-Scott-Jones), s.v. ᾍδης et κυνέη", locus: "—", url: "https://lsj.gr/wiki/ᾍδης" }
review: { status: draft, version: 2 }
```

### MDX

```mdx
---
name: Hadès
role: Le roi des morts, maître du monde souterrain
hook: Spoiler : Hadès n'est pas le méchant. Mais il n'est pas gentil non plus.
---

## En bref

- **Famille :** fils de <E id="cronos">Cronos</E> et <E id="rhea">Rhéa</E> ; frère de <E id="zeus">Zeus</E>, <E id="poseidon">Poséidon</E>, <E id="hera">Héra</E>, <E id="demeter">Déméter</E> et <E id="hestia">Hestia</E> ; époux de <E id="persephone">Perséphone</E>
- **Domaine :** le monde des morts, sous la terre, qui finit par porter son nom
- **Autres noms :** Aïdoneus ; Zeus souterrain ; Ploutôn (« le riche »), d'où le latin Pluto, Pluton en français ; les Romains disent aussi Dis ou Orcus
- **Attributs :** la kunée, casque qui rend invisible ; le chien <E id="cerberus">Cerbère</E>
- **Caractère :** « au cœur sans pitié » chez Hésiode ; implacable, et pour cela le plus détesté des dieux par les mortels, selon Agamemnon dans l'*Iliade*
- **N'est pas :** la Mort en personne — c'est <E id="thanatos">Thanatos</E>, fils de la Nuit
- **Olympien ?** Rarement compté parmi les Douze : il vit sous la terre, pas sur l'<E id="mount-olympus">Olympe</E>

## Son histoire

À peine né, Hadès finit dans le ventre de son père. Cronos craint d'être renversé par un fils : il avale chaque nouveau-né. Seul Zeus, le petit dernier chez Hésiode, y échappe : Rhéa fait avaler une pierre emmaillotée à sa place. Cronos est ensuite forcé de recracher les autres (ruse de Gaïa chez Hésiode, drogue de Métis chez Apollodore).

Hadès et les siens font alors la guerre aux <E id="titans">Titans</E> aux côtés de Zeus. Vient ensuite le partage du monde. Chez Homère, les trois frères tirent au sort : le ciel pour Zeus, la mer pour Poséidon, « l'ombre brumeuse » pour Hadès. La terre et l'Olympe restent communs. Hadès devient le roi des morts, dans les <E id="underworld">Enfers</E>.

Son épisode le plus célèbre est un enlèvement. Dans l'*Hymne homérique à Déméter* (VIIe–VIe siècle av. J.-C.), Perséphone cueille des fleurs. La terre s'ouvre, Hadès surgit sur son char et l'emporte contre son gré. C'est Zeus qui la lui a « donnée », sans demander l'avis de sa mère. Déméter, désespérée, empêche les graines de pousser.

Les humains vont mourir de faim, et les dieux perdre leurs offrandes. Zeus envoie alors <E id="hermes">Hermès</E> chercher Perséphone. Hadès obéit, mais lui fait d'abord manger en cachette un grain de grenade. Ce grain la lie au monde d'en bas : elle y passera un tiers de l'année, et le reste avec sa mère.

## Ses pouvoirs

- Il règne sur les morts : Hésiode l'appelle celui « qui règne sur les morts d'en bas » (*Théogonie*, v. 850 ; trad. de la rédaction).
- En principe, on ne ressort pas de chez lui : chez Hésiode, son chien accueille les arrivants en remuant la queue, puis dévore ceux qui tentent de sortir.
- Sa kunée — à l'origine, un bonnet en peau de chien — est un casque qui rend invisible. Selon Apollodore, les Cyclopes la lui donnent pendant la guerre contre les Titans.
- Dans l'*Iliade*, Athéna enfile ce « casque d'Hadès » pour que le dieu Arès ne la voie pas.
- Il fait rendre des comptes : chez Eschyle (Ve siècle av. J.-C.), les Érinyes — déesses de la vengeance — disent que, sous la terre, il fait rendre des comptes aux mortels et note tout dans son esprit.

<Versions title="Une histoire, plusieurs versions">
  <Version layer="ancient" source="Homère, Iliade, XV, 187–193 (fin du VIIIe – début du VIIe siècle av. J.-C.)">Poséidon raconte que les trois fils de Cronos ont tiré le monde au sort. Hadès a obtenu « l'ombre brumeuse », Poséidon la mer, Zeus le ciel. La terre et l'Olympe restent à tous.</Version>
  <Version layer="ancient" source="Hésiode, Théogonie, v. 881–885 (vers 700 av. J.-C.)">Hésiode ne parle pas de tirage au sort : sur le conseil de Gaïa, les dieux poussent Zeus à régner, et c'est lui qui répartit les honneurs entre eux.</Version>
  <Version layer="ancient" source="Hymne homérique à Déméter, v. 371–374 et 411–413">Hadès donne en secret à Perséphone un grain de grenade. Plus tard, elle raconte à sa mère qu'il l'a forcée à le manger. Résultat : un tiers de l'année sous terre.</Version>
  <Version layer="ancient" source="Apollodore, Bibliothèque, I, 5, 1–3 (Ier–IIe siècle apr. J.-C.)">Hadès enlève Perséphone « avec l'aide de Zeus ». Il lui donne un grain de grenade ; Ascalaphe, un habitant des Enfers, témoigne qu'elle l'a mangé. Elle passe un tiers de l'année avec Hadès.</Version>
  <Version layer="ancient" source="Ovide, Métamorphoses, V, 365–384, 536–539, 564–567 (poète romain, vers 8 apr. J.-C.)">Chez le poète romain Ovide, c'est Cupidon qui, sur ordre de Vénus, frappe Dis (Hadès) d'une flèche. Proserpine (Perséphone) mange sept grains de grenade. Jupiter coupe l'année en deux moitiés égales.</Version>
  <Version layer="interpretation">Les lectures modernes voient plutôt en Hadès un gardien sévère de l'ordre des morts qu'un dieu du mal. La mort elle-même, c'est Thanatos. Pas un héros pour autant : dans le mythe, c'est lui qui enlève Perséphone.</Version>
</Versions>

## Le saviez-vous ?

- **Un nom qui devient une adresse.** Chez Homère, Hadès est presque toujours une personne : mort, tu irais « dans la maison d'Hadès ». Selon le dictionnaire LSJ, le nom désigne le lieu pour la première fois en *Iliade*, XXIII, 244.
- **Panique au sous-sol.** Quand Poséidon secoue la terre pendant la bataille des dieux, Aïdoneus bondit de son trône en criant. Il a peur que la terre s'ouvre et dévoile sa demeure (*Iliade*, XX, 61–65).
- **Un temple ouvert un jour par an.** Selon Pausanias (IIe siècle apr. J.-C.), les habitants d'Élis sont les seuls qu'il connaisse à rendre un culte à Hadès. Raison avancée : on ne descend chez Hadès qu'une fois.

## Dans la culture populaire

- **Hercule** (Disney, 1997) : Hadès devient le grand méchant, aux cheveux de flammes. Il complote pour renverser Zeus et régner sur l'Olympe — tout ce que le mythe ne raconte pas.
- ***Le Voleur de foudre*** (Percy Jackson, tome 1, Rick Riordan, 2005) : Percy et ses amis soupçonnent Hadès d'avoir volé la foudre de Zeus. Il est innocent, et on lui a même volé son propre casque.
- **Hades** (Supergiant Games, 2020) : tu joues Zagreus, son fils, qui tente de s'évader des Enfers. Hadès y est un père sévère et distant, et le boss final.

## Pour aller plus loin

- <E id="persephone">Perséphone</E> — Reine des Enfers un tiers de l'année : enlevée, puis liée au monde d'en bas par un grain de grenade.
- <E id="underworld">Les Enfers</E> — Fleuves, juges et châtiments : visite guidée du royaume des morts.
- <E id="cerberus">Cerbère</E> — Trois têtes ou cinquante ? Le chien de garde change selon les auteurs.

## Sources

- Homère, *Iliade*, V, 395–402 et 844–845 ; IX, 158–159 et 457 ; XV, 187–193 ; XX, 61–65 ; XXIII, 19 et 244 (fin du VIIIe – début du VIIe siècle av. J.-C.)
- Hésiode, *Théogonie*, v. 211–212, 310–312, 453–506, 767–774, 850, 881–885, 912–914 (vers 700 av. J.-C.)
- (Pseudo-)Hésiode, *Bouclier d'Héraclès*, v. 226–227 (fin VIIe – milieu VIe siècle av. J.-C.)
- *Hymne homérique à Déméter*, v. 1–20, 30–32, 77–87, 305–313, 334–374, 393–400, 411–413, 445–447 (VIIe–VIe siècle av. J.-C.)
- Eschyle, *Euménides*, v. 273–275 (Ve siècle av. J.-C.)
- Platon, *Cratyle*, 403a (IVe siècle av. J.-C.)
- (Pseudo-)Apollodore, *Bibliothèque*, I, 1, 5–7 ; I, 2, 1 ; I, 5, 1–3 ; II, 5, 12 (Ier–IIe siècle apr. J.-C.)
- Pausanias, *Description de la Grèce*, VI, 25, 2–3 (IIe siècle apr. J.-C.)
- Ovide, *Métamorphoses*, V, 365–384, 536–539, 564–567 (poète romain, vers 8 apr. J.-C.)
- Liddell, Scott, Jones, *Greek-English Lexicon* (LSJ), articles ᾍδης et κυνέη
```

### Sources consultées

Textes antiques (traductions), visités pour la v1 :
- https://www.theoi.com/Khthonios/Haides.html — compilation : naissance, partage, casque, Pluton, Cerbère, caractère, culte à Élis, blessure par Héraclès, épithètes.
- https://www.theoi.com/Text/HomerIliad15.html — Iliade XV [184] : discours de Poséidon, tirage au sort.
- https://www.theoi.com/Text/HomerIliad5.html — Iliade V : blessure à Pylos et guérison sur l'Olympe ; « casque d'Hadès » mis par Athéna.
- https://www.theoi.com/Text/HomerIliad9.html — Iliade IX [141] : discours d'Agamemnon.
- https://www.theoi.com/Text/HesiodTheogony.html — Théogonie (trad. Evelyn-White).
- https://www.theoi.com/Text/HomericHymns1.html — Hymne à Déméter (trad. Evelyn-White).
- https://www.theoi.com/Text/Apollodorus1.html et https://www.theoi.com/Text/Apollodorus2.html — Bibliothèque I, 1, 5 à I, 5, 3 et II, 5, 12 (trad. Frazer).
- https://www.theoi.com/Text/Pausanias6B.html — VI, 25, 2–3 (trad. Jones).
- https://www.thelatinlibrary.com/ovid/ovid.met5.shtml — Ovide, Mét. V.

Visités ou relus pour la v2 :
- https://raw.githubusercontent.com/PerseusDL/canonical-latinLit/master/data/phi0959/phi006/phi0959.phi006.perseus-lat2.xml — Ovide, Mét. V, latin numéroté : v. 365–366 (Vénus à Cupidon), 383–384 (« percussit… Ditem », v. 384), 536–537 (septem grana), 564–567 (année partagée).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0525/tlg001/tlg0525.tlg001.perseus-grc2.xml — Pausanias VI, 25, 2 : temple ouvert ἅπαξ κατὰ ἔτος, μόνοι τιμῶσιν Ἅιδην Ἠλεῖοι ; Hadès allié des Pyliens τῇ ἀπεχθείᾳ τοῦ Ἡρακλέους.
- https://lsj.gr/wiki/ᾍδης — « in Hom. only as pr.n. » ; sens de lieu « first in Il. 23.244 ».
- https://lsj.gr/wiki/κυνέη — « a dog's skin » (bonnet de soldat) ; Ἄϊδος κυνέη, casque mythique qui rend invisible (Il. 5.845).
- Dépôt PerseusDL, textes grecs numérotés relus : Iliade (tlg0012.tlg001) IX, 158–159 (discours d'Agamemnon, βροτοῖσι), XV, 185–193 (discours de Poséidon), XX, 54–66, XXIII, 244 (Ἄϊδι κεύθωμαι) ; Théogonie (tlg0020.tlg001) v. 850 (Ἀίδης, ἐνέροισι καταφθιμένοισιν ἀνάσσων, narrateur), v. 881–885 (Γαίης φραδμοσύνῃσιν) ; Hymne à Déméter (tlg0013.tlg002) v. 30–32, 305–313 (καί νύ κε… εἰ μὴ Ζεὺς ἐνόησεν), 411–413.

Lus pour la v1 (textes grecs PerseusDL, déjà détaillés dans le draft v1) : Bouclier v. 226–227 ; Euménides v. 267–275 ; Cratyle 403a ; Apollodore I, 1, 5 ; I, 2, 1 ; I, 5, 1–3 ; II, 5, 12.

Références (point de départ, v1) : https://en.wikipedia.org/wiki/Hades ; https://www.britannica.com/topic/Hades-Greek-mythology ; https://en.wikipedia.org/wiki/Twelve_Olympians ; https://en.wikipedia.org/wiki/Cap_of_invisibility ; https://en.wikipedia.org/wiki/Thanatos ; https://human.libretexts.org/Courses/Long_Beach_City_College/Temples_of_the_Gods%3A_An_Introduction_to_Classical_Mythology/05%3A_The_Feminine_Divine/5.06%3A_The_Homeric_Hymn_to_Demeter ; https://en.wikipedia.org/wiki/Hercules_(1997_film) ; https://en.wikipedia.org/wiki/The_Lightning_Thief ; https://en.wikipedia.org/wiki/Hades_(video_game).

Vérifications reprises du rapport du vérificateur (/home/claude/editorial/reviews/hades.review.md), **non revisitées par moi** : titre français du roman (*Percy Jackson, t. 1 : Le Voleur de foudre*, livraddict.com) ; dates de Pausanias (IIe s. apr. J.-C.), des Euménides (458 av. J.-C.), d'Apollodore et d'Ovide (Wikipédia EN) ; Théogonie v. 624–634 (Titanomachie) ; date du Bouclier (reprise de la fiche Méduse).

### Doutes

1. **Relation `heracles → hades : enemy-of`** : conservée, car le critère de l'arbitrage Q4 (« conflit direct ») est rempli. *Iliade*, V, 395–402 : Héraclès blesse Hadès d'une flèche ; Pausanias, VI, 25, 2 : Hadès vint aider les Pyliens « par hostilité envers Héraclès » (texte grec lu). Le directeur peut la supprimer s'il juge l'épisode trop isolé.
2. **Iliade, XV, 188** : comme IX, 158–159, c'est un discours de personnage (Poséidon). La puce « Il règne sur les morts » s'appuie désormais sur Hésiode, v. 850 (narrateur) ; le bloc `<Versions>` attribue le tirage au sort à Poséidon.
3. **« Plus tard » pour le nom-lieu** : la v2 suit le LSJ (« première fois en *Iliade*, XXIII, 244 »). Je n'ai pas de source qui date la généralisation de ce sens après Homère ; le texte n'en dit donc rien.
4. **Platon, *Cratyle*, 403a** : le passage dit aussi qu'on emploie « Pluton » par peur du nom d'Hadès. Ce n'est pas repris dans le MDX, pour garder la puce courte. Ajout possible.
5. **Sources retirées par alignement YAML/MDX** : Eschyle, *Suppliantes*, v. 230–231 (« un autre Zeus » qui juge chez les morts, sans nommer Hadès) et Platon, *Lois*, VIII, 828c–d (mois de Pluton, contre-exemple aux Douze). Les deux sont vérifiées et non utilisées dans le texte.
6. **Épithètes** : seules quatre épithètes attestées sont listées dans le YAML. Le sens de Polydegmôn (« qui reçoit beaucoup ») n'est pas glosé dans le MDX : je n'ai pas vérifié cette traduction dans une source.
7. **Datations** reprises du vérificateur sans nouvelle visite (voir « Sources consultées »).
8. **Typographie** : espaces insécables non saisies explicitement ; à appliquer au rendu.
9. **Accroche et D9 (tutoiement)** : j'ai gardé mot pour mot la formule de l'arbitrage Q1 (« Mais il n'est pas gentil non plus »), qui ne s'adresse pas au lecteur. Variante tutoyée possible : « Mais ne crois pas qu'il soit gentil pour autant. » À arbitrer.
10. **D1 (rang de Zeus)** : seule la version d'Hésiode est donnée (« le petit dernier », ὁπλότατον παίδων, v. 478, vérifié). La précision homérique (Zeus aîné de Poséidon, *Iliade* XIII, 355 ; XV, 166) n'est pas reprise : sans objet pour Hadès, sur qui Homère ne dit rien. Pas de vérification personnelle de ces deux vers.

### Changements v1 → v2

- **❌ #36 corrigé** : la citation d'*Iliade*, IX, 158–159 est attribuée à Agamemnon, avec « par les mortels », et déplacée dans « En bref » (ligne « Caractère »). Elle n'est plus utilisée dans l'interprétation.
- **Même erreur repérée et corrigée** : *Iliade*, XV, 188 est dans un discours de Poséidon. La puce s'appuie désormais sur Hésiode, v. 850 (narrateur), et la version homérique du tirage au sort est attribuée à Poséidon.
- **Interprétation (arbitrage Q1)** : « sévère mais juste » supprimé. Le texte s'appuie sur Hésiode (« au cœur sans pitié », v. 456) et Eschyle (il fait rendre des comptes) ; Hadès n'est pas un dieu du mal, la Mort c'est Thanatos, mais ce n'est pas un héros non plus (il enlève Perséphone).
- **Accroche** : « Spoiler : Hadès n'est pas le méchant. Mais il n'est pas gentil non plus. » « Ne laisse sortir personne » supprimé.
- **Formules absolues** : « Personne ne ressort » remplacé par « En principe, on ne ressort pas » ; « Les humains meurent de faim » remplacé par « vont mourir de faim » (menace évitée, Hymne v. 310–313) ; « Il juge » remplacé par « Il fait rendre des comptes », avec « sous la terre ».
- **Porte Perséphone** : « tout ça pour un grain de grenade » remplacé par « enlevée, puis liée au monde d'en bas par un grain de grenade ».
- **Ovide** : vers corrigés en « V, 365–384, 536–539, 564–567 » (YAML, Versions, Sources), vérifiés sur le latin numéroté.
- **Nom-lieu** : balise [À VÉRIFIER] retirée ; anecdote réécrite d'après le LSJ (*Iliade*, XXIII, 244) ; ligne « Domaine » d'« En bref » complétée.
- **Casque** : don par les Cyclopes (Apollodore) ajouté dans le MDX ; glose « à l'origine, un bonnet en peau de chien » ajoutée (LSJ).
- **Hésiode** : « Pas de tirage au sort » remplacé par « Hésiode ne parle pas de tirage au sort : sur le conseil de Gaïa… ».
- **Percy Jackson** : titre corrigé en « *Le Voleur de foudre* (Percy Jackson, tome 1, Rick Riordan, 2005) » ; « Percy et ses amis » au lieu de « tout le monde ».
- **« Le saviez-vous ? » (arbitrage Q5)** : anecdote *Iliade*, XX, 61–65 ajoutée ; l'anecdote « Pas vraiment Olympien » (blessure à Pylos), la plus faible, est retirée, et la question des Olympiens reste traitée dans « En bref ».
- **« En bref »** : « Épouse » fusionnée dans « Famille » ; ligne « Caractère » ajoutée ; « Autres noms » reformulé (Pluton n'apparaît plus deux fois) avec « Zeus souterrain ».
- **YAML (arbitrage Q3)** : bloc `deity:` converti au format officiel (domains `underworld`, `the-dead`, `wealth` ; symbols en ids ; `olympian: false` ; `residence: underworld` ; `epithets` sans traduction, avec sources).
- **YAML (arbitrage Q4)** : `cyclopes → hades : helped` conservé ; `heracles → hades : enemy-of` conservé car un conflit direct est attesté, avec Pausanias VI, 25, 2–3 ajouté en source (voir Doutes 1).
- **Décisions du lot (DECISIONS_LOT1.md)** :
  - D1 : Zeus « le petit dernier chez Hésiode » (v. 478 vérifié) ;
  - D2 : « forcé de recracher les autres (ruse de Gaïa chez Hésiode, drogue de Métis chez Apollodore) », vérifié sur Hésiode v. 494–497 et Apollodore I, 2, 1 ;
  - D3 : « offrent » remplacé par « donnent » pour le casque ;
  - D9 : tutoiement ajouté dans l'anecdote « Un nom qui devient une adresse » ;
  - D10 : Homère daté « fin du VIIIe – début du VIIe siècle av. J.-C. » (Versions et Sources).
  - Le premier paragraphe de « Son histoire » a été scindé autrement pour rester ≤ 60 mots.
- **Sources** : listes YAML et MDX alignées (ajout du Bouclier, d'*Iliade* IX, 457, XX, 61–65 et XXIII, 244, de Théogonie v. 850, du LSJ ; retrait des *Suppliantes* et des *Lois*, non utilisées dans le texte).
