# Livrable rédacteur — Fiche « Hermès » — Lot 1, vague B — draft

### YAML

```yaml
id: hermes
type: deity
category: gods
names:
  greek: Ἑρμῆς               # forme épique : Ἑρμείας (Hermeias)
  transliteration: Hermēs
  roman: Mercurius
  aliases: [Hermès, Hermeias, Mercure, Mercury, Argeiphontès, Kyllénios]
gender: m
era: olympians
importance: 1
deity:
  domains: [messengers, travel, trade, thieves, flocks, guide-of-souls]
  # messengers : Hésiode, Théogonie, v. 939 (κήρυκʼ ἀθανάτων) ; Hymne à Hermès, v. 3 (ἄγγελον ἀθανάτων) ; Odyssée, V, 29
  # travel / trade : Aristophane, Ploutos, v. 1155 et 1159 (ἐμπολαῖος « du commerce », ἡγεμόνιος « guide »)
  # thieves : Hymne à Hermès, v. 292 (ἀρχὸς φηλητέων, « prince des voleurs ») et v. 175
  # flocks : Hymne à Hermès, v. 567–571
  # guide-of-souls : Odyssée, XXIV, 1–14 ; Hymne à Hermès, v. 572 (seul messager attitré auprès d'Hadès)
  symbols: [kerykeion, petasos, winged-sandals, lyre, tortoise]
  # kerykeion : baguette d'or chez Homère (Odyssée, V, 47 ; XXIV, 2–3 ; épithète χρυσόρραπις, Odyssée, X, 277) ;
  #   « baguette d'or à trois feuilles » donnée par Apollon (Hymne à Hermès, v. 529–530). Les serpents : iconographie.
  # winged-sandals : sandales d'or chez Homère, SANS ailes (Odyssée, V, 44–46 ; Iliade, XXIV, 340–342) ; ailes = art plus tardif.
  # petasos : chapeau de voyageur, attribut iconographique (pas de source textuelle vérifiée).
  # lyre / tortoise : Hymne à Hermès, v. 24–51.
  olympian: true             # compté parmi les Douze dans les listes courantes (listes variables : cf. brief)
  residence: mount-olympus   # Hymne à Hermès, v. 505 ; Odyssée, X, 307 ; né au mont Cyllène (Hymne, v. 1–6)
  epithets:
    - { greek: Ἀργεϊφόντης, transliteration: Argeiphontēs, source: "Homère, Odyssée, V, 43 et X, 302 ; Hymne à Hermès, v. 73 ; explication « tueur d'Argos » : Apollodore, Bibliothèque, II, 1, 3" }
    - { greek: διάκτορος, transliteration: diaktoros, source: "Homère, Odyssée, V, 43 ; Iliade, XXIV, 339 ; Hymne à Hermès, v. 392" }
    - { greek: χρυσόρραπις, transliteration: chrysorrhapis, source: "Homère, Odyssée, X, 277 ; Hymne homérique à Déméter, v. 335" }
    - { greek: ἐριούνιος, transliteration: eriounios, source: "Hymne à Hermès, v. 3, 28 et 145" }
    - { greek: Κυλλήνιος, transliteration: Kyllēnios, source: "Homère, Odyssée, XXIV, 1 ; Hymne à Hermès, v. 304" }
relations:                   # sens : from → to
  - { from: zeus, to: hermes, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 938–939 ; Hymne à Hermès, v. 1–7 ; Apollodore, Bibliothèque, III, 10, 2" }
  - { from: maia, to: hermes, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 938–939 ; Hymne à Hermès, v. 1–7 ; Apollodore, Bibliothèque, III, 10, 2" }
  - { from: hermes, to: apollo, type: sibling-of, certainty: canonical, source: "Hymne à Hermès, v. 504 et 539 (deux fils de Zeus ; Apollon l'appelle κασίγνητε, « frère »)" }
  - { from: hermes, to: lyre, type: created, certainty: canonical, source: "Hymne à Hermès, v. 24–51 ; Apollodore, Bibliothèque, III, 10, 2" }
  - { from: hermes, to: perseus, type: helped, certainty: canonical, source: "Apollodore, Bibliothèque, II, 4, 2 (faucille en adamant ; Hermès et Athéna le guident vers les Phorcides) et II, 4, 3" }
  - { from: hermes, to: odysseus, type: helped, certainty: canonical, source: "Homère, Odyssée, X, 275–306 (le moly)" }
  - { from: hermes, to: argus, type: defeated, certainty: canonical, source: "Apollodore, Bibliothèque, II, 1, 3 (le tue d'une pierre, d'où « Argeiphontès »)" }
  - { from: hermes, to: pan, type: parent-of, certainty: variant, source: "Hymne homérique XIX (À Pan), v. 1 et 34–36 (mère : fille de Dryops) ; filiation variable selon les auteurs" }
  - { from: hermes, to: mount-olympus, type: lives-in, certainty: canonical, source: "Hymne à Hermès, v. 505 ; Odyssée, X, 307" }
# Non exprimé faute de type adapté :
#   - Hermès envoyé par Zeus pour ramener Perséphone ; il conduit le char (Hymne homérique à Déméter, v. 334–341, 377–384) — cohérent avec la fiche Hadès v2 ;
#   - Hermès guide Priam jusqu'à Achille (Iliade, XXIV, 333–348, 460–469, 690–694) : `priam` et `achilles` non validés ;
#   - échange lyre / bœufs avec Apollon (Hymne, v. 490–498) ; serment de ne plus voler Apollon (v. 521–523).
sources:
  - { source: "Hymne homérique IV, À Hermès", locus: "v. 1–19, 24–51, 68–86, 101–153, 212–214, 254–292, 322–396, 418–512, 521–573", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg004/tlg0013.tlg004.perseus-grc2.xml" }
  - { source: "Hésiode, Théogonie", locus: "v. 938–939", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml" }
  - { source: "Homère, Iliade", locus: "XXIV, 333–348, 460–469", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml" }
  - { source: "Homère, Odyssée", locus: "V, 28–54 ; X, 275–307 ; XXIV, 1–14", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg002/tlg0012.tlg002.perseus-grc2.xml" }
  - { source: "Hymne homérique II, À Déméter", locus: "v. 334–341, 377–384", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg002/tlg0013.tlg002.perseus-grc2.xml" }
  - { source: "Hymne homérique XIX, À Pan", locus: "v. 1, 28–40", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg019/tlg0013.tlg019.perseus-grc2.xml" }
  - { source: "Aristophane, Ploutos", locus: "v. 1153–1161", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0019/tlg011/tlg0019.tlg011.perseus-grc2.xml" }
  - { source: "Thucydide, Histoire de la guerre du Péloponnèse", locus: "VI, 27, 1", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0003/tlg001/tlg0003.tlg001.perseus-grc2.xml" }
  - { source: "(Pseudo-)Apollodore, Bibliothèque", locus: "II, 1, 3 ; II, 4, 2–3 ; III, 10, 2", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-grc2.xml" }
  - { source: "Pausanias, Description de la Grèce", locus: "IX, 22, 1", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0525/tlg001/tlg0525.tlg001.perseus-eng2.xml" }
  - { source: "Wikipedia EN, « Caduceus as a symbol of medicine » (point de départ, cite Friedlander 1992)", locus: "—", url: "https://en.wikipedia.org/wiki/Caduceus_as_a_symbol_of_medicine" }
review: { status: draft }
```

### MDX

```mdx
---
name: Hermès
role: Le messager des dieux, voleur dès le berceau
hook: Né à l'aube, musicien à midi, voleur de bœufs le soir. Et tu n'as encore rien vu : il n'a pas un jour.
---

## En bref

- **Famille :** fils de <E id="zeus">Zeus</E> et de la nymphe <E id="maia">Maïa</E> ; demi-frère d'<E id="apollo">Apollon</E>
- **Né :** dans une grotte du mont Cyllène, en Arcadie
- **Rôles :** messager des dieux, guide des âmes vers le monde des morts, protecteur des troupeaux, des voyageurs, des marchands… et des voleurs
- **Attributs :** le kérykeion (caducée en latin), baguette de héraut ; des sandales d'or ; un chapeau de voyageur, le pétase
- **Invention :** la lyre, tirée d'une carapace de tortue
- **Surnom :** Argeiphontès, compris dès l'Antiquité comme « le tueur d'Argos »
- **Nom romain :** Mercure (d'où *mercredi*, « jour de Mercure »)

## Son histoire

Hermès naît dans une grotte du mont Cyllène, en Arcadie. Sa mère est la nymphe Maïa ; son père, Zeus, venait la voir la nuit, en cachette d'<E id="hera">Héra</E>. L'*Hymne homérique à Hermès*, composé avant 500 av. J.-C., résume sa première journée : né à l'aube, il joue de la lyre à midi et vole des bœufs le soir.

Tout commence par une tortue croisée devant la grotte. Hermès vide sa carapace, y fixe des roseaux, tend une peau de bœuf et sept cordes en boyau de brebis : voilà la première lyre. Puis il file en Piérie et sépare cinquante vaches du troupeau d'Apollon.

Pour brouiller les pistes, il inverse leurs traces et marche lui-même à rebours, chaussé de sandales de branchages. Près du fleuve Alphée, il invente l'art d'allumer le feu avec des bâtons et sacrifie deux bêtes. À l'aube, il rentre par le trou de la serrure, « comme une brume », et se recouche dans son berceau.

Apollon remonte la piste jusqu'au berceau. Hermès jure qu'il n'y est pour rien : « Je suis né hier » (trad. de la rédaction). L'affaire finit devant Zeus, qui éclate de rire. Hermès joue alors de la lyre ; Apollon, conquis, l'échange contre les bœufs. Les deux frères deviennent amis, et le restent.

## Ses pouvoirs

- Messager de Zeus, il file sur la mer et la terre grâce à des sandales d'or qui le portent « avec le souffle du vent » ; Homère ne leur donne pas d'ailes.
- Sa baguette d'or endort ou réveille qui il veut (*Odyssée*, V, 47–48).
- Guide des âmes — on dit psychopompe : dans l'*Odyssée* (XXIV), il conduit les âmes des prétendants tués jusqu'à la prairie d'asphodèles, chez les morts.
- Il est le seul messager attitré auprès d'Hadès (*Hymne à Hermès*, v. 572). Dans l'*Hymne homérique à Déméter*, Zeus l'envoie chercher <E id="persephone">Perséphone</E> chez <E id="hades">Hadès</E>, dans les <E id="underworld">Enfers</E>, et il conduit son char jusqu'à sa mère.
- Il aide les héros : le moly, une plante magique, pour Ulysse face à Circé ; une faucille en adamant, matériau légendaire réputé indestructible, pour <E id="perseus">Persée</E> ; il fait passer le roi Priam sans être vu jusqu'à Achille (*Iliade*, XXIV).

<Versions title="Une histoire, plusieurs versions">
  <Version layer="ancient" source="Hymne homérique à Hermès, v. 47–51, 490–498, 529–530 (avant 500 av. J.-C.)">La lyre a sept cordes en boyau de brebis. Hermès l'offre à Apollon contre les bœufs. Apollon lui donne un fouet brillant, la garde des troupeaux, puis une baguette d'or à trois feuilles.</Version>
  <Version layer="ancient" source="Apollodore, Bibliothèque, III, 10, 2 (Ier–IIe siècle apr. J.-C.)">Les cordes viennent des bœufs sacrifiés. Hermès invente aussi la syrinx, la flûte de Pan. Apollon la veut : il donne en échange sa baguette d'or et lui apprend à deviner l'avenir avec des cailloux. Zeus fait d'Hermès son héraut et celui des dieux d'en bas.</Version>
  <Version layer="ancient" source="Apollodore, Bibliothèque, II, 1, 3">Sur ordre de Zeus, Hermès doit voler Io, changée en vache et gardée par Argos, le géant aux cent yeux. Ne pouvant agir en secret, il tue Argos d'une pierre : d'où son surnom d'Argeiphontès, « tueur d'Argos ».</Version>
  <Version layer="interpretation">Selon certains spécialistes, le nom d'Hermès viendrait de *herma*, « tas de pierres », comme ceux qui balisaient les routes. Ce rapprochement est aujourd'hui discuté : d'autres linguistes y voient un mot antérieur au grec. [À VÉRIFIER]</Version>
</Versions>

## Le saviez-vous ?

- **Le mauvais bâton.** Le caducée d'Hermès porte deux serpents ; le bâton d'Asclépios, dieu de la médecine, un seul. L'armée américaine a pourtant adopté le caducée pour ses médecins en 1902. La confusion dure encore.
- **Une nuit de vandalisme.** En 415 av. J.-C., pendant les préparatifs de l'expédition de Sicile, les hermès d'Athènes — des piliers à tête d'Hermès — ont presque tous le visage mutilé en une seule nuit (Thucydide, VI, 27).
- **Un bélier sur les épaules.** À Tanagra, raconte Pausanias (IIe siècle apr. J.-C.), Hermès aurait écarté une épidémie en portant un bélier autour des remparts. Chaque année, le plus beau jeune homme refaisait le tour avec un agneau.

## Dans la culture populaire

- ***Le Voleur de foudre*** (Percy Jackson, tome 1, Rick Riordan, 2005) : Luke, fils d'Hermès, se révèle être le vrai voleur de la foudre de Zeus et du casque d'Hadès. Les enfants mortels d'Hermès sont une invention moderne : Luke n'existe pas dans le mythe.
- **Hades** (Supergiant Games, 2020) : Hermès aide en secret Zagreus à s'évader des Enfers. Ses bonus rendent le héros plus rapide. Logique, pour le dieu aux sandales d'or.

## Pour aller plus loin

- <E id="apollo">Apollon</E> — Le grand frère volé, puis conquis par une lyre.
- <E id="perseus">Persée</E> — Le héros qui a tranché la tête de Méduse avec la faucille d'Hermès.
- <E id="odysseus">Ulysse</E> — Le héros rusé qu'Hermès sauve des sortilèges de Circé.

## Sources

- *Hymne homérique à Hermès* (avant 500 av. J.-C.), v. 1–19, 24–51, 68–153, 212–292, 322–396, 418–512, 521–573
- Hésiode, *Théogonie*, v. 938–939 (vers 700 av. J.-C.)
- Homère, *Iliade*, XXIV, 333–348 et 460–469 ; *Odyssée*, V, 28–54 ; X, 275–307 ; XXIV, 1–14 (fin du VIIIe – début du VIIe siècle av. J.-C.)
- *Hymne homérique à Déméter*, v. 334–341 et 377–384 (VIIe–VIe siècle av. J.-C.)
- *Hymne homérique à Pan* (XIX), v. 1 et 28–40
- Aristophane, *Ploutos*, v. 1153–1161 (début du IVe siècle av. J.-C.)
- Thucydide, *Histoire de la guerre du Péloponnèse*, VI, 27, 1 (fin du Ve siècle av. J.-C.)
- (Pseudo-)Apollodore, *Bibliothèque*, II, 1, 3 ; II, 4, 2–3 ; III, 10, 2 (Ier–IIe siècle apr. J.-C.)
- Pausanias, *Description de la Grèce*, IX, 22, 1 (IIe siècle apr. J.-C.)
- M. Friedlander, *The Golden Wand of Medicine* (1992), cité d'après Wikipédia EN, « Caduceus as a symbol of medicine »
```

### Sources consultées

Textes grecs numérotés (dépôt PerseusDL, raw.githubusercontent.com), lus ligne à ligne :
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg004/tlg0013.tlg004.perseus-grc2.xml — *Hymne à Hermès*, texte intégral (v. 1–580) : parents et grotte de Cyllène (1–9) ; journée de naissance (17–19 : ἠῷος γεγονὼς μέσῳ ἤματι ἐγκιθάριζεν, ἑσπέριος βοῦς κλέψεν) ; tortue et lyre, 7 cordes θηλυτέρων ὀίων (24–51) ; 50 vaches (74) ; traces inversées et marche à rebours (75–78) ; sandales de tamaris et myrte (79–86) ; Alphée, bâtons à feu (101–111 : Ἑρμῆς τοι πρώτιστα πυρήια πῦρ τʼ ἀνέδωκε) ; deux bêtes (116–119) ; trou de serrure, « comme une brume » (146–147) ; présage de l'oiseau (213–214) ; « χθὲς γενόμην » (273) ; ἀρχὸς φηλητέων (292) ; Zeus rit (389) ; « digne de cinquante bœufs » (437) ; échange lyre / bœufs, fouet (490–498) ; Hermès et Apollon amis « encore aujourd'hui » (507–508) ; syrinx (511–512) ; serment (521–523) ; baguette d'or à trois feuilles (529–530) ; κασίγνητε (539) ; seigneur des animaux, seul messager attitré auprès d'Hadès (567–573).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml — *Théogonie* v. 938–939 (Maïa fille d'Atlas, κήρυκʼ ἀθανάτων).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg002/tlg0012.tlg002.perseus-grc2.xml — *Odyssée* V, 28–54 (mission auprès de Calypso, sandales d'or « avec le souffle du vent », baguette qui endort ou éveille) ; X, 275–309 (rencontre d'Ulysse, φάρμακον, μῶλυ, v. 305 ; retour vers l'Olympe, v. 307) ; XXIV, 1–14 (âmes des prétendants, prairie d'asphodèles) ; VIII, 333–343 (lu, non utilisé).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml — *Iliade* XXIV, 333–348 (Zeus l'envoie guider Priam sans être vu ; mêmes vers sur les sandales et la baguette), 460–469, 690–694.
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg002/tlg0013.tlg002.perseus-grc2.xml — *Hymne à Déméter* v. 334–341 (Zeus envoie Hermès dans l'Érèbe), 346–356, 377–384 (Hermès prend rênes et fouet du char). Cohérent avec la fiche Hadès v2.
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-grc2.xml (+ trad. Frazer, perseus-eng2) — Apollodore III, 10, 2 (naissance, vol, lyre, syrinx, baguette d'or, divination par cailloux, héraut des dieux souterrains) ; II, 1, 3 (Argos, ὅθεν ἀργειφόντης ἐκλήθη) ; II, 4, 2 (παρὰ Ἑρμοῦ ἀδαμαντίνην ἅρπην ; Ἑρμοῦ καὶ Ἀθηνᾶς προκαθηγουμένων) ; II, 4, 3 (Persée rend sandales, kibisis et casque à Hermès, qui les rend aux nymphes). Numéros de section vérifiés par les balises CTS du fichier.
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg019/tlg0013.tlg019.perseus-grc2.xml — *Hymne à Pan* v. 1 (Ἑρμείαο φίλον γόνον), 28–40 (union avec la fille de Dryops).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0019/tlg011/tlg0019.tlg011.perseus-grc2.xml — Aristophane, *Ploutos* v. 1153–1161 (στροφαῖος, ἐμπολαῖος, δόλιος, ἡγεμόνιος, ἐναγώνιος).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0003/tlg001/tlg0003.tlg001.perseus-grc2.xml — Thucydide VI, 27, 1 (Ἑρμαῖ… μιᾷ νυκτὶ οἱ πλεῖστοι περιεκόπησαν τὰ πρόσωπα).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0525/tlg001/tlg0525.tlg001.perseus-eng2.xml — Pausanias IX, 22, 1 (Hermès Criophore à Tanagra, statue de Calamis, rite du plus beau jeune homme).

Références (point de départ) :
- https://en.wikipedia.org/wiki/Hermes — étymologie *herma* discutée (Beekes : origine pré-grecque), mutilation des hermès en 415, ailes des sandales tardives dans l'art, pétase.
- https://www.theoi.com/Olympios/Hermes.html — synthèse des fonctions et attributs (kérykeion, pétase, pedila).
- https://en.wikipedia.org/wiki/Caduceus_as_a_symbol_of_medicine — adoption par l'Army Medical Department en 1902, enquête Friedlander (1992).
- https://en.wikipedia.org/wiki/Caduceus — iconographie à deux serpents.
- https://en.wikipedia.org/wiki/Mercury_(mythology) — dies Mercurii ; étymologie *merx* présentée comme possible.
- https://bmcr.brynmawr.edu/?p=39592 — compte rendu de l'édition Richardson : *Hymne à Hermès* « daté d'avant 500 av. J.-C. ».
- https://en.wikipedia.org/wiki/Luke_Castellan et https://en.wikipedia.org/wiki/The_Lightning_Thief — Luke fils d'Hermès ; « real thief of Hades's Helm and Zeus's Bolt ».
- https://hades.fandom.com/wiki/Hermes — rôle d'Hermès dans *Hades* (aide secrète, bonus de vitesse).
- Recherche web sans résultat exploitable : étymologie antique de *Mercurius* chez Festus.

### Doutes

1. **Étymologie *herma* (bloc Versions, couche interpretation)** : vue uniquement sur Wikipédia EN, qui cite Beekes. Je n'ai pas consulté de source savante directe : [À VÉRIFIER], ou à retirer.
2. **« Mercredi, jour de Mercure »** : *dies Mercurii* figure dans l'infobox de Wikipédia EN, sans source vérifiée par moi. Le lien Mercure / *merx* (marchandise) n'est pas repris dans le texte, car il est présenté comme seulement « possible ».
3. **Pétase** : aucune attestation textuelle antique trouvée, seulement l'iconographie (Wikipédia, theoi). Je n'en ai rien dit d'autre qu'« un chapeau de voyageur ».
4. **Caducée à serpents** : les textes vérifiés parlent d'une baguette d'or, sans serpents. Les serpents ne relèvent que de l'iconographie. Je n'ai pas daté leur apparition.
5. **Date de l'*Hymne à Hermès*** : « avant 500 av. J.-C. » vient d'un compte rendu (BMCR) de l'édition Richardson, pas de l'édition elle-même.
6. **Dates d'Aristophane (*Ploutos*) et de Thucydide** : données de mémoire et non revérifiées (« début du IVe s. », « fin du Ve s. »).
7. **Caducée médical (1902)** : vient de Wikipédia EN, qui cite Friedlander, que je n'ai pas lu. Il faut aussi nuancer : le Medical Corps de l'armée américaine garde le caducée, mais d'autres services militaires utilisent le bâton d'Asclépios.
8. **Ids hors liste** : `maia` est validé (D6), `odysseus` est annoncé par le brief. En revanche, `lyre`, `argus`, `pan`, `kerykeion`, `petasos`, `winged-sandals` et `tortoise` sont à créer ou à valider. J'ai mis `<E id="maia">` et `<E id="odysseus">` dans le MDX.
9. **Messager auprès d'Hadès** : l'*Hymne à Hermès* (v. 572) fait de lui le « seul messager attitré » auprès d'Hadès. Le texte s'en tient à cette formule, sans affirmer qu'il serait le seul dieu à circuler entre les mondes.
10. **Moly** : l'*Odyssée* dit seulement qu'il protège des drogues de Circé. Je n'ai pas repris la consigne d'Hermès sur le lit de Circé (X, 296–301), un détail sensible et inutile ici.
11. **Pop culture** : la traduction française de « Hermes cabin » n'a pas été vérifiée, d'où une formulation générale. Je n'ai pas vérifié non plus si Hermès apparaît dans *Hercule* (Disney, 1997) : œuvre non citée.
12. **Le présage « venu du ventre »** (Hymne, v. 295–297) : épisode comique non utilisé (une seule touche d'humour par section).
13. **Typographie** : espaces insécables à appliquer au rendu.
