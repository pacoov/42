# Livrable rédacteur — Fiche « Déméter » — Lot 1, vague B — draft v1

### YAML

```yaml
id: demeter
type: deity
category: gods
names:
  greek: Δημήτηρ
  transliteration: Dēmētēr
  roman: Ceres
  aliases: [Déméter, Dêô, Deo, Cérès, Ceres]
gender: f
era: olympians
importance: 1
deity:
  domains: [agriculture, grain, harvest, mysteries]
  symbols: [ear-of-wheat, torch]     # torches : Hymne, v. 48, 61 ; épi : Hippolyte, Réfutation, V, 8 (rite éleusinien)
  olympian: true                     # comptée parmi les Douze dans la tradition courante (liste variable : voir brief)
  residence: mount-olympus           # elle rejoint l'Olympe à la fin de l'Hymne (v. 483–485) ; séjour à Éleusis dans le récit
  epithets:
    - { greek: Δηώ, transliteration: Dēō, source: "Hymne homérique à Déméter, v. 47, 211, 492" }
    - { greek: ὡρηφόρος, transliteration: hōrēphoros, source: "Hymne homérique à Déméter, v. 54, 192" }
    - { greek: ἀγλαόδωρος, transliteration: aglaodōros, source: "Hymne homérique à Déméter, v. 54, 192" }
    - { greek: χρυσάορος, transliteration: chrysaoros, source: "Hymne homérique à Déméter, v. 4" }
    - { greek: ξανθή, transliteration: xanthē, source: "Homère, Iliade, V, 500" }
relations:                           # sens : from → to
  - { from: cronos, to: demeter, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–454" }
  - { from: rhea, to: demeter, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–454 ; Hymne homérique à Déméter, v. 60, 75" }
  - { from: demeter, to: zeus, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–457" }
  - { from: demeter, to: hera, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 454" }
  - { from: demeter, to: hestia, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 454" }
  - { from: demeter, to: hades, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–455 ; Hymne homérique à Déméter, v. 79, 85" }
  - { from: demeter, to: poseidon, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–456" }
  # Union Zeus–Déméter : Hésiode dit seulement que Zeus « vint au lit » de Déméter (v. 912), sans préciser le consentement → filiation seule (D6).
  - { from: zeus, to: persephone, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 912–913" }
  - { from: demeter, to: persephone, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 912–913 ; Hymne homérique à Déméter, v. 1–2" }
  - { from: demeter, to: iasion, type: lover-of, certainty: canonical, source: "Hésiode, Théogonie, v. 969–971 ; Homère, Odyssée, V, 125–127" }   # union consentie (« cédant à son cœur », Od. V, 126)
  - { from: demeter, to: plutus, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 969–974" }
  - { from: iasion, to: plutus, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 969–971" }
  - { from: hecate, to: demeter, type: helped, certainty: canonical, source: "Hymne homérique à Déméter, v. 51–61" }
  - { from: helios, to: demeter, type: helped, certainty: canonical, source: "Hymne homérique à Déméter, v. 62–87 (lui révèle le rôle de Zeus et d'Hadès)" }
  - { from: demeter, to: triptolemus, type: mentor-of, certainty: canonical, source: "Hymne homérique à Déméter, v. 473–479 ; Apollodore, Bibliothèque, I, 5, 2 (char de dragons ailés et blé)" }
  - { from: demeter, to: ascalaphus, type: punished, certainty: variant, source: "Apollodore, Bibliothèque, I, 5, 3 (lourde pierre posée sur lui chez Hadès)" }
# Non exprimé faute de type adapté : enlèvement de Perséphone (voir fiche Hadès : zeus → hades : helped) ; Démophon nourri dans le feu ;
# temple d'Éleusis construit sur son ordre (Hymne, v. 270–272, 296–300).
sources:
  - { source: "Hymne homérique à Déméter", locus: "v. 1–4, 19–20, 40–61, 62–87, 90–123, 184–211, 231–274, 275–313, 314–333, 334–374, 384–413, 438–447, 470–490", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg002/tlg0013.tlg002.perseus-grc2.xml" }
  - { source: "Hésiode, Théogonie", locus: "v. 453–457, 912–914, 969–974", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml" }
  - { source: "Homère, Iliade", locus: "V, 499–502", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml" }
  - { source: "Homère, Odyssée", locus: "V, 125–128", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg002/tlg0012.tlg002.perseus-grc2.xml" }
  - { source: "(Pseudo-)Apollodore, Bibliothèque", locus: "I, 5, 1–3", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-grc2.xml" }
  - { source: "Ovide, Métamorphoses (poète romain)", locus: "V, 441–443, 468–470, 505", url: "https://raw.githubusercontent.com/PerseusDL/canonical-latinLit/master/data/phi0959/phi006/phi0959.phi006.perseus-lat2.xml" }
  - { source: "Hippolyte de Rome, Réfutation de toutes les hérésies", locus: "V, 8 (§ 39–40 dans la numérotation de la trad. Legge [À VÉRIFIER])", url: "https://people.well.com/~aquarius/hippolytus-refutatio.htm" }
  - { source: "Britannica, « Eleusinian Mysteries »", locus: "—", url: "https://www.britannica.com/print/article/184459" }
  - { source: "Encyclopedia of Religion (encyclopedia.com), « Eleusinian Mysteries »", locus: "—", url: "https://www.encyclopedia.com/environment/encyclopedias-almanacs-transcripts-and-maps/eleusinian-mysteries" }
review: { status: draft, version: 1 }
```

### MDX

```mdx
---
name: Déméter
role: La déesse des moissons, qui affama le monde pour sa fille
hook: Sa fille disparaît. Alors Déméter fait grève, et plus rien ne pousse sur terre.
---

## En bref

- **Famille :** fille de <E id="cronos">Cronos</E> et <E id="rhea">Rhéa</E> ; sœur de <E id="zeus">Zeus</E>, <E id="hera">Héra</E>, <E id="hestia">Hestia</E>, <E id="hades">Hadès</E> et <E id="poseidon">Poséidon</E> ; mère de <E id="persephone">Perséphone</E> (avec Zeus) et de Ploutos, « la Richesse » (avec le mortel Iasion)
- **Domaine :** le blé, les moissons, la terre cultivée ; les Mystères d'<E id="eleusis">Éleusis</E>
- **Autres noms :** Dêô ; chez les Romains, Cérès
- **Symboles :** l'épi de blé, les torches
- **Lieu-clé :** Éleusis, près d'Athènes, où elle fait bâtir son temple
- **Surnom inattendu :** « au glaive d'or » (*Hymne homérique à Déméter*, v. 4)

## Son histoire

Perséphone cueille des fleurs. La terre s'ouvre, <E id="hades">Hadès</E> l'emporte sur son char. Zeus l'a « donnée » à son frère, sans demander l'avis de la mère. C'est ce que raconte l'*Hymne homérique à Déméter* (VIIe–VIe siècle av. J.-C.). Déméter entend le cri de sa fille. Personne ne veut lui dire la vérité.

Neuf jours, elle parcourt la terre, des torches enflammées dans les mains, sans manger ni se laver. Le dixième jour, Hécate la conduit à Hélios, le Soleil, qui voit tout. Il lui révèle tout : c'est Zeus qui a donné Perséphone à Hadès. Furieuse, Déméter quitte l'Olympe et erre chez les humains, déguisée en vieille femme.

À Éleusis, elle se fait engager comme nourrice par la reine Métanire. Démasquée, elle exige un temple et s'y enferme. Puis elle bloque tout : les graines ne germent plus. L'humanité va mourir de faim, et les dieux perdre leurs sacrifices. Zeus envoie les dieux un par un, avec des cadeaux. Elle refuse tout tant qu'elle n'a pas revu sa fille.

Zeus cède et envoie <E id="hermes">Hermès</E>. Mais Hadès a fait avaler en secret un grain de grenade à Perséphone. Compromis : elle passera un tiers de l'année sous terre, le reste avec sa mère. Déméter fait alors repousser les récoltes. Avant de remonter sur l'Olympe, elle enseigne ses rites secrets aux princes d'Éleusis.

## Ses pouvoirs

- Elle fait pousser le grain… ou l'en empêche : dans l'*Hymne*, elle « cache » la semence dans la terre pendant un an entier (v. 305–307).
- Elle peut rendre un mortel immortel. La nuit, elle cache le bébé Démophon dans le feu comme un tison, pour lui ôter la mort (v. 239–242).
- Elle change d'apparence : vieille femme à Éleusis, puis déesse immense dont la tête touche le plafond (v. 188–189, 275–280).
- Elle fixe ses propres rites : les Mystères d'Éleusis, qu'elle enseigne elle-même aux princes de la ville (v. 473–479).

## Les Mystères d'Éleusis

Ce qu'on sait : chaque automne, au mois de Boédromion (septembre–octobre), les initiés — les *mystes* — marchaient en procession d'Athènes à Éleusis. Ils jeûnaient, puis buvaient le *cycéon*, boisson d'orge et d'eau, celle-là même que réclame Déméter dans l'*Hymne* (v. 208–210). D'abord réservés aux Athéniens, les Mystères s'ouvrent à tous les Grecs au Ve siècle av. J.-C.

Ce qu'on ignore : presque tout le reste. Les rites, célébrés dans une grande salle, le Télestérion, étaient secrets, et le secret a été bien gardé. L'*Hymne* le dit lui-même : on ne doit ni les divulguer ni même chercher à les connaître. En échange, l'initié espère un meilleur sort après la mort (v. 480–482).

<Versions title="Une histoire, plusieurs versions">
  <Version layer="ancient" source="Hymne homérique à Déméter, v. 371–374, 398–403, 411–413 et 441–447 (VIIe–VIe siècle av. J.-C.)">Hadès donne en secret un grain de grenade à Perséphone ; elle dira à sa mère qu'il l'a forcée à le manger. Par la voix de Rhéa, Zeus fixe le partage : un tiers de l'année sous terre, deux tiers avec sa mère. Elle remonte au printemps, quand la terre fleurit.</Version>
  <Version layer="ancient" source="Hymne homérique à Déméter, v. 242–262">Surprise par la mère, Déméter jette Démophon à terre. L'enfant survit mais restera mortel ; la déesse lui promet pourtant un honneur éternel.</Version>
  <Version layer="ancient" source="Apollodore, Bibliothèque, I, 5, 1–3 (Ier–IIe siècle apr. J.-C.)">Déméter cherche sa fille avec des torches, de nuit comme de jour. Ici, le bébé brûle dans le feu. Elle offre à Triptolème, son frère aîné, un char tiré par des dragons ailés et du blé à semer sur toute la terre. Ascalaphe, qui a dénoncé Perséphone, finit écrasé sous une lourde pierre.</Version>
  <Version layer="ancient" source="Ovide, Métamorphoses, V, 441–443, 468–470, 505 (poète romain, vers 8 apr. J.-C.)">Chez le poète romain Ovide, l'histoire se passe en Sicile. Cérès allume ses torches au feu de l'Etna. Elle retrouve la ceinture de sa fille dans un étang, puis apprend par la nymphe Aréthuse que Proserpine règne sous terre. Le partage final se fait en deux moitiés égales.</Version>
  <Version layer="interpretation">Beaucoup de lectures modernes voient dans le mythe une explication des saisons : la terre reste stérile tant que Perséphone est sous terre. L'*Hymne*, lui, lie surtout son retour au printemps. Le détail exact (quel tiers de l'année ?) reste discuté [À VÉRIFIER].</Version>
</Versions>

## Le saviez-vous ?

- **Le premier stand-up de la mythologie.** Déméter, en deuil, refuse de sourire. Une servante, Iambé, la fait rire à force de plaisanteries (*Hymne*, v. 202–204). Selon Apollodore, c'est pour cela que les femmes échangent des moqueries aux Thesmophories, une fête de Déméter.
- **Ton petit-déjeuner porte son nom.** Le mot « céréale » vient du latin *cerealis*, « de Cérès » — le nom romain de Déméter (dictionnaire Larousse).
- **Un épi pour tout secret.** Selon l'auteur chrétien Hippolyte (IIIe siècle apr. J.-C.), on montrait aux initiés d'Éleusis « un épi moissonné en silence » (trad. de la rédaction). C'est l'un des rares détails transmis, par un adversaire du culte.

## Dans la culture populaire

- ***Lore Olympus*** (Rachel Smythe, webtoon, 2018–2024) : Déméter y est une mère étouffante et contrôlante, qui laisse très peu de liberté à Perséphone.
- **Hades** (Supergiant Games, 2020) : Déméter arrive dans le jeu avec la mise à jour « The Long Winter » (janvier 2020). Ses bienfaits apportent le froid et ralentissent les ennemis.
- **Cérès, planète naine** : découverte en 1801 par l'astronome Giuseppe Piazzi à Palerme, elle porte le nom de la déesse, dont le plus ancien temple se trouvait en Sicile, selon lui.

## Pour aller plus loin

- <E id="persephone">Perséphone</E> — Pas seulement « la fille enlevée » : une reine des Enfers à part entière.
- <E id="hades">Hadès</E> — Le ravisseur, l'oncle et le gendre : un seul dieu pour trois rôles.
- <E id="eleusis">Éleusis</E> — Le sanctuaire où des milliers de Grecs ont gardé le même secret pendant des siècles.

## Sources

- *Hymne homérique à Déméter*, v. 1–4, 19–20, 40–123, 184–313, 314–413, 438–490 (VIIe–VIe siècle av. J.-C.)
- Hésiode, *Théogonie*, v. 453–457, 912–914, 969–974 (vers 700 av. J.-C.)
- Homère, *Iliade*, V, 499–502 ; *Odyssée*, V, 125–128 (fin du VIIIe – début du VIIe siècle av. J.-C.)
- (Pseudo-)Apollodore, *Bibliothèque*, I, 5, 1–3 (Ier–IIe siècle apr. J.-C.)
- Ovide, *Métamorphoses*, V, 441–443, 468–470, 505 (poète romain, vers 8 apr. J.-C.)
- Hippolyte de Rome, *Réfutation de toutes les hérésies*, V, 8 (IIIe siècle apr. J.-C.)
- *Encyclopædia Britannica*, « Eleusinian Mysteries » ; *Encyclopedia of Religion*, « Eleusinian Mysteries »
```

### Sources consultées

Textes antiques (lus moi-même) :
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg002/tlg0013.tlg002.perseus-grc2.xml — *Hymne à Déméter*, grec numéroté : v. 2–4 (Ἀιδωνεὺς ἥρπαξεν, δῶκεν δὲ… Ζεύς ; χρυσαόρου, v. 4), 19–20 (ἀέκουσαν), 47–51 (ἐννῆμαρ, αἰθομένας δαΐδας, jeûne, pas de bain, dixième aurore), 54 et 192 (ὡρηφόρος, ἀγλαόδωρος), 61, 122 (Δωσώ), 192–211 (Iambé, refus du vin, ἄλφι καὶ ὕδωρ… γλήχωνι, κυκεῶ v. 210, Δηώ v. 211), 233–234, 239–242 (feu, ἀγήρων τʼ ἀθάνατον), 260–262, 270–271 (temple), 305–313 (année stérile, menace sur les humains et les offrandes), 371–374 (grenade λάθρῃ), 398–403 (tiers de l'année, retour au printemps), 411–413 (« forcée »), 441–447 (Rhéa, partage), 470–482 (retour des récoltes, rites enseignés, secret, bonheur de l'initié), 484–489.
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg002/tlg0013.tlg002.perseus-eng2.xml — trad. anglaise Evelyn-White avec numéros (Hécate, Hélios, Doso, filles de Céléos, Métanire, Démophon, Iris, dieux envoyés, Hermès, Ploutos).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml — Théogonie v. 453–458 (enfants de Cronos et Rhéa), 912–914 (Δήμητρος… ἐς λέχος ἦλθεν ; Perséphone ; Aïdoneus l'enlève, Zeus la donne), 969–974 (Ploutos, fils de Déméter et Iasion, en Crète).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml — Iliade V, 499–502 (ξανθὴ Δημήτηρ, vannage) ; II, 696 et XIV, 326 repérés, non utilisés.
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg002/tlg0012.tlg002.perseus-grc2.xml — Odyssée V, 125–128 (Iasion, ᾧ θυμῷ εἴξασα ; foudroyé par Zeus).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0548/tlg001/tlg0548.tlg001.perseus-grc2.xml et …perseus-eng2.xml — Apollodore I, 5, 1–3, grec et trad. Frazer : torches nuit et jour, Hermione, rocher Agélastos, Iambé et Thesmophories, Démophon consumé, Praxithéa, Triptolème (char de dragons ailés, blé), grenade, Ascalaphe, tiers de l'année.
- https://raw.githubusercontent.com/PerseusDL/canonical-latinLit/master/data/phi0959/phi006/phi0959.phi006.perseus-lat2.xml — Ovide, Mét. V, 441–443 (torches à l'Etna), 468–470 (zona), 505 (Aréthuse a vu Proserpine). Moitiés égales : v. 564–567, vérifiés dans la fiche Hadès v2 (non relus par moi).
- https://www.thelatinlibrary.com/ovid/ovid.met5.shtml — même passage (contrôle).
- https://people.well.com/~aquarius/hippolytus-refutatio.htm — Hippolyte, Réfutation V, 8 (trad. Legge) : « a green ear of corn reaped in silence » montré aux époptes.

Références :
- https://www.britannica.com/print/article/184459 — Grands Mystères en Boédromion (septembre–octobre), procession d'Athènes à Éleusis, Télestérion, rites restés secrets, jeûne.
- https://www.encyclopedia.com/environment/encyclopedias-almanacs-transcripts-and-maps/eleusinian-mysteries — ouverture à tous les Grecs dans la seconde moitié du Ve s., Petits Mystères à Agrai, epopteia, Théodose et destruction par les Goths (395).
- https://fhw.gr/chronos/05/en/culture/4141ritual_eleusinia.html — déroulement du festival, cycéon, épi montré par le hiérophante.
- https://www.theoi.com/Olympios/Demeter.html — attributs (gerbe, torche, sceptre, pavot…), nom romain Cérès.
- https://www.larousse.fr/dictionnaires/college/c%C3%A9r%C3%A9ale/7071 — « lat. cerealis, de Cérès ».
- https://en.wikipedia.org/wiki/Ceres_(dwarf_planet) — Piazzi, 1er janvier 1801, Palerme ; nom choisi pour la déesse « whose earthly home, and oldest temple, lay in Sicily ».
- https://en.wikipedia.org/wiki/Lore_Olympus — Rachel Smythe ; Déméter mère surprotectrice et contrôlante ; WEBTOON Canvas mars 2018, fin 2 juin 2024.
- https://en.wikipedia.org/wiki/Hades_(video_game) — Déméter parmi les personnages.
- https://gameranx.com/updates/id/190534/article/hades-supergiant-games-long-winter-update/ — mise à jour « The Long Winter », 21 janvier 2020 ; Déméter « powers over desolation and cold », effets de ralentissement.
- Fiche de cohérence : /home/claude/editorial/drafts/hades.v2.md.

### Doutes

1. **Section « Les Mystères d'Éleusis »** : ajoutée hors gabarit (§ 5), car le brief demande ce point et il ne tient pas dans « Son histoire » (≤ 60 mots par paragraphe). À arbitrer : garder la section, ou la réduire à une puce de « Ses pouvoirs » + un « Le saviez-vous ? ».
2. **« Son histoire »** : environ 230 mots en 4 paragraphes, dans la fourchette ; le 3e paragraphe frôle les 60 mots, à recompter au rendu.
3. **Interprétation saisonnière** : quel tiers de l'année Perséphone passe sous terre (hiver, ou été selon certaines lectures savantes dont je n'ai pas retrouvé l'auteur) n'est pas vérifié → [À VÉRIFIER] dans le texte ; je n'ai lu aucune source secondaire sur ce point.
4. **Hippolyte** : numérotation « V, 8, 39–40 » donnée par la page de la trad. Legge ; les éditions modernes numérotent autrement. Datation « IIIe siècle apr. J.-C. » non vérifiée sur une source dédiée.
5. **Ovide, partage en moitiés égales (V, 564–567)** : repris de la fiche Hadès v2, pas relu par moi.
6. **Cycéon** : γλήχων (v. 209) est d'ordinaire traduit par « menthe pouliot » ; je n'ai écrit que « orge et eau » dans le MDX pour ne pas affirmer la glose sans dictionnaire consulté. Le texte omet donc l'herbe.
7. **Ids nouveaux** proposés hors liste du brief : `iasion`, `plutus`, `hecate`, `helios`, `triptolemus`, `ascalaphus`, `eleusis` (ce dernier annoncé par le brief). Ploutos est nommé sans `<E>` dans le MDX faute de fiche annoncée.
8. **`olympian: true`** et `residence: mount-olympus` : tradition courante ; l'*Hymne* la montre fuyant l'Olympe puis y retournant (v. 92, 484). Aucune liste antique des Douze consultée pour elle.
9. **Épithètes** : sens donnés d'après Evelyn-White (« bringer of seasons », « giver of good gifts », « lady of the golden sword ») ; seul « au glaive d'or » est traduit dans le MDX. Pas de vérification dans le LSJ.
10. **Pop culture** : la date de la mise à jour Hades vient d'un média (gameranx), pas des notes officielles de Supergiant (repérées, non ouvertes). Les détails du gameplay restent généraux (« froid », « ralentir »).
11. **Démophon dans l'Hymne** : le texte dit qu'il ne pourra échapper à la mort ; le dire « survit » repose sur v. 289–291 et 300 (il grandit), lus en traduction.
12. **Typographie** : espaces insécables à appliquer au rendu.
