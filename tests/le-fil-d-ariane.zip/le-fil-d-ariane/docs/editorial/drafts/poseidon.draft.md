# Livrable rédacteur — Fiche « Poséidon » (lot 1, vague A) — v1

### YAML

```yaml
id: poseidon
type: deity
category: gods
names:
  greek: Ποσειδῶν
  transliteration: Poseidôn
  roman: Neptunus
  aliases: [Poséidon, Poseidon, Neptune, Ennosigaios, Ébranleur de la terre, Hippios]
era: olympians
importance: 1
deity:                     # spécialisation proposée (le guide ne donne que le modèle `creature`) ; à valider
  domains: [mer, tremblements de terre, chevaux]
  symbols: [trident, cheval, taureau]   # taureau : sacrifices de taureaux noirs à Pylos (Odyssée, III, 5–6)
  epithets:
    - { greek: Ἐννοσίγαιος, transliteration: Ennosigaios, meaning: "l'Ébranleur de la terre", source: "Hésiode, Théogonie, v. 456 ; Iliade, XV, 184 ; Hymne homérique 22, v. 4" }
    - { greek: ἐνοσίχθων, transliteration: Enosichthôn, meaning: "qui secoue la terre", source: "Iliade, XX, 63 ; Odyssée, I, 74" }
    - { greek: γαιήοχος, transliteration: Gaiêochos, meaning: "qui tient la terre (sens discuté)", source: "Odyssée, I, 68 ; Hymne homérique 22, v. 6" }
    - { greek: κυανοχαίτης, transliteration: Kyanochaitês, meaning: "aux cheveux sombres", source: "Hésiode, Théogonie, v. 278 ; Odyssée, IX, 528" }
    - { greek: Ἵππιος, transliteration: Hippios, meaning: "le dieu des chevaux", source: "Pausanias, VIII, 25, 7 ; I, 30, 4" }
  home: "Palais d'or au fond de la mer, à Aigai (Iliade, XIII, 21–22 ; Odyssée, V, 381)"
relations:                 # sens : from → to
  - { from: cronos, to: poseidon, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–456 ; Homère, Iliade, XV, 187 ; Apollodore, Bibliothèque, I, 1, 5" }
  - { from: rhea, to: poseidon, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–456 ; Homère, Iliade, XV, 187" }
  - { from: poseidon, to: zeus, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–457 ; Homère, Iliade, XV, 187–188" }
  - { from: poseidon, to: hades, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–456 ; Homère, Iliade, XV, 187–188" }
  - { from: poseidon, to: hera, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–456 ; Apollodore, Bibliothèque, I, 1, 5" }
  - { from: poseidon, to: hestia, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–456 ; Apollodore, Bibliothèque, I, 1, 5" }
  - { from: poseidon, to: demeter, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–456 ; Apollodore, Bibliothèque, I, 1, 5" }
  - { from: cyclopes, to: poseidon, type: helped, certainty: canonical, source: "Apollodore, Bibliothèque, I, 2, 1 (lui donnent le trident)" }
  - { from: poseidon, to: trident, type: owns, certainty: canonical, source: "Homère, Odyssée, IV, 506 ; V, 292 ; Iliade, XII, 27 ; Apollodore, Bibliothèque, I, 2, 1" }
  - { from: poseidon, to: aigai, type: lives-in, certainty: canonical, source: "Homère, Iliade, XIII, 21–22 ; Odyssée, V, 381" }
  - { from: poseidon, to: amphitrite, type: spouse-of, certainty: canonical, source: "Hésiode, Théogonie, v. 930–933 ; Apollodore, Bibliothèque, I, 4, 5" }
  - { from: poseidon, to: triton, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 930–933" }
  - { from: amphitrite, to: triton, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 930–933" }
  - { from: poseidon, to: polyphemus, type: parent-of, certainty: canonical, source: "Homère, Odyssée, I, 68–73 ; IX, 519, 529" }
  - { from: thoosa, to: polyphemus, type: parent-of, certainty: canonical, source: "Homère, Odyssée, I, 71–73" }
  - { from: poseidon, to: pegasus, type: parent-of, certainty: canonical, source: "Apollodore, Bibliothèque, II, 4, 3 (union avec Méduse : Hésiode, Théogonie, v. 278–281)" }
  - { from: poseidon, to: chrysaor, type: parent-of, certainty: canonical, source: "Apollodore, Bibliothèque, II, 4, 3 (union avec Méduse : Hésiode, Théogonie, v. 278–281)" }
  - { from: poseidon, to: theseus, type: parent-of, certainty: variant, source: "Bacchylide, 17, v. 33–36 et 58–60 ; Apollodore, Bibliothèque, III, 15, 7 (double paternité avec Égée) ; Pausanias, I, 17, 3" }
  - { from: odysseus, to: polyphemus, type: defeated, certainty: canonical, source: "Homère, Odyssée, IX (aveuglement) ; I, 69" }
  - { from: poseidon, to: odysseus, type: enemy-of, certainty: canonical, source: "Homère, Odyssée, I, 19–21 et 68–75 ; V, 282–290" }
  - { from: poseidon, to: athena, type: enemy-of, certainty: variant, source: "Hérodote, Histoires, VIII, 55 ; Apollodore, Bibliothèque, III, 14, 1 (rivalité ponctuelle : la dispute pour l'Attique ; ailleurs, ils sont dans le même camp)" }
  - { from: poseidon, to: peleus, type: helped, certainty: canonical, source: "Apollodore, Bibliothèque, III, 13, 5 (chevaux immortels Balios et Xanthos)" }
# Non exprimable avec les types autorisés, consigné ici :
#   - Partage du monde : tirage au sort chez Homère (Iliade, XV, 187–193) et Apollodore (I, 2, 1) ;
#     chez Hésiode (Théogonie, v. 881–885), Zeus, proclamé roi, répartit les honneurs → voir la fiche `zeus`.
#   - Le trident est « donné » par les Cyclopes chez Apollodore (Κύκλωπες … διδόασι … Ποσειδῶνι δὲ τρίαιναν) ;
#     le texte ne dit pas explicitement « forgé ». Pas de relation `cyclopes created trident` proposée.
#   - Rivalités territoriales hors Attique (Pausanias) : avec Héra pour l'Argolide (II, 15, 5 ; II, 22, 4),
#     avec Hélios pour Corinthe (II, 1, 6) — non traitées dans le MDX.
sources:
  - { source: "Hésiode, Théogonie", locus: "v. 139–141, 278–281, 453–467, 501–506, 881–885, 930–933", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml" }
  - { source: "Homère, Iliade", locus: "XII, 27 ; XIII, 17–31 ; XV, 184–193 ; XX, 56–66 ; XXI, 441–457 ; XXIII, 306–308, 584–585", url: "https://www.theoi.com/Text/HomerIliad15.html" }
  - { source: "Homère, Odyssée", locus: "I, 19–27, 68–75 ; IV, 505–511 ; V, 282–294, 366, 375–381 ; IX, 366–367, 408–412, 518–536 ; XIII, 159–164", url: "https://www.theoi.com/Text/HomerOdyssey1.html" }
  - { source: "Hymne homérique 22, À Poséidon", locus: "v. 1–7", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg022/tlg0013.tlg022.perseus-grc2.xml" }
  - { source: "Bacchylide, Dithyrambe 17 (Les Jeunes gens, ou Thésée)", locus: "v. 33–38, 57–63, 97–116", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0199/tlg002/tlg0199.tlg002.perseus-grc2.xml" }
  - { source: "Hérodote, Histoires", locus: "VIII, 55", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0016/tlg001/tlg0016.tlg001.perseus-grc2.xml" }
  - { source: "Sophocle, Œdipe à Colone", locus: "v. 707–719", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0011/tlg007/tlg0011.tlg007.perseus-grc2.xml" }
  - { source: "(Pseudo-)Apollodore, Bibliothèque", locus: "I, 1, 5–7 ; I, 2, 1 ; I, 4, 5 ; II, 4, 2–3 ; III, 13, 5 ; III, 14, 1 ; III, 15, 7", url: "https://www.theoi.com/Text/Apollodorus1.html" }
  - { source: "Pausanias, Description de la Grèce", locus: "I, 17, 3 ; I, 24, 5 ; I, 26, 5 ; I, 30, 4 ; VIII, 8, 2 ; VIII, 25, 7", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0525/tlg001/tlg0525.tlg001.perseus-eng2.xml" }
  - { source: "Ovide, Métamorphoses (poète romain)", locus: "VI, 70–82", url: "https://www.thelatinlibrary.com/ovid/ovid.met6.shtml" }
  - { source: "Augustin, La Cité de Dieu, citant Varron (auteurs latins)", locus: "XVIII, 9", url: "https://www.thelatinlibrary.com/augustine/civ18.shtml" }
review: { status: draft }
```

### MDX

```mdx
---
name: Poséidon
role: Le dieu de la mer, des séismes et des chevaux
hook: Quand il marche, les montagnes tremblent. Quand il se vexe, Ulysse ne rentre plus chez lui.
---

## En bref

- **Famille :** fils de <E id="cronos">Cronos</E> et <E id="rhea">Rhéa</E> ; frère de <E id="zeus">Zeus</E>, d'<E id="hades">Hadès</E>, d'<E id="hera">Héra</E>, d'<E id="hestia">Hestia</E> et de <E id="demeter">Déméter</E>
- **Domaines :** la mer, les tremblements de terre, les chevaux
- **Symbole :** le <E id="trident">trident</E>, donné par les <E id="cyclopes">Cyclopes</E> selon Apollodore
- **Lieu :** un palais d'or au fond de la mer, à Aigai
- **Épouse :** <E id="amphitrite">Amphitrite</E>, mère de <E id="triton">Triton</E>
- **Enfants célèbres :** <E id="polyphemus">Polyphème</E>, <E id="pegasus">Pégase</E>, <E id="chrysaor">Chrysaor</E> et, selon certaines versions, <E id="theseus">Thésée</E>
- **Chez les Romains :** Neptune

## Son histoire

Mauvais départ dans la vie : à peine né, Poséidon est avalé par son père. <E id="cronos">Cronos</E> craint d'être renversé par un de ses enfants, alors il les engloutit tous. Seul <E id="zeus">Zeus</E> y échappe. Adulte, il force Cronos à recracher toute la fratrie, puis mène la guerre contre les <E id="titans">Titans</E>.

Après la victoire, il faut partager le monde. Dans l'*Iliade*, Poséidon raconte un tirage au sort : « Le sort m'a donné la mer grise, pour l'habiter à jamais » (XV, 190, trad. de la rédaction). Zeus obtient le ciel, Hadès les ténèbres. Chez Hésiode, c'est Zeus, proclamé roi, qui distribue les honneurs.

La mer n'est pas son seul domaine. Les poètes l'appellent Ennosigaios, « l'Ébranleur de la terre » : les séismes, c'est lui. On l'honore aussi comme Hippios, « le dieu des chevaux ». Il vit dans un palais d'or étincelant, au fond des eaux, à Aigai.

Dans l'*Odyssée*, il devient le pire ennemi d'<E id="odysseus">Ulysse</E>. Le héros a aveuglé le Cyclope <E id="polyphemus">Polyphème</E>, fils de Poséidon et de la nymphe Thoosa. Le Cyclope prie son père : qu'Ulysse rentre tard, seul et dans le malheur. Poséidon ne le tue pas. Il le fait errer loin de chez lui, tempête après tempête.

## Ses pouvoirs

- Il ébranle la terre : dans l'*Iliade* (XX, 57–60), il secoue le sol immense et les sommets des montagnes.
- Il déchaîne la mer : trident en main, il rassemble les nuages et lève tous les vents contre Ulysse (*Odyssée*, V, 291–294).
- Il pétrifie : il change en rocher le navire des Phéaciens qui a ramené Ulysse chez lui (*Odyssée*, XIII, 159–164).
- Il règne sur les chevaux : l'*Hymne homérique à Poséidon* le dit « dompteur de chevaux et sauveur des navires » (trad. de la rédaction).
- Il fait des cadeaux de dieu : selon Apollodore, il offre à Pélée, père d'Achille, deux chevaux immortels, Balios et Xanthos.

<Versions title="Athènes : qui a gagné, et comment ?">
  <Version layer="ancient" source="Hérodote, Histoires, VIII, 55 (vers 430 av. J.-C.)">L'historien grec Hérodote rapporte une tradition athénienne : Poséidon et <E id="athena">Athéna</E> se sont disputé le pays. Sur l'Acropole, dans le temple d'Érechthée, un olivier et une « mer » — de l'eau salée — en sont les témoins. Il ne raconte ni le jugement ni le vainqueur.</Version>
  <Version layer="ancient" source="Apollodore, Bibliothèque, III, 14, 1 (Ier–IIe s. apr. J.-C.)">Poséidon arrive le premier : d'un coup de trident sur l'Acropole, il fait jaillir une « mer ». Athéna plante ensuite un olivier, devant le roi Cécrops. Les douze dieux jugent : le pays revient à Athéna, qui a planté la première. Furieux, Poséidon inonde la plaine de Thria et submerge l'Attique.</Version>
  <Version layer="ancient" source="Augustin, La Cité de Dieu, XVIII, 9, citant Varron (auteurs latins)">Chez l'érudit romain Varron (Ier s. av. J.-C.), un olivier et une source apparaissent soudain. Les citoyens votent : les hommes pour Neptune, les femmes pour Minerve, qui gagne d'une voix. Neptune ravage le pays sous les flots. Pour l'apaiser, on retire aux femmes le droit de vote.</Version>
  <Version layer="ancient" source="Ovide, Métamorphoses, VI, 70–82 (poète romain, vers 8 apr. J.-C.)">Chez le poète romain Ovide, Minerve tisse elle-même la scène lors de son concours contre Arachné. Douze dieux siègent autour de Jupiter. Le dieu de la mer fait jaillir de l'eau de mer du rocher ; Minerve fait pousser un olivier. La Victoire couronne son œuvre.</Version>
  <Version layer="interpretation">Ce récit est souvent lu comme un mythe étiologique — une histoire qui explique l'origine d'une chose. Il justifierait le nom d'Athènes, le culte commun des deux dieux sur l'Acropole et les « reliques » qu'on y montrait.</Version>
</Versions>

## Le saviez-vous ?

- **Le coup du poulain.** Selon une légende arcadienne rapportée par Pausanias (VIII, 8, 2), Rhéa aurait caché Poséidon parmi des agneaux. À Cronos, elle donne un poulain à avaler à sa place.
- **Hadès en sursaute.** Dans l'*Iliade* (XX, 61–65), Poséidon secoue tant la terre qu'Hadès bondit de son trône en criant. Il a peur que le sol s'ouvre et dévoile son royaume.
- **Les preuves exposées.** Au IIe siècle apr. J.-C., Pausanias (I, 26, 5) voit dans l'Érechthéion, sur l'Acropole, un puits d'eau de mer et la marque d'un trident sur la roche.

## Dans la culture populaire

- **Percy Jackson** (Rick Riordan, romans depuis 2005 ; série Disney+ depuis 2023) : le héros est un demi-dieu, fils de Poséidon et d'une mortelle. Une invention moderne.
- **God of War III** (Sony, PlayStation 3, 2010) : Kratos tue Poséidon dès le début du jeu, et les océans submergent la Grèce.
- **Hades** (Supergiant Games, 2020) : Poséidon offre au héros, Zagreus, des « bienfaits » qui repoussent les ennemis par des vagues.

## Pour aller plus loin

- <E id="zeus">Zeus</E> — Le petit frère devenu roi : le partage du monde vu de son côté.
- <E id="athena">Athéna</E> — La nièce qui lui a soufflé Athènes avec un simple olivier.
- <E id="odysseus">Ulysse</E> — Le héros qui a mis le dieu de la mer en colère pour des années.

## Sources

- Homère, *Iliade* et *Odyssée* (vers le VIIIe siècle av. J.-C.) : *Il.* XII, 27 ; XIII, 17–31 ; XV, 184–193 ; XX, 56–66 ; *Od.* I, 19–27 et 68–75 ; V, 282–294 ; IX, 518–536 ; XIII, 159–164
- Hésiode, *Théogonie*, v. 453–467, 881–885, 930–933 (vers 700 av. J.-C.)
- *Hymne homérique 22, À Poséidon*, v. 1–7 (date incertaine)
- Bacchylide, *Dithyrambe* 17 (Ve siècle av. J.-C.)
- Hérodote, *Histoires*, VIII, 55 (vers 430 av. J.-C.)
- (Pseudo-)Apollodore, *Bibliothèque*, I, 1, 5 – I, 2, 1 ; I, 4, 5 ; III, 13, 5 ; III, 14, 1 ; III, 15, 7 (Ier–IIe siècle apr. J.-C.)
- Pausanias, *Description de la Grèce*, I, 17, 3 ; I, 26, 5 ; VIII, 8, 2 ; VIII, 25, 7 (IIe siècle apr. J.-C.)
- Ovide, *Métamorphoses*, VI, 70–82 (poète romain, vers 8 apr. J.-C.)
- Augustin, *La Cité de Dieu*, XVIII, 9, citant Varron (auteurs latins, Ve et Ier siècles)
```

### Sources consultées

- https://www.theoi.com/Olympios/Poseidon.html — point de départ : filiation, épithètes, domaines, liste de loci (Iliade, Pausanias, Apollodore) ; légende du poulain (Pausanias VIII, 8, 2) ; aucune source citée pour « trident forgé par les Cyclopes ».
- https://www.theoi.com/Text/Apollodorus1.html — Bibliothèque I, 1, 5–7 (Cronos avale Hestia, Déméter, Héra, Pluton, Poséidon ; pierre), I, 2, 1 (Cyclopes donnent foudre, casque, trident ; tirage au sort), I, 4, 5 (Amphitrite, Triton).
- https://www.theoi.com/Text/Apollodorus3.html — III, 13, 5 (Balios et Xanthos) ; III, 14, 1 (dispute de l'Attique : trident, « mer Érechthéide », olivier, Cécrops témoin, douze dieux, inondation de la plaine Thriasienne).
- https://www.theoi.com/Text/HomerIliad15.html — Iliade XV, discours du partage (trad. Murray).
- https://www.theoi.com/Text/HomerOdyssey1.html — Odyssée I : colère de Poséidon, Éthiopiens, Polyphème fils de Thoosa.
- https://www.theoi.com/Text/HomerOdyssey9.html — Odyssée IX : ruse de « Personne », prière de Polyphème (trad. Murray).
- https://www.theoi.com/Text/Pausanias2A.html — Pausanias II, 1, 6 (dispute avec Hélios pour Corinthe).
- Textes grecs numérotés, dépôt PerseusDL (raw.githubusercontent.com/PerseusDL/canonical-greekLit), lus vers par vers :
  - tlg0012.tlg001 (Iliade) : XII, 17–33 ; XIII, 17–31 ; XV, 184–193 ; XX, 56–66 ; XXI, 441–457 ; VII, 446–453 ; XXIII, 306–308, 584–585.
  - tlg0012.tlg002 (Odyssée) : I, 19–27, 68–75 ; III, 4–8 ; IV, 505–511 ; V, 282–294, 365–381 ; IX, 366–367, 408, 412, 518–536 ; XI, 119–131 ; XIII, 159–169.
  - tlg0020.tlg001 (Théogonie) : v. 139–141, 276–283, 453–467, 501–506, 881–885, 930–933.
  - tlg0013.tlg022 (Hymne homérique 22) : v. 1–7.
  - tlg0016.tlg001 (Hérodote) : VIII, 55.
  - tlg0011.tlg007 (Sophocle, Œdipe à Colone) : v. 707–719 (grec et trad. anglaise).
  - tlg0548.tlg001 (Apollodore, grec) : I, 2, 1 ; II, 4, 2–3 ; III, 14, 1 ; III, 15, 7.
  - tlg0199.tlg002 (Bacchylide, Dithyrambe 17) : v. 1–132.
  - tlg0525.tlg001 (Pausanias, grec et trad. Jones) : I, 2, 4 ; I, 17, 3 ; I, 24, 3 ; I, 24, 5 ; I, 26, 5 ; I, 30, 4 ; II, 1, 6 ; II, 15, 5 ; II, 22, 4 ; II, 33, 1 ; VIII, 8, 2 ; VIII, 25, 7.
- https://www.thelatinlibrary.com/ovid/ovid.met6.shtml — Ovide, Métamorphoses VI, 70–82 (« exsiluisse fretum », olivier, Victoire).
- https://www.thelatinlibrary.com/augustine/civ18.shtml — Augustin, Cité de Dieu XVIII, 9 (Varron : vote, Minerve gagne d'une voix, punition des femmes).
- https://www.thelatinlibrary.com/vergil/geo1.shtml — Virgile, Géorgiques I, 12–14 (Neptune et le premier cheval ; non utilisé dans le texte).
- https://en.wikipedia.org/wiki/Poseidon — point de départ : linéaire B (Pylos), étymologie discutée, Neptune, Hippios.
- https://www.britannica.com/topic/Poseidon — domaines (mer, séismes, chevaux), partage.
- https://en.wikipedia.org/wiki/Theseus_Ring — renvoi à Bacchylide 17 pour l'épisode de l'anneau.
- https://dn710109.ca.archive.org/0/items/bacchylidespoems00bacciala/bacchylidespoems00bacciala_djvu.txt — Jebb, préface (résumé de l'ode sur Thésée) ; texte non exploitable.
- https://en.wikipedia.org/wiki/Percy_Jackson_(character) — fils de Poséidon et de Sally Jackson ; série 2005–2009 ; série Disney+ 2023.
- https://en.wikipedia.org/wiki/God_of_War_III — PS3, 16 mars 2010 ; Kratos tue Poséidon, les océans inondent la Grèce.
- https://en.wikipedia.org/wiki/Hades_(video_game) — Supergiant Games, 2020 ; bienfaits (Boons) de Poséidon à effet de vague qui repousse.

### Doutes

1. **Trident « forgé » par les Cyclopes** : Apollodore (I, 2, 1) dit seulement que les Cyclopes « donnent » (διδόασι) le trident. Hésiode dit qu'ils ont « fabriqué » la foudre de Zeus (v. 141), mais ne parle pas du trident. J'ai écrit « donné » ; ne pas écrire « forgé » sans autre source.
2. **Partage du monde** : je ne développe pas de bloc `<Versions>` (renvoi à la fiche Zeus, selon le brief). Le texte résume en une phrase les deux versions (Homère : tirage au sort ; Hésiode, v. 881–885 : Zeus distribue les honneurs). À harmoniser avec la fiche Zeus.
3. **Gaiêochos** : le sens exact est discuté (« qui tient la terre », « qui porte/étreint la terre » ; Murray traduit « earth-enfolder »). Mention « sens discuté » dans le YAML seulement.
4. **Version populaire « Poséidon offre un cheval aux Athéniens »** : non trouvée dans les sources antiques consultées pour la dispute de l'Attique (toutes parlent d'eau salée ou de source). Le lien trident-premier cheval existe chez Virgile (Géorgiques I, 12–14, poète romain), sans lien avec Athènes. Je ne l'ai pas utilisé. À vérifier si la fiche Athéna l'évoque.
5. **Couche `interpretation` (mythe étiologique)** : lecture générale, au conditionnel, non attribuée à un savant précis. À attribuer (ou supprimer) si le vérificateur l'exige.
6. **Thésée** : Bacchylide (Dithyrambe 17) le fait fils de Poséidon et d'Aethra ; Apollodore (III, 15, 7) donne une double paternité (Égée et Poséidon, la même nuit). Pausanias (I, 17, 3) rapporte l'épisode de l'anneau et de la couronne d'Amphitrite. La numérotation de l'ode (17 dans l'édition Perseus, « 16 » ou « 17 » selon les anciennes éditions) est à confirmer. La date précise de l'ode n'est pas établie : j'écris « Ve siècle av. J.-C. ».
7. **Ids nouveaux proposés** (hors liste du lot) : `amphitrite`, `triton`, `thoosa`, `polyphemus`, `odysseus`, `theseus`, `pegasus`, `chrysaor`, `medusa` (déjà utilisé), `aigai`, `peleus`. À valider par le directeur.
8. **Bloc `deity:` du YAML** : le guide ne donne que le modèle `creature`. Structure proposée, à valider.
9. **Relation `poseidon enemy-of athena`** : certitude `variant`. Les deux dieux sont alliés ailleurs (camp achéen dans l'*Iliade*), d'où ma réserve. On peut aussi la supprimer.
10. **Union avec Méduse** : je renvoie à la fiche `medusa` (« Enfants célèbres » et relations en `parent-of` uniquement, sans `lover-of`). Le MDX ne développe pas les versions (Hésiode : prairie ; Ovide : viol dans le temple) pour ne pas doublonner. À arbitrer si le directeur veut une phrase sobre dans « Son histoire ».
11. **Dates** : Hérodote « vers 430 av. J.-C. », Varron « Ier s. av. J.-C. », Augustin « Ve s. » et l'*Hymne homérique 22* « date incertaine » viennent de connaissances générales. Je ne les ai pas revérifiées en ligne pendant cette session.
12. **Sites inaccessibles** : theoi.com/Text/Bacchylides2.html et theoi.com/Heroes/Theseus.html n'ont pas répondu (erreur de chargement). Je n'ai pas consulté remacle.org : toutes les traductions sont de la rédaction, faites d'après le grec et le latin lus.
13. **Typographie** : espaces insécables à contrôler au rendu.
