# Livrable rédacteur — Fiche « Athéna » (lot 1, vague A) — v2

### YAML

```yaml
id: athena
type: deity
category: gods
names:
  greek: Ἀθηνᾶ               # forme épique : Ἀθήνη ; Παλλὰς Ἀθήνη
  transliteration: Athēna
  roman: Minerva
  aliases: [Athéna, Athéné, Pallas, Pallas Athéna, Parthénos, Tritogénie, Minerve]
gender: f
era: olympians
importance: 1
deity:
  domains: [wisdom, counsel, strategy, war, crafts, weaving, city-protection]
  symbols: [owl, olive-tree, aegis, gorgoneion, spear, helmet]
  olympian: true
  residence: mount-olympus
  epithets:
    - { greek: Παλλάς, transliteration: Pallas, source: "Homère, Iliade, V, 856" }
    - { greek: Γλαυκῶπις, transliteration: Glaukōpis, source: "Hésiode, Théogonie, v. 888" }
    - { greek: Τριτογένεια, transliteration: Tritogeneia, source: "Hésiode, Théogonie, v. 895" }
    - { greek: Παρθένος, transliteration: Parthenos, source: "Hymne homérique 28, v. 3 (παρθένον αἰδοίην)" }
    - { greek: Ἐρυσίπτολις, transliteration: Erysiptolis, source: "Hymne homérique 28, v. 3 ; Hymne homérique 11, v. 1" }
relations:                   # sens : from → to
  - { from: zeus, to: athena, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 886–900 et 924 ; Apollodore, Bibliothèque, I, 3, 6" }
  - { from: metis, to: athena, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 886–900 ; Apollodore, Bibliothèque, I, 3, 6" }
  - { from: zeus, to: metis, type: spouse-of, certainty: canonical, source: "Hésiode, Théogonie, v. 886 (« première épouse »)" }
  - { from: hephaestus, to: zeus, type: helped, certainty: variant, source: "Pindare, Olympiques, VII, 35–38 ; Apollodore, Bibliothèque, I, 3, 6 (« selon d'autres »)" }
  - { from: prometheus, to: zeus, type: helped, certainty: variant, source: "Euripide, Ion, v. 452–457 ; Apollodore, Bibliothèque, I, 3, 6" }
  - { from: athena, to: ares, type: defeated, certainty: canonical, source: "Homère, Iliade, XXI, 403–408 (le terrasse d'une pierre) ; V, 855–861 (guide la lance de Diomède)" }
  - { from: athena, to: perseus, type: helped, certainty: canonical, source: "Apollodore, Bibliothèque, II, 4, 2" }
  - { from: athena, to: heracles, type: helped, certainty: canonical, source: "Homère, Iliade, VIII, 362–365 ; Apollodore, Bibliothèque, II, 5, 6 (crotales de bronze)" }
  - { from: athena, to: odysseus, type: helped, certainty: canonical, source: "Homère, Odyssée, XIII, 296–302" }
  - { from: athena, to: arachne, type: punished, certainty: variant, source: "Ovide, Métamorphoses, VI, 129–145 (poète romain)" }
  - { from: athena, to: aegis, type: owns, certainty: canonical, source: "Homère, Iliade, V, 738–742 (D4 : l'égide appartient à Zeus, qui la prête à Athéna ; Iliade, XV, 307–310)" }
  - { from: athena, to: mount-olympus, type: lives-in, certainty: canonical, source: "Homère, Iliade, I, 221–222 ; Odyssée, VI, 41–42" }
# Pas de relation vers Poséidon ici (D11) : la rivalité pour l'Attique est portée par la fiche Poséidon (`enemy-of`, variant).
# Non exprimable avec les types autorisés, consigné ici :
#   - Héphaïstos, né d'Héra seule, « furieuse » et en querelle avec Zeus, juste après la naissance d'Athéna (Hésiode, Théogonie, v. 927–929) ;
#     le lien de cause (« de cette querelle ») n'est explicite que dans la recension variante (v. 929b).
#   - Athéna fait pousser l'olivier sur l'Acropole (`created` vers un id `olive-tree` hors liste du lot).
#   - Athéna « nourrit » Érechthée, né de la terre (Iliade, II, 547–548) ; sur la statue du Parthénon, un serpent (Érichthonios selon Pausanias)
#     se tient près de la lance, le bouclier repose aux pieds (Pausanias, I, 24, 7).
#   - Tête de Méduse (D4/D5) : « la Gorgone » sur l'égide (Homère) ; tête au milieu du bouclier (Apollodore, II, 4, 3) ;
#     tête en ivoire sur la poitrine de la statue (Pausanias, I, 24, 7).
sources:
  - { source: "Hésiode, Théogonie", locus: "v. 886–900 ; 924–929", url: "https://www.theoi.com/Text/HesiodTheogony.html" }
  - { source: "Hésiode, fr. 343 Merkelbach-West (recension variante, cité par Galien d'après Chrysippe)", locus: "Théogonie, v. 929a–t (éd. Perseus)", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml" }
  - { source: "Homère, Iliade", locus: "I, 221–222 ; V, 733–742 ; V, 855–861 ; VIII, 362–365 ; XIV, 178–179 ; XV, 307–310 ; XX, 33–34 ; XXI, 284–286 ; XXI, 403–408", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml" }
  - { source: "Homère, Odyssée", locus: "VI, 41–42 ; VII, 110–111 ; XIII, 296–302", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg002/tlg0012.tlg002.perseus-grc2.xml" }
  - { source: "Hymne homérique 28, À Athéna", locus: "v. 1–16", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg028/tlg0013.tlg028.perseus-grc2.xml" }
  - { source: "Hymne homérique 5, À Aphrodite", locus: "v. 12–15", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg005/tlg0013.tlg005.perseus-grc2.xml" }
  - { source: "Pindare, Olympiques", locus: "VII, 35–38", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0033/tlg001/tlg0033.tlg001.perseus-grc2.xml" }
  - { source: "Euripide, Ion", locus: "v. 452–457", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0006/tlg010/tlg0006.tlg010.perseus-grc2.xml" }
  - { source: "Hérodote, Histoires", locus: "VIII, 55", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0016/tlg001/tlg0016.tlg001.perseus-grc2.xml" }
  - { source: "Thucydide, Guerre du Péloponnèse", locus: "II, 13, 5", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0003/tlg001/tlg0003.tlg001.perseus-grc2.xml" }
  - { source: "Aristophane, Les Oiseaux", locus: "v. 301", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0019/tlg006/tlg0019.tlg006.perseus-grc2.xml" }
  - { source: "(Pseudo-)Apollodore, Bibliothèque", locus: "I, 3, 6 ; I, 6, 2 ; II, 4, 2–3 ; II, 5, 6 ; III, 14, 1", url: "https://www.theoi.com/Text/Apollodorus1.html" }
  - { source: "Plutarque, Vie de Périclès", locus: "13, 9", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0007/tlg012/tlg0007.tlg012.perseus-grc2.xml" }
  - { source: "Pausanias, Description de la Grèce", locus: "I, 24, 5–7", url: "https://www.theoi.com/Text/Pausanias1B.html" }
  - { source: "Lucien, La Goutte (Podagra)", locus: "allusion à Arachné (cité d'après Wikipédia EN, « Arachne »)", url: "https://en.wikipedia.org/wiki/Arachne" }
  - { source: "Pline l'Ancien, Histoire naturelle (auteur romain)", locus: "XXXVI, 18", url: "https://penelope.uchicago.edu/Thayer/L/Roman/Texts/Pliny_the_Elder/36*.html" }
  - { source: "Ovide, Métamorphoses (poète romain)", locus: "VI, 1–145 (défi : v. 25 ; tapisserie de la dispute : v. 70–82)", url: "https://www.thelatinlibrary.com/ovid/ovid.met6.shtml" }
  - { source: "Augustin, La Cité de Dieu (auteur latin chrétien, d'après Varron)", locus: "XVIII, 9", url: "https://www.thelatinlibrary.com/augustine/civ18.shtml" }
review: { status: draft }
```

### MDX

```mdx
---
name: Athéna
role: La déesse de la sagesse, née tout armée du crâne de Zeus
hook: Tu crois avoir une famille compliquée ? Selon certains récits, Athéna sort du crâne de son père, ouvert d'un coup de hache. En armure. Littéralement.
---

## En bref

- **Famille :** fille de <E id="zeus">Zeus</E> et de <E id="metis">Métis</E>, la plus sage des divinités
- **Domaines :** sagesse et bon conseil, stratégie, guerre réfléchie, artisanat et tissage
- **Ville :** protectrice d'Athènes, où se dresse le Parthénon
- **Statut :** vierge (en grec *parthénos*), d'où son surnom Athéna Parthénos
- **Symboles :** la chouette, l'olivier, l'<E id="aegis">égide</E> prêtée par Zeus, avec la tête de la Gorgone
- **Protégés :** <E id="perseus">Persée</E>, <E id="heracles">Héraclès</E>, <E id="odysseus">Ulysse</E>
- **Chez les Romains :** Minerve

## Son histoire

Le poète grec Hésiode (vers 700 av. J.-C.) raconte que la première épouse de Zeus est Métis, « celle qui en sait le plus parmi les dieux et les hommes » (v. 887). Gaïa et Ouranos préviennent Zeus : après une fille, Métis doit enfanter un fils qui deviendra roi des dieux. (Traduction de la rédaction.)

Zeus a de qui tenir : son père <E id="cronos">Cronos</E> avalait ses enfants. Lui avale directement la mère, enceinte. Puis il met au monde Athéna lui-même, « par sa tête ». Hésiode la dit égale à son père « en force et en sage conseil ». Juste après, <E id="hera">Héra</E>, furieuse et en querelle avec Zeus, donne seule naissance à <E id="hephaestus">Héphaïstos</E>.

Athéna et <E id="poseidon">Poséidon</E> sont rivaux pour l'Attique : elle l'emporte et devient la protectrice d'Athènes. Sur le Parthénon, selon Pausanias, le fronton de l'entrée montrait sa naissance, celui de l'arrière la dispute. Devant Troie, elle combat pour les Grecs et terrasse même <E id="ares">Arès</E>, son demi-frère, d'un coup de pierre.

Le poète romain Ovide (vers 8 apr. J.-C.) raconte l'histoire d'Arachné. Cette jeune Lydienne se vante de tisser mieux que la déesse et la met au défi. Battue sur son propre terrain, Minerve (Athéna chez les Romains) déchire l'ouvrage et change Arachné en araignée. Aucun récit grec complet ne nous est parvenu ; Lucien y fait allusion.

## Ses pouvoirs

- **Intelligence stratégique :** dans l'*Odyssée* (XIII, 298–299), elle se dit « réputée parmi tous les dieux pour sa ruse (*mètis*) et ses astuces ». (Trad. de la rédaction.)
- **Guerre :** l'*Iliade* la montre jetant l'égide sur ses épaules avant la bataille. L'égide appartient à Zeus, qui la prête à Athéna ; c'est elle qu'on voit le plus souvent la porter.
- **Artisanat :** l'*Hymne homérique à Aphrodite* dit qu'elle enseigna aux artisans à fabriquer chars et voitures, et aux jeunes filles les beaux ouvrages.
- **Tissage :** chez Homère, elle tisse sa propre robe et celle d'Héra, et donne aux femmes des Phéaciens l'art du métier à tisser.
- **Métamorphose :** elle prend volontiers une apparence humaine pour conseiller ses protégés : Ulysse, Persée, Héraclès.

<Versions title="Une naissance, plusieurs versions">
  <Version layer="ancient" source="Hésiode, Théogonie, v. 886–900 et 924 (vers 700 av. J.-C.)">Zeus avale Métis enceinte, puis enfante Athéna « par sa tête ». Hésiode ne nomme aucun assistant.</Version>
  <Version layer="ancient" source="Fragment attribué à Hésiode, cité par Galien (Théogonie, v. 929a–t)">Une autre version du poème, connue par une citation, la fait naître près du fleuve Triton, « avec ses armes de guerre ». (Trad. de la rédaction.)</Version>
  <Version layer="ancient" source="Hymne homérique 28, À Athéna (peut-être Ve siècle av. J.-C.)">Athéna jaillit de la tête de Zeus en armes d'or étincelantes, brandissant un javelot. L'Olympe tremble, la mer se soulève et le Soleil arrête ses chevaux.</Version>
  <Version layer="ancient" source="Pindare, Olympiques, VII, 35–38 (464 av. J.-C.)">C'est <E id="hephaestus">Héphaïstos</E> qui ouvre le crâne de Zeus d'un coup de hache de bronze. Athéna en sort en poussant un immense cri de guerre.</Version>
  <Version layer="ancient" source="Euripide, Ion, v. 452–457 (fin du Ve siècle av. J.-C.)">Le chœur attribue l'accouchement au Titan Prométhée.</Version>
  <Version layer="ancient" source="Apollodore, Bibliothèque, I, 3, 6 (Ier–IIe siècle apr. J.-C.)">Le mythographe — compilateur de mythes — retient Prométhée, « ou, selon d'autres, Héphaïstos ». Athéna bondit en armes au bord du fleuve Triton. Métis, elle, changeait de forme pour échapper à Zeus.</Version>
</Versions>

<Versions title="Athènes : l'olivier contre la mer">
  <Version layer="ancient" source="Hérodote, Histoires, VIII, 55 (Ve siècle av. J.-C.)">Sur l'Acropole, le temple d'Érechthée abrite un olivier et une « mer », de l'eau salée. Selon les Athéniens, Poséidon et Athéna les y ont laissés comme témoignages de leur querelle pour le pays.</Version>
  <Version layer="ancient" source="Apollodore, Bibliothèque, III, 14, 1">Poséidon frappe l'Acropole de son <E id="trident">trident</E> et fait jaillir une mer. Athéna plante un olivier, devant le roi Cécrops comme témoin. Les douze dieux, juges désignés par Zeus, donnent le pays à Athéna. Furieux, Poséidon inonde la plaine thriasienne.</Version>
  <Version layer="ancient" source="Ovide, Métamorphoses, VI, 70–82 (poète romain, vers 8 apr. J.-C.)">Sur la tapisserie de Minerve, Neptune frappe le rocher de son trident et en fait jaillir l'eau de mer. La déesse frappe la terre de sa lance : un olivier en sort. La Victoire couronne l'ouvrage.</Version>
  <Version layer="ancient" source="Augustin, La Cité de Dieu, XVIII, 9 (auteur latin chrétien, Ve siècle apr. J.-C., d'après le Romain Varron)">Version romaine tardive : les citoyens votent. Les hommes choisissent Neptune, les femmes Minerve, qui gagne d'une voix. Neptune ravage les terres par la mer ; pour l'apaiser, les femmes perdent le droit de vote.</Version>
</Versions>

## Le saviez-vous ?

- **Une chouette dans ta poche.** Regarde une pièce grecque de 1 € : elle copie une pièce athénienne du Ve siècle av. J.-C. Chez Aristophane, « qui a amené une chouette à Athènes ? » est une blague : il y en avait partout.
- **Une statue de 11 mètres, disparue.** L'Athéna de Phidias, au Parthénon (vers 438 av. J.-C.), était d'ivoire et d'or. Pline lui donne environ 11,5 m ; Thucydide, quarante talents d'or détachables.
- **Une armure en peau de géant.** Selon Apollodore, pendant la guerre contre les Géants, Athéna écorche le géant Pallas. Tu devines ce qu'elle fait de sa peau : elle s'en protège.

## Dans la culture populaire

- **Percy Jackson** (Rick Riordan) : Annabeth Chase est une fille d'Athéna, une invention moderne. Elle est jouée par Alexandra Daddario au cinéma et par Leah Sava Jeffries dans la série Disney+ (2023).
- **Hades** (Supergiant Games, 2020, après un accès anticipé en 2018) : Athéna fait partie des Olympiens qui aident le héros. Ses dons lui permettent de renvoyer les attaques ennemies. Stratégie défensive, logique.
- **Assassin's Creed Odyssey** (Ubisoft, 2018) : le jeu se déroule pendant la guerre du Péloponnèse. Tu peux y visiter la statue d'ivoire et d'or d'Athéna, dans le Parthénon.
- **Nashville (États-Unis)** : une réplique grandeur nature de la statue, réalisée par Alan LeQuire en 1990, trône dans une copie du Parthénon.

## Pour aller plus loin

- <E id="zeus">Zeus</E> — Le père qui a avalé la mère… puis accouché par la tête.
- <E id="medusa">Méduse</E> — La Gorgone dont la tête orne l'égide (Homère) ou le bouclier (Apollodore) d'Athéna.
- <E id="poseidon">Poséidon</E> — Le rival qui a perdu Athènes, et ne l'a pas très bien pris.

## Sources

- Hésiode, *Théogonie*, v. 886–900 et 924–929 ; recension variante citée par Galien, v. 929a–t (vers 700 av. J.-C.)
- Homère, *Iliade*, I, 221–222 ; V, 733–742 et 855–861 ; VIII, 362–365 ; XIV, 178–179 ; XV, 307–310 ; XX, 33–34 ; XXI, 284–286 et 403–408 (fin du VIIIe – début du VIIe siècle av. J.-C.)
- Homère, *Odyssée*, VI, 41–42 ; VII, 110–111 ; XIII, 296–302
- *Hymnes homériques* 5 (À Aphrodite), v. 12–15, et 28 (À Athéna), v. 1–16
- Pindare, *Olympiques*, VII, 35–38 (464 av. J.-C.)
- Euripide, *Ion*, v. 452–457 (fin du Ve siècle av. J.-C.)
- Hérodote, *Histoires*, VIII, 55 (Ve siècle av. J.-C.)
- Thucydide, *Guerre du Péloponnèse*, II, 13, 5 (fin du Ve siècle av. J.-C.)
- Aristophane, *Les Oiseaux*, v. 301 (414 av. J.-C.)
- (Pseudo-)Apollodore, *Bibliothèque*, I, 3, 6 ; I, 6, 2 ; II, 4, 2–3 ; II, 5, 6 ; III, 14, 1 (Ier–IIe siècle apr. J.-C.)
- Plutarque, *Vie de Périclès*, 13, 9 (vers 50 – après 120 apr. J.-C.)
- Pausanias, *Description de la Grèce*, I, 24, 5–7 (IIe siècle apr. J.-C.)
- Lucien, *La Goutte* (IIe siècle apr. J.-C.), cité d'après Wikipédia EN
- Pline l'Ancien, *Histoire naturelle*, XXXVI, 18 (auteur romain, Ier siècle apr. J.-C.)
- Ovide, *Métamorphoses*, VI, 1–145 (poète romain, vers 8 apr. J.-C.)
- Augustin, *La Cité de Dieu*, XVIII, 9 (auteur latin, Ve siècle apr. J.-C.)
```

### Sources consultées

Textes antiques (grec lu directement dans les fichiers PerseusDL, numérotation de l'édition) :
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml — Hésiode, Théogonie v. 886–900 ; v. 924–929 (pas de Triton dans le texte principal) ; v. 929a–t relus pour la v2 : 929b (« ἐκ ταύτης δ' ἔριδος »), 929m (« πὰρ κορυφὴν Τρίτωνος ἐπ' ὄχθῃσιν ποταμοῖο »), 929t (« πολεμήια τεύχε' ἔχουσαν »).
- https://www.theoi.com/Text/HesiodTheogony.html — traduction Evelyn-White ; note sur la recension variante (929a).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml — Iliade I, 221–222 (Olympe, demeure de Zeus) ; V, 733–742 ; V, 855–861 ; VIII, 362–369 ; XIV, 178–179 ; XV, 307–310 ; XX, 33–34 et XXI, 284–286 (Athéna et Poséidon du même camp) ; XXI, 403–408 ; II, 546–549.
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg002/tlg0012.tlg002.perseus-grc2.xml — Odyssée VI, 41–42 (« Οὔλυμπόνδ', ὅθι φασὶ θεῶν ἕδος ») ; VII, 110–111 (tissage des Phéaciennes) ; XIII, 296–302.
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg028/tlg0013.tlg028.perseus-grc2.xml — Hymne 28 (ἄκων = javelot ; παρθένον, ἐρυσίπτολιν, v. 3).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg011/tlg0013.tlg011.perseus-grc2.xml — Hymne 11, v. 1 (ἐρυσίπτολιν).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0013/tlg005/tlg0013.tlg005.perseus-grc2.xml — Hymne à Aphrodite v. 12–15.
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0033/tlg001/tlg0033.tlg001.perseus-grc2.xml — Pindare, Olympique VII, 35–38.
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0006/tlg010/tlg0006.tlg010.perseus-grc2.xml — Euripide, Ion v. 452–457.
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0016/tlg001/tlg0016.tlg001.perseus-grc2.xml — Hérodote VIII, 55.
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0003/tlg001/tlg0003.tlg001.perseus-grc2.xml — Thucydide II, 13, 5.
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0019/tlg006/tlg0019.tlg006.perseus-grc2.xml — Aristophane, Oiseaux v. 301.
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0007/tlg012/tlg0007.tlg012.perseus-grc2.xml — Plutarque, Périclès 13, 9.
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0525/tlg001/tlg0525.tlg001.perseus-grc2.xml — Pausanias I, 24, 5–7 (fronton « en entrant » / « de l'arrière » ; bouclier aux pieds, serpent près de la lance).
- Apollodore (fichier grec PerseusDL de la fiche Méduse, éd. Frazer) — I, 3, 6 (« ἐπὶ ποταμοῦ Τρίτωνος, Ἀθηνᾶ σὺν ὅπλοις ἀνέθορεν ») ; I, 6, 2 ; II, 5, 6 ; III, 14, 1.
- https://www.theoi.com/Text/Apollodorus1.html et https://www.theoi.com/Text/Pausanias1B.html — traductions.
- https://www.thelatinlibrary.com/ovid/ovid.met6.shtml — Ovide, Met. VI (olivier v. 80–81, coups v. 130–133, métamorphose v. 134–145). Le défi d'Arachné (v. 25) et la tapisserie (v. 70–82) sont repris du rapport du vérificateur (PerseusDL canonical-latinLit) : je ne les ai pas relus moi-même.
- https://www.theoi.com/Olympios/AthenaWrath.html — résumé de l'épisode d'Arachné.
- https://www.thelatinlibrary.com/augustine/civ18.shtml — Augustin, Cité de Dieu XVIII, 9.
- https://penelope.uchicago.edu/Thayer/L/Roman/Texts/Pliny_the_Elder/36*.html — Pline, HN XXXVI, 18.
- https://www.theoi.com/Olympios/Athena.html — vue d'ensemble.

Références modernes :
- https://en.wikipedia.org/wiki/Arachne — Lucien, *La Goutte*, IIe siècle apr. J.-C. (allusion à Arachné).
- https://en.wikipedia.org/wiki/Athena_Parthenos ; https://en.wikipedia.org/wiki/Parthenon ; https://en.wikipedia.org/wiki/Owl_of_Athena ; https://mymodernmet.com/greece-euro-coins/ ; https://en.wikipedia.org/wiki/Athena ; https://fr.wikipedia.org/wiki/Athéna ; https://en.wikipedia.org/wiki/Olympian_7 ; https://en.wikipedia.org/wiki/Ion_(play) ; https://en.wikipedia.org/wiki/Homeric_Hymns ; https://en.wikipedia.org/wiki/The_Birds_(play).
- https://en.wikipedia.org/wiki/Annabeth_Chase et https://en.wikipedia.org/wiki/Percy_Jackson_and_the_Olympians_(TV_series) — Annabeth, Daddario, Leah Sava Jeffries, Disney+ 2023.
- https://en.wikipedia.org/wiki/Hades_(video_game) — Supergiant Games, 2020.
- https://www.pcgamer.com/hades-guide-tips-and-tricks/ — dons d'Athéna : « deflect their attacks » (remplace le wiki de fans).
- https://en.wikipedia.org/wiki/Assassin%27s_Creed_Odyssey — Ubisoft, 2018, guerre du Péloponnèse.
- https://news.ubisoft.com/en-us/article/355102/open-world-museum-mode-comes-to-assassins-creed-odyssey-on-september-10 — « Visit the ivory-and-gold statue of Athena inside the Parthenon » (remplace le wiki de fans).

Repris du rapport du vérificateur, non revisités par moi : https://sententiaeantiquae.com/2016/11/17/the-consumption-of-metis-birth-of-athena-and-creation-of-the-aegis-hes-frag-343/ (attribution à Galien citant Chrysippe, fr. 343 M.-W.) ; dates d'Hérodote, Pausanias, Plutarque, Pline, Augustin, Thucydide ; date d'accès anticipé de *Hades* (2018).

### Doutes

1. **Lucien** : je n'ai pas lu le texte grec de *La Goutte* ; l'allusion est citée d'après Wikipédia EN (comme le vérificateur). Mention « cité d'après » ajoutée dans les sources.
2. **Fragment cité par Galien** : l'attribution (Galien citant Chrysippe, fr. 343 M.-W.) vient du rapport et de la note de theoi.com ; j'ai lu les vers 929a–t dans le grec PerseusDL, mais pas le texte de Galien.
3. **« Battue sur son propre terrain »** (Arachné) : glose de la rédaction pour Ovide, VI, 129–131 (Pallas ne peut critiquer l'ouvrage et « souffre de ce succès »).
4. **Blague d'Aristophane** : « il y en avait partout » reste une glose (profusion de chevêches à Athènes, d'après Wikipédia EN *Owl of Athena*) ; un jeu de mots sur les pièces « chouettes » est possible mais non retenu.
5. **Ids hors liste du lot** : `prometheus`, `perseus`, `odysseus`, `arachne`, `medusa`, `olive-tree` (commentaire), à valider par le directeur.
6. **Clés `counsel` et `city-protection`** dans `domains` : proposées par moi (le guide ne fixe pas de vocabulaire contrôlé).
7. **Épithètes** : Polias et Promachos retirées du YAML, faute de source antique lue moi-même ; Ἐρυσίπτολις ajoutée (Hymnes 11 et 28).
8. **Typographie** : espaces insécables à contrôler au rendu.

### Changements v1 → v2

- **Hésiode (❌)** : Triton retiré de sa version, ainsi que la phrase « ne décrit pas d'armure ». Nouvelle ligne `<Version>` pour le fragment cité par Galien (v. 929a–t) : Triton + « avec ses armes de guerre ». Triton et armes attribués aussi à Apollodore (I, 3, 6).
- **Arachné (❌)** : c'est Arachné qui lance le défi. Section propre supprimée (D12) ; récit fondu en 3 phrases dans « Son histoire ». Formule « Aucun récit grec complet ne nous est parvenu ; Lucien y fait allusion » ; balise [À VÉRIFIER] levée ; pas d'aryballe.
- **Poséidon (D11)** : relation `enemy-of` supprimée du YAML ; « rivaux pour l'Attique » dans le texte. Ajout d'Ovide (VI, 70–82) au bloc de la dispute (mêmes sources que la fiche Poséidon) et du ravage par la mer chez Augustin.
- **Interprétation « olivier contre la mer » (❓)** : retirée.
- **Parthénon** : section propre supprimée (D12). Frontons « de l'entrée » / « de l'arrière » dans « Son histoire » ; statue dans « Le saviez-vous ? ». Serpent près de la lance, bouclier aux pieds (commentaire YAML).
- **Égide (D4)** : note commune ajoutée (« Ses pouvoirs ») ; « peau-bouclier » remplacé par « jeter l'égide sur ses épaules » ; porte Méduse : « l'égide (Homère) ou le bouclier (Apollodore) ».
- **Olympe** : balise [À VÉRIFIER] levée, sources Iliade I, 221–222 et Odyssée VI, 41–42 ; `residence: mount-olympus`.
- **YAML** : bloc `deity:` conforme (clés anglaises, `residence`, épithètes en objets sourcés, `city` supprimé) ; `gender: f` ; URL raw complètes ; Pindare « VII, 35–38 » partout ; Hymne à Aphrodite « v. 12–15 » ; Héphaïstos : lien causal retiré (« juste après »).
- **Ton (D9)** : tutoiement dans l'accroche (« Tu crois avoir une famille compliquée ? »), dans les trois « Le saviez-vous ? » et dans Assassin's Creed. Accroche signalée comme une version (« selon certains récits », D13).
- **Dates (D10)** : Homère « fin du VIIIe – début du VIIe siècle av. J.-C. » ; Plutarque daté ; Hades « après un accès anticipé en 2018 ».
- **Détails** : prophétie attribuée à Gaïa et Ouranos ; « javelot » dans l'Hymne 28 ; v. 887 et XIII, 298–299 précisés ; Odyssée VII, 110–111 exploitée (tissage des Phéaciennes) ; temple d'Érechthée et plaine thriasienne nommés ; anecdote Aristophane fondue dans celle de la chouette ; sources pop culture : PC Gamer et Ubisoft à la place des wikis de fans.
