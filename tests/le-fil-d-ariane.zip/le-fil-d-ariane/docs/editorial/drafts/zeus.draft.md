# Livrable rédacteur — Fiche « Zeus » (lot 1, vague A) — draft

### YAML

```yaml
id: zeus
type: deity
category: gods
names:
  greek: Ζεύς
  transliteration: Zeus
  roman: Jupiter
  aliases: [Zeus, Jupiter, Kronidès, Cronide, Zeus Xénios, Zeus Horkios]
era: olympians
importance: 1
deity:
  domains: [sky, thunder, justice, hospitality, oaths, kingship]
  symbols: [thunderbolt, eagle, oak, aegis]   # aegis partagée avec Athéna
  home: mount-olympus
relations:                 # sens : from → to
  - { from: cronos, to: zeus, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–458 ; Homère, Iliade, XV, 187–188 ; Apollodore, Bibliothèque, I, 1, 5–6" }
  - { from: rhea, to: zeus, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–458 ; Homère, Iliade, XV, 187–188" }
  - { from: zeus, to: hestia, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–457" }
  - { from: zeus, to: demeter, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–457" }
  - { from: zeus, to: hera, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–457" }
  - { from: zeus, to: hades, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–457 ; Homère, Iliade, XV, 187–188" }
  - { from: zeus, to: poseidon, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie, v. 453–457 ; Homère, Iliade, XV, 187–188" }
  - { from: zeus, to: metis, type: spouse-of, certainty: canonical, source: "Hésiode, Théogonie, v. 886–900 (première épouse, avalée)" }
  - { from: zeus, to: hera, type: spouse-of, certainty: canonical, source: "Hésiode, Théogonie, v. 921 (dernière épouse) ; Apollodore, Bibliothèque, I, 3, 1" }
  - { from: zeus, to: athena, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 886–900 et 924–926" }
  - { from: metis, to: athena, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 886–900" }
  - { from: zeus, to: ares, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 921–923 ; Apollodore, Bibliothèque, I, 3, 1" }
  - { from: zeus, to: persephone, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie, v. 912–914 (avec Déméter)" }
  - { from: zeus, to: heracles, type: parent-of, certainty: canonical, source: "Homère, Iliade, XIV, 323–324 (avec la mortelle Alcmène)" }
  - { from: zeus, to: perseus, type: parent-of, certainty: canonical, source: "Homère, Iliade, XIV, 319–320 ; Apollodore, Bibliothèque, II, 4, 1 (pluie d'or « selon certains »)" }
  - { from: zeus, to: cronos, type: defeated, certainty: canonical, source: "Hésiode, Théogonie, v. 71–73 et 490–496" }
  - { from: zeus, to: titans, type: defeated, certainty: canonical, source: "Hésiode, Théogonie, v. 687–735 ; Apollodore, Bibliothèque, I, 2, 1" }
  - { from: zeus, to: titans, type: punished, certainty: canonical, source: "Hésiode, Théogonie, v. 717–731 (enchaînés dans le Tartare « par la volonté de Zeus », v. 730)" }
  - { from: zeus, to: cyclopes, type: helped, certainty: canonical, source: "Hésiode, Théogonie, v. 501–502 (libère « les frères de son père », fils d'Ouranos) ; Apollodore, Bibliothèque, I, 2, 1" }
  - { from: cyclopes, to: zeus, type: helped, certainty: canonical, source: "Hésiode, Théogonie, v. 139–141 et 503–506 ; Apollodore, Bibliothèque, I, 2, 1" }
  - { from: cyclopes, to: thunderbolt, type: created, certainty: canonical, source: "Hésiode, Théogonie, v. 141 (« ils fabriquèrent la foudre ») ; Apollodore, Bibliothèque, I, 2, 1" }
  - { from: zeus, to: thunderbolt, type: owns, certainty: canonical, source: "Hésiode, Théogonie, v. 72, 504–506, 687–699" }
  - { from: zeus, to: aegis, type: owns, certainty: variant, source: "Homère, Iliade, XV, 308–310 (forgée par Héphaïstos pour Zeus) ; XVII, 593 ; portée aussi par Athéna, II, 447 et V, 738" }
  - { from: hephaestus, to: aegis, type: created, certainty: variant, source: "Homère, Iliade, XV, 309–310 (fragment hésiodique, Théogonie v. 929s : fabriquée par Métis)" }
  - { from: zeus, to: mount-olympus, type: lives-in, certainty: canonical, source: "Hésiode, Théogonie, v. 881–885 (« Zeus Olympien ») ; Homère, Iliade, XV, 193" }
# Unions non consenties ou obtenues par la ruse (Europe, Callisto, Io, Danaé, Léda, Ganymède) : pas de lover-of,
# conformément au guide. Les ids correspondants ne figurent pas dans la liste du lot ; filiation à ajouter si les fiches existent :
#   - Europe : Apollodore, III, 1, 1 (taureau ; enfants Minos, Sarpédon, Rhadamanthe) ;
#   - Callisto : Apollodore, III, 8, 2 (ἀκούσῃ, « contre son gré » ; enfant Arcas) ;
#   - Io : Apollodore, II, 1, 3 (enfant Épaphos) ; Léda : Apollodore, III, 10, 7 (Pollux, Hélène) ;
#   - Ganymède : Iliade, XX, 232–235 (enlevé par « les dieux ») ; Apollodore, III, 12, 2 (par Zeus, au moyen d'un aigle).
# Perséphone : Zeus « la donna » à Hadès (Théogonie, v. 913–914) — aucun type autorisé ne l'exprime.
sources:
  - { source: "Hésiode, Théogonie", locus: "v. 71–74, 139–146, 453–506, 617–735, 881–929", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml" }
  - { source: "Hésiode, Théogonie (trad. Evelyn-White)", locus: "idem", url: "https://www.theoi.com/Text/HesiodTheogony.html" }
  - { source: "Hésiode, Les Travaux et les Jours", locus: "v. 238–239, 256–259", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg002/tlg0020.tlg002.perseus-grc2.xml" }
  - { source: "Homère, Iliade", locus: "I, 528–530 ; II, 447 ; III, 276–280 ; V, 738–742 ; XIII, 354–355 ; XIV, 315–328 ; XV, 187–193 et 308–310 ; XVII, 593–596 ; XX, 232–235 ; XXIV, 308–311", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml" }
  - { source: "Homère, Iliade, XV (trad. Murray)", locus: "XV, 187–193", url: "https://www.theoi.com/Text/HomerIliad15.html" }
  - { source: "Homère, Odyssée", locus: "VI, 207–208 ; IX, 269–271 ; XIV, 57–58 et 327–328", url: "https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg002/tlg0012.tlg002.perseus-grc2.xml" }
  - { source: "(Pseudo-)Apollodore, Bibliothèque", locus: "I, 1, 5–7 ; I, 2, 1 ; I, 3, 1 et 6 ; II, 1, 3 ; II, 4, 1 ; III, 1, 1 ; III, 8, 2 ; III, 10, 7 ; III, 12, 2", url: "https://www.theoi.com/Text/Apollodorus1.html" }
  - { source: "Callimaque, Hymne à Zeus (trad. Mair)", locus: "§ 4, 10, 42–54, 61 de l'édition en ligne [vers exacts À VÉRIFIER]", url: "https://topostext.org/work/120" }
  - { source: "Pausanias, Description de la Grèce", locus: "V, 24, 9 (Zeus Horkios)", url: "https://www.theoi.com/Text/Pausanias5B.html" }
  - { source: "Strabon, Géographie", locus: "VIII, 3, 30 (statue de Phidias)", url: "https://penelope.uchicago.edu/Thayer/E/Roman/Texts/Strabo/8C*.html" }
review: { status: draft }
```

### MDX

```mdx
---
name: Zeus
role: Le roi des dieux, arrivé au trône par un coup d'État
hook: Avant de régner sur l'Olympe, Zeus a dû sortir ses frères et sœurs… du ventre de son père. Bienvenue dans la famille la plus toxique de l'Antiquité.
---

## En bref

- **Famille :** fils des Titans <E id="cronos">Cronos</E> et <E id="rhea">Rhéa</E> ; frère d'<E id="hestia">Hestia</E>, <E id="demeter">Déméter</E>, <E id="hera">Héra</E>, <E id="hades">Hadès</E> et <E id="poseidon">Poséidon</E>
- **Domaines :** le ciel, la foudre, la justice, l'hospitalité, les serments
- **Arme :** la <E id="thunderbolt">foudre</E>, offerte par les <E id="cyclopes">Cyclopes</E>
- **Symboles :** la foudre, l'aigle, le chêne, l'<E id="aegis">égide</E> (qu'il partage avec Athéna)
- **Résidence :** le <E id="mount-olympus">mont Olympe</E>
- **Épouse :** Héra, sa sœur — la septième et dernière épouse divine chez Hésiode
- **Chez les Romains :** Jupiter

## Son histoire

Cronos a un problème : une prophétie annonce qu'un de ses enfants le renversera. Sa solution ? Les avaler à la naissance. Hestia, Déméter, Héra, Hadès, Poséidon : tous y passent. Pour le dernier, <E id="rhea">Rhéa</E> ruse. Elle tend à son mari une grosse pierre emmaillotée. Il l'avale sans rien remarquer.

Le bébé grandit caché en Crète. Chez le poète grec Hésiode (vers 700 av. J.-C.), c'est dans une grotte près de Lyctos. Le mythographe — compilateur de mythes — Apollodore la place au mont Dicté. Là, des guerriers, les Courètes, frappent leurs boucliers pour couvrir ses pleurs.

Adulte, Zeus force son père à recracher ses enfants. Commence la <E id="titanomachy">Titanomachie</E> : dix ans de guerre contre les <E id="titans">Titans</E>. Zeus libère les Cyclopes, qui lui offrent le tonnerre et la foudre. Les Titans vaincus finissent enchaînés dans le Tartare, gouffre aussi loin sous la terre que le ciel est au-dessus.

Roi, Zeus rejoue le scénario familial. On prédit à sa première épouse, <E id="metis">Métis</E>, un fils plus fort que lui : il l'avale. Leur fille <E id="athena">Athéna</E> naîtra de sa tête. Zeus multiplie aussi les unions avec des mortelles, souvent par la ruse ou la force : Europe enlevée par un taureau, Callisto prise contre son gré.

## Ses pouvoirs

- **Maître du ciel et de la foudre :** contre les Titans, ses éclairs embrasent la terre et font bouillir la mer, selon Hésiode.
- **Garant de la justice :** sa fille Dikè, la Justice, siège près de lui et lui dénonce les juges malhonnêtes (Hésiode, *Les Travaux et les Jours*).
- **Protecteur des étrangers :** Zeus Xénios veille sur la xenia — le devoir sacré d'accueillir l'étranger — et venge les voyageurs maltraités (*Odyssée*, IX).
- **Gardien des serments :** à Olympie, sa statue de Zeus Horkios, « des serments », tenait une foudre dans chaque main. De toutes, c'était la plus terrifiante pour les coupables, selon Pausanias (IIe s. apr. J.-C.).
- **Ses emblèmes :** l'aigle, « le plus cher des oiseaux » pour lui (*Iliade*, XXIV), et le chêne de Dodone, par lequel il rendait ses oracles (*Odyssée*, XIV).

<Versions title="Le partage du monde : tirage au sort ou élection ?">
  <Version layer="ancient" source="Homère, Iliade, XV, 187–193 (vers le VIIIe s. av. J.-C., trad. de la rédaction)">Poséidon raconte : les trois fils de Cronos ont tiré au sort. Il a reçu la mer, Hadès les ténèbres, Zeus le vaste ciel. La terre et l'Olympe restent communs aux trois. Le monde « a été partagé en trois ».</Version>
  <Version layer="ancient" source="Hésiode, Théogonie, v. 881–885 (vers 700 av. J.-C.)">Pas de tirage au sort. Après la victoire, sur le conseil de Gaïa, les dieux pressent Zeus de devenir roi. C'est lui qui distribue ensuite les honneurs à chacun.</Version>
  <Version layer="ancient" source="Apollodore, Bibliothèque, I, 2, 1 (Ier–IIe s. apr. J.-C.)">Après la Titanomachie, les trois frères tirent au sort le pouvoir : le ciel à Zeus, la mer à Poséidon, le royaume souterrain à Pluton, autre nom d'Hadès.</Version>
  <Version layer="ancient" source="Callimaque, Hymne à Zeus (IIIe s. av. J.-C.) [vers À VÉRIFIER]">Le poète grec Callimaque se moque du tirage au sort : seul un sot jouerait l'Olympe contre l'Hadès. Zeus serait roi par ses exploits et sa force.</Version>
  <Version layer="ancient" source="Homère, Iliade, XIII, 355 / Hésiode, Théogonie, v. 478">Autre divergence : chez Homère, Zeus est l'aîné des frères. Chez Hésiode, il est le plus jeune des enfants de Rhéa.</Version>
  <Version layer="interpretation">Selon l'historien Walter Burkert, le tirage au sort homérique rappellerait un récit mésopotamien, l'épopée d'Atrahasis, où les grands dieux se partagent ciel, terre et eaux par le sort. [À VÉRIFIER]</Version>
</Versions>

## Le saviez-vous ?

- **Une galerie de victimes dans le ciel.** En 1614, l'astronome Simon Marius, sur une idée de Kepler, nomme quatre lunes de Jupiter Io, Europe, Ganymède et Callisto. Tous ont été séduits, trompés ou enlevés par Zeus.
- **Une statue trop grande pour son temple.** Vers 435 av. J.-C., Phidias sculpte à Olympie un Zeus assis, d'or et d'ivoire, d'environ 12 m. Le géographe Strabon note que, debout, il emporterait le toit.
- **Le tombeau d'un immortel.** Les Crétois montraient un tombeau de Zeus. Callimaque s'en moque : « Les Crétois, toujours menteurs ! » Car Zeus, lui, ne meurt jamais. (Trad. de la rédaction.)

## Dans la culture populaire

- **Percy Jackson et le Voleur de foudre** (Rick Riordan, 2005) : l'éclair maître de Zeus a disparu, et tout accuse Percy. Dans la série Disney+ (2023), Zeus est joué par Lance Reddick, mort avant la diffusion.
- **Hercule** (Disney, 1997) : Zeus y est un papa jovial, et Héra la mère d'Hercule. Dans le mythe, la mère d'Héraclès est une mortelle, Alcmène… et Héra le déteste.
- **God of War III** (2010) : sur PlayStation 3, le guerrier Kratos affronte Zeus et finit par le tuer. Le roi des dieux en patron de fin de jeu.

## Pour aller plus loin

- <E id="cronos">Cronos</E> — Le père qui avalait ses enfants, et la pierre qu'il n'a jamais vue venir.
- <E id="titanomachy">Titanomachie</E> — Dix ans de guerre entre deux générations de dieux pour le trône du monde.
- <E id="hera">Héra</E> — Reine des dieux, sœur et épouse de Zeus : bien plus qu'une femme jalouse.

## Sources

- Hésiode, *Théogonie*, v. 71–74, 139–146, 453–506, 617–735, 881–929 (vers 700 av. J.-C.)
- Hésiode, *Les Travaux et les Jours*, v. 238–239, 256–259 (vers 700 av. J.-C.)
- Homère, *Iliade*, I, 528–530 ; III, 276–280 ; XIII, 354–355 ; XIV, 315–328 ; XV, 187–193 et 308–310 ; XVII, 593 ; XXIV, 308–311 (vers le VIIIe siècle av. J.-C.)
- Homère, *Odyssée*, IX, 269–271 ; XIV, 327–328 (vers le VIIIe siècle av. J.-C.)
- Callimaque, *Hymne à Zeus* (IIIe siècle av. J.-C.)
- (Pseudo-)Apollodore, *Bibliothèque*, I, 1, 5–7 ; I, 2, 1 ; I, 3, 1 et 6 ; III, 1, 1 ; III, 8, 2 (Ier–IIe siècle apr. J.-C.)
- Pausanias, *Description de la Grèce*, V, 24, 9 (IIe siècle apr. J.-C.)
- Strabon, *Géographie*, VIII, 3, 30 (début du Ier siècle apr. J.-C.)
```

### Sources consultées

- https://www.theoi.com/Text/HesiodTheogony.html — Théogonie (trad. Evelyn-White) : Cyclopes et foudre, avalement, pierre, Lyctos, mont « Aegeum », pierre à Pytho, Hécatonchires, dix ans de guerre, Tartare, Zeus pressé de régner (v. 881 et suiv., aucun tirage au sort), liste des épouses (Héra « lastly »).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg001/tlg0020.tlg001.perseus-grc2.xml — texte grec numéroté de la Théogonie : v. 71–74, 139–146, 453–506, 617–638 (δέκα… ἐνιαυτούς, v. 636), 687–700, 715–735, 881–929 et fragment 929a–t (Métis, égide).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0020/tlg002/tlg0020.tlg002.perseus-grc2.xml — Travaux et Jours, v. 238–240 et 256–259 (Dikè, fille de Zeus, assise près de lui).
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg001/tlg0012.tlg001.perseus-grc2.xml — Iliade, texte grec numéroté : I, 528–530 ; II, 446–449 ; III, 276–280 ; V, 738–742 ; VIII, 247 ; XIII, 354–357 ; XIV, 315–328 ; XV, 185–195 et 307–311 ; XVI, 233–235 ; XVII, 593–596 ; XX, 232–235 ; XXIV, 308–316.
- https://www.theoi.com/Text/HomerIliad15.html — Iliade XV (trad. Murray), partage par les sorts.
- https://raw.githubusercontent.com/PerseusDL/canonical-greekLit/master/data/tlg0012/tlg002/tlg0012.tlg002.perseus-grc2.xml — Odyssée : VI, 207–208 ; IX, 269–271 ; XIV, 57–58 et 327–328.
- https://www.theoi.com/Text/Apollodorus1.html — Bibliothèque I (trad. Frazer) : grotte du Dicté, Courètes, Adrastée et Ida, Amalthée, Métis et la drogue, dix ans, Campé, armes des Cyclopes, tirage au sort, unions de Zeus.
- Fichier grec de la Bibliothèque d'Apollodore (urn:cts:greekLit:tlg0548.tlg001.perseus-grc2), copie locale déjà téléchargée par le vérificateur dans le scratchpad (non retéléchargée par moi) : I, 1, 5–7 ; I, 2, 1 ; I, 3, 1 et 6 ; II, 1, 3 ; II, 4, 1 ; III, 1, 1 ; III, 8, 2 ; III, 10, 7 ; III, 12, 2.
- https://www.theoi.com/Text/CallimachusHymns1.html et https://topostext.org/work/120 — Callimaque, Hymne I (trad. Mair) : Ida ou Arcadie, Parrhasie, « Cretans are ever liars », tombeau, Courètes, Amalthée chèvre, rejet du tirage au sort, royauté par les exploits.
- https://www.theoi.com/Text/Pausanias5B.html — Pausanias V, 24, 9 : Zeus Horkios, une foudre dans chaque main, serment des athlètes.
- https://penelope.uchicago.edu/Thayer/E/Roman/Texts/Strabo/8C*.html — Strabon VIII, 3, 30 : la statue « décoifferait » le temple si Zeus se levait.
- https://en.wikipedia.org/wiki/Statue_of_Zeus_at_Olympia — Phidias, vers 435 av. J.-C., chryséléphantine, env. 12,4 m.
- https://en.wikipedia.org/wiki/Zeus — point de départ : étymologie, Xénios, Horkios, Dodone, Ida/Dicté.
- https://www.britannica.com/topic/Zeus — dieu du ciel et du temps, identifié à Jupiter, foudre (contenu partiel).
- https://en.wikipedia.org/wiki/Galilean_moons et https://www.lindahall.org/about/news/scientist-of-the-day/simon-marius/ — Marius, Kepler, *Mundus Iovialis* (1614), noms adoptés au milieu du XXe siècle.
- https://en.wikipedia.org/wiki/Atrahasis et https://jewishchristianlit.com/?p=157 — Burkert (note), tirage au sort des dieux dans Atrahasis.
- https://en.wikipedia.org/wiki/The_Lightning_Thief et https://www.shmoop.com/study-guides/percy-jackson-lightning-thief/chapter-9-summary.html — éclair maître volé, Percy soupçonné, 2005.
- https://en.wikipedia.org/wiki/Percy_Jackson_and_the_Olympians_(TV_series) et https://whatsondisneyplus.com/courtney-b-vance-replacing-the-late-lance-reddick-in-percy-jackson-and-the-olympians-disney-series/ — série Disney+ (19 décembre 2023), Lance Reddick (mort en mars 2023), remplacé par Courtney B. Vance.
- https://en.wikipedia.org/wiki/Hercules_(1997_film) — Zeus et Héra parents d'Hercule, Hadès méchant.
- https://en.wikipedia.org/wiki/God_of_War_III — 2010, PlayStation 3, Kratos tue Zeus.

### Doutes

1. **Callimaque, numéros de vers** : je n'ai lu que des traductions anglaises (Mair) avec des repères par paragraphes (§ 4, 10, 42, 54/61). Le passage sur le tirage au sort se situe vers les v. 60–66 et « Cretans are ever liars » vers le v. 8 [À VÉRIFIER dans une édition grecque numérotée]. Les deux citations (« sot », « toujours menteurs ») sont des traductions de la rédaction d'après l'anglais, pas d'après le grec.
2. **Burkert / Atrahasis** : la thèse n'est attestée que par une note de Wikipédia EN ; je n'ai pas lu Burkert (probablement *The Orientalizing Revolution*, 1992) [À VÉRIFIER]. Dans Atrahasis, le partage par le sort est confirmé (ciel à Anu, terre à Enlil, verrou de la mer à Enki), mais la nuance « ciel, terre et eaux » est une simplification. Possibilité de supprimer cette Version si la vérification ne peut pas sourcer Burkert.
3. **Mont de la grotte chez Hésiode** : le texte dit Αἰγαίῳ ἐν ὄρει (v. 484), « mont Aigaion », dont l'identification est incertaine. Je ne l'ai pas nommé dans le texte. Le **mont Ida** (Crète) n'apparaît que via Callimaque (« certains disent »), et je ne l'ai pas utilisé non plus. Le brief demandait Ida/Dicté : à arbitrer si le directeur veut l'Ida en toutes lettres (attribué à Callimaque).
4. **« Libère les Cyclopes »** : Hésiode (v. 501–502) dit « les frères de son père, fils d'Ouranos », sans les nommer. L'identification aux Cyclopes est déduite du v. 504 et des v. 139–141, et explicite seulement chez Apollodore (I, 2, 1, Zeus tue la geôlière Campé). Formulation à surveiller.
5. **Comment Cronos recrache ses enfants** : ruse de Gaïa chez Hésiode (v. 494–496), drogue de Métis chez Apollodore (I, 2, 1). Faute de place, le texte dit seulement « Zeus force son père », sans détailler la variante. Peut aller dans `<Versions>` si on accepte un bloc plus long.
6. **« Sept épouses »** : Hésiode énumère sept unions divines successives (Métis, Thémis, Eurynomé, Déméter, Mnémosyne, Létô, Héra) ; seules Métis et Héra sont dites explicitement « épouses » (ἄλοχον / ἄκοιτιν). « Septième et dernière épouse divine » est donc une simplification ; possible de dire « septième et dernière union ».
7. **Athéna « naîtra de sa tête »** : Hésiode, v. 924 (ἐκ κεφαλῆς). L'aide d'Héphaïstos ou de Prométhée relève de la fiche Athéna (Apollodore I, 3, 6).
8. **Égide** : chez Homère, Héphaïstos l'a forgée pour Zeus (XV, 309–310), Zeus la secoue (XVII, 593–595), mais Athéna la porte aussi (II, 447 ; V, 738). Le fragment hésiodique 929s l'attribue à Métis. La relation `hephaestus → aegis` est marquée `variant`.
9. **Relation `zeus → titanomachy`** : aucun type autorisé ne relie un personnage à un événement ; je n'ai donc pas créé de relation vers `titanomachy` (lien seulement via `<E>`). Les unions non consenties (Europe, Callisto, Io, Danaé, Léda, Ganymède) ne sont qu'en commentaire, faute d'ids dans le lot.
10. **Champ `deity:`** : le guide ne donne que l'exemple `creature:`. J'ai créé une spécialisation `deity:` (domains, symbols, home) par analogie ; à valider. Le sceptre, faute de source vérifiée, n'y figure pas.
11. **Étymologie** (*Dyēus*, « ciel lumineux », même racine que Jupiter) : vérifiée seulement sur Wikipédia ; non utilisée dans le texte.
12. **Statue de Phidias** : date (vers 435 av. J.-C.) et hauteur (environ 12 m) issues de Wikipédia EN, non recoupées avec une source savante.
13. **Pausanias V, 24, 9** : vérifié en traduction anglaise (Jones) : « of all the images of Zeus the one most likely to strike terror into the hearts of sinners ». Paraphrase « la plus terrifiante pour les coupables » ; non contrôlée sur le grec.
14. **Percy Jackson** : « tout accuse Percy » s'appuie sur un résumé (Shmoop) ; le nom exact de l'objet en français (« éclair maître ») est à confirmer dans la traduction française du roman [À VÉRIFIER].
15. **Typographie** : espaces insécables à contrôler au rendu.
