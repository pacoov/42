# Livrable rédacteur — Fiche « Méduse » (pilote)

### YAML

```yaml
id: medusa
type: creature
category: creatures
names:
  greek: Μέδουσα
  transliteration: Medousa
  roman: Medusa
  aliases: [Méduse, Medusa, Gorgone, Gorgô]
era: heroes
importance: 1
creature:
  kind: monster
  danger: 3
  habitat: [land]          # « au-delà de l'Océan, vers la Nuit » (Hésiode) ; île de Sarpédon (Chants cypriens) — à affiner si l'enum le permet
  defeatedBy: [perseus]
relations:
  - { to: phorcys, type: child-of, certainty: canonical, source: "Hésiode, Théogonie" }
  - { to: ceto, type: child-of, certainty: canonical, source: "Hésiode, Théogonie" }
  - { to: stheno, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie" }
  - { to: euryale, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie" }
  - { to: graeae, type: sibling-of, certainty: canonical, source: "Hésiode, Théogonie (Céto enfante aussi les Grées à Phorcys)" }
  - { to: poseidon, type: partner-of, certainty: canonical, source: "Hésiode, Théogonie (« le dieu aux cheveux sombres ») ; Apollodore, Bibliothèque 2.4.2 ; Ovide, Métamorphoses 4.798 (version romaine, union forcée)" }
  - { to: pegasus, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie ; Apollodore, Bibliothèque 2.4.2" }
  - { to: chrysaor, type: parent-of, certainty: canonical, source: "Hésiode, Théogonie ; Apollodore, Bibliothèque 2.4.2" }
  - { to: perseus, type: killed-by, certainty: canonical, source: "Hésiode, Théogonie ; Apollodore, Bibliothèque 2.4.2" }
  - { to: athena, type: enemy-of, certainty: variant, source: "Apollodore 2.4.3 (rivalité de beauté) ; Ovide, Métamorphoses 4.798–801 (punition)" }
  - { to: aegis, type: part-of, certainty: canonical, source: "Apollodore 2.4.3 (tête au centre du bouclier d'Athéna) ; Ovide, Métamorphoses 4.803" }
sources:
  - { source: "Hésiode, Théogonie", locus: "v. 270 et suiv. [numéros exacts À VÉRIFIER : env. 274–283]", url: "https://www.theoi.com/Text/HesiodTheogony.html" }
  - { source: "Homère, Iliade", locus: "V, 733 et suiv.", url: "https://www.theoi.com/Text/HomerIliad5.html" }
  - { source: "(Pseudo-)Hésiode, Bouclier d'Héraclès", locus: "v. 216–237", url: "https://www.theoi.com/Text/HesiodShield.html" }
  - { source: "Eschyle, Prométhée enchaîné", locus: "v. 790 et suiv.", url: "https://www.theoi.com/Text/AeschylusPrometheus.html" }
  - { source: "Pindare, Pythiques", locus: "XII", url: "https://cts.perseids.org/read/greekLit/tlg0033/tlg002/perseus-eng3/12.1-12.30" }
  - { source: "Apollodore, Bibliothèque", locus: "II, 4, 2–3", url: "https://www.theoi.com/Text/Apollodorus2.html" }
  - { source: "Ovide, Métamorphoses (poète romain)", locus: "IV, 770–803", url: "https://www.thelatinlibrary.com/ovid/ovid.met4.shtml" }
review: { status: draft }
```

### MDX

```mdx
---
name: Méduse
role: La Gorgone au regard qui pétrifie
hook: Un regard, et tu deviens statue. Mais avant d'être un monstre de jeu vidéo, Méduse a eu une histoire — et même plusieurs.
---

## En bref

- **Famille :** fille de Phorcys et Céto, deux divinités marines ; sœur de Sthéno et Euryale
- **Statut :** la seule Gorgone mortelle
- **Pouvoir :** quiconque la regarde est changé en pierre
- **Lieu :** au bout du monde, « au-delà de l'Océan », du côté de la Nuit
- **Vaincue par :** <E id="perseus">Persée</E>, avec l'aide d'<E id="athena">Athéna</E> et d'Hermès
- **Enfants :** <E id="pegasus">Pégase</E> et Chrysaor, nés de son cou tranché
- **Symbole :** sa tête, le gorgonéion, gravée sur les boucliers et les temples

## Son histoire

Elles sont trois sœurs, les Gorgones : Sthéno, Euryale et Méduse. Le poète grec Hésiode (vers 700 av. J.-C.) précise un détail qui change tout : Méduse est mortelle. Ses deux sœurs, elles, sont immortelles et ne vieillissent pas.

Toujours chez Hésiode, Méduse s'unit au « dieu aux cheveux sombres », c'est-à-dire <E id="poseidon">Poséidon</E>, « dans une prairie tendre, parmi les fleurs du printemps ». Pas de temple, pas de punition : elle est Gorgone de naissance.

Bien plus tard, le mythographe — compilateur de mythes — Apollodore raconte la chasse. Le roi Polydectès veut éloigner Persée. Le héros part chercher la tête de Méduse. Des nymphes lui donnent des sandales ailées, une besace et le casque d'Hadès, qui rend invisible. Hermès lui offre une faucille en adamant, un métal réputé indestructible.

Persée surprend les Gorgones endormies. Athéna guide sa main ; lui regarde le reflet de Méduse dans un bouclier de bronze, et tranche. Du cou jaillissent Pégase, le cheval ailé, et Chrysaor, le guerrier à l'épée d'or. De retour, Persée change Polydectès et sa cour en pierre, puis offre la tête à Athéna.

## Ses pouvoirs

- Son regard change en pierre quiconque la contemple, et sa tête coupée garde ce pouvoir.
- Selon Apollodore, les Gorgones ont des écailles de serpent sur la tête, des défenses de sanglier, des mains de bronze et des ailes d'or.
- Ces ailes leur permettent de voler : dans le *Bouclier d'Héraclès*, Sthéno et Euryale poursuivent Persée dans les airs.
- Mortelle, Méduse est pourtant la seule des trois qu'on puisse tuer.

<Versions title="Une histoire, plusieurs versions">
  <Version layer="ancient" source="Hésiode, Théogonie, v. 270 et suiv.">Méduse naît Gorgone, fille de deux divinités marines. Elle s'unit à Poséidon dans une prairie. Le texte ne parle ni de temple, ni de punition, ni de beauté perdue.</Version>
  <Version layer="ancient" source="Apollodore, Bibliothèque, II, 4, 3">Apollodore rapporte que, selon certains, Athéna aurait voulu la mort de Méduse parce que la Gorgone prétendait rivaliser avec elle en beauté.</Version>
  <Version layer="ancient" source="Ovide, Métamorphoses, IV, 794–803 (poète romain, vers 8 apr. J.-C.)">Chez le poète romain Ovide, Méduse est d'abord une jeune femme d'une grande beauté. Le dieu de la mer la viole dans le temple de Minerve (nom romain d'Athéna). La déesse détourne les yeux, puis punit Méduse en changeant ses cheveux en serpents. C'est une version romaine tardive, pas « la » version grecque.</Version>
  <Version layer="interpretation">Depuis le XXe siècle, beaucoup de lectures font de Méduse une victime dont on a fait un monstre. L'essai d'Hélène Cixous, *Le Rire de la Méduse* (1975 [À VÉRIFIER]), en a fait un symbole féministe. Cette lecture s'appuie surtout sur Ovide : chez Hésiode, Méduse est un monstre dès l'origine.</Version>
</Versions>

## Le saviez-vous ?

- **Une musique née d'un cri.** Chez Pindare (Pythiques XII, début du Ve siècle av. J.-C. [date exacte À VÉRIFIER]), Athéna invente un air de flûte en imitant la lamentation des Gorgones après la mort de Méduse. Elle l'appelle l'air « aux nombreuses têtes ».
- **Laide, puis belle.** Dans l'art grec archaïque, la Gorgone a barbe, crocs et langue tirée. À partir du Ve siècle av. J.-C., les artistes la représentent de plus en plus comme une belle jeune femme (Metropolitan Museum of Art).
- **Le premier gorgonéion d'Athéna est chez Homère.** Dans l'*Iliade* (V, 733 et suiv.), la tête de la Gorgone orne déjà l'égide, la cuirasse-bouclier d'Athéna.

## Dans la culture populaire

- **Percy Jackson et le Voleur de foudre** (Rick Riordan, 2005) : Méduse, sous le nom d'« Aunty Em », tient un magasin de statues de jardin. Ses statues sont ses victimes pétrifiées.
- **Le Choc des Titans** (Desmond Davis, 1981) : la Méduse animée image par image par Ray Harryhausen est devenue culte. Le remake de 2010 (Louis Leterrier) reprend la scène du reflet dans le bouclier.
- **Hades** (Supergiant Games, 2020) : Dusa, une tête de Gorgone volante, est femme de ménage dans le palais d'Hadès. Plus inoffensif, tu meurs.
- **Versace** : la maison de mode italienne a fait de la tête de Méduse son emblème.

## Pour aller plus loin

- <E id="perseus">Persée</E> — Le héros qui a tué Méduse sans jamais la regarder en face.
- <E id="pegasus">Pégase</E> — Le cheval ailé né d'un cou tranché.
- <E id="athena">Athéna</E> — La déesse qui porte la tête de Méduse sur sa poitrine depuis des siècles.

## Sources

- Hésiode, *Théogonie*, v. 270 et suiv. (vers 700 av. J.-C.)
- Homère, *Iliade*, V, 733 et suiv. (VIIIe siècle av. J.-C.)
- (Pseudo-)Hésiode, *Bouclier d'Héraclès*, v. 216–237 (VIe siècle av. J.-C. [À VÉRIFIER])
- Eschyle, *Prométhée enchaîné*, v. 790 et suiv. (Ve siècle av. J.-C.)
- Pindare, *Pythiques*, XII (Ve siècle av. J.-C.)
- Apollodore, *Bibliothèque*, II, 4, 2–3 (Ier–IIe siècle apr. J.-C.)
- Ovide, *Métamorphoses*, IV, 770–803 (poète romain, vers 8 apr. J.-C.)
- M. Glennon, « Medusa in Ancient Greek Art », The Metropolitan Museum of Art, 2017
```

### Sources consultées

- https://www.theoi.com/Pontios/Gorgones.html — compilation des sources : parenté (Hésiode, Chants cypriens, Hygin), mortalité de Méduse, union avec Poséidon, naissance de Pégase/Chrysaor, Ovide (temple), Apollodore (objets, reflet, tête sur le bouclier), Iliade (égide), pétrification.
- https://www.theoi.com/Text/HesiodTheogony.html — Théogonie, bloc [270] : Gorgones nommées, « au-delà de l'Océan… vers la Nuit », Méduse mortelle, « the Dark-haired One in a soft meadow amid spring flowers » (note 14 : Poséidon), Chrysaor et Pégase sortent quand Persée lui tranche la tête, étymologie des noms.
- http://www.perseus.tufts.edu/hopper/text?doc=Perseus:text:1999.01.0130:card=270 — même passage (traduction Evelyn-White) : confirmé, mais sans numéros de vers exacts.
- https://www.theatre-classique.fr/pages/pdf/HESIODE_THEOGONIE.pdf — traduction française ancienne : « Méduse était mortelle… », « Neptune aux noirs cheveux s'unit avec elle dans une molle prairie ».
- https://www.theoi.com/Text/Apollodorus2.html — Bibliothèque II, 4, 2–3 : Polydectès, Hippodamie, filles de Phorcys (œil et dent), nymphes (sandales, kibisis, casque d'Hadès), faucille adamantine d'Hermès, Athéna guide la main, bouclier de bronze, Gorgones endormies, description physique, Pégase/Chrysaor « par Poséidon », rivalité de beauté avec Athéna, tête au centre du bouclier d'Athéna, pétrification des convives, objets rendus à Hermès.
- https://www.theoi.com/Text/OvidMetamorphoses4.html — Ovide, fin du livre IV (trad. Brookes More) : reflet sur le bouclier, beauté de Méduse, temple de Minerve, cheveux changés en serpents.
- https://www.thelatinlibrary.com/ovid/ovid.met4.shtml — texte latin et numéros de vers : 775 (Phorcides, un seul œil), 782–783 (reflet), 786 (Pégase et son frère nés du sang), 794 (clarissima forma), 798 (pelagi rector… templo… Minervae), 799–800 (égide), 801 (cheveux en hydres), 803 (serpents sur la poitrine).
- https://www.theoi.com/Text/HomerIliad5.html — Iliade V, [733] : la tête de la Gorgone sur l'égide d'Athéna.
- https://www.theoi.com/Text/HesiodShield.html — Bouclier d'Héraclès [216]–[237] : Persée avec sandales ailées, épée, sac d'argent contenant la tête, casque d'Hadès ; les Gorgones le poursuivent.
- https://www.theoi.com/Text/AeschylusPrometheus.html — Prométhée [790] : Gorgones que nul mortel ne peut regarder sans cesser de respirer.
- https://cts.perseids.org/read/greekLit/tlg0033/tlg002/perseus-eng3/12.1-12.30 — Pindare, Pythique XII : chant des Gorgones transformé en musique par Athéna, « many-headed strain », mort apportée à Sériphos, « beautiful Medusa ».
- https://en.wikipedia.org/wiki/Medusa — point de départ : Pythique XII datée de 490 av. J.-C., évolution iconographique, Cixous, Harrison, Freud.
- https://en.wikipedia.org/wiki/Gorgoneion — fonction apotropaïque, fronton de Corfou (début VIe s. av. J.-C.), pelikè de Polygnotos, Méduse Rondanini.
- https://www.metmuseum.org/en/essays/medusa-in-ancient-greek-art — usage protecteur (antéfixes, armures, coupes), évolution du monstrueux vers le beau, Persée qui détourne le regard dans l'art.
- https://en.wikipedia.org/wiki/Perseus — Polydectès, variantes sur les donateurs des objets (Phérécyde fr. 11 cité).
- https://ebsco.com/research-starters/religion-and-philosophy/perseus-and-medusa — reflet présent chez Apollodore et Ovide ; rien sur l'origine du motif.
- https://litcharts.com/lit/the-lightning-thief/chapter-11 — Percy Jackson, chap. 11 : « Aunty Em's Garden Gnome Emporium », statues = victimes.
- https://en.wikipedia.org/wiki/Dusa_(Hades) — Dusa, tête de Gorgone, femme de ménage dans Hades (2020).
- https://en.wikipedia.org/wiki/Clash_of_the_Titans_(1981_film) — Desmond Davis, 1981, Harryhausen, reflet du bouclier, tête contre le Kraken.
- https://en.wikipedia.org/wiki/Clash_of_the_Titans_(2010_film) — Louis Leterrier, Natalia Vodianova, reflet du bouclier.
- https://www.adweek.com/brand-marketing/versaces-medusa-logo-breaks-every-design-rule-so-why-does-it-work/ et https://sixtysixmag.com/landing/what-does-the-versace-logo-mean/ — logo Méduse de Versace (date 1978 avancée par une source faible, non reprise dans le texte).

Pages tentées sans succès (non utilisées) : theoi.com/Pontios/Medousa.html, theoi.com/Text/PindarPythianOdes.html, britannica.com (Gorgon), fr.wikisource.org (Théogonie, Leconte de Lisle), scaife/perseids (texte grec d'Hésiode).

### Doutes

1. **Numéros de vers exacts d'Hésiode** : le passage commence au bloc [270] sur theoi, mais je n'ai pas pu accéder au texte grec numéroté. Les vers sur Méduse seraient vers 274–283 ; d'où « v. 270 et suiv. » dans le texte. [À VÉRIFIER]
2. **Citation d'Hésiode** (« dans une prairie tendre, parmi les fleurs du printemps ») : traduction de la rédaction, faite d'après l'anglais d'Evelyn-White (« in a soft meadow amid spring flowers ») et recoupée avec une ancienne traduction française (« dans une molle prairie »). À contrôler sur le grec ; à signaler comme traduction maison.
3. **« Dieu aux cheveux sombres » = Poséidon** : l'identification vient de la note de theoi et de la traduction française (« Neptune aux noirs cheveux ») ; le grec (Kyanochaitès) n'a pas été vérifié directement.
4. **Origine du reflet dans le bouclier** : attesté chez Apollodore (Ier–IIe s. apr. J.-C.) et Ovide ; dans l'art grec, Persée détourne souvent simplement le regard (Met). Je n'ai pas trouvé la **première attestation** du reflet. Le texte de la fiche ne dit pas que le détail est ancien. [À VÉRIFIER]
5. **Qui donne les objets à Persée** : chez Apollodore, nymphes (sandales, kibisis, casque) + Hermès (faucille) + Athéna (guide). D'autres versions (Phérécyde, cité via Wikipédia) diffèrent ; non vérifié dans la source antique. Un bloc `<Versions>` dédié serait possible dans la fiche « Persée ».
6. **Promesse de Persée à Polydectès** (le défi de ramener la tête) : volontairement simplifié dans la fiche (« part chercher la tête »), car je n'ai pas vérifié le détail exact chez Apollodore.
7. **Date de la Pythique XII** (490 av. J.-C.) : seulement via Wikipédia ; écrit « début du Ve siècle » dans la fiche. [À VÉRIFIER]
8. **Date du *Bouclier d'Héraclès*** (attribution pseudo-hésiodique, VIe s.) : non vérifiée en ligne. [À VÉRIFIER]
9. **Cixous, *Le Rire de la Méduse*** : Wikipédia EN donne 1976 (traduction anglaise) ; l'original français serait de 1975. [À VÉRIFIER]
10. **Percy Jackson en VF** : le nom « Aunty Em » et le titre de chapitre ont été vérifiés en VO seulement ; le nom dans la traduction française n'est pas confirmé.
11. **Versace** : date d'adoption du logo (1978) et anecdote d'origine non confirmées par une source solide ; la fiche mentionne seulement l'emblème, sans date.
12. **Égide chez Homère** : l'Iliade dit « la Gorgone », sans nommer Méduse ni Persée ; la fiche le formule ainsi, mais l'anecdote pourrait laisser croire que l'épisode de Persée est déjà connu d'Homère. À relire.
13. **Ovide, Métamorphoses VI, 119** (Neptune s'unit à Méduse sous la forme d'un oiseau), signalé par theoi : non vérifié dans le texte, donc non utilisé.
14. **Relations YAML** : les types `partner-of`, `enemy-of`, `part-of` et les id `ceto`, `graeae`, `aegis`, `chrysaor`, `stheno`, `euryale` sont des propositions ; vérifier qu'ils existent dans le graphe central.
15. **Le mot « mythographe »** et l'humour (« Plus inoffensif, tu meurs ») : à valider par le directeur éditorial pour le ton.
