# État du projet au 15 octobre 2026, 12 h 35 (mise en pause)

## En ligne sur le site (vérifiées par IA, avec images validées)
Méduse · Zeus · Poséidon · Hadès · Athéna

## En cours, arrêté proprement (reprendre là où c'était)
| Fiche | Étape | Fichiers |
|---|---|---|
| Héra | v2 en cours d'écriture (corrections du rapport + D14, D15) | `drafts/hera.draft.md`, `reviews/hera.review.md` |
| Perséphone | vérification en cours | `drafts/persephone.draft.md` |
| Déméter | vérification en cours (textes primaires faits) | `drafts/demeter.draft.md` |
| Hermès | vérification en cours | `drafts/hermes.draft.md` |

## À faire ensuite
1. Finir Héra v2 → importer (image : `hera-herakles-snakes`, picto `picto-hera`).
2. Arbitrer les rapports Perséphone, Déméter, Hermès → v2 → importer (Perséphone : `persephone-return`).
3. Vague B restante : Hestia, Arès, Aphrodite, Apollon, Artémis, Héphaïstos, Dionysos (briefs prêts : `briefs/lot1-vagueB.md`) + recherche d'images pour chacun.
4. Pousser le dépôt sur GitHub (`pacoov/mini-porjets`) une fois le compte GitHub relié à Claude.
5. Lancer Claude Code avec `docs/PROMPT_CLAUDE_CODE.md`.

## Ce qu'attend Enzo
- Relire Méduse (fiche sensible) et, si possible, Hadès.
- Relier GitHub ou pousser lui-même le zip.

## Références
- Règles communes : `DECISIONS_LOT1.md` (D1 à D15)
- Guides agents : `GUIDE_REDACTION.md`, `GUIDE_VERIFICATION.md`
- Galerie des visuels : artifact « Galerie du Fil d'Ariane »
