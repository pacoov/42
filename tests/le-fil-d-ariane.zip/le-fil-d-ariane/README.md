# Le Fil d'Ariane

La mythologie grecque comme un réseau d'histoires à explorer, pour les 15–25 ans.
Cahier des charges complet : [`docs/PROJECT_BLUEPRINT.md`](docs/PROJECT_BLUEPRINT.md).

## Démarrer

```bash
npm install
npm run dev          # http://localhost:3000 → redirige vers /fr
```

| Commande | Rôle |
|---|---|
| `npm run content:check` | Valide tout le contenu (schémas, références, sources, licences). Lancée automatiquement avant chaque build. |
| `npm test` | Tests du pipeline de contenu (dont : une référence cassée fait échouer le build). |
| `npm run typecheck` | Types des routes + TypeScript strict. |
| `npm run build` | Génère toutes les pages en statique. |

## Organisation

```
app/[lang]/                     Routes (une seule langue publiée : fr)
  [section]/                    Catégories : dieux, titans, heros, creatures, lieux, objets
  [section]/[slug]/             Fiches
components/                     Composants (layout, entity, content)
content/
  entities/<catégorie>/<id>.yaml  Données structurelles (langue-agnostiques)
  i18n/fr/entities/…/<id>.mdx     Texte français de chaque fiche
  i18n/fr/ui.json                 Chaînes d'interface
  media/registry.yaml             Registre des médias (licence + validation galerie obligatoires)
  planned.yaml                    Entités annoncées, citables avant d'être rédigées
lib/content/                    Schémas Zod, chargement, validation, graphe, rendu MDX
lib/i18n/                       Dictionnaires et URLs localisées
docs/editorial/                 Guides des agents rédacteur et vérificateur, briefs, rapports
public/media/                   Images publiées (originaux du Met en CC0, redimensionnés)
```

## Ajouter une fiche

1. `content/entities/<catégorie>/<id>.yaml` (format : `docs/editorial/GUIDE_REDACTION.md`).
2. `content/i18n/fr/entities/<catégorie>/<id>.mdx`.
3. Retirer l'id de `content/planned.yaml` s'il y figurait.
4. `npm run content:check` : toute erreur est listée avec le fichier et la correction attendue.

Statuts publiés : `verified-ai` (avec bandeau « relecture humaine en cours ») et `verified`.
Avant le lancement public, restreindre `PUBLISHABLE` à `verified` dans `lib/content/load.ts`.

## Choix techniques notables

- Next.js 16 sans Cache Components : site 100 % statique, `generateStaticParams` + `dynamicParams = false`.
- Internationalisation native (`app/[lang]`, dictionnaires) plutôt que next-intl.
- Polices auto-hébergées (Fraunces, Inter latin + grec, Cinzel ; licence OFL), aucune requête vers un tiers.
