import Image from "next/image";
import type { ContentGraph, LocalizedEntity } from "@/lib/content/load";

/** Galerie d'œuvres : défilement horizontal avec accroche (mobile), grille (desktop). */
export function Gallery({ e, g, title }: { e: LocalizedEntity; g: ContentGraph; title: string }) {
  const items = e.media.gallery.map((id) => g.media.get(id)!);
  if (!items.length) return null;
  return (
    <section aria-label={title} className="mx-auto mt-16 max-w-6xl px-4 sm:px-8">
      <h2 className="font-display text-[clamp(26px,1.4rem+1vw,34px)] font-semibold">{title}</h2>
      <ul className="mt-5 flex snap-x snap-mandatory gap-4 overflow-x-auto pb-3 md:grid md:grid-cols-4 md:overflow-visible">
        {items.map((m) => (
          <li key={m.id} className="w-[70%] shrink-0 snap-start md:w-auto">
            <figure>
              <div className="overflow-hidden rounded-[var(--radius-card)] border border-border bg-surface-muted">
                <Image src={m.file} width={m.width} height={m.height} alt={m.alt} sizes="(min-width: 768px) 22vw, 70vw" className="aspect-[4/5] h-auto w-full object-contain" />
              </div>
              <figcaption className="mt-2 text-sm text-muted">{m.caption}</figcaption>
            </figure>
          </li>
        ))}
      </ul>
    </section>
  );
}
