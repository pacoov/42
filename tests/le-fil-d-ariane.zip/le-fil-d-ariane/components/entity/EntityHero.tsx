import Image from "next/image";
import type { LocalizedEntity, ContentGraph } from "@/lib/content/load";
import type { Locale } from "@/lib/content/schema";
import type { Dictionary } from "@/lib/i18n";

export function EntityHero({ e, g, locale, t }: { e: LocalizedEntity; g: ContentGraph; locale: Locale; t: Dictionary }) {
  const text = e.text[locale]!;
  const hero = e.media.hero ? g.media.get(e.media.hero) : undefined;
  const danger = e.creature?.danger;
  return (
    <section className="mx-auto grid max-w-6xl gap-8 px-4 pt-8 sm:px-8 md:grid-cols-[minmax(0,5fr)_minmax(0,6fr)] md:items-center md:gap-14 md:pt-14">
      {hero && (
        <figure className="order-1 md:order-none">
          <div className="overflow-hidden rounded-[var(--radius-arch)] border border-border bg-surface-muted">
            <Image
              src={hero.file}
              width={hero.width}
              height={hero.height}
              alt={hero.alt}
              priority
              sizes="(min-width: 768px) 42vw, 100vw"
              className="h-auto w-full"
            />
          </div>
          <figcaption className="mt-2 text-sm text-muted">
            {hero.caption} · {hero.credit}
          </figcaption>
        </figure>
      )}
      <div className="grid gap-4">
        <p className="font-antique text-[13px] tracking-[0.16em] uppercase" style={{ color: `var(--cat-${e.category})` }}>
          {t.nav[e.category]}
        </p>
        <h1 className="font-display text-[clamp(44px,8vw,84px)] leading-[0.95] font-semibold tracking-tight">{text.meta.name}</h1>
        {e.names.greek && (
          <p className="font-display text-xl text-muted" lang="grc">
            <span className="sr-only">{t.entity.greekName} : </span>
            {e.names.greek}
            {e.names.transliteration && <span className="ml-2 text-base not-italic">({e.names.transliteration})</span>}
          </p>
        )}
        <p className="text-xl leading-snug font-medium">{text.meta.role}</p>
        <p className="max-w-prose text-lg text-muted">{text.meta.hook}</p>
        <dl className="mt-2 flex flex-wrap gap-2 text-sm">
          {e.names.roman && (
            <div className="rounded-full border border-border bg-surface px-3 py-1.5">
              <dt className="inline text-muted">{t.entity.roman} : </dt>
              <dd className="inline font-medium">{e.names.roman}</dd>
            </div>
          )}
          {danger && (
            <div className="flex items-center gap-2 rounded-full border border-border bg-surface px-3 py-1.5">
              <dt className="text-muted">{t.entity.danger} :</dt>
              <dd className="flex items-center gap-1.5 font-medium">
                <span aria-hidden="true" className="flex gap-0.5">
                  {[1, 2, 3].map((n) => (
                    <span key={n} className="h-2.5 w-2.5 rounded-full" style={{ background: n <= danger ? "#b3261e" : "var(--border)" }} />
                  ))}
                </span>
                {t.entity.dangerLevels[String(danger) as "1" | "2" | "3"]}
              </dd>
            </div>
          )}
        </dl>
      </div>
    </section>
  );
}
