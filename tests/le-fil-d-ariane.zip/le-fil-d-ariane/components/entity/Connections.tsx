import Link from "next/link";
import { type ContentGraph, displayName, isPublished, neighbors } from "@/lib/content/load";
import { RELATION_FAMILY, type Locale } from "@/lib/content/schema";
import { entityHref, type Dictionary } from "@/lib/i18n";

const FAMILY_ORDER = ["family", "love", "conflict", "alliance", "other"] as const;
/** Style de trait par famille de relation : jamais la couleur seule (§20). */
const FAMILY_STROKE: Record<(typeof FAMILY_ORDER)[number], string> = {
  family: "solid",
  love: "dotted",
  conflict: "dashed",
  alliance: "double",
  other: "solid",
};

export function Connections({ id, g, locale, t }: { id: string; g: ContentGraph; locale: Locale; t: Dictionary }) {
  const all = neighbors(g, id);
  const self = g.entities.get(id);
  if (!all.length) return null;
  const groups = FAMILY_ORDER.map((f) => ({ f, items: all.filter((n) => RELATION_FAMILY[n.relation.type] === f) })).filter((x) => x.items.length);
  return (
    <section aria-labelledby="connexions" className="mx-auto max-w-6xl px-4 sm:px-8">
      <h2 id="connexions" className="font-display text-[clamp(26px,1.4rem+1vw,34px)] font-semibold">
        {t.entity.connections}
      </h2>
      <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {groups.map(({ f, items }) => (
          <div key={f} className="rounded-[var(--radius-card)] border border-border bg-surface p-5">
            <h3 className="mb-3 flex items-center gap-3 text-sm font-semibold tracking-[0.06em] uppercase text-muted">
              <span aria-hidden="true" className="w-8 border-t-2 border-text" style={{ borderTopStyle: FAMILY_STROKE[f] as never, borderTopWidth: f === "alliance" ? 4 : 2 }} />
              {t.relations[f]}
            </h3>
            <ul className="grid gap-2">
              {items.map((n) => {
                const other = g.entities.get(n.other);
                const name = displayName(g, n.other, locale);
                const verb = t.relations[n.relation.type][n.direction][self?.gender ?? "n"];
                return (
                  <li key={`${n.relation.from}-${n.relation.type}-${n.relation.to}`} className="leading-snug">
                    <span className="text-muted">{verb} </span>
                    {other && isPublished(other, locale) ? (
                      <Link href={entityHref(locale, other.category, other.slug)} className="font-medium">
                        {name}
                      </Link>
                    ) : (
                      <span className="font-medium" title={t.entity.notYetWritten}>
                        {name}
                      </span>
                    )}
                    {n.relation.certainty === "variant" && <span className="text-sm text-muted"> ({t.entity.variant})</span>}
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </div>
    </section>
  );
}
