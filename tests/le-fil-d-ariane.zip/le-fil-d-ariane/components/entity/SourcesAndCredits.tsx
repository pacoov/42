import type { ContentGraph, LocalizedEntity } from "@/lib/content/load";
import type { Dictionary } from "@/lib/i18n";

export function SourcesAndCredits({ e, g, t }: { e: LocalizedEntity; g: ContentGraph; t: Dictionary }) {
  const images = [e.media.hero, ...e.media.gallery].filter(Boolean).map((id) => g.media.get(id!)!);
  return (
    <section aria-labelledby="sources" className="mx-auto mt-16 grid max-w-6xl gap-10 px-4 sm:px-8 md:grid-cols-2">
      <div>
        <h2 id="sources" className="font-display text-2xl font-semibold">
          {t.entity.sources}
        </h2>
        <ul className="mt-4 grid gap-2 text-[15px]">
          {e.sources.map((s) => (
            <li key={s.source + (s.locus ?? "")}>
              {s.url ? (
                <a href={s.url} rel="noopener noreferrer" target="_blank">
                  {s.source}
                </a>
              ) : (
                s.source
              )}
              {s.locus && <span className="text-muted">, {s.locus}</span>}
            </li>
          ))}
        </ul>
      </div>
      {images.length > 0 && (
        <div>
          <h2 className="font-display text-2xl font-semibold">{t.entity.mediaCredits}</h2>
          <ul className="mt-4 grid gap-2 text-[15px]">
            {images.map((m) => (
              <li key={m.id}>
                {m.caption} —{" "}
                <a href={m.sourceUrl} rel="noopener noreferrer" target="_blank">
                  {m.credit}
                </a>{" "}
                <span className="text-muted">({m.license === "CC0" ? "domaine public, CC0" : m.license})</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </section>
  );
}
