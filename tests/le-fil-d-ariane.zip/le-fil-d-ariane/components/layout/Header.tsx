import Link from "next/link";
import type { Locale } from "@/lib/content/schema";
import { getDictionary, sectionHref } from "@/lib/i18n";
import { MobileMenu } from "./MobileMenu";

const MAIN_SECTIONS = ["gods", "heroes", "creatures", "places", "objects"] as const;

export function Header({ locale }: { locale: Locale }) {
  const t = getDictionary(locale);
  return (
    <header className="border-b border-border bg-bg/90 backdrop-blur supports-[backdrop-filter]:bg-bg/75 sticky top-0 z-40">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-6 px-4 py-3 sm:px-8">
        <Link href={`/${locale}`} className="flex items-center gap-2.5 no-underline text-text" aria-label={t.site.name}>
          <ThreadMark />
          <span className="font-display text-lg font-semibold tracking-tight">{t.site.name}</span>
        </Link>
        <nav aria-label={t.nav.label} className="hidden md:block">
          <ul className="flex gap-5 text-[15px]">
            {MAIN_SECTIONS.map((c) => (
              <li key={c}>
                <Link className="text-text no-underline hover:text-link" href={sectionHref(locale, c)}>
                  {t.nav[c]}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        <MobileMenu
          items={[{ href: `/${locale}`, label: t.nav.home }, ...MAIN_SECTIONS.map((c) => ({ href: sectionHref(locale, c), label: t.nav[c] }))]}
          openLabel={t.nav.menuOpen}
          closeLabel={t.nav.menuClose}
        />
      </div>
      <div className="thread" aria-hidden="true" />
    </header>
  );
}

/** Monogramme : une pelote dont le fil dessine un A en une seule ligne. */
export function ThreadMark({ className = "h-8 w-8" }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden="true" fill="none" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="9" cy="23" r="5" stroke="var(--thread)" strokeWidth="1.4" />
      <path d="M6.5 21.2c2-1.4 3.6-1.3 5 .4M6.3 24.4c2.3-1.6 4.2-1.4 5.5.5" stroke="var(--thread)" strokeWidth="1" />
      <path d="M13.6 21.6 19.5 6l6.4 20M16 17.5h7.3" stroke="currentColor" strokeWidth="1.6" />
      <path d="M25.9 26c1.2 1.4 2.6 1.6 3.6.8" stroke="var(--thread)" strokeWidth="1.4" />
    </svg>
  );
}
