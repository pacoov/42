import Link from "next/link";
import type { Locale } from "@/lib/content/schema";
import { getDictionary } from "@/lib/i18n";
import { ThreadMark } from "./Header";

export function Footer({ locale }: { locale: Locale }) {
  const t = getDictionary(locale);
  return (
    <footer className="mt-24 border-t border-border bg-surface-muted">
      <div className="mx-auto grid max-w-6xl gap-4 px-4 py-10 sm:px-8">
        <Link href={`/${locale}`} className="flex w-max items-center gap-2 text-text no-underline">
          <ThreadMark className="h-7 w-7" />
          <span className="font-display font-semibold">{t.site.name}</span>
        </Link>
        <p className="max-w-prose text-muted">{t.site.tagline}</p>
        <p className="text-sm text-muted">{t.footer.brands}</p>
      </div>
    </footer>
  );
}
