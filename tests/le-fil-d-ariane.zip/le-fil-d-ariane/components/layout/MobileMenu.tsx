"use client";

import Link from "next/link";
import { useRef } from "react";

type Item = { href: string; label: string };

/** Menu mobile plein écran. <dialog> natif : piège de focus, touche Échap
 * et retour du focus sont gérés par le navigateur (§17.10). */
export function MobileMenu({ items, openLabel, closeLabel }: { items: Item[]; openLabel: string; closeLabel: string }) {
  const ref = useRef<HTMLDialogElement>(null);
  return (
    <>
      <button
        type="button"
        onClick={() => ref.current?.showModal()}
        className="grid h-11 w-11 place-items-center rounded-full text-text md:hidden"
        aria-label={openLabel}
      >
        <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" aria-hidden="true">
          <path d="M4 8h16M4 16h11" />
        </svg>
      </button>
      <dialog
        ref={ref}
        className="m-0 h-dvh max-h-none w-screen max-w-none bg-abyss p-0 text-[#eef2f7] backdrop:bg-transparent open:animate-[menu-in_240ms_cubic-bezier(.22,1,.36,1)]"
        onClick={(e) => {
          if ((e.target as HTMLElement).closest("a")) ref.current?.close();
        }}
      >
        <div className="flex h-full flex-col px-6 pt-[max(1rem,env(safe-area-inset-top))] pb-10">
          <div className="flex justify-end">
            <button
              type="button"
              onClick={() => ref.current?.close()}
              className="grid h-11 w-11 place-items-center rounded-full"
              aria-label={closeLabel}
            >
              <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" aria-hidden="true">
                <path d="M6 6l12 12M18 6 6 18" />
              </svg>
            </button>
          </div>
          <nav className="mt-6 flex-1">
            <ul className="grid gap-1">
              {items.map((it) => (
                <li key={it.href}>
                  <Link href={it.href} className="block py-2 font-display text-[40px] leading-tight font-semibold text-[#eef2f7] no-underline">
                    {it.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
          <div className="thread w-40" aria-hidden="true" />
        </div>
      </dialog>
    </>
  );
}
