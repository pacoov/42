import Link from "next/link";
import type { Dictionary } from "@/lib/i18n";

/** Hero de nuit : le ciel au-dessus de l'Olympe. Un seul moment animé :
 * le fil d'or se dessine sous le titre au chargement (désactivé si
 * l'utilisateur réduit les animations). */
export function Hero({ t, startHref, expertHref }: { t: Dictionary; startHref: string; expertHref: string }) {
  return (
    <section className="hero relative isolate overflow-hidden text-[#eef2f7]">
      <div aria-hidden="true" className="hero-sky absolute inset-0 -z-10" />
      <Olympus />
      <div className="mx-auto grid max-w-6xl gap-6 px-4 pt-20 pb-56 sm:px-8 md:pt-28 md:pb-72">
        <h1 className="font-display text-[clamp(52px,11vw,132px)] leading-[0.88] font-semibold tracking-[-0.02em]" style={{ fontVariationSettings: '"opsz" 144, "SOFT" 30' }}>
          {t.home.title}
        </h1>
        <svg className="hero-thread -mt-2 h-6 w-full max-w-[38rem]" viewBox="0 0 600 24" fill="none" aria-hidden="true" preserveAspectRatio="none">
          <path d="M2 14C80 4 140 22 220 13s150-10 230 2 110 4 146-6" stroke="var(--gold-500)" strokeWidth="1.6" strokeLinecap="round" />
        </svg>
        <p className="max-w-2xl font-display text-[clamp(22px,2.4vw,30px)] leading-snug">{t.home.tagline}</p>
        <p className="max-w-xl text-lg text-[#a9b6c8]">{t.home.intro}</p>
        <div className="mt-2 flex flex-wrap gap-3">
          <Link
            href={startHref}
            className="inline-flex min-h-12 items-center rounded-full bg-[var(--gold-300)] px-6 font-semibold text-[var(--abyss-950)] no-underline transition-transform duration-150 hover:-translate-y-px"
          >
            {t.home.ctaStart}
          </Link>
          <Link
            href={expertHref}
            className="inline-flex min-h-12 items-center rounded-full border border-[#eef2f7]/40 px-6 font-semibold text-[#eef2f7] no-underline hover:border-[#eef2f7]"
          >
            {t.home.ctaExpert}
          </Link>
        </div>
      </div>
    </section>
  );
}

/** Silhouette de l'Olympe, temple au sommet, nuages bas. */
function Olympus() {
  return (
    <svg className="pointer-events-none absolute inset-x-0 bottom-0 -z-10 h-[52%] w-full" viewBox="0 0 1440 420" preserveAspectRatio="xMaxYMax slice" aria-hidden="true">
      <path d="M0 420V318l170-48 140 36 180-92 130 44 170-86 120 40 120-150 70 34 90 96 120-30 130 110v148z" fill="#17365a" />
      <path d="M1030 62 1100 96l90 96 120-30 130 110" fill="none" stroke="#e8c77a" strokeOpacity=".35" strokeWidth="1.2" />
      <path d="M0 420V352l220-44 200 30 230-90 160 52 240-70 190 84 200-18v124z" fill="#0f2742" />
      <g fill="none" stroke="#e8c77a" strokeWidth="1.2" opacity=".85" transform="translate(28 0)">
        <path d="M976 30h52M972 36h60M980 36v22M990 36v22M1000 36v22M1010 36v22M1020 36v22M970 60h64" />
        <path d="M974 30l28-14 28 14" />
      </g>
      <path d="M0 420V388c120-18 260-6 380-20s300-30 460-6 380 18 600-8v66z" fill="#070d16" />
    </svg>
  );
}
