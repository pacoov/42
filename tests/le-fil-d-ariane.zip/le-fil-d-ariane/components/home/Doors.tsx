import Link from "next/link";
import type { Category, Locale } from "@/lib/content/schema";
import { sectionHref, type Dictionary } from "@/lib/i18n";

/** Les portes d'entrée : un sommaire de phrases à la première personne,
 * reliées par le fil. Les portes pas encore ouvertes restent visibles. */
export function Doors({ t, locale }: { t: Dictionary; locale: Locale }) {
  return (
    <section aria-labelledby="portes" className="mx-auto max-w-6xl px-4 py-20 sm:px-8 md:py-28">
      <div className="grid gap-10 md:grid-cols-[minmax(0,4fr)_minmax(0,7fr)]">
        <div>
          <h2 id="portes" className="font-display text-[clamp(32px,4vw,48px)] leading-tight font-semibold">
            {t.home.doorsTitle}
          </h2>
          <p className="mt-3 max-w-sm text-lg text-muted">{t.home.doorsLede}</p>
        </div>
        <ul className="relative border-l border-[var(--thread)] pl-6">
          {t.home.doors.map((d) => (
            <li key={d.label} className="relative py-1">
              <span aria-hidden="true" className="absolute top-1/2 -left-[29px] h-2 w-2 -translate-y-1/2 rounded-full bg-[var(--thread)]" />
              {d.target ? (
                <Link
                  href={sectionHref(locale, d.target as Category)}
                  className="group flex items-baseline justify-between gap-4 py-2.5 font-display text-[clamp(22px,2.6vw,32px)] leading-tight text-text no-underline"
                >
                  <span className="decoration-[var(--thread)] decoration-1 underline-offset-[6px] group-hover:underline">{d.label}</span>
                </Link>
              ) : (
                <span className="flex items-baseline justify-between gap-4 py-2.5 font-display text-[clamp(22px,2.6vw,32px)] leading-tight text-muted">
                  {d.label}
                  <span className="shrink-0 font-sans text-sm text-muted">{t.home.soon}</span>
                </span>
              )}
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
