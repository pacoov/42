"use client";

import { useState } from "react";

type Copy = { title: string; statement: string; myth: string; fiction: string; right: string; wrong: string; again: string };

/** Avant-goût du mini-jeu « Mythe ou fiction ? » (une affirmation vérifiée). */
export function MythOrFiction({ copy, answer }: { copy: Copy; answer: "myth" | "fiction" }) {
  const [choice, setChoice] = useState<"myth" | "fiction" | null>(null);
  const correct = choice === answer;
  return (
    <section aria-labelledby="mythe-fiction" className="bg-abyss text-[#eef2f7]">
      <div className="mx-auto grid max-w-3xl gap-6 px-4 py-20 text-center sm:px-8">
        <h2 id="mythe-fiction" className="font-display text-[clamp(30px,4vw,44px)] font-semibold">
          {copy.title}
        </h2>
        <p className="font-display text-[clamp(22px,2.6vw,30px)] leading-snug">« {copy.statement} »</p>
        {choice === null ? (
          <div className="flex justify-center gap-3">
            {(["myth", "fiction"] as const).map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setChoice(c)}
                className="min-h-12 min-w-36 rounded-full border border-[#eef2f7]/40 px-6 font-semibold hover:border-[var(--gold-300)] hover:text-[var(--gold-300)]"
              >
                {copy[c]}
              </button>
            ))}
          </div>
        ) : (
          <div aria-live="polite" className="grid justify-items-center gap-4">
            <p className="max-w-xl text-lg">
              <span aria-hidden="true" className="mr-2" style={{ color: correct ? "#6fd3a1" : "#f2a39c" }}>
                {correct ? "✓" : "✕"}
              </span>
              {correct ? copy.right : copy.wrong}
            </p>
            <button type="button" onClick={() => setChoice(null)} className="text-[var(--gold-300)] underline underline-offset-4">
              {copy.again}
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
