import type { ReactNode } from "react";
import type { Dictionary } from "@/lib/i18n";

type Layer = "ancient" | "interpretation" | "modern";

const LAYER_ICON: Record<Layer, string> = { ancient: "🏺", interpretation: "🔍", modern: "🎬" };

/** Pastille de couche éditoriale : icône + libellé texte (jamais la couleur seule). */
export function LayerBadge({ layer, t }: { layer: Layer; t: Dictionary }) {
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-md border px-2 py-1 text-[12px] font-semibold uppercase tracking-[0.06em]"
      style={{ color: `var(--layer-${layer})`, borderColor: "currentColor" }}
    >
      <span aria-hidden="true">{LAYER_ICON[layer]}</span>
      {t.entity.layers[layer]}
    </span>
  );
}

export function makeVersions(t: Dictionary) {
  function Versions({ title, children }: { title?: string; children: ReactNode }) {
    return (
      <section aria-label={title} className="not-prose my-10 rounded-[var(--radius-card)] border border-border bg-surface p-5 sm:p-7">
        <p className="font-antique text-[13px] tracking-[0.14em] text-accent uppercase">{title ?? "Plusieurs versions"}</p>
        <p className="mt-1 mb-5 text-sm text-muted">Les mythes n’ont pas une version unique. Voici les principales, avec leurs sources.</p>
        <ol className="grid gap-4">{children}</ol>
      </section>
    );
  }
  function Version({ layer, source, children }: { layer: Layer; source?: string; children: ReactNode }) {
    return (
      <li className="grid gap-2 border-l-2 pl-4" style={{ borderColor: `var(--layer-${layer})` }}>
        <div className="flex flex-wrap items-center gap-2">
          <LayerBadge layer={layer} t={t} />
          {source && <span className="text-sm text-muted">{source}</span>}
        </div>
        <p className="m-0">{children}</p>
      </li>
    );
  }
  return { Versions, Version };
}
