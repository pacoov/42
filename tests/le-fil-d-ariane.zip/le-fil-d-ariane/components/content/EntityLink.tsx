import Link from "next/link";
import type { ReactNode } from "react";
import { type ContentGraph, isPublished } from "@/lib/content/load";
import type { Locale } from "@/lib/content/schema";
import { entityHref } from "@/lib/i18n";

/** Lien vers une autre fiche. Une fiche annoncée mais pas encore publiée
 * s'affiche en texte simple (pas de lien mort). */
export function makeEntityLink(g: ContentGraph, locale: Locale, notYet: string) {
  return function E({ id, children }: { id: string; children: ReactNode }) {
    const e = g.entities.get(id);
    if (e && isPublished(e, locale)) {
      return <Link href={entityHref(locale, e.category, e.slug)}>{children}</Link>;
    }
    return (
      <span className="decoration-dotted underline decoration-muted underline-offset-4" title={notYet}>
        {children}
      </span>
    );
  };
}
