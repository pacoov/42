#!/usr/bin/env python3
"""Importe un livrable d'agent rédacteur (### YAML / ### MDX) dans content/.

Usage : python3 scripts/import-draft.py <livrable.md> [--media "hero=id,gallery=id1|id2,pictogram=id"]
- écrit content/entities/<category>/<id>.yaml et content/i18n/fr/entities/<category>/<id>.mdx
- retire l'id de content/planned.yaml
Le contrôle complet se fait ensuite avec `npm run content:check`.
"""
import re, sys, pathlib, yaml

root = pathlib.Path(__file__).resolve().parent.parent / "content"
src = pathlib.Path(sys.argv[1]).read_text(encoding="utf-8")
y = re.search(r"### YAML\s*\n+```ya?ml\n(.*?)```", src, re.S).group(1)
m = re.search(r"### MDX\s*\n+```mdx\n(.*?)```\s*\n+### ", src, re.S).group(1)
data = yaml.safe_load(y)
eid, cat = data["id"], data["category"]

if "--media" in sys.argv:
    spec = sys.argv[sys.argv.index("--media") + 1]
    media = {}
    for part in spec.split(","):
        k, v = part.split("=")
        media[k] = v.split("|") if k == "gallery" else v
    block = "media:\n" + "".join(
        f"  {k}: [{', '.join(v)}]\n" if isinstance(v, list) else f"  {k}: {v}\n" for k, v in media.items()
    )
    y = re.sub(r"^media:.*?(?=^\S)", "", y, flags=re.S | re.M)
    y = re.sub(r"^(review:)", block + r"\1", y, flags=re.M)

(root / "entities" / cat).mkdir(parents=True, exist_ok=True)
(root / "entities" / cat / f"{eid}.yaml").write_text(y, encoding="utf-8")
d = root / "i18n" / "fr" / "entities" / cat
d.mkdir(parents=True, exist_ok=True)
# En-tête : chaque valeur est réécrite entre guillemets (« Spoiler : … » casserait le YAML).
fm = re.match(r"---\n(.*?)\n---\n", m, re.S)
if fm:
    lines = []
    for line in fm.group(1).splitlines():
        k, _, v = line.partition(":")
        v = v.strip().strip('"')
        lines.append(f'{k.strip()}: "{v.replace(chr(34), chr(92) + chr(34))}"')
    m = "---\n" + "\n".join(lines) + "\n---\n" + m[fm.end():]
(d / f"{eid}.mdx").write_text(m, encoding="utf-8")

planned = root / "planned.yaml"
lines = planned.read_text(encoding="utf-8").splitlines(keepends=True)
planned.write_text("".join(l for l in lines if f"id: {eid}," not in l), encoding="utf-8")
print(f"importé : {cat}/{eid}")
