// Vérifie le contenu sans lancer Next : `npm run content:check`.
import path from "node:path";
import { ContentError, loadContent, PUBLISHABLE } from "../lib/content/load";

try {
  const g = loadContent(path.join(process.cwd(), "content"));
  const byStatus = new Map<string, number>();
  for (const e of g.entities.values()) byStatus.set(e.review.status, (byStatus.get(e.review.status) ?? 0) + 1);
  console.log(`✓ Contenu valide : ${g.entities.size} fiche(s), ${g.relations.length} relation(s), ${g.media.size} média(s), ${g.planned.size} entité(s) annoncée(s).`);
  console.log(`  Statuts : ${[...byStatus].map(([s, n]) => `${s} ${n}`).join(" · ")} (publiés : ${PUBLISHABLE.join(", ")})`);
} catch (e) {
  if (e instanceof ContentError) {
    console.error(`✗ ${e.message}`);
    process.exit(1);
  }
  throw e;
}
