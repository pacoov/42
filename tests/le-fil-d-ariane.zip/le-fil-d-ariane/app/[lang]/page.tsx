import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getGraph, publishedEntities } from "@/lib/content";
import { entityHref, getDictionary, hasLocale, sectionHref } from "@/lib/i18n";
import { Hero } from "@/components/home/Hero";
import { Doors } from "@/components/home/Doors";
import { MythOrFiction } from "@/components/home/MythOrFiction";

export default async function Home({ params }: PageProps<"/[lang]">) {
  const { lang } = await params;
  if (!hasLocale(lang)) notFound();
  const t = getDictionary(lang);
  const g = getGraph();
  const published = publishedEntities(g, lang);
  const featured = g.entities.get("medusa");
  const featuredHero = featured?.media.hero ? g.media.get(featured.media.hero) : undefined;

  return (
    <>
      <Hero t={t} startHref={sectionHref(lang, "gods")} expertHref={sectionHref(lang, "creatures")} />
      <Doors t={t} locale={lang} />

      {featured && featuredHero && featured.text[lang] && (
        <section aria-labelledby="a-lire" className="mx-auto max-w-6xl px-4 pb-24 sm:px-8">
          <div className="grid items-center gap-8 md:grid-cols-[minmax(0,4fr)_minmax(0,6fr)] md:gap-16">
            <div className="overflow-hidden rounded-[var(--radius-arch)] border border-border bg-surface-muted">
              <Image src={featuredHero.file} width={featuredHero.width} height={featuredHero.height} alt={featuredHero.alt} sizes="(min-width: 768px) 36vw, 100vw" className="h-auto w-full" />
            </div>
            <div className="grid gap-4">
              <h2 id="a-lire" className="text-muted">
                {t.home.featuredLabel}
              </h2>
              <p className="font-display text-[clamp(34px,5vw,60px)] leading-none font-semibold">{featured.text[lang]!.meta.name}</p>
              <p className="max-w-prose text-xl">{featured.text[lang]!.meta.hook}</p>
              <Link href={entityHref(lang, featured.category, featured.slug)} className="w-max text-lg font-semibold">
                {t.home.featuredCta}
              </Link>
            </div>
          </div>
        </section>
      )}

      <MythOrFiction copy={t.home.quiz} answer="fiction" />

      <section aria-labelledby="en-ligne" className="mx-auto max-w-6xl px-4 py-20 sm:px-8">
        <h2 id="en-ligne" className="font-display text-3xl font-semibold">
          {t.home.available}
        </h2>
        <p className="mt-2 text-muted">{t.home.building}</p>
        <ul className="mt-6 flex flex-wrap gap-x-6 gap-y-2 text-lg">
          {published.map((e) => (
            <li key={e.id}>
              <Link href={entityHref(lang, e.category, e.slug)}>{e.text[lang]!.meta.name}</Link>
            </li>
          ))}
        </ul>
      </section>
    </>
  );
}
