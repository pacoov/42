import type { Metadata, Viewport } from "next";
import { notFound } from "next/navigation";
import { LOCALES } from "@/lib/content/schema";
import { getDictionary, hasLocale } from "@/lib/i18n";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { cinzel, fraunces, inter, interGreek } from "../fonts";
import "../globals.css";

export const dynamicParams = false;

export function generateStaticParams() {
  return LOCALES.map((lang) => ({ lang }));
}

export async function generateMetadata({ params }: LayoutProps<"/[lang]">): Promise<Metadata> {
  const { lang } = await params;
  if (!hasLocale(lang)) return {};
  const t = getDictionary(lang);
  return {
    title: { default: t.site.name, template: `%s | ${t.site.name}` },
    description: t.site.description,
    metadataBase: new URL(process.env.SITE_URL ?? "http://localhost:3000"),
    openGraph: { siteName: t.site.name, locale: "fr_FR", type: "website" },
  };
}

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#faf8f4" },
    { media: "(prefers-color-scheme: dark)", color: "#0b1626" },
  ],
};

export default async function RootLayout({ children, params }: LayoutProps<"/[lang]">) {
  const { lang } = await params;
  if (!hasLocale(lang)) notFound();
  const t = getDictionary(lang);
  return (
    <html lang={lang} className={`${fraunces.variable} ${inter.variable} ${interGreek.variable} ${cinzel.variable}`}>
      <body className="flex min-h-dvh flex-col antialiased">
        <a href="#contenu" className="skip-link">
          {t.nav.skip}
        </a>
        <Header locale={lang} />
        <main id="contenu" className="flex-1">
          {children}
        </main>
        <Footer locale={lang} />
      </body>
    </html>
  );
}
