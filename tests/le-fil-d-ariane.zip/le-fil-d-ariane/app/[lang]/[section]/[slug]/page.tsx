import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getGraph, publishedEntities } from "@/lib/content";
import { renderMdx } from "@/lib/content/mdx";
import { LOCALES } from "@/lib/content/schema";
import { categoryFromSegment, entityHref, getDictionary, hasLocale, SECTION_SEGMENTS } from "@/lib/i18n";
import { EntityHero } from "@/components/entity/EntityHero";
import { Connections } from "@/components/entity/Connections";
import { Gallery } from "@/components/entity/Gallery";
import { SourcesAndCredits } from "@/components/entity/SourcesAndCredits";

export const dynamicParams = false;

export function generateStaticParams() {
  const g = getGraph();
  return LOCALES.flatMap((lang) =>
    publishedEntities(g, lang).map((e) => ({ lang, section: SECTION_SEGMENTS[lang][e.category], slug: e.slug })),
  );
}

function resolve(lang: string, section: string, slug: string) {
  if (!hasLocale(lang)) return undefined;
  const category = categoryFromSegment(lang, section);
  if (!category) return undefined;
  const e = publishedEntities(getGraph(), lang, category).find((x) => x.slug === slug);
  return e ? { lang, e } : undefined;
}

export async function generateMetadata({ params }: PageProps<"/[lang]/[section]/[slug]">): Promise<Metadata> {
  const { lang, section, slug } = await params;
  const r = resolve(lang, section, slug);
  if (!r) return {};
  const text = r.e.text[r.lang]!.meta;
  const g = getGraph();
  const hero = r.e.media.hero ? g.media.get(r.e.media.hero) : undefined;
  return {
    title: `${text.name} — ${text.role}`,
    description: text.hook,
    alternates: { canonical: entityHref(r.lang, r.e.category, r.e.slug) },
    openGraph: { title: text.name, description: text.hook, images: hero ? [{ url: hero.file, alt: hero.alt }] : undefined },
  };
}

/** Retire la section « ## Sources » du MDX : les sources sont rendues
 * à partir des données structurées (avec liens). */
function withoutSourcesSection(body: string) {
  return body.replace(/\n## Sources[\s\S]*$/, "\n");
}

export default async function EntityPage({ params }: PageProps<"/[lang]/[section]/[slug]">) {
  const { lang, section, slug } = await params;
  const r = resolve(lang, section, slug);
  if (!r) notFound();
  const { e } = r;
  const g = getGraph();
  const t = getDictionary(r.lang);
  const body = await renderMdx(withoutSourcesSection(e.text[r.lang]!.body), g, r.lang, t);

  return (
    <article>
      {e.review.status === "verified-ai" && (
        <p role="note" className="border-b border-border bg-surface-muted px-4 py-2 text-center text-sm text-muted">
          {t.entity.reviewAi}
        </p>
      )}
      <EntityHero e={e} g={g} locale={r.lang} t={t} />
      <div className="mx-auto mt-6 max-w-6xl px-4 sm:px-8">
        <div className="prose-fil">{body}</div>
      </div>
      <Gallery e={e} g={g} title="Dans l'art antique" />
      <div className="mt-16">
        <Connections id={e.id} g={g} locale={r.lang} t={t} />
      </div>
      <SourcesAndCredits e={e} g={g} t={t} />
    </article>
  );
}
