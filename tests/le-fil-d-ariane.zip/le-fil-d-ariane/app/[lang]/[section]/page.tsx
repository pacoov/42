import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import { getGraph, publishedEntities } from "@/lib/content";
import { CATEGORIES, LOCALES } from "@/lib/content/schema";
import { categoryFromSegment, entityHref, getDictionary, hasLocale, SECTION_SEGMENTS } from "@/lib/i18n";

export const dynamicParams = false;

export function generateStaticParams() {
  return LOCALES.flatMap((lang) => CATEGORIES.map((c) => ({ lang, section: SECTION_SEGMENTS[lang][c] })));
}

export async function generateMetadata({ params }: PageProps<"/[lang]/[section]">): Promise<Metadata> {
  const { lang, section } = await params;
  if (!hasLocale(lang)) return {};
  const c = categoryFromSegment(lang, section);
  if (!c) return {};
  const s = getDictionary(lang).sections[c];
  return { title: s.title, description: s.lede };
}

export default async function SectionPage({ params }: PageProps<"/[lang]/[section]">) {
  const { lang, section } = await params;
  if (!hasLocale(lang)) notFound();
  const category = categoryFromSegment(lang, section);
  if (!category) notFound();
  const t = getDictionary(lang);
  const g = getGraph();
  const items = publishedEntities(g, lang, category);
  const planned = [...g.planned.values()].filter((p) => p.category === category);
  return (
    <div className="mx-auto max-w-6xl px-4 py-12 sm:px-8 md:py-16">
      <p className="font-antique text-[13px] tracking-[0.16em] uppercase" style={{ color: `var(--cat-${category})` }}>
        {t.nav[category]}
      </p>
      <h1 className="mt-2 font-display text-[clamp(38px,6vw,64px)] leading-none font-semibold">{t.sections[category].title}</h1>
      <p className="mt-4 max-w-prose text-lg text-muted">{t.sections[category].lede}</p>
      <div className="thread mt-6 w-40" aria-hidden="true" />

      <ul className="mt-10 grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-5 lg:grid-cols-4">
        {items.map((e) => {
          const text = e.text[lang]!.meta;
          const picto = e.media.pictogram ? g.media.get(e.media.pictogram) : undefined;
          return (
            <li key={e.id}>
              <Link
                href={entityHref(lang, e.category, e.slug)}
                className="group grid h-full gap-3 rounded-[var(--radius-arch)] border border-border bg-surface px-4 pt-8 pb-5 text-center text-text no-underline transition-shadow duration-200 hover:shadow-[var(--shadow-2)]"
              >
                {picto && <Image src={picto.file} width={56} height={56} alt="" className="mx-auto h-14 w-14 dark:invert" />}
                <span className="font-display text-2xl font-semibold">{text.name}</span>
                {e.names.greek && (
                  <span className="text-sm text-muted" lang="grc">
                    {e.names.greek}
                  </span>
                )}
                <span className="text-[15px] leading-snug text-muted">{text.role}</span>
              </Link>
            </li>
          );
        })}
        {planned.map((p) => (
          <li key={p.id} aria-label={`${p.name} (${t.entity.notYetWritten})`}>
            <div className="grid h-full content-center gap-2 rounded-[var(--radius-arch)] border border-dashed border-border px-4 pt-8 pb-5 text-center text-muted">
              <span className="font-display text-xl">{p.name}</span>
              <span className="text-xs tracking-[0.08em] uppercase">{t.entity.notYetWritten}</span>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
