import Link from "next/link";
import { getDictionary } from "@/lib/i18n";

export default function NotFound() {
  const t = getDictionary("fr");
  return (
    <div className="mx-auto grid max-w-2xl gap-4 px-4 py-24 text-center sm:px-8">
      <h1 className="font-display text-4xl font-semibold">{t.notFound.title}</h1>
      <p className="text-lg text-muted">{t.notFound.body}</p>
      <div className="thread mx-auto w-40" aria-hidden="true" />
      <Link href="/fr">{t.notFound.back}</Link>
    </div>
  );
}
