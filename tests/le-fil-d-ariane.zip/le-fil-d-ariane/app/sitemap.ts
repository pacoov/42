import type { MetadataRoute } from "next";
import { getGraph, publishedEntities } from "@/lib/content";
import { CATEGORIES, LOCALES } from "@/lib/content/schema";
import { entityHref, sectionHref } from "@/lib/i18n";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = process.env.SITE_URL ?? "http://localhost:3000";
  const g = getGraph();
  return LOCALES.flatMap((l) => [
    { url: `${base}/${l}` },
    ...CATEGORIES.map((c) => ({ url: `${base}${sectionHref(l, c)}` })),
    ...publishedEntities(g, l).map((e) => ({ url: `${base}${entityHref(l, e.category, e.slug)}`, lastModified: e.review.at })),
  ]);
}
