import localFont from "next/font/local";

// Polices auto-hébergées (licence SIL OFL), aucune requête vers un tiers.
export const fraunces = localFont({
  src: "../node_modules/@fontsource-variable/fraunces/files/fraunces-latin-full-normal.woff2",
  variable: "--font-fraunces",
  display: "swap",
  weight: "100 900",
});

export const inter = localFont({
  src: "../node_modules/@fontsource-variable/inter/files/inter-latin-wght-normal.woff2",
  variable: "--font-inter",
  display: "swap",
  weight: "100 900",
});

// Sous-ensemble grec séparé : les noms grecs (Μέδουσα) s'affichent sans police de secours.
export const interGreek = localFont({
  src: "../node_modules/@fontsource-variable/inter/files/inter-greek-wght-normal.woff2",
  variable: "--font-inter-greek",
  display: "swap",
  weight: "100 900",
  preload: false,
});

export const cinzel = localFont({
  src: "../node_modules/@fontsource/cinzel/files/cinzel-latin-600-normal.woff2",
  variable: "--font-cinzel",
  display: "swap",
  weight: "600",
  preload: false,
});
