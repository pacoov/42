import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { describe, expect, it } from "vitest";
import { ContentError, loadContent, neighbors, publishedEntities, slugify } from "@/lib/content/load";

const ROOT = path.join(__dirname, "../../content");

/** Copie le vrai contenu dans un dossier temporaire et applique une mutation. */
function mutated(mutate: (dir: string) => void): string {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "fil-"));
  fs.cpSync(ROOT, dir, { recursive: true });
  mutate(dir);
  return dir;
}

const MEDUSA = "entities/creatures/medusa.yaml";

describe("contenu réel", () => {
  it("se charge sans erreur", () => {
    const g = loadContent(ROOT);
    expect(g.entities.size).toBeGreaterThan(0);
  });
  it("calcule les relations inverses (Persée a vaincu Méduse → visible depuis Méduse)", () => {
    const g = loadContent(ROOT);
    const n = neighbors(g, "medusa").find((x) => x.other === "perseus" && x.relation.type === "defeated");
    expect(n?.direction).toBe("in");
  });
  it("publie Méduse sous le slug « meduse »", () => {
    const g = loadContent(ROOT);
    expect(publishedEntities(g, "fr", "creatures").map((e) => e.slug)).toContain("meduse");
  });
});

describe("le build échoue quand…", () => {
  it("une relation pointe vers une entité inconnue", () => {
    const dir = mutated((d) => {
      const f = path.join(d, MEDUSA);
      fs.writeFileSync(f, fs.readFileSync(f, "utf8").replace("to: pegasus", "to: pegasos"));
    });
    expect(() => loadContent(dir)).toThrow(/pegasos.*entité inconnue/);
  });
  it("un lien <E> du texte pointe vers une entité inconnue", () => {
    const dir = mutated((d) => {
      const f = path.join(d, "i18n/fr/entities/creatures/medusa.mdx");
      fs.writeFileSync(f, fs.readFileSync(f, "utf8").replace('<E id="hermes">', '<E id="hermès">'));
    });
    expect(() => loadContent(dir)).toThrow(ContentError);
  });
  it("une fiche n'a aucune source", () => {
    const dir = mutated((d) => {
      const f = path.join(d, MEDUSA);
      fs.writeFileSync(f, fs.readFileSync(f, "utf8").replace(/^sources:[\s\S]*?(?=^media:)/m, "sources: []\n"));
    });
    expect(() => loadContent(dir)).toThrow(/au moins une source/);
  });
  it("une image n'a pas été validée en galerie", () => {
    const dir = mutated((d) => {
      const f = path.join(d, "media/registry.yaml");
      fs.writeFileSync(f, fs.readFileSync(f, "utf8").replace("approvedInGallery: true", "approvedInGallery: false"));
    });
    expect(() => loadContent(dir)).toThrow(/galerie/);
  });
  it("une image utilisée est absente du registre", () => {
    const dir = mutated((d) => {
      const f = path.join(d, MEDUSA);
      fs.writeFileSync(f, fs.readFileSync(f, "utf8").replace("hero: medusa-pelike-polygnotos", "hero: image-inconnue"));
    });
    expect(() => loadContent(dir)).toThrow(/registre des médias/);
  });
  it("un type de relation n'est pas autorisé", () => {
    const dir = mutated((d) => {
      const f = path.join(d, MEDUSA);
      fs.writeFileSync(f, fs.readFileSync(f, "utf8").replace("type: defeated", "type: killed"));
    });
    expect(() => loadContent(dir)).toThrow(ContentError);
  });
});

describe("slugify", () => {
  it("retire accents et apostrophes", () => {
    expect(slugify("Méduse")).toBe("meduse");
    expect(slugify("Casque d'Hadès")).toBe("casque-d-hades");
    expect(slugify("Héraclès")).toBe("heracles");
  });
});
