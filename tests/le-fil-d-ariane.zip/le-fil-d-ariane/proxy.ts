import { NextResponse, type NextRequest } from "next/server";

// La racine redirige vers la langue par défaut (une seule langue publiée pour l'instant).
export function proxy(request: NextRequest) {
  return NextResponse.redirect(new URL("/fr", request.url));
}

export const config = { matcher: ["/"] };
